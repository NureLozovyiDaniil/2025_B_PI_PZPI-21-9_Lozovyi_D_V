package utils

import (
	"context"
	"os"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

type ContextKey string

const (
	RequestIDKey ContextKey = "request_id"

	UserIDKey ContextKey = "user_id"

	PollIDKey ContextKey = "poll_id"
)

type Logger struct {
	*zap.Logger
	sugar *zap.SugaredLogger
}

type Config struct {
	Level      string `json:"level"`
	Format     string `json:"format"`
	Output     string `json:"output"`
	FilePath   string `json:"file_path"`
	AddCaller  bool   `json:"add_caller"`
	Stacktrace bool   `json:"stacktrace"`
}

type FileWriter struct {
	Path string
	file *os.File
}

func (fw *FileWriter) Write(p []byte) (n int, err error) {
	if fw.file == nil {
		fw.file, err = os.OpenFile(fw.Path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
		if err != nil {
			return 0, err
		}
	}
	return fw.file.Write(p)
}

func NewLogger(config Config) (*Logger, error) {

	level := zap.InfoLevel
	switch config.Level {
	case "debug":
		level = zap.DebugLevel
	case "info":
		level = zap.InfoLevel
	case "warn":
		level = zap.WarnLevel
	case "error":
		level = zap.ErrorLevel
	}

	var encoderConfig zapcore.EncoderConfig
	var encoder zapcore.Encoder

	if config.Format == "json" {
		encoderConfig = zap.NewProductionEncoderConfig()
		encoderConfig.TimeKey = "timestamp"
		encoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
		encoder = zapcore.NewJSONEncoder(encoderConfig)
	} else {
		encoderConfig = zap.NewDevelopmentEncoderConfig()
		encoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
		encoder = zapcore.NewConsoleEncoder(encoderConfig)
	}

	var writeSyncer zapcore.WriteSyncer
	switch config.Output {
	case "file":
		writeSyncer = zapcore.AddSync(&FileWriter{Path: config.FilePath})
	case "both":
		fileWriter := zapcore.AddSync(&FileWriter{Path: config.FilePath})
		stdoutWriter := zapcore.AddSync(os.Stdout)
		writeSyncer = zapcore.NewMultiWriteSyncer(fileWriter, stdoutWriter)
	default:
		writeSyncer = zapcore.AddSync(os.Stdout)
	}

	core := zapcore.NewCore(encoder, writeSyncer, level)

	var opts []zap.Option
	if config.AddCaller {
		opts = append(opts, zap.AddCaller())
	}
	if config.Stacktrace {
		opts = append(opts, zap.AddStacktrace(zapcore.ErrorLevel))
	}

	logger := zap.New(core, opts...).With(
		zap.String("service", "poll-management"),
		zap.String("version", "1.0.0"),
	)

	return &Logger{
		Logger: logger,
		sugar:  logger.Sugar(),
	}, nil
}

func (l *Logger) WithContext(ctx context.Context) *zap.Logger {
	fields := []zap.Field{}

	if requestID := ctx.Value(RequestIDKey); requestID != nil {
		fields = append(fields, zap.String("request_id", requestID.(string)))
	}

	if userID := ctx.Value(UserIDKey); userID != nil {
		fields = append(fields, zap.Uint("user_id", userID.(uint)))
	}

	if pollID := ctx.Value(PollIDKey); pollID != nil {
		fields = append(fields, zap.Uint("poll_id", pollID.(uint)))
	}

	return l.Logger.With(fields...)
}

func WithRequestID(ctx context.Context, requestID string) context.Context {
	return context.WithValue(ctx, RequestIDKey, requestID)
}

func WithUserID(ctx context.Context, userID uint) context.Context {
	return context.WithValue(ctx, UserIDKey, userID)
}

func WithPollID(ctx context.Context, pollID uint) context.Context {
	return context.WithValue(ctx, PollIDKey, pollID)
}

func GetRequestID(ctx context.Context) string {
	if requestID := ctx.Value(RequestIDKey); requestID != nil {
		return requestID.(string)
	}
	return ""
}

func (l *Logger) LogPollOperation(ctx context.Context, operation string, pollID uint, userID uint, extra map[string]interface{}) {
	logger := l.WithContext(ctx)

	fields := []zap.Field{
		zap.String("operation", operation),
		zap.Uint("poll_id", pollID),
		zap.Uint("user_id", userID),
	}

	if extra != nil {
		for key, value := range extra {
			fields = append(fields, zap.Any(key, value))
		}
	}

	logger.Info("Poll operation executed", fields...)
}

func (l *Logger) LogVoteOperation(ctx context.Context, pollID uint, optionID uint, userID *uint, anonymousID *string) {
	logger := l.WithContext(ctx)

	fields := []zap.Field{
		zap.String("operation", "vote"),
		zap.Uint("poll_id", pollID),
		zap.Uint("option_id", optionID),
	}

	if userID != nil {
		fields = append(fields, zap.Uint("user_id", *userID))
	}

	if anonymousID != nil {
		fields = append(fields, zap.String("anonymous_id", *anonymousID))
	}

	logger.Info("Vote cast successfully", fields...)
}

func (l *Logger) LogBlockchainTransaction(ctx context.Context, txType string, txHash string, status string, extra map[string]interface{}) {
	logger := l.WithContext(ctx)

	fields := []zap.Field{
		zap.String("operation", "blockchain_transaction"),
		zap.String("tx_type", txType),
		zap.String("tx_hash", txHash),
		zap.String("tx_status", status),
	}

	if extra != nil {
		for key, value := range extra {
			fields = append(fields, zap.Any(key, value))
		}
	}

	if status == "failed" {
		logger.Error("Blockchain transaction failed", fields...)
	} else {
		logger.Info("Blockchain transaction processed", fields...)
	}
}

func (l *Logger) LogError(ctx context.Context, msg string, err error, extra map[string]interface{}) {
	logger := l.WithContext(ctx)

	fields := []zap.Field{zap.Error(err)}

	if extra != nil {
		for key, value := range extra {
			fields = append(fields, zap.Any(key, value))
		}
	}

	logger.Error(msg, fields...)
}

func (l *Logger) GinLogger() gin.HandlerFunc {
	return func(c *gin.Context) {

		requestID := c.GetHeader("X-Request-ID")
		if requestID == "" {
			requestID = uuid.New().String()
		}

		ctx := WithRequestID(c.Request.Context(), requestID)
		c.Request = c.Request.WithContext(ctx)

		c.Header("X-Request-ID", requestID)

		start := time.Now()
		path := c.Request.URL.Path
		raw := c.Request.URL.RawQuery

		c.Next()

		latency := time.Since(start)
		clientIP := c.ClientIP()
		method := c.Request.Method
		statusCode := c.Writer.Status()

		if raw != "" {
			path = path + "?" + raw
		}

		logger := l.WithContext(ctx)
		fields := []zap.Field{
			zap.String("method", method),
			zap.String("path", path),
			zap.Int("status_code", statusCode),
			zap.String("client_ip", clientIP),
			zap.Duration("latency", latency),
			zap.Int("body_size", c.Writer.Size()),
		}

		switch {
		case statusCode >= 500:
			logger.Error("HTTP request completed with server error", fields...)
		case statusCode >= 400:
			logger.Warn("HTTP request completed with client error", fields...)
		default:
			logger.Info("HTTP request completed successfully", fields...)
		}
	}
}

func RequestIDMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		requestID := c.GetHeader("X-Request-ID")
		if requestID == "" {
			requestID = uuid.New().String()
		}

		ctx := WithRequestID(c.Request.Context(), requestID)
		c.Request = c.Request.WithContext(ctx)
		c.Header("X-Request-ID", requestID)

		c.Next()
	}
}

func NewProductionLogger(filePath string) (*Logger, error) {
	return NewLogger(Config{
		Level:      "info",
		Format:     "json",
		Output:     "both",
		FilePath:   filePath,
		AddCaller:  false,
		Stacktrace: true,
	})
}

func NewDevelopmentLogger() (*Logger, error) {
	return NewLogger(Config{
		Level:      "debug",
		Format:     "console",
		Output:     "stdout",
		AddCaller:  true,
		Stacktrace: true,
	})
}

func DefaultConfig(debug bool) Config {
	if debug {
		return Config{
			Level:      "debug",
			Format:     "console",
			Output:     "stdout",
			AddCaller:  true,
			Stacktrace: true,
		}
	}

	return Config{
		Level:      "info",
		Format:     "json",
		Output:     "both",
		FilePath:   "/var/log/poll-service/app.log",
		AddCaller:  false,
		Stacktrace: true,
	}
}
