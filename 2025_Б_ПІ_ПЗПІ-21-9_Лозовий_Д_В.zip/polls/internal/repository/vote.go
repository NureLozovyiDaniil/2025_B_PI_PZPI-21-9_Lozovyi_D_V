package repository

import (
	"context"

	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

type voteRepository struct {
	db *gorm.DB
}

func NewVoteRepository(db *gorm.DB) VoteRepository {
	return &voteRepository{db: db}
}

func (r *voteRepository) Create(ctx context.Context, vote *model.Vote) error {
	return r.db.WithContext(ctx).Create(vote).Error
}

func (r *voteRepository) GetByPollID(ctx context.Context, pollID uint) ([]model.Vote, error) {
	var votes []model.Vote
	err := r.db.WithContext(ctx).
		Where("poll_id = ?", pollID).
		Order("timestamp DESC").
		Find(&votes).Error

	return votes, err
}

func (r *voteRepository) CountByPollID(ctx context.Context, pollID uint) (int, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Vote{}).
		Where("poll_id = ?", pollID).
		Count(&count).Error

	return int(count), err
}

func (r *voteRepository) CountByOptionID(ctx context.Context, optionID uint) (int, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Vote{}).
		Where("option_id = ?", optionID).
		Count(&count).Error

	return int(count), err
}

func (r *voteRepository) HasUserVoted(ctx context.Context, pollID, userID uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Vote{}).
		Where("poll_id = ? AND user_id = ?", pollID, userID).
		Count(&count).Error

	return count > 0, err
}

func (r *voteRepository) HasAnonymousVoted(ctx context.Context, pollID uint, anonymousID string) (bool, error) {

	return false, nil
}

func (r *voteRepository) GetVoteStatsByPoll(ctx context.Context, pollID uint) ([]model.OptionResult, error) {
	var results []model.OptionResult

	query := `
		SELECT 
			o.id as option_id,
			o.poll_id as poll_id,
			COALESCE(vote_counts.vote_count, 0) as vote_count,
			CASE 
				WHEN total_votes.total > 0 THEN 
					ROUND((COALESCE(vote_counts.vote_count, 0)::numeric / total_votes.total::numeric) * 100, 2)
				ELSE 0 
			END as percentage
		FROM options o
		LEFT JOIN (
			SELECT option_id, COUNT(*) as vote_count
			FROM votes 
			WHERE poll_id = ? AND deleted_at IS NULL
			GROUP BY option_id
		) vote_counts ON o.id = vote_counts.option_id
		CROSS JOIN (
			SELECT COUNT(*) as total
			FROM votes 
			WHERE poll_id = ? AND deleted_at IS NULL
		) total_votes
		WHERE o.poll_id = ? AND o.deleted_at IS NULL
		ORDER BY vote_count DESC, o.id ASC
	`

	err := r.db.WithContext(ctx).Raw(query, pollID, pollID, pollID).Scan(&results).Error
	if err != nil {
		return nil, err
	}

	return results, nil
}

func (r *voteRepository) SetBlockchainTx(ctx context.Context, id uint, txHash string) error {
	return r.db.WithContext(ctx).
		Model(&model.Vote{}).
		Where("id = ?", id).
		Update("blockchain_tx", txHash).Error
}

func (r *voteRepository) GetVotesByUser(ctx context.Context, userID uint, pagination model.Pagination) ([]model.Vote, model.PaginationResult, error) {
	query := r.db.WithContext(ctx).Where("user_id = ?", userID)

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("timestamp DESC")

	var votes []model.Vote
	err = query.Find(&votes).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return votes, paginationResult, nil
}

func (r *voteRepository) GetVoteByUserAndPoll(ctx context.Context, userID, pollID uint) (*model.Vote, error) {
	var vote model.Vote
	err := r.db.WithContext(ctx).
		Where("user_id = ? AND poll_id = ?", userID, pollID).
		First(&vote).Error

	if err != nil {
		return nil, err
	}

	return &vote, nil
}

func (r *voteRepository) DeleteVote(ctx context.Context, id uint) error {
	return r.db.WithContext(ctx).Delete(&model.Vote{}, id).Error
}

func (r *voteRepository) GetRecentVotes(ctx context.Context, limit int) ([]model.Vote, error) {
	var votes []model.Vote
	err := r.db.WithContext(ctx).
		Order("timestamp DESC").
		Limit(limit).
		Find(&votes).Error

	return votes, err
}
