package config

import (
	"fmt"
	"strings"
	"time"

	"github.com/spf13/viper"
)

type Config struct {
	Server     ServerConfig     `mapstructure:"server"`
	Database   DatabaseConfig   `mapstructure:"database"`
	JWT        JWTConfig        `mapstructure:"jwt"`
	Services   ServicesConfig   `mapstructure:"services"`
	Blockchain BlockchainConfig `mapstructure:"blockchain"`
	Cron       CronConfig       `mapstructure:"cron"`
}

type ServerConfig struct {
	Port         string        `mapstructure:"port"`
	Host         string        `mapstructure:"host"`
	ReadTimeout  time.Duration `mapstructure:"read_timeout"`
	WriteTimeout time.Duration `mapstructure:"write_timeout"`
	IdleTimeout  time.Duration `mapstructure:"idle_timeout"`
	Debug        bool          `mapstructure:"debug"`
}

type DatabaseConfig struct {
	Host            string        `mapstructure:"host"`
	Port            string        `mapstructure:"port"`
	User            string        `mapstructure:"user"`
	Password        string        `mapstructure:"password"`
	DBName          string        `mapstructure:"db_name"`
	SSLMode         string        `mapstructure:"ssl_mode"`
	MaxOpenConns    int           `mapstructure:"max_open_conns"`
	MaxIdleConns    int           `mapstructure:"max_idle_conns"`
	ConnMaxLifetime time.Duration `mapstructure:"conn_max_lifetime"`
}

type JWTConfig struct {
	SecretKey       string        `mapstructure:"secret_key"`
	TokenExpiration time.Duration `mapstructure:"token_expiration"`
	Issuer          string        `mapstructure:"issuer"`
}

type ServicesConfig struct {
	IdentityService   ServiceEndpoint `mapstructure:"identity_service"`
	BlockchainService ServiceEndpoint `mapstructure:"blockchain_service"`
	RequestTimeout    time.Duration   `mapstructure:"request_timeout"`
	RetryAttempts     int             `mapstructure:"retry_attempts"`
}

type ServiceEndpoint struct {
	URL    string `mapstructure:"url"`
	APIKey string `mapstructure:"api_key"`
}

type BlockchainConfig struct {
	NetworkName        string        `mapstructure:"network_name"`
	ChainID            int64         `mapstructure:"chain_id"`
	RetryAttempts      int           `mapstructure:"retry_attempts"`
	ConfirmBlocks      int           `mapstructure:"confirm_blocks"`
	TransactionTimeout time.Duration `mapstructure:"transaction_timeout"`
}

type CronConfig struct {
	PollFinalizerInterval     time.Duration `mapstructure:"poll_finalizer_interval"`
	BlockchainMonitorInterval time.Duration `mapstructure:"blockchain_monitor_interval"`
	EnableJobs                bool          `mapstructure:"enable_jobs"`
}

func Load() (*Config, error) {
	v := viper.New()

	v.SetConfigName("config")
	v.SetConfigType("yaml")
	v.AddConfigPath(".")
	v.AddConfigPath("./configs")
	v.AddConfigPath("internal/config")

	v.AutomaticEnv()
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	v.SetEnvPrefix("POLL")

	setDefaults(v)

	if err := v.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("error reading config file: %w", err)
		}

	}

	var config Config
	if err := v.Unmarshal(&config); err != nil {
		return nil, fmt.Errorf("unable to decode into config struct: %w", err)
	}

	if err := config.Validate(); err != nil {
		return nil, fmt.Errorf("config validation failed: %w", err)
	}

	return &config, nil
}

func setDefaults(v *viper.Viper) {

	v.SetDefault("server.port", "8080")
	v.SetDefault("server.host", "0.0.0.0")
	v.SetDefault("server.read_timeout", "10s")
	v.SetDefault("server.write_timeout", "10s")
	v.SetDefault("server.idle_timeout", "60s")
	v.SetDefault("server.debug", false)

	v.SetDefault("database.host", "localhost")
	v.SetDefault("database.port", "5432")
	v.SetDefault("database.user", "poll_user")
	v.SetDefault("database.db_name", "poll_management")
	v.SetDefault("database.ssl_mode", "disable")
	v.SetDefault("database.max_open_conns", 25)
	v.SetDefault("database.max_idle_conns", 5)
	v.SetDefault("database.conn_max_lifetime", "5m")

	v.SetDefault("jwt.token_expiration", "24h")
	v.SetDefault("jwt.issuer", "poll-management-service")

	v.SetDefault("services.identity_service.url", "http://localhost:8081")
	v.SetDefault("services.blockchain_service.url", "http://localhost:8083")
	v.SetDefault("services.verification_service.url", "http://localhost:8084")
	v.SetDefault("services.request_timeout", "30s")
	v.SetDefault("services.retry_attempts", 3)

	v.SetDefault("blockchain.network_name", "polygon-mumbai")
	v.SetDefault("blockchain.chain_id", 80001)
	v.SetDefault("blockchain.retry_attempts", 3)
	v.SetDefault("blockchain.confirm_blocks", 3)
	v.SetDefault("blockchain.transaction_timeout", "2m")

	v.SetDefault("cron.poll_finalizer_interval", "1m")
	v.SetDefault("cron.blockchain_monitor_interval", "30s")
	v.SetDefault("cron.enable_jobs", true)
}

func (c *Config) Validate() error {
	if c.Database.Password == "" {
		return fmt.Errorf("database.password is required (set POLL_DATABASE_PASSWORD)")
	}

	if c.JWT.SecretKey == "" {
		return fmt.Errorf("jwt.secret_key is required (set POLL_JWT_SECRET_KEY)")
	}

	if c.Services.IdentityService.URL == "" {
		return fmt.Errorf("services.identity_service.url is required")
	}

	if c.Services.BlockchainService.URL == "" {
		return fmt.Errorf("services.blockchain_service.url is required")
	}

	return nil
}

func (c *Config) GetDSN() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.Database.Host,
		c.Database.Port,
		c.Database.User,
		c.Database.Password,
		c.Database.DBName,
		c.Database.SSLMode,
	)
}
