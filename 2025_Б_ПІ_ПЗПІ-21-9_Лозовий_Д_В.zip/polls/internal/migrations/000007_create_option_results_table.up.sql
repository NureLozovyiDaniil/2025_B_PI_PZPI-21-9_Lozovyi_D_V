CREATE TABLE option_results (
                                id SERIAL PRIMARY KEY,
                                poll_id INTEGER NOT NULL,
                                option_id INTEGER NOT NULL,
                                vote_count INTEGER NOT NULL DEFAULT 0,
                                percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                                created_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- Foreign key constraints
                                CONSTRAINT fk_option_results_poll_id FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
                                CONSTRAINT fk_option_results_option_id FOREIGN KEY (option_id) REFERENCES options(id) ON DELETE CASCADE,

    -- Validation constraints
                                CONSTRAINT check_vote_count_positive CHECK (vote_count >= 0),
                                CONSTRAINT check_percentage_range CHECK (percentage >= 0.00 AND percentage <= 100.00),

    -- Prevent duplicate results for same option
                                CONSTRAINT unique_poll_option_result UNIQUE (poll_id, option_id)
);

CREATE INDEX idx_option_results_poll_id ON option_results(poll_id);
CREATE INDEX idx_option_results_option_id ON option_results(option_id);
CREATE INDEX idx_option_results_vote_count ON option_results(vote_count);
CREATE INDEX idx_option_results_percentage ON option_results(percentage);

CREATE INDEX idx_option_results_poll_vote_count ON option_results(poll_id, vote_count DESC);
