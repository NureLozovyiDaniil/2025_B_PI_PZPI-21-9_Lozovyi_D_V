CREATE TABLE votes (
                       id SERIAL PRIMARY KEY,
                       poll_id INTEGER NOT NULL,
                       option_id INTEGER NOT NULL,
                       user_id INTEGER,
                       anonymous_id VARCHAR(64),
                       zk_proof_hash VARCHAR(64),
                       blockchain_tx VARCHAR(66),
                       timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
                       created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                       deleted_at TIMESTAMP,

    -- Foreign key constraints
                       CONSTRAINT fk_votes_poll_id FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
                       CONSTRAINT fk_votes_option_id FOREIGN KEY (option_id) REFERENCES options(id) ON DELETE CASCADE,

    -- Business logic constraints
                       CONSTRAINT check_voter_identity CHECK (
                           (user_id IS NOT NULL AND anonymous_id IS NULL) OR
                           (user_id IS NULL AND anonymous_id IS NOT NULL)
                           ),
                       CONSTRAINT check_anonymous_requires_zkproof CHECK (
                           anonymous_id IS NULL OR
                           (anonymous_id IS NOT NULL AND zk_proof_hash IS NOT NULL)
                           ),

    -- Prevent duplicate votes
                       CONSTRAINT unique_user_poll UNIQUE (poll_id, user_id),
                       CONSTRAINT unique_anonymous_poll UNIQUE (poll_id, anonymous_id)
);

CREATE INDEX idx_votes_poll_id ON votes(poll_id);
CREATE INDEX idx_votes_option_id ON votes(option_id);
CREATE INDEX idx_votes_user_id ON votes(user_id);
CREATE INDEX idx_votes_anonymous_id ON votes(anonymous_id);
CREATE INDEX idx_votes_timestamp ON votes(timestamp);
CREATE INDEX idx_votes_blockchain_tx ON votes(blockchain_tx);
CREATE INDEX idx_votes_deleted_at ON votes(deleted_at);

CREATE INDEX idx_votes_poll_option ON votes(poll_id, option_id);
CREATE INDEX idx_votes_poll_timestamp ON votes(poll_id, timestamp);
