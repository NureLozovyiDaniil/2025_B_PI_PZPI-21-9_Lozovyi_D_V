package handler

import (
	"identity-api/internal/model"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (h *Handler) getAllRoles(c *gin.Context) {
	roles, err := h.services.Role.List(c.Request.Context())
	if err != nil {
		h.logger.Error("failed to get roles", zap.Error(err))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Failed to retrieve roles",
			},
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"data":    roles,
		"message": "Roles retrieved successfully",
	})
}

func (h *Handler) createRole(c *gin.Context) {
	var input model.RoleCreate
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid role creation request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	role, err := h.services.Role.Create(c.Request.Context(), input)
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role created successfully", zap.String("code", role.Code), zap.Uint("id", role.ID))

	c.JSON(http.StatusCreated, gin.H{
		"data":    role,
		"message": "Role created successfully",
	})
}

func (h *Handler) getRoleByID(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid role ID",
			},
		})
		return
	}

	role, err := h.services.Role.GetByID(c.Request.Context(), uint(id))
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"data":    role,
		"message": "Role retrieved successfully",
	})
}

func (h *Handler) updateRole(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid role ID",
			},
		})
		return
	}

	var input model.RoleUpdate
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid role update request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	role, err := h.services.Role.Update(c.Request.Context(), uint(id), input)
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role updated successfully", zap.Uint("id", uint(id)))

	c.JSON(http.StatusOK, gin.H{
		"data":    role,
		"message": "Role updated successfully",
	})
}

func (h *Handler) deleteRole(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid role ID",
			},
		})
		return
	}

	err = h.services.Role.Delete(c.Request.Context(), uint(id))
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role deleted successfully", zap.Uint("id", uint(id)))

	c.JSON(http.StatusOK, gin.H{
		"message": "Role deleted successfully",
	})
}

func (h *Handler) assignRole(c *gin.Context) {
	assignedBy := c.GetUint("userID")
	if assignedBy == 0 {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": gin.H{
				"code":    "ERR_UNAUTHORIZED",
				"message": "User not authenticated",
			},
		})
		return
	}

	var input model.UserRoleAssign
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid role assignment request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	err := h.services.Role.AssignRole(c.Request.Context(), input.UserID, input.RoleID, assignedBy, input.ExpiresAt)
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role assigned successfully",
		zap.Uint("user_id", input.UserID),
		zap.Uint("role_id", input.RoleID),
		zap.Uint("assigned_by", assignedBy))

	c.JSON(http.StatusCreated, gin.H{
		"message": "Role assigned successfully",
	})
}

func (h *Handler) revokeRole(c *gin.Context) {
	userIDStr := c.Param("user_id")
	roleIDStr := c.Param("role_id")

	userID, err := strconv.ParseUint(userIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	roleID, err := strconv.ParseUint(roleIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid role ID",
			},
		})
		return
	}

	err = h.services.Role.RevokeRole(c.Request.Context(), uint(userID), uint(roleID))
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role revoked successfully",
		zap.Uint("user_id", uint(userID)),
		zap.Uint("role_id", uint(roleID)))

	c.JSON(http.StatusOK, gin.H{
		"message": "Role revoked successfully",
	})
}

func (h *Handler) extendRoleExpiration(c *gin.Context) {
	userIDStr := c.Param("user_id")
	roleIDStr := c.Param("role_id")

	userID, err := strconv.ParseUint(userIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	roleID, err := strconv.ParseUint(roleIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid role ID",
			},
		})
		return
	}

	var input model.UserRoleExtend
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid role extension request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	err = h.services.Role.ExtendRoleExpiration(c.Request.Context(), uint(userID), uint(roleID), input.ExpiresAt)
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	h.logger.Info("role expiration extended successfully",
		zap.Uint("user_id", uint(userID)),
		zap.Uint("role_id", uint(roleID)),
		zap.Time("expires_at", input.ExpiresAt))

	c.JSON(http.StatusOK, gin.H{
		"message": "Role expiration extended successfully",
	})
}

func (h *Handler) getUserRoles(c *gin.Context) {
	userIDStr := c.Param("user_id")
	userID, err := strconv.ParseUint(userIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	roles, err := h.services.Role.GetUserRoles(c.Request.Context(), uint(userID))
	if err != nil {
		h.handleRoleError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"data":    roles,
		"message": "User roles retrieved successfully",
	})
}

func (h *Handler) handleRoleError(c *gin.Context, err error) {
	switch err {
	case model.ErrRoleNotFound:
		c.JSON(http.StatusNotFound, gin.H{
			"error": gin.H{
				"code":    "ERR_ROLE_NOT_FOUND",
				"message": "Role not found",
			},
		})
	case model.ErrRoleAlreadyExists:
		c.JSON(http.StatusConflict, gin.H{
			"error": gin.H{
				"code":    "ERR_ROLE_EXISTS",
				"message": "Role with this code already exists",
			},
		})
	case model.ErrUserNotFound:
		c.JSON(http.StatusNotFound, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_NOT_FOUND",
				"message": "User not found",
			},
		})
	case model.ErrInsufficientPermissions:
		c.JSON(http.StatusForbidden, gin.H{
			"error": gin.H{
				"code":    "ERR_INSUFFICIENT_PERMISSIONS",
				"message": "Insufficient permissions",
			},
		})
	default:
		h.logger.Error("role operation error", zap.Error(err))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Internal server error",
			},
		})
	}
}
