package service

import (
	"context"
	"errors"
	"identity-api/internal/config"
	"identity-api/internal/model"
	"identity-api/internal/repository"
	"identity-api/pkg/jwt"
	"identity-api/pkg/util"

	"go.uber.org/zap"
)

type AuthImpl struct {
	userRepo     repository.UserRepository
	userRoleRepo repository.UserRoleRepository
	jwtService   *jwt.Service
	logger       *zap.Logger
}

func NewAuthImpl(
	userRepo repository.UserRepository,
	userRoleRepo repository.UserRoleRepository,
	jwtConfig config.JWTConfig,
	logger *zap.Logger,
) *AuthImpl {
	jwtService := jwt.NewJWTService(jwtConfig.SecretKey, jwtConfig.Expiration)

	return &AuthImpl{
		userRepo:     userRepo,
		userRoleRepo: userRoleRepo,
		jwtService:   jwtService,
		logger:       logger,
	}
}

func (s *AuthImpl) Register(ctx context.Context, input model.UserCreate) (*model.User, error) {

	existingUser, _ := s.userRepo.GetByEmail(ctx, input.Email)
	if existingUser != nil {
		return nil, errors.New("user with this email already exists")
	}

	hashedPassword, err := util.HashPassword(input.Password)
	if err != nil {
		s.logger.Error("failed to hash password", zap.Error(err))
		return nil, errors.New("failed to process password")
	}

	user := &model.User{
		Email:        input.Email,
		PhoneNumber:  input.PhoneNumber,
		CountryCode:  input.CountryCode,
		PasswordHash: hashedPassword,
		Status:       "pending",
	}

	if err := s.userRepo.Create(ctx, user); err != nil {
		s.logger.Error("failed to create user during registration", zap.Error(err))
		return nil, errors.New("failed to create user")
	}

	s.logger.Info("user registered successfully",
		zap.Uint("user_id", user.ID),
		zap.String("email", user.Email))

	return user, nil
}

func (s *AuthImpl) Login(ctx context.Context, email, password string) (string, error) {

	user, err := s.userRepo.GetByEmail(ctx, email)
	if err != nil {
		s.logger.Warn("login attempt with non-existent email", zap.String("email", email))
		return "", errors.New("invalid credentials")
	}

	if err := util.CheckPassword(user.PasswordHash, password); err != nil {
		s.logger.Warn("login attempt with incorrect password",
			zap.Uint("user_id", user.ID),
			zap.String("email", email))
		return "", errors.New("invalid credentials")
	}

	if user.Status == "blocked" {
		s.logger.Warn("login attempt by blocked user",
			zap.Uint("user_id", user.ID),
			zap.String("email", email))
		return "", errors.New("account is blocked")
	}

	if user.Status == "inactive" {
		s.logger.Warn("login attempt by inactive user",
			zap.Uint("user_id", user.ID),
			zap.String("email", email))
		return "", errors.New("account is inactive")
	}

	roles, err := s.userRoleRepo.GetUserRoles(ctx, user.ID)
	if err != nil {
		s.logger.Error("failed to get user roles",
			zap.Error(err),
			zap.Uint("user_id", user.ID))
		return "", errors.New("failed to authenticate")
	}

	roleCodes := make([]string, len(roles))
	for i, role := range roles {
		roleCodes[i] = role.Code
	}

	if len(roleCodes) == 0 {
		roleCodes = []string{"user"}
	}

	token, err := s.jwtService.GenerateToken(user.ID, roleCodes)
	if err != nil {
		s.logger.Error("failed to generate JWT token",
			zap.Error(err),
			zap.Uint("user_id", user.ID))
		return "", errors.New("failed to generate token")
	}

	s.logger.Info("user logged in successfully",
		zap.Uint("user_id", user.ID),
		zap.String("email", email),
		zap.Strings("roles", roleCodes))

	return token, nil
}

func (s *AuthImpl) ParseToken(token string) (uint, []string, error) {
	userID, roles, err := s.jwtService.ParseToken(token)
	if err != nil {
		return 0, nil, err
	}

	return userID, roles, nil
}

func (s *AuthImpl) GenerateToken(userID uint, roles []string) (string, error) {
	return s.jwtService.GenerateToken(userID, roles)
}

func (s *AuthImpl) ValidateUser(ctx context.Context, userID uint) (*model.User, error) {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return nil, err
	}

	if user.Status == "blocked" {
		return nil, errors.New("account is blocked")
	}

	if user.Status == "inactive" {
		return nil, errors.New("account is inactive")
	}

	return user, nil
}

func (s *AuthImpl) RefreshUserRoles(ctx context.Context, userID uint) ([]string, error) {

	roles, err := s.userRoleRepo.GetUserRoles(ctx, userID)
	if err != nil {
		s.logger.Error("failed to refresh user roles",
			zap.Error(err),
			zap.Uint("user_id", userID))
		return nil, errors.New("failed to get user roles")
	}

	roleCodes := make([]string, len(roles))
	for i, role := range roles {
		roleCodes[i] = role.Code
	}

	if len(roleCodes) == 0 {
		roleCodes = []string{"user"}
	}

	return roleCodes, nil
}

func (s *AuthImpl) GenerateTokenForUser(ctx context.Context, userID uint) (string, error) {
	roleCodes, err := s.RefreshUserRoles(ctx, userID)
	if err != nil {
		return "", err
	}

	token, err := s.jwtService.GenerateToken(userID, roleCodes)
	if err != nil {
		s.logger.Error("failed to generate token for user",
			zap.Error(err),
			zap.Uint("user_id", userID))
		return "", errors.New("failed to generate token")
	}

	return token, nil
}
