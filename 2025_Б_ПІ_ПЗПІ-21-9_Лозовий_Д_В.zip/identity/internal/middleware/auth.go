package middleware

import (
	"identity-api/internal/service"
	"net/http"
	"strconv"
	"strings"

	"github.com/casbin/casbin/v2"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func Auth(authService service.AuthService) gin.HandlerFunc {
	return func(c *gin.Context) {

		header := c.GetHeader("Authorization")
		if header == "" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_MISSING_TOKEN",
					"message": "Authorization header is required",
				},
			})
			c.Abort()
			return
		}

		headerParts := strings.Split(header, " ")
		if len(headerParts) != 2 || headerParts[0] != "Bearer" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN_FORMAT",
					"message": "Invalid authorization header format",
				},
			})
			c.Abort()
			return
		}

		token := headerParts[1]

		userID, roles, err := authService.ParseToken(token)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN",
					"message": "Invalid or expired token",
				},
			})
			c.Abort()
			return
		}

		c.Set("userID", userID)
		c.Set("roles", roles)

		permissions := extractPermissionsFromRoles(roles)
		c.Set("permissions", permissions)

		c.Next()
	}
}

func InternalAPI(secretKey string) gin.HandlerFunc {
	return func(c *gin.Context) {
		apiKey := c.GetHeader("X-Internal-API-Key")
		if apiKey == secretKey {
			c.Next()
		} else {
			c.JSON(http.StatusUnauthorized, gin.H{})
		}
	}
}

func RequireRole(requiredRole string) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		hasRole := false
		for _, role := range rolesList {
			if role == requiredRole {
				hasRole = true
				break
			}
		}

		if !hasRole {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": "Required role not found",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func RequirePermission(enforcer *casbin.Enforcer, resource, action string) gin.HandlerFunc {
	return func(c *gin.Context) {
		userID, exists := c.Get("userID")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_NO_ROLES",
					"message": "User has no roles assigned",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		hasPermission := false
		for _, role := range rolesList {
			allowed, err := enforcer.Enforce(role, resource, action)
			if err != nil {

				continue
			}
			if allowed {
				hasPermission = true
				break
			}
		}

		if !hasPermission {
			userIDStr := userID.(uint)
			allowed, err := enforcer.Enforce(userIDStr, resource, action)
			if err == nil && allowed {
				hasPermission = true
			}
		}

		if !hasPermission {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_PERMISSIONS",
					"message": "Insufficient permissions for this action",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func RequireAnyRole(requiredRoles ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		hasRole := false
		for _, userRole := range rolesList {
			for _, requiredRole := range requiredRoles {
				if userRole == requiredRole {
					hasRole = true
					break
				}
			}
			if hasRole {
				break
			}
		}

		if !hasRole {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": "Required role not found",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func RequireSelfOrAdmin() gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetUint("userID")
		if userID == 0 {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		targetUserIDStr := c.Param("id")
		if targetUserIDStr == "" {

			c.Next()
			return
		}

		if targetUserIDStr == "me" || targetUserIDStr == strconv.Itoa(int(userID)) {
			c.Next()
			return
		}

		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_ACCESS_DENIED",
					"message": "Access denied",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		isAdmin := false
		for _, role := range rolesList {
			if role == "admin" || role == "super_admin" {
				isAdmin = true
				break
			}
		}

		if !isAdmin {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_ACCESS_DENIED",
					"message": "Access denied: admin role required",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func extractPermissionsFromRoles(roles []string) []string {

	permissionMap := map[string][]string{
		"admin":       {"users:read", "users:write", "users:delete", "roles:read", "roles:write", "roles:delete"},
		"moderator":   {"users:read", "users:write", "roles:read"},
		"user":        {"users:read"},
		"premium":     {"users:read", "polls:create_private"},
		"super_admin": {"*:*"},
	}

	var permissions []string
	permissionSet := make(map[string]bool)

	for _, role := range roles {
		if rolePermissions, exists := permissionMap[role]; exists {
			for _, permission := range rolePermissions {
				if !permissionSet[permission] {
					permissions = append(permissions, permission)
					permissionSet[permission] = true
				}
			}
		}
	}

	return permissions
}

func AuthWithLogger(authService service.AuthService, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {

		header := c.GetHeader("Authorization")
		if header == "" {
			logger.Warn("missing authorization header", zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_MISSING_TOKEN",
					"message": "Authorization header is required",
				},
			})
			c.Abort()
			return
		}

		headerParts := strings.Split(header, " ")
		if len(headerParts) != 2 || headerParts[0] != "Bearer" {
			logger.Warn("invalid token format", zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN_FORMAT",
					"message": "Invalid authorization header format",
				},
			})
			c.Abort()
			return
		}

		token := headerParts[1]
		userID, roles, err := authService.ParseToken(token)
		if err != nil {
			logger.Warn("invalid token", zap.Error(err), zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN",
					"message": "Invalid or expired token",
				},
			})
			c.Abort()
			return
		}

		if strings.Contains(c.FullPath(), "/roles") || strings.Contains(c.FullPath(), "/user-roles") {
			logger.Info("authenticated request",
				zap.Uint("user_id", userID),
				zap.Strings("roles", roles),
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))
		}

		c.Set("userID", userID)
		c.Set("roles", roles)
		c.Set("permissions", extractPermissionsFromRoles(roles))

		c.Next()
	}
}
