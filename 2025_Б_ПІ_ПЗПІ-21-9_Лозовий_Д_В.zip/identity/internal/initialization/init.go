package initialization

import (
	"context"
	"time"

	"identity-api/internal/model"
	"identity-api/internal/service"

	"github.com/casbin/casbin/v2"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

type DefaultRole struct {
	Code        string
	Name        string
	Description string
	Permissions []string
}

type SystemInitializer struct {
	logger *zap.Logger
}

func NewSystemInitializer(logger *zap.Logger) *SystemInitializer {
	return &SystemInitializer{
		logger: logger,
	}
}

func (si *SystemInitializer) InitializeDefaultRoles(ctx context.Context, roleService service.RoleService) error {
	si.logger.Info("Initializing default roles")

	defaultRoles := []DefaultRole{
		{
			Code:        "admin",
			Name:        "Administrator",
			Description: "System administrator with user and role management",
			Permissions: []string{
				"users:read", "users:write", "users:delete",
				"polls:read", "polls:write", "polls:delete",
				"user_roles:read", "user_roles:write", "user_roles:delete",
			},
		},
		{
			Code:        "premium",
			Name:        "Premium User",
			Description: "Premium user with additional features",
			Permissions: []string{
				"users:read",
				"polls:read", "polls:write", "polls:create_private",
				"analytics:read",
			},
		},
		{
			Code:        "user",
			Name:        "Regular User",
			Description: "Standard user with basic permissions",
			Permissions: []string{
				"users:read",
				"polls:read", "polls:write", "polls:participate",
			},
		},
	}

	for _, roleData := range defaultRoles {
		if err := si.createRoleIfNotExists(ctx, roleService, roleData); err != nil {
			si.logger.Error("Failed to create default role",
				zap.String("role_code", roleData.Code),
				zap.Error(err))
			continue
		}
	}

	si.logger.Info("Default roles initialization completed")
	return nil
}

func (si *SystemInitializer) createRoleIfNotExists(ctx context.Context, roleService service.RoleService, roleData DefaultRole) error {

	if _, err := roleService.GetByCode(ctx, roleData.Code); err == nil {
		si.logger.Debug("Role already exists, skipping", zap.String("role_code", roleData.Code))
		return nil
	}

	roleInput := model.RoleCreate{
		Code:        roleData.Code,
		Name:        roleData.Name,
		Description: roleData.Description,
		Permissions: si.permissionsToJSON(roleData.Permissions),
	}

	role, err := roleService.Create(ctx, roleInput)
	if err != nil {
		return err
	}

	si.logger.Info("Created default role",
		zap.String("role_code", role.Code),
		zap.String("role_name", role.Name),
		zap.Uint("role_id", role.ID))

	return nil
}

func (si *SystemInitializer) permissionsToJSON(permissions []string) string {

	result := "["
	for i, perm := range permissions {
		if i > 0 {
			result += ", "
		}
		result += `"` + perm + `"`
	}
	result += "]"
	return result
}

func SetupCasbin(modelPath, policyPath string) (*casbin.Enforcer, error) {
	enforcer, err := casbin.NewEnforcer(modelPath, policyPath)
	if err != nil {
		return nil, err
	}

	enforcer.EnableAutoSave(true)

	if err := enforcer.LoadPolicy(); err != nil {
		return nil, err
	}

	return enforcer, nil
}

func CheckDatabaseConnection(db *gorm.DB, logger *zap.Logger) error {
	const maxRetries = 3
	const retryDelay = 2 * time.Second

	for attempt := 1; attempt <= maxRetries; attempt++ {
		sqlDB, err := db.DB()
		if err != nil {
			return err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		err = sqlDB.PingContext(ctx)
		cancel()

		if err == nil {
			logger.Info("Database connection established", zap.Int("attempt", attempt))
			return nil
		}

		if attempt < maxRetries {
			logger.Warn("Database connection failed, retrying",
				zap.Int("attempt", attempt),
				zap.Int("max_retries", maxRetries),
				zap.Error(err))
			time.Sleep(retryDelay)
		} else {
			logger.Error("Database connection failed after all retries",
				zap.Int("attempts", maxRetries),
				zap.Error(err))
		}
	}

	return nil
}

type BackgroundTaskManager struct {
	logger   *zap.Logger
	services *service.Service
}

func NewBackgroundTaskManager(services *service.Service, logger *zap.Logger) *BackgroundTaskManager {
	return &BackgroundTaskManager{
		logger:   logger,
		services: services,
	}
}

func (btm *BackgroundTaskManager) StartBackgroundTasks(ctx context.Context) {
	btm.logger.Info("Starting background tasks")

	go btm.startExpiredRolesCleanup(ctx)

	go btm.startHealthMonitoring(ctx)

	go btm.startMetricsCollection(ctx)

	go btm.startDatabaseMonitoring(ctx)

	btm.logger.Info("All background tasks started successfully")
}

func (btm *BackgroundTaskManager) startExpiredRolesCleanup(ctx context.Context) {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	btm.logger.Info("Started expired roles cleanup task")

	for {
		select {
		case <-ctx.Done():
			btm.logger.Info("Stopping expired roles cleanup task")
			return
		case <-ticker.C:
			btm.logger.Debug("Running expired roles cleanup")

			if err := btm.services.Role.DeactivateExpiredRoles(context.Background()); err != nil {
				btm.logger.Error("Failed to deactivate expired roles", zap.Error(err))
			} else {
				btm.logger.Debug("Expired roles cleanup completed successfully")
			}
		}
	}
}

func (btm *BackgroundTaskManager) startHealthMonitoring(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	btm.logger.Info("Started health monitoring task")

	for {
		select {
		case <-ctx.Done():
			btm.logger.Info("Stopping health monitoring task")
			return
		case <-ticker.C:
			btm.performHealthCheck()
		}
	}
}

func (btm *BackgroundTaskManager) performHealthCheck() {
	btm.logger.Debug("Performing system health check")

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if _, err := btm.services.User.List(ctx, 0, 1); err != nil {
		btm.logger.Error("Health check failed: database connectivity issue", zap.Error(err))
		return
	}

	if _, err := btm.services.Role.List(ctx); err != nil {
		btm.logger.Error("Health check failed: role service issue", zap.Error(err))
		return
	}

	btm.logger.Debug("System health check passed")
}

func (btm *BackgroundTaskManager) startMetricsCollection(ctx context.Context) {
	ticker := time.NewTicker(15 * time.Minute)
	defer ticker.Stop()

	btm.logger.Info("Started metrics collection task")

	for {
		select {
		case <-ctx.Done():
			btm.logger.Info("Stopping metrics collection task")
			return
		case <-ticker.C:
			btm.collectMetrics()
		}
	}
}

func (btm *BackgroundTaskManager) collectMetrics() {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	btm.logger.Debug("Collecting system metrics")

	users, err := btm.services.User.List(ctx, 0, 1000)
	if err != nil {
		btm.logger.Error("Failed to collect user metrics", zap.Error(err))
		return
	}

	roles, err := btm.services.Role.List(ctx)
	if err != nil {
		btm.logger.Error("Failed to collect role metrics", zap.Error(err))
		return
	}

	btm.logger.Info("System metrics collected",
		zap.Int("total_users", len(users)),
		zap.Int("total_roles", len(roles)),
		zap.Time("collected_at", time.Now()))
}

func (btm *BackgroundTaskManager) startDatabaseMonitoring(ctx context.Context) {
	ticker := time.NewTicker(2 * time.Minute)
	defer ticker.Stop()

	btm.logger.Info("Started database monitoring task")

	for {
		select {
		case <-ctx.Done():
			btm.logger.Info("Stopping database monitoring task")
			return
		case <-ticker.C:
			btm.monitorDatabase()
		}
	}
}

func (btm *BackgroundTaskManager) monitorDatabase() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if _, err := btm.services.Role.List(ctx); err != nil {
		btm.logger.Error("Database monitoring alert: connection issue detected", zap.Error(err))
	} else {
		btm.logger.Debug("Database monitoring: connection healthy")
	}
}
