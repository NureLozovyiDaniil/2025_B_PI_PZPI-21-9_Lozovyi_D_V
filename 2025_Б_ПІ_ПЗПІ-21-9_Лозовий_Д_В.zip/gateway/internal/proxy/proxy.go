package proxy

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

type ProxyHandler struct {
	client *Client
	logger *zap.Logger
}

func NewProxyHandler(client *Client, logger *zap.Logger) *ProxyHandler {
	return &ProxyHandler{
		client: client,
		logger: logger,
	}
}

func (p *ProxyHandler) RouteToService(path string) (string, error) {

	normalizedPath := strings.TrimPrefix(path, "/")

	if strings.HasPrefix(normalizedPath, "health") ||
		strings.HasPrefix(normalizedPath, "ready") ||
		strings.HasPrefix(normalizedPath, "api/v1/health") {
		return "", fmt.Errorf("health endpoints should be handled locally")
	}

	if strings.HasPrefix(normalizedPath, "api/v1/") {

		identityPrefixes := []string{
			"api/v1/auth/",
			"api/v1/users/",
			"api/v1/roles/",
			"api/v1/user-roles/",
			"api/v1/admin/",
			"api/v1/system/",
		}

		for _, prefix := range identityPrefixes {
			if strings.HasPrefix(normalizedPath, prefix) {
				return "identity", nil
			}
		}

		pollPrefixes := []string{
			"api/v1/polls/",
			"api/v1/votes/",
			"api/v1/results/",
		}

		for _, prefix := range pollPrefixes {
			if strings.HasPrefix(normalizedPath, prefix) {
				return "poll", nil
			}
		}

		verificationPrefixes := []string{
			"api/v1/verification/",
			"api/v1/blind-signatures/",
			"api/v1/zkp/",
			"api/v1/trusted-parties/",
		}

		for _, prefix := range verificationPrefixes {
			if strings.HasPrefix(normalizedPath, prefix) {
				return "verification", nil
			}
		}

		blockchainPrefixes := []string{
			"api/v1/blockchain/",
			"api/v1/contracts/",
			"api/v1/transactions/",
		}

		for _, prefix := range blockchainPrefixes {
			if strings.HasPrefix(normalizedPath, prefix) {
				return "blockchain", nil
			}
		}
	}

	return "", fmt.Errorf("no service found for path: %s", path)
}

func (p *ProxyHandler) ProxyRequest(c *gin.Context) {
	start := time.Now()
	path := c.Request.URL.Path
	method := c.Request.Method

	requestID, exists := c.Get("requestID")
	if !exists {
		requestID = "unknown"
	}

	reqID := fmt.Sprintf("%v", requestID)

	serviceName, err := p.RouteToService(path)
	if err != nil {
		p.logger.Warn("failed to route request",
			zap.String("request_id", reqID),
			zap.String("path", path),
			zap.String("method", method),
			zap.Error(err))

		c.JSON(http.StatusNotFound, gin.H{
			"error": gin.H{
				"code":    "ERR_ROUTE_NOT_FOUND",
				"message": "Route not found",
			},
		})
		return
	}

	service, exists := p.client.GetService(serviceName)
	if !exists {
		p.logger.Error("service not configured",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.String("path", path))

		c.JSON(http.StatusServiceUnavailable, gin.H{
			"error": gin.H{
				"code":    "ERR_SERVICE_UNAVAILABLE",
				"message": "Service temporarily unavailable",
			},
		})
		return
	}

	if !service.IsHealthy() {
		p.logger.Warn("proxying to unhealthy service",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.String("path", path))
	}

	if p.shouldLogProxyRequest(path) {
		p.logger.Info("proxying request",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.String("method", method),
			zap.String("path", path),
			zap.String("client_ip", c.ClientIP()))
	}

	resp, err := p.client.ProxyRequest(serviceName, c.Request, reqID)
	if err != nil {
		p.logger.Error("proxy request failed",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.String("path", path),
			zap.Error(err))

		statusCode, errorResponse := p.handleProxyError(err)
		c.JSON(statusCode, errorResponse)
		return
	}
	defer resp.Body.Close()

	proxyDuration := time.Since(start)

	p.logger.Debug("proxy request completed",
		zap.String("request_id", reqID),
		zap.String("service", serviceName),
		zap.String("path", path),
		zap.Int("status", resp.StatusCode),
		zap.Duration("proxy_duration", proxyDuration))

	p.copyResponseHeaders(resp, c)

	c.Header("X-Proxy-Service", serviceName)
	c.Header("X-Proxy-Duration", proxyDuration.String())

	c.Status(resp.StatusCode)

	if _, err := io.Copy(c.Writer, resp.Body); err != nil {
		p.logger.Error("failed to copy response body",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.Error(err))

		return
	}

	if proxyDuration > 5*time.Second {
		p.logger.Warn("slow proxy request",
			zap.String("request_id", reqID),
			zap.String("service", serviceName),
			zap.String("path", path),
			zap.Duration("duration", proxyDuration))
	}
}

func (p *ProxyHandler) copyResponseHeaders(resp *http.Response, c *gin.Context) {

	headersToCopy := []string{
		"Content-Type",
		"Content-Length",
		"Content-Encoding",
		"Cache-Control",
		"Expires",
		"Last-Modified",
		"ETag",
		"Location",
		"Set-Cookie",
	}

	for _, header := range headersToCopy {
		if value := resp.Header.Get(header); value != "" {
			c.Header(header, value)
		}
	}

	for key, values := range resp.Header {
		if strings.HasPrefix(key, "X-") &&
			key != "X-Proxy-Service" &&
			key != "X-Proxy-Duration" {
			for _, value := range values {
				c.Header(key, value)
			}
		}
	}
}

func (p *ProxyHandler) handleProxyError(err error) (int, gin.H) {
	errorStr := err.Error()

	switch {
	case strings.Contains(errorStr, "connection refused"):
		return http.StatusServiceUnavailable, gin.H{
			"error": gin.H{
				"code":    "ERR_SERVICE_UNAVAILABLE",
				"message": "Backend service is currently unavailable",
			},
		}
	case strings.Contains(errorStr, "timeout"):
		return http.StatusGatewayTimeout, gin.H{
			"error": gin.H{
				"code":    "ERR_GATEWAY_TIMEOUT",
				"message": "Request timeout while communicating with backend service",
			},
		}
	case strings.Contains(errorStr, "no such host"):
		return http.StatusBadGateway, gin.H{
			"error": gin.H{
				"code":    "ERR_BAD_GATEWAY",
				"message": "Backend service configuration error",
			},
		}
	default:
		return http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_PROXY_FAILED",
				"message": "Internal proxy error",
			},
		}
	}
}

func (p *ProxyHandler) shouldLogProxyRequest(path string) bool {
	importantPaths := []string{
		"/api/v1/auth/login",
		"/api/v1/auth/register",
		"/api/v1/polls",
		"/api/v1/votes",
		"/api/v1/verification",
		"/api/v1/blockchain",
		"/api/v1/admin",
		"/api/v1/system",
		"/api/v1/user-roles",
	}

	for _, importantPath := range importantPaths {
		if strings.HasPrefix(path, importantPath) {
			return true
		}
	}
	return false
}

func (p *ProxyHandler) GetServicesStatus() gin.HandlerFunc {
	return func(c *gin.Context) {
		serviceHealth := p.client.GetServiceHealth()

		allHealthy := true
		for _, healthy := range serviceHealth {
			if !healthy {
				allHealthy = false
				break
			}
		}

		status := "healthy"
		httpStatus := http.StatusOK

		if !allHealthy {
			status = "degraded"
			httpStatus = http.StatusServiceUnavailable
		}

		c.JSON(httpStatus, gin.H{
			"status":    status,
			"timestamp": time.Now().Unix(),
			"services":  serviceHealth,
		})
	}
}

func (p *ProxyHandler) GetServiceMetrics() gin.HandlerFunc {
	return func(c *gin.Context) {

		serviceHealth := p.client.GetServiceHealth()

		metrics := gin.H{
			"timestamp": time.Now().Unix(),
			"services":  serviceHealth,
			"proxy": gin.H{
				"version": "1.0.0",
				"uptime":  time.Since(time.Now()).String(),
			},
		}

		c.JSON(http.StatusOK, gin.H{
			"data": metrics,
		})
	}
}
