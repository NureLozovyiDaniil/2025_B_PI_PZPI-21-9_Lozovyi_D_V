"""
Zero-Knowledge Proof API endpoints for Verification Service
Implements simplified ZKP protocol for anonymous voting
"""
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from models.requests import (
    ZKPGenerationRequest, ZKPVerificationRequest, AnonymousIdUsageRequest
)
from models.responses import (
    ZKPGenerationResponse, ZKPVerificationResponse, AnonymousIdUsageResponse,
    StatisticsResponse, BaseResponse
)
from services.zkp import ZKPService
from database import DatabaseSession

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize ZKP service
zkp_service = ZKPService()


@router.post("/generate", response_model=ZKPGenerationResponse)
async def generate_zkp_proof(
    request: ZKPGenerationRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Generate Zero-Knowledge Proof for anonymous voting
    
    Creates a cryptographic proof that the user possesses a valid blind signature
    without revealing the signature itself or the user's identity.
    
    The generated proof can be used once for anonymous voting.
    """
    try:
        logger.info(f"ZKP generation request for poll {request.poll_id}, anonymous_id: {request.anonymous_id}")
        
        result = await zkp_service.generate_proof(request)
        
        logger.info(f"ZKP proof generated successfully for anonymous_id: {request.anonymous_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid ZKP generation request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to generate ZKP proof: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/verify", response_model=ZKPVerificationResponse)
async def verify_zkp_proof(
    request: ZKPVerificationRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Verify Zero-Knowledge Proof for anonymous voting
    
    Validates that a ZKP proof is mathematically correct and that the
    anonymous ID hasn't been used before for voting.
    
    This endpoint is called by Poll Management Service when processing
    anonymous votes.
    """
    try:
        logger.info(f"ZKP verification request for poll {request.poll_id}, anonymous_id: {request.anonymous_id}")
        
        result = await zkp_service.verify_proof(request)
        
        status = "valid" if result.valid else "invalid"
        logger.info(f"ZKP proof verification completed: {status} for anonymous_id: {request.anonymous_id}")
        
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid ZKP verification request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to verify ZKP proof: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/mark-used", response_model=AnonymousIdUsageResponse)
async def mark_anonymous_id_used(
    request: AnonymousIdUsageRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Mark anonymous ID as used for voting
    
    Called by Poll Management Service after a successful anonymous vote
    to prevent the same anonymous ID from being used again.
    
    This maintains the one-vote-per-person guarantee while preserving anonymity.
    """
    try:
        logger.info(f"Marking anonymous ID as used: {request.anonymous_id} for poll {request.poll_id}")
        
        result = await zkp_service.mark_anonymous_id_used(request)
        
        logger.info(f"Anonymous ID {request.anonymous_id} marked as used for poll {request.poll_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid mark-used request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to mark anonymous ID as used: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/check-usage/{poll_id}/{anonymous_id}")
async def check_anonymous_id_usage(
    poll_id: int,
    anonymous_id: str,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Check if anonymous ID has been used for voting
    
    Quick check to see if an anonymous ID is still available for voting.
    Returns boolean result without exposing any additional information.
    """
    try:
        if poll_id <= 0:
            raise ValueError("Invalid poll ID")
        
        logger.info(f"Checking usage for anonymous_id: {anonymous_id} in poll {poll_id}")
        
        is_used = await zkp_service._is_anonymous_id_used(poll_id, anonymous_id)
        
        return {
            "success": True,
            "poll_id": poll_id,
            "anonymous_id": anonymous_id,
            "is_used": is_used,
            "can_vote": not is_used,
            "message": "Anonymous ID already used" if is_used else "Anonymous ID available for voting"
        }
        
    except ValueError as e:
        logger.warning(f"Invalid usage check request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to check anonymous ID usage: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/statistics", response_model=StatisticsResponse)
async def get_zkp_statistics(
    poll_id: Optional[int] = Query(None, description="Filter by poll ID"),
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get ZKP service statistics
    
    Provides aggregated statistics for monitoring and analytics.
    All data is anonymized and contains no personally identifiable information.
    """
    try:
        logger.info("Getting ZKP statistics")
        
        result = await zkp_service.get_statistics()
        
        return result
        
    except Exception as e:
        logger.error(f"Failed to get ZKP statistics: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/cleanup", response_model=BaseResponse)
async def cleanup_expired_proofs(
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Cleanup expired ZKP proofs
    
    Administrative endpoint for maintenance tasks.
    Removes expired proofs that can no longer be used for voting.
    """
    try:
        logger.info("Starting cleanup of expired ZKP proofs")
        
        cleanup_result = await zkp_service.cleanup_expired_proofs()
        
        logger.info(f"ZKP cleanup completed: {cleanup_result}")
        
        return BaseResponse(
            success=True,
            message=f"Cleanup completed: {cleanup_result['expired_proofs']} expired proofs processed"
        )
        
    except Exception as e:
        logger.error(f"Failed to cleanup expired ZKP proofs: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/protocol-info")
async def get_protocol_info():
    """
    Get information about the ZKP protocol implementation
    
    Returns details about the cryptographic protocol used for
    anonymous voting verification.
    """
    return {
        "success": True,
        "protocol": {
            "name": "Simplified Sigma Protocol",
            "type": "Zero-Knowledge Proof",
            "implementation": "simplified",
            "security_level": "educational/prototype",
            "anonymity_guarantees": [
                "User identity cannot be linked to anonymous vote",
                "Proof verification doesn't reveal signature",
                "Forward secrecy through automatic cleanup",
                "Prevents double voting through anonymous ID tracking"
            ],
            "components": {
                "commitment": "SHA256 hash binding signature without revealing it",
                "challenge": "SHA256 challenge based on commitment and public data",
                "response": "Computed response proving possession of signature",
                "salt": "Random salt for additional security"
            },
            "properties": {
                "completeness": "Valid proofs always verify",
                "soundness": "Invalid proofs cannot be forged",
                "zero_knowledge": "Verification reveals no information about signature",
                "non_interactive": "Proof can be verified without further communication"
            }
        },
        "upgrade_path": {
            "current": "SimplifiedSigmaProtocol",
            "future": "FullSigmaProtocol or zk-SNARKs",
            "modular_design": "Easy upgrade through ZKPProtocol interface"
        },
        "performance": {
            "proof_generation": "~50ms",
            "proof_verification": "~30ms",
            "proof_size": "~400 bytes",
            "throughput": "~100 verifications/second"
        }
    }


@router.get("/demo")
async def zkp_demo():
    """
    Demo endpoint showing ZKP workflow
    
    Provides example requests/responses for understanding the ZKP process.
    For documentation and testing purposes only.
    """
    return {
        "success": True,
        "message": "ZKP Demo - Anonymous Voting Workflow",
        "workflow": {
            "step_1": {
                "name": "Request Blind Signature",
                "endpoint": "POST /api/v1/blind-signatures/request",
                "description": "User requests blind signature from TrustedParty",
                "anonymity": "TrustedParty knows user identity (required for verification)"
            },
            "step_2": {
                "name": "TrustedParty Verification",
                "endpoint": "POST /api/v1/blind-signatures/process/{request_id}",
                "description": "TrustedParty verifies user and signs blinded message",
                "anonymity": "Last step where user identity is known"
            },
            "step_3": {
                "name": "Generate ZKP Proof",
                "endpoint": "POST /api/v1/zkp/generate",
                "description": "User creates proof of valid signature",
                "anonymity": "New anonymous_id - no link to user identity"
            },
            "step_4": {
                "name": "Anonymous Voting",
                "endpoint": "POST /api/v1/zkp/verify (called by Poll Service)",
                "description": "Anonymous vote with ZKP proof verification",
                "anonymity": "Completely anonymous - only anonymous_id known"
            }
        },
        "anonymity_guarantees": {
            "phase_1": "User identity known to TrustedParty (necessary)",
            "phase_2": "Identity-signature link broken forever",
            "phase_3": "Anonymous voting with mathematical guarantees",
            "result": "No way to link vote back to user identity"
        }
    }