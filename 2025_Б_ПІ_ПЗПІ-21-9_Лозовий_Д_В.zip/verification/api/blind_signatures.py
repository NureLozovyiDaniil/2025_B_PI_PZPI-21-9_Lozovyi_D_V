"""
Blind Signatures API endpoints for Verification Service
Handles anonymous verification through RSA blind signatures
"""
import logging
from typing import List

from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from models.requests import (
    BlindSignatureRequest, ProcessSignatureRequest, TrustedPartyKeyRequest,
    BatchPublicKeysRequest
)
from models.responses import (
    BlindSignatureResponse, SignatureResultResponse, PendingSignaturesResponse,
    BatchPublicKeysResponse, TrustedPartyKey, BaseResponse
)
from services.blind_signature import BlindSignatureService
from database import DatabaseSession

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize service
blind_signature_service = BlindSignatureService()


@router.post("/request", response_model=BlindSignatureResponse)
async def request_blind_signature(
    request: BlindSignatureRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Request a blind signature from a TrustedParty
    
    The TrustedParty will know the requester's identity for verification purposes,
    but this knowledge cannot be linked to the final anonymous vote.
    """
    try:
        logger.info(f"Blind signature request from user {request.requester_id} for poll {request.poll_id}")
        
        result = await blind_signature_service.request_blind_signature(request)
        
        logger.info(f"Blind signature request created: {result.request_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid blind signature request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to create blind signature request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/pending/{trusted_party_id}", response_model=PendingSignaturesResponse)
async def get_pending_requests(
    trusted_party_id: int,
    poll_id: int = Query(None, description="Filter by poll ID"),
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get pending blind signature requests for a TrustedParty
    
    Used by TrustedParty to see which users need verification.
    The TrustedParty will see requester IDs to verify their identity.
    """
    try:
        if trusted_party_id <= 0:
            raise ValueError("Invalid trusted party ID")
        
        logger.info(f"Getting pending requests for trusted party {trusted_party_id}")
        
        result = await blind_signature_service.get_pending_requests(
            trusted_party_id=trusted_party_id,
            poll_id=poll_id
        )
        
        logger.info(f"Found {result.total_count} pending requests for trusted party {trusted_party_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid request for pending signatures: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to get pending requests: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/process/{request_id}", response_model=SignatureResultResponse)
async def process_signature_request(
    request_id: int,
    trusted_party_id: int,
    decision: ProcessSignatureRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Process a blind signature request (approve or reject)
    
    TrustedParty reviews the user's identity documents and decides
    whether to provide a blind signature for anonymous voting.
    """
    try:
        if request_id <= 0 or trusted_party_id <= 0:
            raise ValueError("Invalid request ID or trusted party ID")
        
        logger.info(f"Processing signature request {request_id} by trusted party {trusted_party_id}")
        
        result = await blind_signature_service.process_signature_request(
            request_id=request_id,
            trusted_party_id=trusted_party_id,
            decision=decision
        )
        
        status = "approved" if decision.approved else "rejected"
        logger.info(f"Signature request {request_id} {status} by trusted party {trusted_party_id}")
        
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid signature processing request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to process signature request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/result/{request_id}", response_model=SignatureResultResponse)
async def get_signature_result(
    request_id: int,
    requester_id: int = Query(..., description="User ID who made the request"),
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get the result of a blind signature request
    
    User checks if their blind signature request has been processed.
    This is the last step where the user's identity is involved.
    """
    try:
        if request_id <= 0 or requester_id <= 0:
            raise ValueError("Invalid request ID or requester ID")
        
        logger.info(f"Getting signature result for request {request_id} by user {requester_id}")
        
        result = await blind_signature_service.get_signature_result(
            request_id=request_id,
            requester_id=requester_id
        )
        
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid signature result request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to get signature result: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/public-key/{trusted_party_id}", response_model=TrustedPartyKey)
async def get_trusted_party_public_key(
    trusted_party_id: int,
    poll_id: int = Query(..., description="Poll ID"),
    force_refresh: bool = Query(False, description="Force refresh from Poll Management Service"),
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get public key for a TrustedParty
    
    Used for verifying blind signatures and ZKP proofs.
    Public keys can be cached for performance.
    """
    try:
        if trusted_party_id <= 0 or poll_id <= 0:
            raise ValueError("Invalid trusted party ID or poll ID")
        
        logger.info(f"Getting public key for trusted party {trusted_party_id}, poll {poll_id}")
        
        # Get public key from service
        public_key_pem = await blind_signature_service.get_trusted_party_public_key(
            trusted_party_id=trusted_party_id,
            poll_id=poll_id
        )
        
        from utils.crypto import calculate_data_hash
        from datetime import datetime
        
        key_hash = calculate_data_hash(public_key_pem)
        
        return TrustedPartyKey(
            trusted_party_id=trusted_party_id,
            poll_id=poll_id,
            public_key=public_key_pem,
            key_hash=key_hash,
            fetched_at=datetime.utcnow()
        )
        
    except ValueError as e:
        logger.warning(f"Invalid public key request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to get public key: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/public-keys/batch", response_model=BatchPublicKeysResponse)
async def get_batch_public_keys(
    request: BatchPublicKeysRequest,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get public keys for multiple TrustedParties (batch operation)
    
    Optimizes performance when multiple keys are needed for ZKP verification.
    """
    try:
        logger.info(f"Batch public key request for {len(request.trusted_party_ids)} trusted parties")
        
        keys = []
        cache_hits = 0
        api_calls = 0
        
        for tp_id in request.trusted_party_ids:
            try:
                public_key_pem = await blind_signature_service.get_trusted_party_public_key(
                    trusted_party_id=tp_id,
                    poll_id=request.poll_id
                )
                
                from utils.crypto import calculate_data_hash
                from datetime import datetime
                
                key_hash = calculate_data_hash(public_key_pem)
                
                keys.append(TrustedPartyKey(
                    trusted_party_id=tp_id,
                    poll_id=request.poll_id,
                    public_key=public_key_pem,
                    key_hash=key_hash,
                    fetched_at=datetime.utcnow()
                ))
                
                api_calls += 1
                
            except Exception as e:
                logger.warning(f"Failed to get public key for trusted party {tp_id}: {e}")
                continue
        
        return BatchPublicKeysResponse(
            success=True,
            message=f"Retrieved {len(keys)} public keys",
            keys=keys,
            poll_id=request.poll_id,
            cache_hits=cache_hits,
            api_calls=api_calls
        )
        
    except Exception as e:
        logger.error(f"Failed batch public key request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/cleanup", response_model=BaseResponse)
async def cleanup_expired_signatures(
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Cleanup expired blind signature requests
    
    Administrative endpoint for maintenance tasks.
    Should be called periodically by background jobs.
    """
    try:
        logger.info("Starting cleanup of expired blind signature requests")
        
        cleanup_result = await blind_signature_service.cleanup_expired_requests()
        
        logger.info(f"Cleanup completed: {cleanup_result}")
        
        return BaseResponse(
            success=True,
            message=f"Cleanup completed: {cleanup_result['expired_requests']} expired requests processed"
        )
        
    except Exception as e:
        logger.error(f"Failed to cleanup expired signatures: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/statistics")
async def get_blind_signature_statistics():
    """
    Get statistics about blind signature operations
    
    Provides insights for monitoring and analytics.
    No personally identifiable information is exposed.
    """
    try:
        from database import get_database_statistics
        
        db_stats = await get_database_statistics()
        
        return {
            "success": True,
            "message": "Statistics retrieved successfully",
            "data": {
                "total_requests": db_stats.get("blind_signatures_total", 0),
                "pending_requests": db_stats.get("blind_signatures_pending", 0),
                "completed_requests": db_stats.get("blind_signatures_total", 0) - db_stats.get("blind_signatures_pending", 0),
                "cached_keys": db_stats.get("cached_keys_total", 0)
            },
            "anonymity_note": "All statistics are aggregated and contain no personally identifiable information"
        }
        
    except Exception as e:
        logger.error(f"Failed to get blind signature statistics: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")