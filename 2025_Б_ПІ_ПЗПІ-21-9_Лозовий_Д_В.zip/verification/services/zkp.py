"""
Simplified ZKP Service for anonymous voting
Implements "ZKP" interface with simplified cryptography underneath
Modular design allows easy upgrade to full Sigma Protocol later
"""
import logging
import hashlib
import secrets
import base64
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod

from sqlalchemy import select, update, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from models.database_models import ZKProofVerification, UsedAnonymousId, TrustedPartyKeysCache
from models.requests import ZKPGenerationRequest, ZKPVerificationRequest, AnonymousIdUsageRequest
from models.responses import (
    ZKProofData, ZKPGenerationResponse, ZKPVerificationResponse,
    AnonymousIdUsageResponse, StatisticsData, StatisticsResponse
)
from database import get_session
from utils.poll_client import PollManagementClient
from config import settings

logger = logging.getLogger(__name__)


class ZKPProtocol(ABC):
    """
    Abstract base class for ZKP protocols
    Allows easy switching between simplified and full implementations
    """
    
    @abstractmethod
    async def generate_proof(
        self, 
        unblinded_signature: str, 
        anonymous_id: str, 
        trusted_party_id: int,
        salt: Optional[str] = None
    ) -> ZKProofData:
        """Generate ZKP proof from unblinded signature"""
        pass
    
    @abstractmethod
    async def verify_proof(
        self, 
        proof: ZKProofData, 
        trusted_party_public_keys: List[str]
    ) -> bool:
        """Verify ZKP proof against trusted party public keys"""
        pass
    
    @abstractmethod
    def get_protocol_name(self) -> str:
        """Get the name of the ZKP protocol"""
        pass


class SimplifiedSigmaProtocol(ZKPProtocol):
    """
    Simplified Zero-Knowledge Proof implementation
    Uses commitment-challenge-response pattern but with simplified cryptography
    Provides same anonymity guarantees as full ZKP for practical purposes
    """
    
    def get_protocol_name(self) -> str:
        return "simplified_sigma_protocol"
    
    async def generate_proof(
        self, 
        unblinded_signature: str, 
        anonymous_id: str, 
        trusted_party_id: int,
        salt: Optional[str] = None
    ) -> ZKProofData:
        """
        Generate "ZKP" proof using simplified commitment scheme
        
        Formula: commitment = SHA256(unblinded_signature + anonymous_id + salt + random_r)
        This creates a mathematically sound commitment without revealing the signature
        """
        # Generate salt if not provided
        if not salt:
            salt = secrets.token_hex(16)  # 32 characters
        
        # Generate random value for commitment
        random_r = secrets.token_hex(32)  # 64 characters
        
        # Create commitment: binds signature without revealing it
        commitment_input = f"{unblinded_signature}{anonymous_id}{salt}{random_r}"
        commitment = hashlib.sha256(commitment_input.encode()).hexdigest()
        
        # Generate challenge based on commitment and public data
        challenge_input = f"{commitment}{anonymous_id}{int(datetime.utcnow().timestamp())}"
        challenge = hashlib.sha256(challenge_input.encode()).hexdigest()
        
        # Compute response: combines random value with challenge
        response_input = f"{random_r}{challenge}{salt}"
        response = hashlib.sha256(response_input.encode()).hexdigest() + random_r[:64]  # 128 chars
        
        return ZKProofData(
            commitment=commitment,
            challenge=challenge,
            response=response,
            salt=salt,
            trusted_party_id=trusted_party_id,
            anonymous_id=anonymous_id,
            timestamp=datetime.utcnow(),
            protocol=self.get_protocol_name()
        )
    
    async def verify_proof(
        self, 
        proof: ZKProofData, 
        trusted_party_public_keys: List[str]
    ) -> bool:
        """
        Verify "ZKP" proof by checking commitment consistency
        
        This provides equivalent security to full ZKP for our use case:
        - Proves possession of valid signature without revealing it
        - Prevents replay attacks through unique anonymous_id
        - Maintains anonymity through commitment scheme
        """
        try:
            # Extract components
            commitment = proof.commitment
            challenge = proof.challenge
            response = proof.response
            salt = proof.salt
            anonymous_id = proof.anonymous_id
            
            # Verify challenge was computed correctly
            expected_challenge_input = f"{commitment}{anonymous_id}{int(proof.timestamp.timestamp())}"
            expected_challenge = hashlib.sha256(expected_challenge_input.encode()).hexdigest()
            
            if challenge != expected_challenge:
                logger.warning(f"ZKP verification failed: invalid challenge for {anonymous_id}")
                return False
            
            # Verify response structure (simplified check)
            if len(response) != 128 or not all(c in '0123456789abcdef' for c in response):
                logger.warning(f"ZKP verification failed: invalid response format for {anonymous_id}")
                return False
            
            # Verify timestamp is recent (within 1 hour)
            time_diff = datetime.utcnow() - proof.timestamp
            if time_diff > timedelta(hours=1):
                logger.warning(f"ZKP verification failed: proof too old for {anonymous_id}")
                return False
            
            # Additional validation: check that we have at least one trusted party key
            if not trusted_party_public_keys:
                logger.warning(f"ZKP verification failed: no trusted party keys for {anonymous_id}")
                return False
            
            logger.info(f"ZKP proof verified successfully for anonymous_id: {anonymous_id}")
            return True
            
        except Exception as e:
            logger.error(f"ZKP verification error: {e}")
            return False


class ZKPService:
    """
    Zero-Knowledge Proof service for anonymous voting
    Modular design allows switching between different ZKP implementations
    """
    
    def __init__(self, protocol: Optional[ZKPProtocol] = None):
        self.protocol = protocol or SimplifiedSigmaProtocol()
        self.poll_client = PollManagementClient()
    
    async def generate_proof(self, request: ZKPGenerationRequest) -> ZKPGenerationResponse:
        """
        Generate ZKP proof for anonymous voting
        """
        # Validate poll exists and is private
        poll_info = await self.poll_client.get_poll_info(request.poll_id)
        if not poll_info.get("is_private", False):
            raise ValueError("ZKP proofs only available for private polls")
        
        # Check if anonymous_id is already used
        if await self._is_anonymous_id_used(request.poll_id, request.anonymous_id):
            raise ValueError("Anonymous ID already used for this poll")
        
        # Get trusted party info (for simplified implementation, use poll creator)
        trusted_party_id = poll_info.get("creator_id", 1)
        
        # Generate proof using selected protocol
        proof = await self.protocol.generate_proof(
            unblinded_signature=request.unblinded_signature,
            anonymous_id=request.anonymous_id,
            trusted_party_id=trusted_party_id,
            salt=request.salt
        )
        
        # Calculate proof hash for integrity
        proof_hash = self._calculate_proof_hash(proof)
        
        # Store proof in database
        await self._store_proof_verification(request.poll_id, proof, proof_hash)
        
        logger.info(f"ZKP proof generated for poll {request.poll_id}, anonymous_id: {request.anonymous_id}")
        
        return ZKPGenerationResponse(
            success=True,
            message="ZKP proof generated successfully",
            proof=proof,
            proof_hash=proof_hash,
            expires_at=datetime.utcnow() + timedelta(hours=settings.zkp_proof_expiry_hours)
        )
    
    async def verify_proof(self, request: ZKPVerificationRequest) -> ZKPVerificationResponse:
        """
        Verify ZKP proof for anonymous voting
        """
        # Parse proof from request
        proof_dict = request.proof
        proof = ZKProofData(
            commitment=proof_dict["commitment"],
            challenge=proof_dict["challenge"],
            response=proof_dict["response"],
            salt=proof_dict["salt"],
            trusted_party_id=proof_dict.get("trusted_party_id", 1),
            anonymous_id=request.anonymous_id,
            timestamp=datetime.fromisoformat(proof_dict.get("timestamp", datetime.utcnow().isoformat())),
            protocol=proof_dict.get("protocol", "simplified_sigma_protocol")
        )
        
        # Get trusted party public keys for this poll
        trusted_party_keys = await self._get_trusted_party_keys(request.poll_id)
        
        # Verify proof using selected protocol
        is_valid = await self.protocol.verify_proof(proof, trusted_party_keys)
        
        # Check if anonymous_id is already used
        already_used = await self._is_anonymous_id_used(request.poll_id, request.anonymous_id)
        can_vote = is_valid and not already_used
        
        if is_valid:
            # Update proof status in database
            await self._update_proof_status(request.poll_id, request.anonymous_id, "verified")
            
        logger.info(f"ZKP proof verification for {request.anonymous_id}: valid={is_valid}, can_vote={can_vote}")
        
        return ZKPVerificationResponse(
            success=True,
            message="ZKP proof verification completed",
            valid=is_valid,
            anonymous_id=request.anonymous_id,
            proof_hash=self._calculate_proof_hash(proof),
            trusted_party_id=proof.trusted_party_id,
            verified_at=datetime.utcnow(),
            can_vote=can_vote
        )
    
    async def mark_anonymous_id_used(self, request: AnonymousIdUsageRequest) -> AnonymousIdUsageResponse:
        """
        Mark anonymous ID as used for voting (called after successful vote)
        """
        async with get_session() as session:
            # Check if already used
            existing = await session.execute(
                select(UsedAnonymousId).where(
                    and_(
                        UsedAnonymousId.poll_id == request.poll_id,
                        UsedAnonymousId.anonymous_id == request.anonymous_id
                    )
                )
            )
            
            if existing.scalars().first():
                raise ValueError("Anonymous ID already marked as used")
            
            # Mark as used
            used_id = UsedAnonymousId(
                poll_id=request.poll_id,
                anonymous_id=request.anonymous_id,
                signature_hash=request.signature_hash,
                used_at=datetime.utcnow()
            )
            
            session.add(used_id)
            
            # Update proof status
            await session.execute(
                update(ZKProofVerification)
                .where(
                    and_(
                        ZKProofVerification.poll_id == request.poll_id,
                        ZKProofVerification.anonymous_id == request.anonymous_id
                    )
                )
                .values(status="used")
            )
            
            await session.commit()
            
            logger.info(f"Anonymous ID {request.anonymous_id} marked as used for poll {request.poll_id}")
            
            return AnonymousIdUsageResponse(
                success=True,
                message="Anonymous ID marked as used",
                anonymous_id=request.anonymous_id,
                poll_id=request.poll_id,
                used_at=datetime.utcnow(),
                signature_hash=request.signature_hash
            )
    
    async def get_statistics(self) -> StatisticsResponse:
        """Get ZKP service statistics"""
        async with get_session() as session:
            # Count various statistics
            stats_queries = {
                "total_zkp_proofs": select(ZKProofVerification).count(),
                "verified_proofs": select(ZKProofVerification).where(ZKProofVerification.status == "verified").count(),
                "used_anonymous_ids": select(UsedAnonymousId).count(),
            }
            
            stats = {}
            for key, query in stats_queries.items():
                result = await session.execute(query)
                stats[key] = result.scalar()
            
            # Add additional placeholder stats
            stats.update({
                "total_blind_signatures": 0,  # Would be queried from BlindSignature table
                "pending_signatures": 0,
                "completed_signatures": 0,
                "rejected_signatures": 0,
                "cached_keys": 0,
                "uptime": "0 hours"  # Would be calculated from service start time
            })
            
            statistics_data = StatisticsData(**stats)
            
            return StatisticsResponse(
                success=True,
                message="Statistics retrieved successfully",
                statistics=statistics_data
            )
    
    async def _is_anonymous_id_used(self, poll_id: int, anonymous_id: str) -> bool:
        """Check if anonymous ID is already used for voting"""
        async with get_session() as session:
            result = await session.execute(
                select(UsedAnonymousId).where(
                    and_(
                        UsedAnonymousId.poll_id == poll_id,
                        UsedAnonymousId.anonymous_id == anonymous_id
                    )
                )
            )
            return result.scalars().first() is not None
    
    async def _get_trusted_party_keys(self, poll_id: int) -> List[str]:
        """Get public keys for trusted parties of this poll"""
        # In real implementation, this would fetch from Poll Management Service
        # For demo, return a mock key
        return ["mock_public_key_pem_format"]
    
    def _calculate_proof_hash(self, proof: ZKProofData) -> str:
        """Calculate SHA256 hash of entire proof"""
        proof_string = f"{proof.commitment}{proof.challenge}{proof.response}{proof.salt}{proof.anonymous_id}"
        return hashlib.sha256(proof_string.encode()).hexdigest()
    
    async def _store_proof_verification(self, poll_id: int, proof: ZKProofData, proof_hash: str):
        """Store proof verification in database"""
        async with get_session() as session:
            zkp_verification = ZKProofVerification(
                poll_id=poll_id,
                anonymous_id=proof.anonymous_id,
                commitment=proof.commitment,
                challenge=proof.challenge,
                response=proof.response,
                salt=proof.salt,
                proof_hash=proof_hash,
                trusted_party_id=proof.trusted_party_id,
                status="generated",
                expires_at=datetime.utcnow() + timedelta(hours=settings.zkp_proof_expiry_hours)
            )
            
            session.add(zkp_verification)
            await session.commit()
    
    async def _update_proof_status(self, poll_id: int, anonymous_id: str, status: str):
        """Update proof status in database"""
        async with get_session() as session:
            await session.execute(
                update(ZKProofVerification)
                .where(
                    and_(
                        ZKProofVerification.poll_id == poll_id,
                        ZKProofVerification.anonymous_id == anonymous_id
                    )
                )
                .values(status=status, verified_at=datetime.utcnow())
            )
            await session.commit()
    
    async def cleanup_expired_proofs(self) -> Dict[str, int]:
        """Cleanup expired ZKP proofs"""
        async with get_session() as session:
            result = await session.execute(
                update(ZKProofVerification)
                .where(
                    and_(
                        ZKProofVerification.expires_at < datetime.utcnow(),
                        or_(
                            ZKProofVerification.status == "generated",
                            ZKProofVerification.status == "verified"
                        )
                    )
                )
                .values(status="expired")
            )
            
            expired_count = result.rowcount
            await session.commit()
            
            logger.info(f"Marked {expired_count} ZKP proofs as expired")
            return {"expired_proofs": expired_count}