"""
Request models for Verification Service API
Pydantic models for request validation
"""
from typing import Optional, List
from pydantic import BaseModel, Field, validator
import re


class BlindSignatureRequest(BaseModel):
    """Request for blind signature from TrustedParty"""
    requester_id: int = Field(..., gt=0, description="User ID requesting signature")
    poll_id: int = Field(..., gt=0, description="Poll ID for voting")
    blinded_anonymous_id: str = Field(..., min_length=100, max_length=2000, 
                                     description="Blinded anonymous ID (base64 encoded)")
    trusted_party_session: Optional[str] = Field(None, description="Session ID for grouping requests")
    
    @validator('blinded_anonymous_id')
    def validate_blinded_message(cls, v):
        # Basic validation for base64-like format
        if not re.match(r'^[A-Za-z0-9+/=]+$', v):
            raise ValueError('Blinded message must be base64 encoded')
        return v


class ProcessSignatureRequest(BaseModel):
    """TrustedParty decision on signature request"""
    approved: bool = Field(..., description="Whether to approve the signature")
    reject_reason: Optional[str] = Field(None, max_length=500, 
                                        description="Reason for rejection if not approved")
    trusted_party_session: Optional[str] = Field(None, description="Session ID")


class ZKPGenerationRequest(BaseModel):
    """Request to generate ZKP proof"""
    poll_id: int = Field(..., gt=0, description="Poll ID")
    anonymous_id: str = Field(..., pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                             description="UUID anonymous ID")
    unblinded_signature: str = Field(..., min_length=100, max_length=2000,
                                    description="Unblinded signature from TrustedParty")
    salt: Optional[str] = Field(None, pattern=r'^[0-9a-f]{32}$', 
                               description="32 character hex salt (auto-generated if not provided)")
    
    @validator('unblinded_signature')
    def validate_signature(cls, v):
        if not re.match(r'^[A-Za-z0-9+/=]+$', v):
            raise ValueError('Signature must be base64 encoded')
        return v


class ZKPVerificationRequest(BaseModel):
    """Request to verify ZKP proof"""
    poll_id: int = Field(..., gt=0, description="Poll ID")
    anonymous_id: str = Field(..., pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                             description="UUID anonymous ID")
    proof: dict = Field(..., description="ZKP proof object")
    
    @validator('proof')
    def validate_proof_structure(cls, v):
        required_fields = ['commitment', 'challenge', 'response', 'salt']
        for field in required_fields:
            if field not in v:
                raise ValueError(f'Proof must contain {field} field')
        return v


class BatchPublicKeysRequest(BaseModel):
    """Request multiple public keys for trusted parties"""
    trusted_party_ids: List[int] = Field(..., min_items=1, max_items=50,
                                         description="List of TrustedParty IDs")
    poll_id: int = Field(..., gt=0, description="Poll ID")


class AnonymousIdUsageRequest(BaseModel):
    """Mark anonymous ID as used for voting"""
    poll_id: int = Field(..., gt=0, description="Poll ID")
    anonymous_id: str = Field(..., pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                             description="UUID anonymous ID")
    signature_hash: str = Field(..., pattern=r'^[0-9a-f]{64}$', 
                               description="SHA256 hash of signature")


class TrustedPartyKeyRequest(BaseModel):
    """Request public key for specific trusted party"""
    trusted_party_id: int = Field(..., gt=0, description="TrustedParty ID")
    poll_id: int = Field(..., gt=0, description="Poll ID")
    force_refresh: bool = Field(False, description="Force refresh from Poll Management Service")


# Internal API models (for Poll Management Service integration)
class PollInfoRequest(BaseModel):
    """Request poll information from Poll Management Service"""
    poll_id: int = Field(..., gt=0, description="Poll ID")


class TrustedPartyInfoRequest(BaseModel):
    """Request trusted party information"""
    trusted_party_id: int = Field(..., gt=0, description="TrustedParty ID")
    poll_id: int = Field(..., gt=0, description="Poll ID")