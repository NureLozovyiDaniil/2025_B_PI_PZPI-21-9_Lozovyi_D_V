"""
Database models for Verification Service
Implements anonymous blind signature architecture
"""
from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, Index, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()


class BlindSignature(Base):
    """
    Blind signature requests from users
    TrustedParty knows the requester for verification purposes
    """
    __tablename__ = "blind_signatures"
    
    id = Column(Integer, primary_key=True, index=True)
    requester_id = Column(Integer, nullable=False, comment="User ID (TrustedParty must know for verification)")
    trusted_party_id = Column(Integer, nullable=False, comment="TrustedParty ID from Poll Management Service")
    poll_id = Column(Integer, nullable=False, comment="Poll ID from Poll Management Service")
    
    # Blind signature data
    blinded_anonymous_id = Column(Text, nullable=False, comment="blind(anonymous_id, blinding_factor)")
    signature = Column(Text, nullable=True, comment="RSA signature of blinded_anonymous_id")
    blinding_factor = Column(String(64), nullable=True, comment="For debugging purposes (optional)")
    
    # Status tracking
    status = Column(String(20), nullable=False, default="pending", comment="pending/signed/rejected/expired")
    reject_reason = Column(Text, nullable=True, comment="Reason for rejection")
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    processed_at = Column(DateTime(timezone=True), nullable=True, comment="When TrustedParty processed")
    expires_at = Column(DateTime(timezone=True), nullable=False, 
                       default=lambda: datetime.utcnow() + timedelta(hours=24))
    
    # Session tracking for TrustedParty
    trusted_party_session = Column(String(36), nullable=True, comment="Session ID for grouping requests")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('requester_id', 'poll_id', name='uq_user_poll_signature'),
        Index('idx_blind_signatures_poll_status', 'poll_id', 'status'),
        Index('idx_blind_signatures_trusted_party', 'trusted_party_id', 'status'),
        Index('idx_blind_signatures_expires', 'expires_at'),
    )

    def is_expired(self) -> bool:
        """Check if the signature request has expired"""
        return datetime.utcnow() > self.expires_at
    
    def can_be_processed(self) -> bool:
        """Check if the request can be processed by TrustedParty"""
        return self.status == "pending" and not self.is_expired()


class UsedAnonymousId(Base):
    """
    Registry of used anonymous IDs to prevent double voting
    Fast O(1) lookup for duplicate prevention
    """
    __tablename__ = "used_anonymous_ids"
    
    poll_id = Column(Integer, primary_key=True, comment="Poll ID")
    anonymous_id = Column(String(36), primary_key=True, comment="UUID anonymous ID used for voting")
    used_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    signature_hash = Column(String(64), nullable=False, comment="SHA256 hash of signature for validation")
    
    # Indexes
    __table_args__ = (
        Index('idx_used_anonymous_poll_time', 'poll_id', 'used_at'),
    )


class TrustedPartyKeysCache(Base):
    """
    Cache for TrustedParty public keys from Poll Management Service
    Reduces HTTP requests and improves performance
    """
    __tablename__ = "trusted_party_keys_cache"
    
    id = Column(Integer, primary_key=True, index=True)
    trusted_party_id = Column(Integer, nullable=False, comment="TrustedParty ID from Poll Management")
    poll_id = Column(Integer, nullable=False, comment="Poll ID")
    
    # Key data
    public_key = Column(Text, nullable=False, comment="RSA public key in PEM format")
    key_hash = Column(String(64), nullable=False, comment="SHA256 hash of public key")
    
    # Cache metadata
    fetched_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False,
                       default=lambda: datetime.utcnow() + timedelta(hours=1))
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('trusted_party_id', 'poll_id', name='uq_trusted_party_poll_cache'),
        Index('idx_trusted_keys_hash', 'key_hash'),
        Index('idx_trusted_keys_expires', 'expires_at'),
    )
    
    def is_expired(self) -> bool:
        """Check if the cached key has expired"""
        return datetime.utcnow() > self.expires_at


class ZKProofVerification(Base):
    """
    ZKP verification records - simplified implementation
    Stores "ZKP proofs" which are actually commitment-based verifications
    """
    __tablename__ = "zkp_verifications"
    
    id = Column(Integer, primary_key=True, index=True)
    poll_id = Column(Integer, nullable=False, comment="Poll ID")
    anonymous_id = Column(String(36), nullable=False, comment="Anonymous ID for voting")
    
    # "ZKP" components (simplified implementation)
    commitment = Column(String(64), nullable=False, comment="SHA256 commitment hash")
    challenge = Column(String(64), nullable=False, comment="SHA256 challenge hash")
    response = Column(String(128), nullable=False, comment="Computed response")
    salt = Column(String(32), nullable=False, comment="Random salt for security")
    
    # Metadata
    proof_hash = Column(String(64), nullable=False, comment="SHA256 hash of entire proof")
    trusted_party_id = Column(Integer, nullable=False, comment="Which TrustedParty verified this")
    
    # Status
    status = Column(String(20), nullable=False, default="generated", 
                   comment="generated/verified/used/expired")
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    verified_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=False,
                       default=lambda: datetime.utcnow() + timedelta(hours=1))
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('poll_id', 'anonymous_id', name='uq_poll_anonymous_proof'),
        Index('idx_zkp_anonymous_id', 'anonymous_id'),
        Index('idx_zkp_poll_status', 'poll_id', 'status'),
        Index('idx_zkp_expires', 'expires_at'),
        Index('idx_zkp_proof_hash', 'proof_hash'),
    )
    
    def is_expired(self) -> bool:
        """Check if the ZKP proof has expired"""
        return datetime.utcnow() > self.expires_at
    
    def can_be_used(self) -> bool:
        """Check if the proof can be used for voting"""
        return self.status == "verified" and not self.is_expired()