"""
Response models for Verification Service API
Pydantic models for API responses
"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class BaseResponse(BaseModel):
    """Base response model"""
    success: bool = Field(..., description="Whether the operation was successful")
    message: str = Field(..., description="Human-readable message")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")


class ErrorResponse(BaseResponse):
    """Error response model"""
    success: bool = Field(False, description="Always false for errors")
    error_code: str = Field(..., description="Machine-readable error code")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = Field(..., description="Service status")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    version: str = Field("1.0.0", description="Service version")
    environment: str = Field(..., description="Environment (dev/prod/test)")
    database: Dict[str, Any] = Field(..., description="Database health status")
    external_services: Dict[str, Any] = Field(..., description="External service status")


class BlindSignatureResponse(BaseResponse):
    """Response after requesting blind signature"""
    request_id: int = Field(..., description="Unique request ID for tracking")
    status: str = Field(..., description="Request status (pending/signed/rejected)")
    expires_at: datetime = Field(..., description="When the request expires")
    estimated_processing_time: str = Field("24 hours", description="Expected processing time")


class SignatureResultResponse(BaseResponse):
    """Response with signature result"""
    request_id: int = Field(..., description="Request ID")
    status: str = Field(..., description="Current status")
    signature: Optional[str] = Field(None, description="RSA signature if approved")
    reject_reason: Optional[str] = Field(None, description="Rejection reason if denied")
    processed_at: Optional[datetime] = Field(None, description="When processed")
    expires_at: datetime = Field(..., description="Expiration time")


class PendingSignatureItem(BaseModel):
    """Single pending signature request for TrustedParty"""
    request_id: int = Field(..., description="Request ID")
    requester_id: int = Field(..., description="User ID who requested")
    poll_id: int = Field(..., description="Poll ID")
    blinded_anonymous_id: str = Field(..., description="Blinded message to sign")
    created_at: datetime = Field(..., description="When request was created")
    trusted_party_session: Optional[str] = Field(None, description="Session ID")


class PendingSignaturesResponse(BaseResponse):
    """List of pending signature requests for TrustedParty"""
    requests: List[PendingSignatureItem] = Field(..., description="Pending requests")
    total_count: int = Field(..., description="Total number of pending requests")
    trusted_party_id: int = Field(..., description="TrustedParty ID")


class ZKProofData(BaseModel):
    """ZKP proof structure (simplified implementation)"""
    commitment: str = Field(..., pattern=r'^[0-9a-f]{64}$', description="SHA256 commitment")
    challenge: str = Field(..., pattern=r'^[0-9a-f]{64}$', description="SHA256 challenge")
    response: str = Field(..., pattern=r'^[0-9a-f]{128}$', description="Computed response")
    salt: str = Field(..., pattern=r'^[0-9a-f]{32}$', description="Random salt")
    trusted_party_id: int = Field(..., description="TrustedParty ID")
    anonymous_id: str = Field(..., description="Anonymous ID")
    timestamp: datetime = Field(..., description="Proof generation time")
    protocol: str = Field("simplified_sigma", description="ZKP protocol used")


class ZKPGenerationResponse(BaseResponse):
    """Response after generating ZKP proof"""
    proof: ZKProofData = Field(..., description="Generated ZKP proof")
    proof_hash: str = Field(..., pattern=r'^[0-9a-f]{64}$', description="SHA256 hash of proof")
    expires_at: datetime = Field(..., description="Proof expiration time")


class ZKPVerificationResponse(BaseResponse):
    """Response after verifying ZKP proof"""
    valid: bool = Field(..., description="Whether the proof is valid")
    anonymous_id: str = Field(..., description="Anonymous ID from proof")
    proof_hash: str = Field(..., description="Hash of verified proof")
    trusted_party_id: Optional[int] = Field(None, description="Which TrustedParty signed")
    verified_at: datetime = Field(default_factory=datetime.utcnow, description="Verification time")
    can_vote: bool = Field(..., description="Whether this proof can be used for voting")


class TrustedPartyKey(BaseModel):
    """TrustedParty public key information"""
    trusted_party_id: int = Field(..., description="TrustedParty ID")
    poll_id: int = Field(..., description="Poll ID")
    public_key: str = Field(..., description="RSA public key in PEM format")
    key_hash: str = Field(..., pattern=r'^[0-9a-f]{64}$', description="SHA256 hash of key")
    fetched_at: datetime = Field(..., description="When key was fetched")


class BatchPublicKeysResponse(BaseResponse):
    """Response with multiple public keys"""
    keys: List[TrustedPartyKey] = Field(..., description="Public keys")
    poll_id: int = Field(..., description="Poll ID")
    cache_hits: int = Field(..., description="Number of keys from cache")
    api_calls: int = Field(..., description="Number of API calls made")


class StatisticsData(BaseModel):
    """Service statistics"""
    total_blind_signatures: int = Field(..., description="Total signature requests")
    pending_signatures: int = Field(..., description="Pending signature requests")
    completed_signatures: int = Field(..., description="Completed signatures")
    rejected_signatures: int = Field(..., description="Rejected signatures")
    total_zkp_proofs: int = Field(..., description="Total ZKP proofs generated")
    verified_proofs: int = Field(..., description="Successfully verified proofs")
    used_anonymous_ids: int = Field(..., description="Used anonymous IDs")
    cached_keys: int = Field(..., description="Cached TrustedParty keys")
    uptime: str = Field(..., description="Service uptime")


class StatisticsResponse(BaseResponse):
    """Service statistics response"""
    statistics: StatisticsData = Field(..., description="Service statistics")
    poll_statistics: Optional[Dict[int, Dict[str, int]]] = Field(None, 
                                                                description="Per-poll statistics")


class AnonymousIdUsageResponse(BaseResponse):
    """Response after marking anonymous ID as used"""
    anonymous_id: str = Field(..., description="Anonymous ID")
    poll_id: int = Field(..., description="Poll ID")
    used_at: datetime = Field(..., description="When ID was marked as used")
    signature_hash: str = Field(..., description="Associated signature hash")


# Utility response models
class ValidationResult(BaseModel):
    """Validation result for various operations"""
    valid: bool = Field(..., description="Whether validation passed")
    errors: List[str] = Field(default_factory=list, description="Validation errors")
    warnings: List[str] = Field(default_factory=list, description="Validation warnings")


class ProcessingStatus(BaseModel):
    """Generic processing status"""
    status: str = Field(..., description="Current status")
    progress: Optional[int] = Field(None, ge=0, le=100, description="Progress percentage")
    estimated_completion: Optional[datetime] = Field(None, description="Estimated completion time")
    last_updated: datetime = Field(default_factory=datetime.utcnow, description="Last status update")