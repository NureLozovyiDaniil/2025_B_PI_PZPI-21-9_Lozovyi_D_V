package repository

import (
	"context"
	"identity-api/internal/model"
	"time"

	"gorm.io/gorm"
)

type UserRepository interface {
	Create(ctx context.Context, user *model.User) error
	GetByID(ctx context.Context, id uint) (*model.User, error)
	GetByEmail(ctx context.Context, email string) (*model.User, error)
	Update(ctx context.Context, user *model.User) error
	Delete(ctx context.Context, id uint) error
	List(ctx context.Context, offset, limit int) ([]model.User, error)
}

type RoleRepository interface {
	Create(ctx context.Context, role *model.Role) error
	GetByID(ctx context.Context, id uint) (*model.Role, error)
	GetByCode(ctx context.Context, code string) (*model.Role, error)
	Update(ctx context.Context, role *model.Role) error
	Delete(ctx context.Context, id uint) error
	List(ctx context.Context) ([]model.Role, error)
}

type UserRoleRepository interface {
	Assign(ctx context.Context, userRole *model.UserRole) error
	Revoke(ctx context.Context, userID, roleID uint) error
	GetUserRoles(ctx context.Context, userID uint) ([]model.Role, error)
	HasRole(ctx context.Context, userID uint, roleCode string) (bool, error)
	ExtendExpiration(ctx context.Context, userID, roleID uint, expiresAt time.Time) error
	DeactivateExpiredRoles(ctx context.Context, now time.Time) error
}

type Repository struct {
	User     UserRepository
	Role     RoleRepository
	UserRole UserRoleRepository
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{
		User:     NewUserRepository(db),
		Role:     NewRoleRepository(db),
		UserRole: NewUserRoleRepository(db),
	}
}
