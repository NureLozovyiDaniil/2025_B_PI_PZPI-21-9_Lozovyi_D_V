package repository

import (
	"context"
	"identity-api/internal/model"
	"time"

	"gorm.io/gorm"
)

type UserRoleRepo struct {
	db *gorm.DB
}

func NewUserRoleRepository(db *gorm.DB) *UserRoleRepo {
	return &UserRoleRepo{db: db}
}

func (r *UserRoleRepo) Assign(ctx context.Context, userRole *model.UserRole) error {
	return r.db.WithContext(ctx).Create(userRole).Error
}

func (r *UserRoleRepo) Revoke(ctx context.Context, userID, roleID uint) error {
	return r.db.WithContext(ctx).
		Where("user_id = ? AND role_id = ?", userID, roleID).
		Delete(&model.UserRole{}).Error
}

func (r *UserRoleRepo) GetUserRoles(ctx context.Context, userID uint) ([]model.Role, error) {
	var roles []model.Role
	err := r.db.WithContext(ctx).
		Joins("JOIN user_roles ON user_roles.role_id = roles.id").
		Where("user_roles.user_id = ? AND user_roles.is_active = true", userID).
		Where("user_roles.expires_at IS NULL OR user_roles.expires_at > ?", time.Now()).
		Find(&roles).Error
	return roles, err
}

func (r *UserRoleRepo) HasRole(ctx context.Context, userID uint, roleCode string) (bool, error) {
	var count int64
	now := time.Now()

	err := r.db.WithContext(ctx).Model(&model.UserRole{}).
		Joins("JOIN roles ON user_roles.role_id = roles.id").
		Where("user_roles.user_id = ? AND roles.code = ? AND user_roles.is_active = true", userID, roleCode).
		Where("user_roles.expires_at IS NULL OR user_roles.expires_at > ?", now).
		Count(&count).Error

	return count > 0, err
}

func (r *UserRoleRepo) ExtendExpiration(ctx context.Context, userID, roleID uint, expiresAt time.Time) error {
	return r.db.WithContext(ctx).
		Model(&model.UserRole{}).
		Where("user_id = ? AND role_id = ?", userID, roleID).
		Update("expires_at", expiresAt).Error
}

func (r *UserRoleRepo) DeactivateExpiredRoles(ctx context.Context, now time.Time) error {
	return r.db.WithContext(ctx).
		Model(&model.UserRole{}).
		Where("expires_at IS NOT NULL AND expires_at < ? AND is_active = true", now).
		Update("is_active", false).Error
}

func (r *UserRoleRepo) WithTx(tx *gorm.DB) *UserRoleRepo {
	return &UserRoleRepo{db: tx}
}
