package middleware

import (
	"context"
	"fmt"
	"mime"
	"net/http"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"golang.org/x/time/rate"
)

func CORS() gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := c.Request.Header.Get("Origin")

		allowedOrigins := map[string]bool{
			"http://localhost:8082": true,
			"http://localhost:8083": true,
			"http://localhost:3000": true,
		}

		if allowedOrigins[origin] || origin == "" {
			c.Header("Access-Control-Allow-Origin", origin)
		}

		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Header("Access-Control-Allow-Credentials", "true")
		c.Header("Access-Control-Max-Age", "86400")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}

		c.Next()
	}
}

func Security() gin.HandlerFunc {
	return func(c *gin.Context) {

		c.Header("X-Frame-Options", "DENY")

		c.Header("X-Content-Type-Options", "nosniff")

		c.Header("X-XSS-Protection", "1; mode=block")

		c.Header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

		c.Header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'")

		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")

		c.Next()
	}
}

func RateLimiter(requestsPerMinute int) gin.HandlerFunc {
	type client struct {
		limiter  *rate.Limiter
		lastSeen time.Time
	}

	var (
		mu      sync.Mutex
		clients = make(map[string]*client)
	)

	go func() {
		for {
			time.Sleep(5 * time.Minute)
			mu.Lock()
			for ip, client := range clients {
				if time.Since(client.lastSeen) > 5*time.Minute {
					delete(clients, ip)
				}
			}
			mu.Unlock()
		}
	}()

	return func(c *gin.Context) {
		ip := c.ClientIP()

		mu.Lock()
		if _, found := clients[ip]; !found {
			clients[ip] = &client{
				limiter: rate.NewLimiter(rate.Limit(requestsPerMinute)/60, requestsPerMinute),
			}
		}
		clients[ip].lastSeen = time.Now()
		limiter := clients[ip].limiter
		mu.Unlock()

		if !limiter.Allow() {
			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_RATE_LIMIT",
					"message": "Too many requests",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func AuthRateLimiter() gin.HandlerFunc {
	return RateLimiter(10)
}

func APIRateLimiter() gin.HandlerFunc {
	return RateLimiter(100)
}

func RequestID() gin.HandlerFunc {
	return func(c *gin.Context) {
		requestID := c.GetHeader("X-Request-ID")
		if requestID == "" {
			requestID = generateRequestID()
		}

		c.Header("X-Request-ID", requestID)
		c.Set("RequestID", requestID)

		c.Next()
	}
}

func Timeout(timeout time.Duration, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {

		ctx, cancel := context.WithTimeout(c.Request.Context(), timeout)
		defer cancel()

		c.Request = c.Request.WithContext(ctx)

		finished := make(chan struct{})
		panicChan := make(chan interface{}, 1)

		go func() {
			defer func() {
				if p := recover(); p != nil {
					panicChan <- p
				}
			}()

			c.Next()
			finished <- struct{}{}
		}()

		select {
		case <-finished:

		case <-ctx.Done():

			logger.Warn("request timed out",
				zap.String("path", c.FullPath()),
				zap.Duration("timeout", timeout))

			c.JSON(http.StatusRequestTimeout, gin.H{
				"error": gin.H{
					"code":    "ERR_TIMEOUT",
					"message": "Request timeout",
				},
			})
			c.Abort()
		case p := <-panicChan:

			logger.Error("panic in request handler", zap.Any("panic", p))
			panic(p)
		}
	}
}

func ValidateContentType(allowedTypes ...string) gin.HandlerFunc {
	allowedMap := make(map[string]bool)
	for _, contentType := range allowedTypes {
		allowedMap[contentType] = true
	}

	return func(c *gin.Context) {

		if c.Request.Method == "GET" || c.Request.Method == "DELETE" || c.Request.Method == "OPTIONS" {
			c.Next()
			return
		}

		contentType := c.GetHeader("Content-Type")
		if contentType == "" {
			c.JSON(http.StatusUnsupportedMediaType, gin.H{
				"error": gin.H{
					"code":    "ERR_UNSUPPORTED_MEDIA_TYPE",
					"message": "Content-Type header required",
				},
			})
			c.Abort()
			return
		}
		mediaType, _, err := mime.ParseMediaType(contentType)
		if err != nil || !allowedMap[mediaType] {
			c.JSON(http.StatusUnsupportedMediaType, gin.H{
				"error": gin.H{
					"code":    "ERR_UNSUPPORTED_MEDIA_TYPE",
					"message": "Unsupported content type",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func JSONContentType() gin.HandlerFunc {
	return ValidateContentType("application/json")
}

func RequestSize(maxSize int64) gin.HandlerFunc {
	return func(c *gin.Context) {

		if c.Request.Method == "GET" || c.Request.Method == "HEAD" || c.Request.Method == "OPTIONS" {
			c.Next()
			return
		}

		if c.Request.ContentLength > maxSize {
			c.JSON(http.StatusRequestEntityTooLarge, gin.H{
				"error": gin.H{
					"code":    "ERR_REQUEST_TOO_LARGE",
					"message": fmt.Sprintf("Request body too large (max: %d bytes)", maxSize),
				},
			})
			c.Abort()
			return
		}

		if c.Request.Body != nil {
			c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, maxSize)
		}
		c.Next()
	}
}

func RecoveryWithLogger(logger *zap.Logger) gin.HandlerFunc {
	return gin.CustomRecovery(func(c *gin.Context, recovered interface{}) {
		requestID, _ := c.Get("RequestID")

		logger.Error("panic recovered",
			zap.Any("panic", recovered),
			zap.String("path", c.FullPath()),
			zap.String("method", c.Request.Method),
			zap.String("ip", c.ClientIP()),
			zap.Any("request_id", requestID),
		)

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Internal server error",
			},
		})
	})
}

func UserContext(userService interface{}) gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetUint("userID")
		if userID == 0 {
			c.Next()
			return
		}

		c.Next()
	}
}

func generateRequestID() string {
	return fmt.Sprintf("%d-%d", time.Now().UnixNano(), time.Now().Unix())
}

func GetRequestID(c *gin.Context) string {
	if requestID, exists := c.Get("RequestID"); exists {
		if id, ok := requestID.(string); ok {
			return id
		}
	}
	return ""
}

func DatabaseHealthCheck(db interface{}) gin.HandlerFunc {
	return func(c *gin.Context) {

		c.Next()
	}
}

func ConditionalMiddleware(condition func(*gin.Context) bool, middleware gin.HandlerFunc) gin.HandlerFunc {
	return func(c *gin.Context) {
		if condition(c) {
			middleware(c)
		} else {
			c.Next()
		}
	}
}
