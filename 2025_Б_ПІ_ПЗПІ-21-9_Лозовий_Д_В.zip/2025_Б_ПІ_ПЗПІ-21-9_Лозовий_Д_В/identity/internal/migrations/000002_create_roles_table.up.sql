CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_roles_code ON roles(code);

--   
INSERT INTO roles (code, name, description, permissions, created_at, updated_at)
VALUES
    ('admin', 'Administrator', 'Full system access', '["*"]', NOW(), NOW()),
    ('user', 'User', 'Basic user access', '["user:read", "user:update"]', NOW(), NOW());