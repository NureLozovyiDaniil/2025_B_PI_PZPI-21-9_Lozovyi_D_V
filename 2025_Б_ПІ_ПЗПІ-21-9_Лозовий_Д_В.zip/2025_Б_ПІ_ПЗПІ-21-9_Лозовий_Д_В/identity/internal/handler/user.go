package handler

import (
	"identity-api/internal/model"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (h *Handler) getAllUsers(c *gin.Context) {

	offsetStr := c.DefaultQuery("offset", "0")
	limitStr := c.DefaultQuery("limit", "10")

	offset, err := strconv.Atoi(offsetStr)
	if err != nil || offset < 0 {
		offset = 0
	}

	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit <= 0 || limit > 100 {
		limit = 10
	}

	users, err := h.services.User.List(c.Request.Context(), offset, limit)
	if err != nil {
		h.logger.Error("failed to get users", zap.Error(err))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Failed to retrieve users",
			},
		})
		return
	}

	userResponses := make([]model.UserResponse, len(users))
	for i, user := range users {
		userResponses[i] = user.ToResponse()
	}

	c.JSON(http.StatusOK, gin.H{
		"data":    userResponses,
		"message": "Users retrieved successfully",
	})
}

func (h *Handler) getUserByID(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	user, err := h.services.User.GetByID(c.Request.Context(), uint(id))
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"data":    user.ToResponse(),
		"message": "User retrieved successfully",
	})
}

func (h *Handler) getUserInternal(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	user, err := h.services.User.GetByID(c.Request.Context(), uint(id))
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"user_id":    user.ID,
		"email":      user.Email,
		"public_key": user.PublicKey,
		"is_active":  user.Status == model.UserStatusActive,
	})
}

func (h *Handler) getUserByEmail(c *gin.Context) {
	email := c.Param("email")
	if email == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	user, err := h.services.User.GetByEmail(c.Request.Context(), email)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"user_id":    user.ID,
		"email":      user.Email,
		"public_key": user.PublicKey,
		"is_active":  user.Status == "active",
	})
}

func (h *Handler) updateUser(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	var input model.UserUpdate
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid user update request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	user, err := h.services.User.Update(c.Request.Context(), uint(id), input)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	h.logger.Info("user updated successfully", zap.Uint("id", uint(id)))

	c.JSON(http.StatusOK, gin.H{
		"data":    user.ToResponse(),
		"message": "User updated successfully",
	})
}

func (h *Handler) updateCurrentUser(c *gin.Context) {
	userID := c.GetUint("userID")
	if userID == 0 {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": gin.H{
				"code":    "ERR_UNAUTHORIZED",
				"message": "User not authenticated",
			},
		})
		return
	}

	var input model.UserUpdate
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid user update request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	input.Status = nil

	user, err := h.services.User.Update(
		c.Request.Context(),
		userID,
		input,
	)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	h.logger.Info("user updated own profile successfully", zap.Uint("id", userID))

	c.JSON(http.StatusOK, gin.H{
		"data":    user.ToResponse(),
		"message": "Profile updated successfully",
	})
}

func (h *Handler) deleteUser(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_ID",
				"message": "Invalid user ID",
			},
		})
		return
	}

	err = h.services.User.Delete(c.Request.Context(), uint(id))
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	h.logger.Info("user deleted successfully", zap.Uint("id", uint(id)))

	c.JSON(http.StatusOK, gin.H{
		"message": "User deleted successfully",
	})
}

func (h *Handler) getCurrentUser(c *gin.Context) {
	userID := c.GetUint("userID")
	if userID == 0 {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": gin.H{
				"code":    "ERR_UNAUTHORIZED",
				"message": "User not authenticated",
			},
		})
		return
	}

	user, err := h.services.User.GetByID(c.Request.Context(), userID)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	roles, err := h.services.Role.GetUserRoles(c.Request.Context(), userID)
	if err != nil {
		h.handleUserError(c, err)
		return
	}
	user.Roles = roles

	c.JSON(http.StatusOK, gin.H{
		"data":    user.ToResponse(),
		"message": "User retrieved successfully",
	})
}

func (h *Handler) getUserPublicKey(c *gin.Context) {
	h.logger.Info("get user public key")
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{})
	}
	user, err := h.services.User.GetByID(c.Request.Context(), uint(id))
	if err != nil {
		h.handleUserError(c, err)
	}

	c.JSON(http.StatusOK, gin.H{
		"user_id":    user.ID,
		"public_key": user.PublicKey,
	})
}

func (h *Handler) changePassword(c *gin.Context) {
	userID := c.GetUint("userID")
	if userID == 0 {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": gin.H{
				"code":    "ERR_UNAUTHORIZED",
				"message": "User not authenticated",
			},
		})
		return
	}

	var input model.UserPasswordChange
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid password change request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	err := h.services.User.ChangePassword(c.Request.Context(), userID, input.OldPassword, input.NewPassword)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	h.logger.Info("password changed successfully", zap.Uint("user_id", userID))

	c.JSON(http.StatusOK, gin.H{
		"message": "Password changed successfully",
	})
}

func (h *Handler) handleUserError(c *gin.Context, err error) {
	switch err {
	case model.ErrUserNotFound:
		c.JSON(http.StatusNotFound, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_NOT_FOUND",
				"message": "User not found",
			},
		})
	case model.ErrUserAlreadyExists:
		c.JSON(http.StatusConflict, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_EXISTS",
				"message": "User with this email already exists",
			},
		})
	case model.ErrIncorrectPassword:
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INCORRECT_PASSWORD",
				"message": "Current password is incorrect",
			},
		})
	case model.ErrInsufficientPermissions:
		c.JSON(http.StatusForbidden, gin.H{
			"error": gin.H{
				"code":    "ERR_INSUFFICIENT_PERMISSIONS",
				"message": "Insufficient permissions",
			},
		})
	default:
		h.logger.Error("user operation error", zap.Error(err))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Internal server error",
			},
		})
	}
}
