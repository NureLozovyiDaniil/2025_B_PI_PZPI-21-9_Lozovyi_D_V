package handler

import (
	"identity-api/internal/middleware"
	"identity-api/internal/service"
	"time"

	"github.com/casbin/casbin/v2"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

type Handler struct {
	services *service.Service
	logger   *zap.Logger
	enforcer *casbin.Enforcer
}

func NewHandler(services *service.Service, logger *zap.Logger, enforcer *casbin.Enforcer) *Handler {
	return &Handler{
		services: services,
		logger:   logger,
		enforcer: enforcer,
	}
}

func (h *Handler) InitRoutes() *gin.Engine {
	router := gin.New()

	router.Use(middleware.RequestID())
	router.Use(middleware.CORS())
	router.Use(middleware.Security())
	router.Use(middleware.Logger(h.logger))
	router.Use(middleware.RecoveryWithLogger(h.logger))
	router.Use(middleware.RequestSize(10 << 20))
	router.Use(middleware.Timeout(30*time.Second, h.logger))

	router.GET("/health", h.healthCheck)
	router.GET("/ready", h.readinessCheck)
	router.GET("/internal/user/:id/public-key",
		middleware.InternalAPI("super_secret_key"),
		h.getUserPublicKey)
	router.GET("/internal/user-by-email/:email",
		middleware.InternalAPI("super_secret_key"),
		h.getUserByEmail)
	router.GET("/internal/users/:id",
		middleware.InternalAPI("super_secret_key"),
		h.getUserInternal)

	internal := router.Group("/internal")
	internal.GET("/validate-voter", middleware.Auth(h.services.Auth), h.validateVoter)

	api := router.Group("/api/v1")
	api.Use(middleware.JSONContentType())
	{

		auth := api.Group("/auth")
		auth.Use(middleware.AuthRateLimiter())
		{
			auth.POST("/register", h.register)
			auth.POST("/login", h.login)
		}

		protected := api.Group("")
		protected.Use(middleware.APIRateLimiter())
		protected.Use(middleware.AuthWithLogger(h.services.Auth, h.logger))
		{

			userRoutes := protected.Group("/users")
			{

				userRoutes.GET("/me", h.getCurrentUser)
				userRoutes.PUT("/me", h.updateCurrentUser)
				userRoutes.PUT("/me/password", h.changePassword)

				adminUserRoutes := userRoutes.Group("")
				adminUserRoutes.Use(middleware.RequirePermission(h.enforcer, "users", "read"))
				{
					adminUserRoutes.GET("/",
						middleware.ConditionalMiddleware(
							func(context *gin.Context) bool {
								apiKey := context.GetHeader("X-Internal-API-Key")
								return apiKey == "super_secret_key"
							},
							middleware.RequireRole("admin"),
						),
						h.getAllUsers)
					adminUserRoutes.GET("/:id",
						middleware.RequireSelfOrAdmin(),
						h.getUserByID)
				}

				modifyUserRoutes := userRoutes.Group("")
				modifyUserRoutes.Use(middleware.RequirePermission(h.enforcer, "users", "write"))
				{
					modifyUserRoutes.PUT("/:id",
						middleware.RequireSelfOrAdmin(),
						h.updateUser)
				}

				deleteUserRoutes := userRoutes.Group("")
				deleteUserRoutes.Use(middleware.RequireSelfOrAdmin())
				{
					deleteUserRoutes.DELETE("/:id", h.deleteUser)
				}
			}

			userRoleRoutes := protected.Group("/user-roles")
			userRoleRoutes.Use(middleware.RequireAnyRole("admin", "premium"))
			{
				userRoleRoutes.POST("/", h.assignRole)

				userRoleRoutes.DELETE("/:user_id/:role_id", h.revokeRole)
				userRoleRoutes.PUT("/:user_id/:role_id", h.extendRoleExpiration)

				userRoleRoutes.GET("/user/:user_id",
					middleware.ConditionalMiddleware(
						func(c *gin.Context) bool {

							userID := c.GetUint("userID")
							targetUserID := c.Param("user_id")
							return targetUserID != "me" && targetUserID != string(rune(userID))
						},
						middleware.RequireRole("admin"),
					),
					h.getUserRoles)
			}

			adminRoutes := protected.Group("/admin")
			adminRoutes.Use(middleware.RequireRole("admin"))
			{
				adminRoutes.GET("/stats", h.getSystemStats)
				adminRoutes.POST("/maintenance", h.triggerMaintenance)
				adminRoutes.GET("/config", h.getSystemConfig)
			}
		}
	}

	return router
}

func (h *Handler) healthCheck(c *gin.Context) {
	c.JSON(200, gin.H{
		"status":    "ok",
		"timestamp": time.Now().Unix(),
		"service":   "identity-api",
	})
}

func (h *Handler) readinessCheck(c *gin.Context) {

	ctx := c.Request.Context()
	if _, err := h.services.User.List(ctx, 0, 1); err != nil {
		c.JSON(503, gin.H{
			"status": "not_ready",
			"error":  "database_unavailable",
		})
		return
	}

	c.JSON(200, gin.H{
		"status":    "ready",
		"timestamp": time.Now().Unix(),
		"service":   "identity-api",
	})
}

func (h *Handler) getSystemStats(c *gin.Context) {
	ctx := c.Request.Context()

	users, err := h.services.User.List(ctx, 0, 1000)
	if err != nil {
		c.JSON(500, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Failed to retrieve stats",
			},
		})
		return
	}

	roles, err := h.services.Role.List(ctx)
	if err != nil {
		c.JSON(500, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": "Failed to retrieve stats",
			},
		})
		return
	}

	c.JSON(200, gin.H{
		"data": gin.H{
			"total_users": len(users),
			"total_roles": len(roles),
			"timestamp":   time.Now().Unix(),
		},
		"message": "System stats retrieved successfully",
	})
}

func (h *Handler) triggerMaintenance(c *gin.Context) {
	ctx := c.Request.Context()

	if err := h.services.Role.DeactivateExpiredRoles(ctx); err != nil {
		h.logger.Error("Manual maintenance task failed", zap.Error(err))
		c.JSON(500, gin.H{
			"error": gin.H{
				"code":    "ERR_MAINTENANCE_FAILED",
				"message": "Maintenance task failed",
			},
		})
		return
	}

	h.logger.Info("Manual maintenance task completed", zap.Uint("triggered_by", c.GetUint("userID")))

	c.JSON(200, gin.H{
		"message": "Maintenance tasks completed successfully",
	})
}

func (h *Handler) getSystemConfig(c *gin.Context) {

	c.JSON(200, gin.H{
		"data": gin.H{
			"version":     "1.0.0",
			"environment": "development",
			"features": gin.H{
				"user_registration": true,
				"role_management":   true,
				"casbin_enabled":    true,
			},
		},
		"message": "System configuration retrieved successfully",
	})
}

func (h *Handler) updateSystemConfig(c *gin.Context) {
	var input struct {
		Features map[string]bool `json:"features"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(400, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid configuration format",
			},
		})
		return
	}

	h.logger.Info("System configuration update requested",
		zap.Uint("updated_by", c.GetUint("userID")),
		zap.Any("features", input.Features))

	c.JSON(200, gin.H{
		"message": "System configuration updated successfully",
	})
}
