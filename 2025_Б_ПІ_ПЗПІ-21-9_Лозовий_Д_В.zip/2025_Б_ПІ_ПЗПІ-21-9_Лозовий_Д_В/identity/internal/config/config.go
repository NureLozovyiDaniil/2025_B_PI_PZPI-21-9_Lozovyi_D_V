package config

import (
	"errors"
	"fmt"
	"time"

	"github.com/spf13/viper"
)

type Config struct {
	ServerAddress string
	LogLevel      string
	Database      DatabaseConfig
	JWT           JWTConfig
	Crypto        CryptoConfig
}

type DatabaseConfig struct {
	Host     string
	Port     string
	Username string
	Password string
	DBName   string
	SSLMode  string
}

type JWTConfig struct {
	SecretKey  string
	Expiration time.Duration
}

type CryptoConfig struct {
	ServerKey string
}

func (c *DatabaseConfig) GetDSN() string {
	return fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.Host, c.Port, c.Username, c.Password, c.DBName, c.SSLMode)
}

func Load() (*Config, error) {
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")
	viper.AddConfigPath("internal/config")
	viper.AddConfigPath(".")

	viper.SetDefault("server.address", ":8080")
	viper.SetDefault("log.level", "development")
	viper.SetDefault("database.sslmode", "disable")
	viper.SetDefault("jwt.expiration", "24h")

	viper.AutomaticEnv()
	viper.SetEnvPrefix("IDENTITY")
	viper.BindEnv("server.address", "IDENTITY_SERVER_ADDRESS")
	viper.BindEnv("database.host", "IDENTITY_DB_HOST")
	viper.BindEnv("database.port", "IDENTITY_DB_PORT")
	viper.BindEnv("database.username", "IDENTITY_DB_USER")
	viper.BindEnv("database.password", "IDENTITY_DB_PASSWORD")
	viper.BindEnv("database.dbname", "IDENTITY_DB_NAME")
	viper.BindEnv("jwt.secretkey", "IDENTITY_JWT_SECRET")
	viper.BindEnv("crypto.serverkey", "IDENTITY_CRYPTO_KEY")

	if err := viper.ReadInConfig(); err != nil {

		var configFileNotFoundError viper.ConfigFileNotFoundError
		if !errors.As(err, &configFileNotFoundError) {
			return nil, fmt.Errorf("failed to read config file: %w", err)
		}
	}

	var cfg Config
	cfg.ServerAddress = viper.GetString("server.address")
	cfg.LogLevel = viper.GetString("log.level")

	cfg.Database = DatabaseConfig{
		Host:     viper.GetString("database.host"),
		Port:     viper.GetString("database.port"),
		Username: viper.GetString("database.username"),
		Password: viper.GetString("database.password"),
		DBName:   viper.GetString("database.dbname"),
		SSLMode:  viper.GetString("database.sslmode"),
	}

	expDuration, err := time.ParseDuration(viper.GetString("jwt.expiration"))
	if err != nil {
		return nil, fmt.Errorf("invalid JWT expiration duration: %w", err)
	}
	cfg.JWT = JWTConfig{
		SecretKey:  viper.GetString("jwt.secretkey"),
		Expiration: expDuration,
	}

	cfg.Crypto = CryptoConfig{
		ServerKey: viper.GetString("crypto.serverkey"),
	}

	return &cfg, nil
}
