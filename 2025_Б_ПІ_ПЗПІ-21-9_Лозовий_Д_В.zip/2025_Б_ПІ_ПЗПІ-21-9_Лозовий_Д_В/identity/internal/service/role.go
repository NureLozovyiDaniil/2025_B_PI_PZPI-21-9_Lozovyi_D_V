package service

import (
	"context"
	"encoding/json"
	"errors"
	"identity-api/internal/model"
	"identity-api/internal/repository"
	"time"

	"github.com/casbin/casbin/v2"
	"go.uber.org/zap"
)

type RoleImpl struct {
	roleRepo     repository.RoleRepository
	userRoleRepo repository.UserRoleRepository
	enforcer     *casbin.Enforcer
	logger       *zap.Logger
}

func NewRoleImpl(
	roleRepo repository.RoleRepository,
	userRoleRepo repository.UserRoleRepository,
	enforcer *casbin.Enforcer,
	logger *zap.Logger,
) *RoleImpl {
	return &RoleImpl{
		roleRepo:     roleRepo,
		userRoleRepo: userRoleRepo,
		enforcer:     enforcer,
		logger:       logger,
	}
}

func (s *RoleImpl) Create(ctx context.Context, input model.RoleCreate) (*model.Role, error) {

	existingRole, _ := s.roleRepo.GetByCode(ctx, input.Code)
	if existingRole != nil {
		return nil, errors.New("role with this code already exists")
	}

	if input.Permissions != "" {
		if !s.isValidPermissionsJSON(input.Permissions) {
			return nil, errors.New("invalid permissions format")
		}
	}

	role := &model.Role{
		Code:        input.Code,
		Name:        input.Name,
		Description: input.Description,
		Permissions: input.Permissions,
	}

	if err := s.roleRepo.Create(ctx, role); err != nil {
		s.logger.Error("failed to create role", zap.Error(err))
		return nil, errors.New("failed to create role")
	}

	if input.Permissions != "" {
		s.updateCasbinPolicies(role.Code, input.Permissions)
	}

	s.logger.Info("role created successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return role, nil
}

func (s *RoleImpl) GetByID(ctx context.Context, id uint) (*model.Role, error) {
	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	return role, nil
}

func (s *RoleImpl) GetByCode(ctx context.Context, code string) (*model.Role, error) {
	role, err := s.roleRepo.GetByCode(ctx, code)
	if err != nil {
		return nil, err
	}
	return role, nil
}

func (s *RoleImpl) Update(ctx context.Context, id uint, input model.RoleUpdate) (*model.Role, error) {

	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}

	if input.Name != "" {
		role.Name = input.Name
	}

	if input.Description != "" {
		role.Description = input.Description
	}

	if input.Permissions != "" {
		if !s.isValidPermissionsJSON(input.Permissions) {
			return nil, errors.New("invalid permissions format")
		}
		role.Permissions = input.Permissions
	}

	if err := s.roleRepo.Update(ctx, role); err != nil {
		s.logger.Error("failed to update role", zap.Error(err))
		return nil, errors.New("failed to update role")
	}

	if input.Permissions != "" {
		s.updateCasbinPolicies(role.Code, input.Permissions)
	}

	s.logger.Info("role updated successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return role, nil
}

func (s *RoleImpl) Delete(ctx context.Context, id uint) error {

	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}

	if err := s.roleRepo.Delete(ctx, id); err != nil {
		s.logger.Error("failed to delete role", zap.Error(err))
		return errors.New("failed to delete role")
	}

	if s.enforcer != nil {
		_, err = s.enforcer.RemoveFilteredPolicy(0, role.Code)
		if err != nil {
			s.logger.Error("failed to remove filtered policy", zap.Error(err))
			return errors.New("failed to remove filtered policy")
		}
	} else {
		s.logger.Warn("casbin enforcer not initialized, skipping policy removal")
	}

	s.logger.Info("role deleted successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return nil
}

func (s *RoleImpl) List(ctx context.Context) ([]model.Role, error) {
	roles, err := s.roleRepo.List(ctx)
	if err != nil {
		s.logger.Error("failed to list roles", zap.Error(err))
		return nil, errors.New("failed to retrieve roles")
	}

	return roles, nil
}

func (s *RoleImpl) AssignRole(ctx context.Context, userID, roleID, assignedBy uint, expiresAt *time.Time) error {

	_, err := s.roleRepo.GetByID(ctx, roleID)
	if err != nil {
		return err
	}

	userRole := &model.UserRole{
		UserID:     userID,
		RoleID:     roleID,
		AssignedAt: time.Now(),
		AssignedBy: assignedBy,
		ExpiresAt:  expiresAt,
		IsActive:   true,
	}

	if err := s.userRoleRepo.Assign(ctx, userRole); err != nil {
		s.logger.Error("failed to assign role to user",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to assign role")
	}

	s.logger.Info("role assigned successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID),
		zap.Uint("assigned_by", assignedBy))

	return nil
}

func (s *RoleImpl) RevokeRole(ctx context.Context, userID, roleID uint) error {
	if err := s.userRoleRepo.Revoke(ctx, userID, roleID); err != nil {
		s.logger.Error("failed to revoke role from user",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to revoke role")
	}

	s.logger.Info("role revoked successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID))

	return nil
}

func (s *RoleImpl) GetUserRoles(ctx context.Context, userID uint) ([]model.Role, error) {
	roles, err := s.userRoleRepo.GetUserRoles(ctx, userID)
	if err != nil {
		s.logger.Error("failed to get user roles",
			zap.Error(err),
			zap.Uint("user_id", userID))
		return nil, errors.New("failed to get user roles")
	}

	return roles, nil
}

func (s *RoleImpl) HasRole(ctx context.Context, userID uint, roleCode string) (bool, error) {
	hasRole, err := s.userRoleRepo.HasRole(ctx, userID, roleCode)
	if err != nil {
		s.logger.Error("failed to check user role",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.String("role_code", roleCode))
		return false, errors.New("failed to check user role")
	}

	return hasRole, nil
}

func (s *RoleImpl) ExtendRoleExpiration(ctx context.Context, userID, roleID uint, expiresAt time.Time) error {
	if err := s.userRoleRepo.ExtendExpiration(ctx, userID, roleID, expiresAt); err != nil {
		s.logger.Error("failed to extend role expiration",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to extend role expiration")
	}

	s.logger.Info("role expiration extended successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID),
		zap.Time("expires_at", expiresAt))

	return nil
}

func (s *RoleImpl) DeactivateExpiredRoles(ctx context.Context) error {
	now := time.Now()

	if err := s.userRoleRepo.DeactivateExpiredRoles(ctx, now); err != nil {
		s.logger.Error("failed to deactivate expired roles", zap.Error(err))
		return errors.New("failed to deactivate expired roles")
	}

	s.logger.Info("expired roles deactivated successfully")
	return nil
}

func (s *RoleImpl) CheckPermission(ctx context.Context, userID uint, resource, action string) (bool, error) {

	roles, err := s.GetUserRoles(ctx, userID)
	if err != nil {
		return false, err
	}

	for _, role := range roles {
		if allowed, _ := s.enforcer.Enforce(role.Code, resource, action); allowed {
			return true, nil
		}
	}

	return false, nil
}

func (s *RoleImpl) StartExpirationChecker(ctx context.Context, interval time.Duration) {
	ticker := time.NewTicker(interval)
	go func() {
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				if err := s.DeactivateExpiredRoles(ctx); err != nil {
					s.logger.Error("failed to deactivate expired roles in background task", zap.Error(err))
				}
			case <-ctx.Done():
				s.logger.Info("role expiration checker stopped")
				return
			}
		}
	}()

	s.logger.Info("role expiration checker started", zap.Duration("interval", interval))
}

func (s *RoleImpl) isValidPermissionsJSON(permissions string) bool {
	var js json.RawMessage
	return json.Unmarshal([]byte(permissions), &js) == nil
}

func (s *RoleImpl) updateCasbinPolicies(roleCode, permissions string) {
	if s.enforcer == nil {
		s.logger.Error("casbin enforcer is not initialized",
			zap.String("role_code", roleCode))
		return
	}

	s.enforcer.RemoveFilteredPolicy(0, roleCode)

	var perms []string
	if err := json.Unmarshal([]byte(permissions), &perms); err != nil {
		s.logger.Error("failed to parse permissions JSON",
			zap.Error(err),
			zap.String("role_code", roleCode))
		return
	}

	for _, perm := range perms {

		if perm == "*" {

			s.enforcer.AddPolicy(roleCode, "*", "*")
		} else {

			parts := splitPermission(perm)
			if len(parts) == 2 {
				s.enforcer.AddPolicy(roleCode, parts[0], parts[1])
			}
		}
	}

	s.enforcer.SavePolicy()

	s.logger.Info("Updated Casbin policies for role",
		zap.String("role_code", roleCode),
		zap.Any("permissions", perms))

	policies, err := s.enforcer.GetPolicy()
	s.logger.Info("All current policies", zap.Any("policies", policies), zap.Error(err))
}

func splitPermission(permission string) []string {

	parts := make([]string, 0, 2)
	if colon := findChar(permission, ':'); colon != -1 {
		parts = append(parts, permission[:colon])
		parts = append(parts, permission[colon+1:])
	}
	return parts
}

func findChar(s string, ch byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == ch {
			return i
		}
	}
	return -1
}

func (s *RoleImpl) GetRolePermissions(ctx context.Context, roleCode string) ([]string, error) {
	role, err := s.roleRepo.GetByCode(ctx, roleCode)
	if err != nil {
		return nil, err
	}

	if role.Permissions == "" {
		return []string{}, nil
	}

	var permissions []string
	if err := json.Unmarshal([]byte(role.Permissions), &permissions); err != nil {
		s.logger.Error("failed to parse role permissions",
			zap.Error(err),
			zap.String("role_code", roleCode))
		return nil, errors.New("invalid permissions format")
	}

	return permissions, nil
}

func (s *RoleImpl) AssignTemporaryRole(ctx context.Context, userID, roleID, assignedBy uint, duration time.Duration) error {
	expiresAt := time.Now().Add(duration)
	return s.AssignRole(ctx, userID, roleID, assignedBy, &expiresAt)
}

func (s *RoleImpl) BulkAssignRole(ctx context.Context, userIDs []uint, roleID, assignedBy uint, expiresAt *time.Time) error {

	_, err := s.roleRepo.GetByID(ctx, roleID)
	if err != nil {
		return err
	}

	successCount := 0
	for _, userID := range userIDs {
		if err := s.AssignRole(ctx, userID, roleID, assignedBy, expiresAt); err != nil {
			s.logger.Warn("failed to assign role to user in bulk operation",
				zap.Error(err),
				zap.Uint("user_id", userID),
				zap.Uint("role_id", roleID))
			continue
		}
		successCount++
	}

	s.logger.Info("bulk role assignment completed",
		zap.Int("success_count", successCount),
		zap.Int("total_count", len(userIDs)),
		zap.Uint("role_id", roleID))

	if successCount == 0 {
		return errors.New("failed to assign role to any user")
	}

	return nil
}

func (s *RoleImpl) GetUsersWithRole(ctx context.Context, roleCode string) ([]uint, error) {

	role, err := s.roleRepo.GetByCode(ctx, roleCode)
	if err != nil {
		return nil, err
	}

	s.logger.Info("getting users with role",
		zap.String("role_code", roleCode),
		zap.Uint("role_id", role.ID))

	return []uint{}, nil
}
