package service

import (
	"identity-api/pkg/crypto"
)

type KeyImpl struct {
	encryptionService *crypto.EncryptionService
}

func NewKeyImpl(serverKey string) *KeyImpl {
	return &KeyImpl{
		encryptionService: crypto.NewEncryptionService(serverKey),
	}
}

func (s *KeyImpl) GenerateKeyPair() (publicKey, privateKey string, err error) {

	return s.encryptionService.GenerateECDSAKeyPair()
}

func (s *KeyImpl) EncryptPrivateKey(privateKey string) (string, error) {
	return s.encryptionService.Encrypt(privateKey)
}

func (s *KeyImpl) DecryptPrivateKey(encryptedKey string) (string, error) {
	return s.encryptionService.Decrypt(encryptedKey)
}
