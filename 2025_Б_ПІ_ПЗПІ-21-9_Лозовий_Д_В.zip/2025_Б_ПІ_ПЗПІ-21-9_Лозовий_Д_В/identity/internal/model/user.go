package model

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

const (
	UserStatusActive  = "active"
	UserStatusBlocked = "blocked"
)

type User struct {
	ID                  uint      `gorm:"primaryKey" json:"id"`
	UUID                string    `gorm:"type:uuid;uniqueIndex" json:"uuid"`
	Email               string    `gorm:"uniqueIndex;size:255" json:"email"`
	PhoneNumber         string    `gorm:"size:20" json:"phone_number"`
	CountryCode         string    `gorm:"size:3" json:"country_code"`
	PasswordHash        string    `gorm:"size:255" json:"-"`
	PublicKey           string    `gorm:"size:255" json:"public_key,omitempty"`
	EncryptedPrivateKey string    `gorm:"type:text" json:"-"`
	Status              string    `gorm:"default:pending" json:"status"`
	CreatedAt           time.Time `json:"created_at"`
	UpdatedAt           time.Time `json:"updated_at"`
	Roles               []Role    `gorm:"many2many:user_roles;" json:"roles,omitempty"`
}

func (u *User) BeforeCreate(tx *gorm.DB) error {
	if u.UUID == "" {
		u.UUID = uuid.New().String()
	}
	return nil
}

type UserCreate struct {
	Email       string `json:"email" binding:"required,email"`
	PhoneNumber string `json:"phone_number" binding:"required"`
	CountryCode string `json:"country_code" binding:"required"`
	Password    string `json:"password" binding:"required,min=8"`
}

type UserUpdate struct {
	Email  string  `json:"email" binding:"omitempty,email"`
	Status *string `json:"status" binding:"omitempty,oneof=pending active inactive blocked"`
}

type UserPasswordChange struct {
	OldPassword string `json:"old_password" binding:"required"`
	NewPassword string `json:"new_password" binding:"required,min=8"`
}

type UserResponse struct {
	ID        uint      `json:"id"`
	UUID      string    `json:"uuid"`
	Email     string    `json:"email"`
	Phone     string    `json:"phone_number"`
	Country   string    `json:"country_code"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
	Roles     []Role    `json:"roles,omitempty"`
}

func (u *User) ToResponse() UserResponse {
	return UserResponse{
		ID:        u.ID,
		UUID:      u.UUID,
		Email:     u.Email,
		Phone:     u.PhoneNumber,
		Country:   u.CountryCode,
		Status:    u.Status,
		CreatedAt: u.CreatedAt,
		Roles:     u.Roles,
	}
}
