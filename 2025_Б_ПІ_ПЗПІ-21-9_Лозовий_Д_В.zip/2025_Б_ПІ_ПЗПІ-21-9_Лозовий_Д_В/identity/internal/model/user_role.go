package model

import "time"

type UserRole struct {
	UserID     uint       `gorm:"primaryKey" json:"user_id"`
	RoleID     uint       `gorm:"primaryKey" json:"role_id"`
	AssignedAt time.Time  `json:"assigned_at"`
	AssignedBy uint       `json:"assigned_by"`
	ExpiresAt  *time.Time `json:"expires_at"`
	IsActive   bool       `gorm:"default:true" json:"is_active"`
}

type UserRoleAssign struct {
	UserID    uint       `json:"user_id" binding:"required"`
	RoleID    uint       `json:"role_id" binding:"required"`
	ExpiresAt *time.Time `json:"expires_at"`
}

type UserRoleExtend struct {
	ExpiresAt time.Time `json:"expires_at" binding:"required"`
}
