package crypto

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/hex"
	"encoding/pem"
	"strings"
	"testing"

	"github.com/ethereum/go-ethereum/crypto"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewEncryptionService(t *testing.T) {
	service := NewEncryptionService("test-key")

	assert.NotNil(t, service)
	assert.Equal(t, "test-key", service.serverKey)
}

func TestEncryptDecrypt_Success(t *testing.T) {
	tests := []struct {
		name      string
		serverKey string
		data      string
	}{
		{
			name:      "normal data with 32-byte key",
			serverKey: "12345678901234567890123456789012",
			data:      "Hello, World!",
		},
		{
			name:      "empty data",
			serverKey: "test-key",
			data:      "",
		},
		{
			name:      "long data",
			serverKey: "test-key",
			data:      strings.Repeat("A", 1000),
		},
		{
			name:      "unicode data",
			serverKey: "test-key",
			data:      "Hello 世界! 🌍",
		},
		{
			name:      "short key (padded)",
			serverKey: "short",
			data:      "test data",
		},
		{
			name:      "long key (truncated)",
			serverKey: "this-is-a-very-long-key-that-exceeds-32-bytes-and-should-be-truncated",
			data:      "test data",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := NewEncryptionService(tt.serverKey)

			encrypted, err := service.Encrypt(tt.data)
			require.NoError(t, err)
			assert.NotEmpty(t, encrypted)
			assert.NotEqual(t, tt.data, encrypted)

			decrypted, err := service.Decrypt(encrypted)
			require.NoError(t, err)
			assert.Equal(t, tt.data, decrypted)
		})
	}
}

func TestEncrypt_ConsistentFormat(t *testing.T) {
	service := NewEncryptionService("test-key")
	data := "test data"

	encrypted1, err := service.Encrypt(data)
	require.NoError(t, err)

	encrypted2, err := service.Encrypt(data)
	require.NoError(t, err)

	assert.NotEqual(t, encrypted1, encrypted2)

	decrypted1, err := service.Decrypt(encrypted1)
	require.NoError(t, err)
	assert.Equal(t, data, decrypted1)

	decrypted2, err := service.Decrypt(encrypted2)
	require.NoError(t, err)
	assert.Equal(t, data, decrypted2)
}

func TestDecrypt_InvalidInput(t *testing.T) {
	service := NewEncryptionService("test-key")

	tests := []struct {
		name          string
		encryptedData string
		expectError   string
	}{
		{
			name:          "invalid base64",
			encryptedData: "invalid-base64!@#",
			expectError:   "illegal base64 data",
		},
		{
			name:          "too short ciphertext",
			encryptedData: "dGVzdA==",
			expectError:   "ciphertext too short",
		},
		{
			name:          "empty string",
			encryptedData: "",
			expectError:   "ciphertext too short",
		},
		{
			name:          "corrupted ciphertext",
			encryptedData: "MTIzNDU2Nzg5MDEyY29ycnVwdGVkZGF0YQ==",
			expectError:   "cipher: message authentication failed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := service.Decrypt(tt.encryptedData)
			require.Error(t, err)
			assert.Contains(t, err.Error(), tt.expectError)
		})
	}
}

func TestGenerateRSAKeyPair_Success(t *testing.T) {
	service := NewEncryptionService("test-key")

	publicKeyPEM, privateKeyPEM, err := service.GenerateRSAKeyPair()
	require.NoError(t, err)

	assert.NotEmpty(t, publicKeyPEM)
	assert.NotEmpty(t, privateKeyPEM)

	assert.Contains(t, publicKeyPEM, "-----BEGIN PUBLIC KEY-----")
	assert.Contains(t, publicKeyPEM, "-----END PUBLIC KEY-----")
	assert.Contains(t, privateKeyPEM, "-----BEGIN RSA PRIVATE KEY-----")
	assert.Contains(t, privateKeyPEM, "-----END RSA PRIVATE KEY-----")

	publicBlock, _ := pem.Decode([]byte(publicKeyPEM))
	require.NotNil(t, publicBlock)
	assert.Equal(t, "PUBLIC KEY", publicBlock.Type)

	publicKey, err := x509.ParsePKIXPublicKey(publicBlock.Bytes)
	require.NoError(t, err)

	rsaPublicKey, ok := publicKey.(*rsa.PublicKey)
	require.True(t, ok)
	assert.Equal(t, 2048, rsaPublicKey.Size()*8)

	privateBlock, _ := pem.Decode([]byte(privateKeyPEM))
	require.NotNil(t, privateBlock)
	assert.Equal(t, "RSA PRIVATE KEY", privateBlock.Type)

	privateKey, err := x509.ParsePKCS1PrivateKey(privateBlock.Bytes)
	require.NoError(t, err)
	assert.Equal(t, 2048, privateKey.Size()*8)
}

func TestGenerateRSAKeyPair_MultipleGenerations(t *testing.T) {
	service := NewEncryptionService("test-key")

	publicKey1, privateKey1, err := service.GenerateRSAKeyPair()
	require.NoError(t, err)

	publicKey2, privateKey2, err := service.GenerateRSAKeyPair()
	require.NoError(t, err)

	assert.NotEqual(t, publicKey1, publicKey2)
	assert.NotEqual(t, privateKey1, privateKey2)
}

func TestGenerateECDSAKeyPair_Success(t *testing.T) {
	service := NewEncryptionService("test-key")

	publicKeyHex, privateKeyPEM, err := service.GenerateECDSAKeyPair()
	require.NoError(t, err)

	assert.NotEmpty(t, publicKeyHex)
	assert.NotEmpty(t, privateKeyPEM)

	assert.Contains(t, privateKeyPEM, "-----BEGIN SECP256K1 PRIVATE KEY-----")
	assert.Contains(t, privateKeyPEM, "-----END SECP256K1 PRIVATE KEY-----")

	_, err = hex.DecodeString(publicKeyHex)
	require.NoError(t, err)
	assert.Equal(t, 128, len(publicKeyHex))

	privateBlock, _ := pem.Decode([]byte(privateKeyPEM))
	require.NotNil(t, privateBlock)
	assert.Equal(t, "SECP256K1 PRIVATE KEY", privateBlock.Type)

	privateKey, err := crypto.ToECDSA(privateBlock.Bytes)
	require.NoError(t, err)

	expectedPublicKeyBytes := crypto.FromECDSAPub(&privateKey.PublicKey)
	expectedPublicKeyHex := hex.EncodeToString(expectedPublicKeyBytes[1:])
	assert.Equal(t, expectedPublicKeyHex, publicKeyHex)
}

func TestGenerateECDSAKeyPair_MultipleGenerations(t *testing.T) {
	service := NewEncryptionService("test-key")

	publicKey1, privateKey1, err := service.GenerateECDSAKeyPair()
	require.NoError(t, err)

	publicKey2, privateKey2, err := service.GenerateECDSAKeyPair()
	require.NoError(t, err)

	assert.NotEqual(t, publicKey1, publicKey2)
	assert.NotEqual(t, privateKey1, privateKey2)
}

func TestKeyHandling_EdgeCases(t *testing.T) {
	tests := []struct {
		name      string
		serverKey string
		data      string
	}{
		{
			name:      "exactly 32 bytes key",
			serverKey: "12345678901234567890123456789012",
			data:      "test",
		},
		{
			name:      "less than 32 bytes key",
			serverKey: "short",
			data:      "test",
		},
		{
			name:      "more than 32 bytes key",
			serverKey: "this-is-a-very-long-key-that-exceeds-32-bytes",
			data:      "test",
		},
		{
			name:      "empty key",
			serverKey: "",
			data:      "test",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := NewEncryptionService(tt.serverKey)

			encrypted, err := service.Encrypt(tt.data)
			require.NoError(t, err)

			decrypted, err := service.Decrypt(encrypted)
			require.NoError(t, err)
			assert.Equal(t, tt.data, decrypted)
		})
	}
}

func BenchmarkEncrypt(b *testing.B) {
	service := NewEncryptionService("test-key-for-benchmarking-performance")
	data := "Hello, World! This is a test message for benchmarking."

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := service.Encrypt(data)
		if err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkDecrypt(b *testing.B) {
	service := NewEncryptionService("test-key-for-benchmarking-performance")
	data := "Hello, World! This is a test message for benchmarking."

	encrypted, err := service.Encrypt(data)
	if err != nil {
		b.Fatal(err)
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := service.Decrypt(encrypted)
		if err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkGenerateRSAKeyPair(b *testing.B) {
	service := NewEncryptionService("test-key")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _, err := service.GenerateRSAKeyPair()
		if err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkGenerateECDSAKeyPair(b *testing.B) {
	service := NewEncryptionService("test-key")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _, err := service.GenerateECDSAKeyPair()
		if err != nil {
			b.Fatal(err)
		}
	}
}
