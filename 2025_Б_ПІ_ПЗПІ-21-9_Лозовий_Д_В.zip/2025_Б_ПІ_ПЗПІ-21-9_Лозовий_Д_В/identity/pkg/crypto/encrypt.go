package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"io"

	"github.com/ethereum/go-ethereum/crypto"
)

type EncryptionService struct {
	serverKey string
}

func NewEncryptionService(serverKey string) *EncryptionService {
	return &EncryptionService{
		serverKey: serverKey,
	}
}

func (s *EncryptionService) Encrypt(data string) (string, error) {

	key := []byte(s.serverKey)
	if len(key) < 32 {

		key = append(key, make([]byte, 32-len(key))...)
	} else if len(key) > 32 {

		key = key[:32]
	}

	plaintext := []byte(data)

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, 12)
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	ciphertext := aesgcm.Seal(nil, nonce, plaintext, nil)

	encrypted := make([]byte, len(nonce)+len(ciphertext))
	copy(encrypted, nonce)
	copy(encrypted[len(nonce):], ciphertext)

	return base64.StdEncoding.EncodeToString(encrypted), nil
}

func (s *EncryptionService) Decrypt(encryptedData string) (string, error) {

	key := []byte(s.serverKey)
	if len(key) < 32 {

		key = append(key, make([]byte, 32-len(key))...)
	} else if len(key) > 32 {

		key = key[:32]
	}

	ciphertext, err := base64.StdEncoding.DecodeString(encryptedData)
	if err != nil {
		return "", err
	}

	if len(ciphertext) < 12 {
		return "", errors.New("ciphertext too short")
	}

	nonce, ciphertext := ciphertext[:12], ciphertext[12:]

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	plaintext, err := aesgcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}

	return string(plaintext), nil
}

func (s *EncryptionService) GenerateRSAKeyPair() (string, string, error) {

	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return "", "", err
	}

	privateKeyBytes := x509.MarshalPKCS1PrivateKey(privateKey)
	privateKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "RSA PRIVATE KEY",
			Bytes: privateKeyBytes,
		},
	)

	publicKeyBytes, err := x509.MarshalPKIXPublicKey(&privateKey.PublicKey)
	if err != nil {
		return "", "", err
	}
	publicKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "PUBLIC KEY",
			Bytes: publicKeyBytes,
		},
	)

	return string(publicKeyPEM), string(privateKeyPEM), nil
}

func (s *EncryptionService) GenerateECDSAKeyPair() (string, string, error) {
	privateKey, err := crypto.GenerateKey()
	if err != nil {
		return "", "", err
	}

	privateKeyBytes := crypto.FromECDSA(privateKey)
	privateKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "SECP256K1 PRIVATE KEY",
			Bytes: privateKeyBytes,
		},
	)

	publicKeyBytes := crypto.FromECDSAPub(&privateKey.PublicKey)
	publicKeyHex := hex.EncodeToString(publicKeyBytes[1:])

	return publicKeyHex, string(privateKeyPEM), nil
}
