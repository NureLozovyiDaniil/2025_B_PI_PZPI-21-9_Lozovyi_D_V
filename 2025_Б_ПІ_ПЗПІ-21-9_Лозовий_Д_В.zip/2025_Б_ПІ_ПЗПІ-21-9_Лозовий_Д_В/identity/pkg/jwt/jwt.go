package jwt

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type Service struct {
	signingKey string
	expiration time.Duration
}

func NewJWTService(signingKey string, expiration time.Duration) *Service {
	return &Service{
		signingKey: signingKey,
		expiration: expiration,
	}
}

type Claims struct {
	jwt.RegisteredClaims
	UserID uint     `json:"user_id"`
	Roles  []string `json:"roles"`
}

func (s *Service) GenerateToken(userID uint, roles []string) (string, error) {
	now := time.Now()
	claims := &Claims{
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(now.Add(s.expiration)),
			IssuedAt:  jwt.NewNumericDate(now),
			NotBefore: jwt.NewNumericDate(now),
		},
		UserID: userID,
		Roles:  roles,
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.signingKey))
}

func (s *Service) ParseToken(tokenString string) (uint, []string, error) {
	token, err := jwt.ParseWithClaims(
		tokenString,
		&Claims{},
		func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, errors.New("invalid signing method")
			}
			return []byte(s.signingKey), nil
		},
	)

	if err != nil {
		return 0, nil, err
	}

	claims, ok := token.Claims.(*Claims)
	if !ok {
		return 0, nil, errors.New("invalid token claims")
	}

	return claims.UserID, claims.Roles, nil
}
