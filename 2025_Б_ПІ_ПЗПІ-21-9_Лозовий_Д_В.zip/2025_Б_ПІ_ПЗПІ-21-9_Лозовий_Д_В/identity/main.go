package main

import (
	"context"
	"errors"
	"go.uber.org/zap/zapcore"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"identity-api/internal/config"
	"identity-api/internal/handler"
	"identity-api/internal/initialization"
	"identity-api/internal/repository"
	"identity-api/internal/service"

	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func main() {

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	logger, err := setupLogger(cfg.LogLevel)
	if err != nil {
		log.Fatalf("Failed to setup logger: %v", err)
	}
	defer logger.Sync()

	logger.Info("Starting Identity Service", zap.String("version", "1.0.0"))

	db, err := setupDatabase(cfg.Database)
	if err != nil {
		logger.Fatal("Failed to connect to database", zap.Error(err))
	}

	if err := initialization.CheckDatabaseConnection(db, logger); err != nil {
		logger.Fatal("Database connection check failed", zap.Error(err))
	}
	logger.Info("Database connection established successfully")

	if err := repository.RunMigrations(db, "internal/migrations"); err != nil {
		logger.Fatal("Failed to run migrations", zap.Error(err))
	}
	logger.Info("Database migrations completed")

	enforcer, err := initialization.SetupCasbin(
		"internal/config/casbin_model.conf",
		"internal/config/casbin_policy.csv",
	)
	if err != nil {
		logger.Fatal("Failed to setup Casbin", zap.Error(err))
	}
	logger.Info("Casbin enforcer initialized")

	var (
		repos       = repository.NewRepository(db)
		services    = service.NewService(repos, cfg, logger, enforcer)
		handlers    = handler.NewHandler(services, logger, enforcer)
		initializer = initialization.NewSystemInitializer(logger)
	)

	if err := initializer.InitializeDefaultRoles(context.Background(), services.Role); err != nil {
		logger.Error("Failed to initialize default roles", zap.Error(err))

	}

	engine := handlers.InitRoutes()
	srv := &http.Server{
		Addr:           cfg.ServerAddress,
		Handler:        engine.Handler(),
		ReadTimeout:    30 * time.Second,
		WriteTimeout:   30 * time.Second,
		IdleTimeout:    120 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	taskManager := initialization.NewBackgroundTaskManager(services, logger)
	go taskManager.StartBackgroundTasks(ctx)

	go func() {
		logger.Info("Starting HTTP server", zap.String("address", cfg.ServerAddress))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatal("Failed to start HTTP server", zap.Error(err))
		}
	}()

	logger.Info("Identity Service started successfully", zap.String("address", cfg.ServerAddress))

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("Shutting down Identity Service...")

	cancel()

	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer shutdownCancel()

	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP server forced to shutdown", zap.Error(err))
	} else {
		logger.Info("HTTP server shut down gracefully")
	}

	if sqlDB, err := db.DB(); err == nil {
		if err := sqlDB.Close(); err != nil {
			logger.Error("Failed to close database connection", zap.Error(err))
		} else {
			logger.Info("Database connection closed")
		}
	}

	if err := enforcer.SavePolicy(); err != nil {
		logger.Error("Failed to save Casbin policies", zap.Error(err))
	}

	logger.Info("Identity Service shutdown completed")
}

func setupLogger(level string) (*zap.Logger, error) {
	var cfg zap.Config

	if level == "production" {
		cfg = zap.NewProductionConfig()
		cfg.Level = zap.NewAtomicLevelAt(zap.InfoLevel)

		cfg.OutputPaths = []string{"app.log"}
		cfg.ErrorOutputPaths = []string{"error.log"}
	} else {
		cfg = zap.NewDevelopmentConfig()
		cfg.Level = zap.NewAtomicLevelAt(zap.DebugLevel)

		cfg.OutputPaths = []string{"stdout", "debug.log"}
		cfg.ErrorOutputPaths = []string{"stderr", "error.log"}
	}

	cfg.Development = level != "production"
	cfg.DisableCaller = level == "production"
	cfg.DisableStacktrace = level == "production"

	cfg.EncoderConfig.TimeKey = "timestamp"
	cfg.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	return cfg.Build()
}

func setupDatabase(cfg config.DatabaseConfig) (*gorm.DB, error) {
	dsn := cfg.GetDSN()

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{

		DisableForeignKeyConstraintWhenMigrating: true,

		PrepareStmt: true,
	})
	if err != nil {
		return nil, err
	}

	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(100)
	sqlDB.SetConnMaxLifetime(time.Hour)

	return db, nil
}
