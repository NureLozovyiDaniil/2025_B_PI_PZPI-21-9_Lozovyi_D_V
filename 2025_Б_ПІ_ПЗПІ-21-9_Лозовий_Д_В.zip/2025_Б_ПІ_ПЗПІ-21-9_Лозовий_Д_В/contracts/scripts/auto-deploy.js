const hre = require("hardhat");
const fs = require("fs");

async function main() {
  console.log("Starting auto-deployment...");
  
  //  
  const PollRegistry = await hre.ethers.deployContract("PollRegistry");
  await PollRegistry.waitForDeployment();
  
  const VoteVerifier = await hre.ethers.deployContract("VoteVerifier", [
    "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", // owner
    await PollRegistry.getAddress(),
    "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"  // authorized service
  ]);
  await VoteVerifier.waitForDeployment();
  
  const ResultStorage = await hre.ethers.deployContract("ResultStorage", [
    "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", // owner
    await PollRegistry.getAddress(),
    await VoteVerifier.getAddress()
  ]);
  await ResultStorage.waitForDeployment();
  
  //  
  const deployment = {
    network: "localhost",
    deployer: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
    contracts: {
      PollRegistry: await PollRegistry.getAddress(),
      VoteVerifier: await VoteVerifier.getAddress(),
      ResultStorage: await ResultStorage.getAddress()
    },
    deployedAt: new Date().toISOString()
  };
  
  fs.writeFileSync("deployments.json", JSON.stringify(deployment, null, 2));
  console.log("Deployment completed:", deployment);
}

main().catch(console.error);