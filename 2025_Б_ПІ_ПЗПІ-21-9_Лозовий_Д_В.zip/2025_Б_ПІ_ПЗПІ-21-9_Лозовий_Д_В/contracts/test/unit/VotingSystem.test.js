const { expect } = require("chai");
const { ethers, network } = require("hardhat");

describe("Voting System Integration Test", function() {
  let pollRegistry, voteVerifier, resultStorage;
  let owner, voter1, voter2;
  
  beforeEach(async function() {
    //  
    [owner, voter1, voter2] = await ethers.getSigners();
    
    //  
    const PollRegistry = await ethers.getContractFactory("PollRegistry");
    pollRegistry = await PollRegistry.deploy(owner.address);
    await pollRegistry.waitForDeployment();
    
    const VoteVerifier = await ethers.getContractFactory("VoteVerifier");
    voteVerifier = await VoteVerifier.deploy(owner.address, await pollRegistry.getAddress());
    await voteVerifier.waitForDeployment();
    
    const ResultStorage = await ethers.getContractFactory("ResultStorage");
    resultStorage = await ResultStorage.deploy(
      owner.address,
      await pollRegistry.getAddress(),
      await voteVerifier.getAddress()
    );
    await resultStorage.waitForDeployment();
  });

  it("Should deploy contracts with correct versions", async function() {
    expect(await pollRegistry.version()).to.equal("1.0.0");
    expect(await voteVerifier.version()).to.equal("1.0.0-phase1");
    expect(await resultStorage.version()).to.equal("1.0.0-phase1");
  });

  it("Should create poll and record votes", async function() {
    //    
    const latestBlock = await ethers.provider.getBlock("latest");
    const currentTime = latestBlock.timestamp;
    
    //  
    const pollId = 1;
    const title = "Test Poll";
    const category = "technology";
    const optionsHash = ethers.keccak256(ethers.toUtf8Bytes("option1,option2"));
    const startTime = currentTime + 10;   //   10    
    const endTime = currentTime + 3600;  //   

    await pollRegistry.registerPoll(
      pollId,
      title,
      category,
      optionsHash,
      owner.address,
      startTime,
      endTime,
      false  //  
    );

    //    
    expect(await pollRegistry.pollExists(pollId)).to.be.true;

    //       
    await network.provider.send("evm_increaseTime", [15]); // +15 
    await network.provider.send("evm_mine"); //   

    //     
    expect(await pollRegistry.isPollActive(pollId)).to.be.true;

    // 
    await voteVerifier.connect(voter1).recordVote(pollId, 1, optionsHash);
    await voteVerifier.connect(voter2).recordVote(pollId, 2, optionsHash);

    //  
    expect(await voteVerifier.hasUserVoted(pollId, voter1.address)).to.be.true;
    expect(await voteVerifier.hasUserVoted(pollId, voter2.address)).to.be.true;
    expect(await voteVerifier.getUserChoice(pollId, voter1.address)).to.equal(1);
    expect(await voteVerifier.getUserChoice(pollId, voter2.address)).to.equal(2);
    expect(await voteVerifier.getPollVoteCount(pollId)).to.equal(2);
  });

  it("Should store and verify results", async function() {
    //    
    const latestBlock = await ethers.provider.getBlock("latest");
    const currentTime = latestBlock.timestamp;
    
    //    
    const pollId = 1;
    const title = "Test Poll";
    const category = "technology";
    const optionsHash = ethers.keccak256(ethers.toUtf8Bytes("option1,option2"));
    const startTime = currentTime + 10;
    const endTime = currentTime + 3600;

    await pollRegistry.registerPoll(pollId, title, category, optionsHash, owner.address, startTime, endTime, false);
    
    //      
    await network.provider.send("evm_increaseTime", [15]);
    await network.provider.send("evm_mine");
    
    await voteVerifier.connect(voter1).recordVote(pollId, 1, optionsHash);
    await voteVerifier.connect(voter2).recordVote(pollId, 1, optionsHash); //    1

    //  
    await pollRegistry.updatePollStatus(pollId, 1); // 1 = Ended

    //  
    const optionCounts = [2, 0]; // 2    1, 0   2
    await resultStorage.storeResults(pollId, optionCounts);

    //  
    expect(await resultStorage.hasResults(pollId)).to.be.true;
    
    const [totalVotes, winnerOptionId, isFinalized] = await resultStorage.getResultsSummary(pollId);
    expect(totalVotes).to.equal(2);
    expect(totalVotes).to.equal(2);
    expect(winnerOptionId).to.equal(1);
    expect(isFinalized).to.be.false;

    //  
    expect(await resultStorage.verifyResults(pollId)).to.be.true;
  });

  it("Should prevent double voting", async function() {
    //    
    const latestBlock = await ethers.provider.getBlock("latest");
    const currentTime = latestBlock.timestamp;
    
    //  
    const pollId = 1;
    const optionsHash = ethers.keccak256(ethers.toUtf8Bytes("option1,option2"));
    const startTime = currentTime + 10;
    const endTime = currentTime + 3600;

    await pollRegistry.registerPoll(pollId, "Test", "general", optionsHash, owner.address, startTime, endTime, false);
    
    //      
    await network.provider.send("evm_increaseTime", [15]);
    await network.provider.send("evm_mine");
    
    //   - 
    await voteVerifier.connect(voter1).recordVote(pollId, 1, optionsHash);
    
    //   -  
    await expect(
      voteVerifier.connect(voter1).recordVote(pollId, 2, optionsHash)
    ).to.be.revertedWith("User already voted");
  });
});