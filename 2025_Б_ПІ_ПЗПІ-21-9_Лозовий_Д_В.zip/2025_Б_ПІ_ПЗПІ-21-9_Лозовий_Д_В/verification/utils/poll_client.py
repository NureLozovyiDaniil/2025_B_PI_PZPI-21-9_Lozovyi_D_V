"""
Enhanced HTTP client for Poll Management Service integration
Handles authentication and communication with Poll Management Service
with improved error handling, caching, and performance
"""
import logging
from typing import Optional, Dict, Any, List
import asyncio
from datetime import datetime, timedelta

import httpx
from httpx import AsyncClient, ConnectTimeout, ReadTimeout, RequestError

from config import settings

logger = logging.getLogger(__name__)


class PollManagementClientError(Exception):
    """Base exception for Poll Management Service client errors"""
    pass


class PollNotFoundError(PollManagementClientError):
    """Raised when poll is not found"""
    pass


class TrustedPartyNotFoundError(PollManagementClientError):
    """Raised when trusted party is not found"""
    pass


class PollManagementClient:
    """
    Enhanced HTTP client for Poll Management Service
    Features: connection pooling, retry logic, caching, circuit breaker
    """
    
    def __init__(self):
        self.base_url = settings.poll_management_url
        self.timeout = settings.poll_management_timeout
        self.api_key = settings.internal_api_key
        self.client: Optional[AsyncClient] = None
        
        # Simple in-memory cache for poll info
        self._poll_cache: Dict[int, Dict[str, Any]] = {}
        self._cache_ttl = timedelta(minutes=5)
        self._cache_timestamps: Dict[int, datetime] = {}
        
        # Circuit breaker state
        self._failures = 0
        self._max_failures = 5
        self._circuit_open_until: Optional[datetime] = None
        self._circuit_open_duration = timedelta(minutes=2)
    
    async def _get_client(self) -> AsyncClient:
        """Get or create HTTP client with proper configuration"""
        if self.client is None:
            self.client = AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
                headers={
                    "X-Internal-API-Key": self.api_key,
                    "Content-Type": "application/json",
                    "User-Agent": "VerificationService/1.0",
                    "Accept": "application/json"
                },
                # Connection pooling
                limits=httpx.Limits(
                    max_keepalive_connections=10,
                    max_connections=20,
                    keepalive_expiry=30
                ),
                # Retry configuration
                transport=httpx.AsyncHTTPTransport(
                    retries=3,
                    verify=True
                )
            )
        return self.client
    
    async def close(self):
        """Close HTTP client and cleanup resources"""
        if self.client:
            await self.client.aclose()
            self.client = None
        
        # Clear cache
        self._poll_cache.clear()
        self._cache_timestamps.clear()
        
        logger.info("Poll Management Client closed")
    
    def _is_circuit_open(self) -> bool:
        """Check if circuit breaker is open"""
        if self._circuit_open_until is None:
            return False
        
        if datetime.utcnow() > self._circuit_open_until:
            # Reset circuit breaker
            self._circuit_open_until = None
            self._failures = 0
            logger.info("Circuit breaker reset")
            return False
        
        return True
    
    def _record_success(self):
        """Record successful request"""
        self._failures = 0
        if self._circuit_open_until:
            self._circuit_open_until = None
            logger.info("Circuit breaker closed after successful request")
    
    def _record_failure(self):
        """Record failed request and potentially open circuit"""
        self._failures += 1
        
        if self._failures >= self._max_failures:
            self._circuit_open_until = datetime.utcnow() + self._circuit_open_duration
            logger.warning(f"Circuit breaker opened after {self._failures} failures")
    
    def _is_cache_valid(self, poll_id: int) -> bool:
        """Check if cached poll info is still valid"""
        if poll_id not in self._cache_timestamps:
            return False
        
        cache_time = self._cache_timestamps[poll_id]
        return datetime.utcnow() - cache_time < self._cache_ttl
    
    async def get_poll_info(self, poll_id: int, use_cache: bool = True) -> Dict[str, Any]:
        """
        Get poll information from Poll Management Service
        
        Args:
            poll_id: Poll ID to retrieve
            use_cache: Whether to use cached data if available
            
        Returns:
            Dict with poll information
            
        Raises:
            PollNotFoundError: If poll doesn't exist
            PollManagementClientError: If request fails
        """
        # Check circuit breaker
        if self._is_circuit_open():
            raise PollManagementClientError("Circuit breaker open - service unavailable")
        
        # Check cache first
        if use_cache and self._is_cache_valid(poll_id):
            logger.debug(f"Returning cached poll info for poll {poll_id}")
            return self._poll_cache[poll_id]
        
        try:
            client = await self._get_client()
            
            # Make request with retry logic
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    response = await client.get(f"/api/v1/polls/{poll_id}")
                    break
                except (ConnectTimeout, ReadTimeout) as e:
                    if attempt == max_retries - 1:
                        raise
                    await asyncio.sleep(0.5 * (attempt + 1))  # Exponential backoff
                    logger.warning(f"Retry {attempt + 1} for poll {poll_id}: {e}")
            
            if response.status_code == 404:
                raise PollNotFoundError(f"Poll {poll_id} not found")
            
            if response.status_code != 200:
                raise PollManagementClientError(
                    f"Failed to get poll info: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            
            # Extract and normalize poll information
            poll_data = data.get("data", {})
            poll_info = {
                "poll_id": poll_data.get("id"),
                "title": poll_data.get("title"),
                "is_private": poll_data.get("is_private", False),
                "status": poll_data.get("status"),
                "creator_id": poll_data.get("creator_id"),
                "start_time": poll_data.get("start_time"),
                "end_time": poll_data.get("end_time"),
                "category": poll_data.get("category"),
                "min_voter_turnout": poll_data.get("min_voter_turnout"),
                "max_votes": poll_data.get("max_votes")
            }
            
            # Cache the result
            self._poll_cache[poll_id] = poll_info
            self._cache_timestamps[poll_id] = datetime.utcnow()
            
            self._record_success()
            logger.info(f"Retrieved poll info for poll {poll_id}")
            
            return poll_info
            
        except (PollNotFoundError, PollManagementClientError):
            # Don't record these as failures for circuit breaker
            raise
            
        except (ConnectTimeout, ReadTimeout) as e:
            self._record_failure()
            logger.error(f"Timeout getting poll info for {poll_id}: {e}")
            raise PollManagementClientError(f"Request timeout: {e}")
        
        except RequestError as e:
            self._record_failure()
            logger.error(f"Request error getting poll info for {poll_id}: {e}")
            raise PollManagementClientError(f"Request failed: {e}")
        
        except Exception as e:
            self._record_failure()
            logger.error(f"Unexpected error getting poll info for {poll_id}: {e}")
            raise PollManagementClientError(f"Unexpected error: {e}")
    
    async def get_trusted_party_info(self, trusted_party_id: int, poll_id: int) -> Dict[str, Any]:
        """
        Get trusted party information for specific poll
        
        Args:
            trusted_party_id: Trusted party ID
            poll_id: Poll ID
            
        Returns:
            Dict with trusted party information
            
        Raises:
            TrustedPartyNotFoundError: If trusted party doesn't exist
            PollManagementClientError: If request fails
        """
        if self._is_circuit_open():
            raise PollManagementClientError("Circuit breaker open - service unavailable")
        
        try:
            client = await self._get_client()
            response = await client.get(
                f"/api/v1/polls/{poll_id}/trusted-parties/{trusted_party_id}"
            )
            
            if response.status_code == 404:
                raise TrustedPartyNotFoundError(
                    f"Trusted party {trusted_party_id} not found for poll {poll_id}"
                )
            
            if response.status_code != 200:
                raise PollManagementClientError(
                    f"Failed to get trusted party info: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            
            trusted_party_info = {
                "trusted_party_id": data.get("trusted_party_id"),
                "user_id": data.get("user_id"),
                "poll_id": data.get("poll_id"),
                "public_key": data.get("public_key"),
                "assigned_at": data.get("assigned_at"),
                "assigned_by": data.get("assigned_by")
            }
            
            self._record_success()
            logger.info(f"Retrieved trusted party info: {trusted_party_id} for poll {poll_id}")
            
            return trusted_party_info
            
        except (TrustedPartyNotFoundError, PollManagementClientError):
            raise
            
        except (ConnectTimeout, ReadTimeout) as e:
            self._record_failure()
            logger.error(f"Timeout getting trusted party info: {e}")
            raise PollManagementClientError(f"Request timeout: {e}")
        
        except RequestError as e:
            self._record_failure()
            logger.error(f"Request error getting trusted party info: {e}")
            raise PollManagementClientError(f"Request failed: {e}")
        
        except Exception as e:
            self._record_failure()
            logger.error(f"Unexpected error getting trusted party info: {e}")
            raise PollManagementClientError(f"Unexpected error: {e}")
    
    async def get_trusted_parties_for_poll(self, poll_id: int) -> List[Dict[str, Any]]:
        """
        Get all trusted parties for a poll with enhanced error handling
        """
        if self._is_circuit_open():
            raise PollManagementClientError("Circuit breaker open - service unavailable")
        
        try:
            client = await self._get_client()
            response = await client.get(f"/api/v1/polls/{poll_id}/trusted-parties")
            
            if response.status_code == 404:
                raise PollNotFoundError(f"Poll {poll_id} not found")
            
            if response.status_code != 200:
                raise PollManagementClientError(
                    f"Failed to get trusted parties: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            trusted_parties = data.get("data", [])
            
            result = [
                {
                    "trusted_party_id": tp.get("trusted_party_id"),
                    "user_id": tp.get("user_id"),
                    "public_key": tp.get("public_key"),
                    "assigned_at": tp.get("assigned_at")
                }
                for tp in trusted_parties
            ]
            
            self._record_success()
            logger.info(f"Retrieved {len(result)} trusted parties for poll {poll_id}")
            
            return result
            
        except (PollNotFoundError, PollManagementClientError):
            raise
            
        except Exception as e:
            self._record_failure()
            logger.error(f"Error getting trusted parties for poll {poll_id}: {e}")
            raise PollManagementClientError(f"Request failed: {e}")
    
    async def validate_user(self, user_id: int) -> Dict[str, Any]:
        """
        Validate user exists and is active with caching
        """
        if self._is_circuit_open():
            return {"valid": False, "reason": "Service temporarily unavailable"}
        
        try:
            client = await self._get_client()
            response = await client.get(f"/api/v1/users/{user_id}/validate")
            
            if response.status_code == 404:
                return {"valid": False, "reason": "User not found"}
            
            if response.status_code != 200:
                logger.warning(f"User validation failed for {user_id}: {response.status_code}")
                return {"valid": False, "reason": "Validation service error"}
            
            data = response.json()
            
            result = {
                "valid": data.get("is_active", False),
                "user_id": data.get("user_id"),
                "email": data.get("email"),
                "roles": data.get("roles", []),
                "reason": "User validated successfully" if data.get("is_active") else "User inactive"
            }
            
            self._record_success()
            logger.info(f"Validated user {user_id}")
            
            return result
            
        except Exception as e:
            self._record_failure()
            logger.error(f"Error validating user {user_id}: {e}")
            return {"valid": False, "reason": f"Validation error: {str(e)}"}
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Enhanced health check with circuit breaker consideration
        """
        if self._is_circuit_open():
            return {
                "status": "circuit_open",
                "circuit_open_until": self._circuit_open_until.isoformat(),
                "failures": self._failures
            }
        
        try:
            client = await self._get_client()
            start_time = datetime.utcnow()
            
            response = await client.get("/health", timeout=5.0)
            
            response_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            
            if response.status_code == 200:
                result = {
                    "status": "healthy",
                    "response_time_ms": response_time,
                    "poll_management_version": response.json().get("version", "unknown"),
                    "failures": self._failures,
                    "cache_size": len(self._poll_cache)
                }
                self._record_success()
                return result
            else:
                self._record_failure()
                return {
                    "status": "unhealthy",
                    "status_code": response.status_code,
                    "response": response.text[:200],
                    "failures": self._failures
                }
                
        except Exception as e:
            self._record_failure()
            logger.error(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "failures": self._failures
            }
    
    async def batch_get_public_keys(
        self, 
        trusted_party_ids: List[int], 
        poll_id: int
    ) -> List[Dict[str, Any]]:
        """
        Enhanced batch operation with parallel requests and error handling
        """
        if self._is_circuit_open():
            raise PollManagementClientError("Circuit breaker open - service unavailable")
        
        # Limit concurrent requests to avoid overwhelming the service
        semaphore = asyncio.Semaphore(5)
        
        async def get_single_key(tp_id: int) -> Dict[str, Any]:
            async with semaphore:
                try:
                    info = await self.get_trusted_party_info(tp_id, poll_id)
                    return {
                        "trusted_party_id": tp_id,
                        "public_key": info.get("public_key"),
                        "success": True
                    }
                except Exception as e:
                    logger.warning(f"Failed to get public key for trusted party {tp_id}: {e}")
                    return {
                        "trusted_party_id": tp_id,
                        "public_key": None,
                        "success": False,
                        "error": str(e)
                    }
        
        # Execute requests in parallel
        tasks = [get_single_key(tp_id) for tp_id in trusted_party_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle any exceptions
        final_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                final_results.append({
                    "trusted_party_id": trusted_party_ids[i],
                    "public_key": None,
                    "success": False,
                    "error": str(result)
                })
            else:
                final_results.append(result)
        
        return final_results
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics for monitoring"""
        return {
            "cached_polls": len(self._poll_cache),
            "cache_ttl_seconds": self._cache_ttl.total_seconds(),
            "cache_timestamps": {
                str(poll_id): timestamp.isoformat() 
                for poll_id, timestamp in self._cache_timestamps.items()
            }
        }
    
    def clear_cache(self):
        """Clear all cached data"""
        self._poll_cache.clear()
        self._cache_timestamps.clear()
        logger.info("Poll Management Client cache cleared")
    
    async def __aenter__(self):
        """Async context manager entry"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()


# Singleton instance for dependency injection
_poll_client_instance: Optional[PollManagementClient] = None


def get_poll_client() -> PollManagementClient:
    """Get singleton instance of Poll Management Client"""
    global _poll_client_instance
    if _poll_client_instance is None:
        _poll_client_instance = PollManagementClient()
    return _poll_client_instance


async def close_poll_client():
    """Close singleton Poll Management Client"""
    global _poll_client_instance
    if _poll_client_instance:
        await _poll_client_instance.close()
        _poll_client_instance = None