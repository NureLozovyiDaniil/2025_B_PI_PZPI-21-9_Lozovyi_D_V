package middleware

import (
	"time"

	"gateway/internal/config"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// Manager centralizes all middleware configuration and creation
type Manager struct {
	config *config.Config
	logger *zap.Logger
}

// New creates a new middleware manager
func New(cfg *config.Config, logger *zap.Logger) *Manager {
	return &Manager{
		config: cfg,
		logger: logger,
	}
}

// GetAuth returns the authentication middleware
func (m *Manager) GetAuth() gin.HandlerFunc {
	return Auth(m.config, m.logger)
}

// GetCORS returns the CORS middleware
func (m *Manager) GetCORS() gin.HandlerFunc {
	return CORS(&m.config.CORS, m.logger)
}

// GetRateLimit returns the rate limiting middleware
func (m *Manager) GetRateLimit() gin.HandlerFunc {
	return RateLimit(&m.config.RateLimit, m.logger)
}

// GetUserBasedRateLimit returns user-based rate limiting middleware
func (m *Manager) GetUserBasedRateLimit() gin.HandlerFunc {
	return UserBasedRateLimit(&m.config.RateLimit, m.logger)
}

// GetEndpointSpecificRateLimit returns endpoint-specific rate limiting middleware
func (m *Manager) GetEndpointSpecificRateLimit() gin.HandlerFunc {
	return EndpointSpecificRateLimit(m.logger)
}

// GetBurstProtection returns burst protection middleware
func (m *Manager) GetBurstProtection(maxBurst int, windowDuration time.Duration) gin.HandlerFunc {
	return BurstProtection(maxBurst, windowDuration, m.logger)
}

// GetRequestLogger returns request logging middleware
func (m *Manager) GetRequestLogger() gin.HandlerFunc {
	return RequestLogger(m.logger)
}

// GetErrorLogger returns error logging middleware
func (m *Manager) GetErrorLogger() gin.HandlerFunc {
	return ErrorLogger(m.logger)
}

// GetPerformanceLogger returns performance logging middleware
func (m *Manager) GetPerformanceLogger(threshold time.Duration) gin.HandlerFunc {
	return PerformanceLogger(m.logger, threshold)
}

// Role-based middleware functions

// GetRequireRole returns role requirement middleware
func (m *Manager) GetRequireRole(role string) gin.HandlerFunc {
	return RequireRole(role, m.logger)
}

// GetRequireAnyRole returns any-role requirement middleware
func (m *Manager) GetRequireAnyRole(roles []string) gin.HandlerFunc {
	return RequireAnyRole(roles, m.logger)
}

// GetRequirePremium returns premium requirement middleware
func (m *Manager) GetRequirePremium() gin.HandlerFunc {
	return RequirePremium(m.logger)
}

// GetRequireAdmin returns admin requirement middleware
func (m *Manager) GetRequireAdmin() gin.HandlerFunc {
	return RequireAdmin(m.logger)
}
