package middleware

import (
	"net/http"
	"strconv"
	"strings"
	_ "time"

	"gateway/internal/config"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// CORS middleware with configurable settings
func CORS(cfg *config.CORSConfig, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := c.Request.Header.Get("Origin")

		// Check if origin is allowed
		if origin != "" && isOriginAllowed(origin, cfg.AllowedOrigins) {
			c.Header("Access-Control-Allow-Origin", origin)
		} else if containsWildcard(cfg.AllowedOrigins) {
			c.Header("Access-Control-Allow-Origin", "*")
		}

		// Set allowed methods
		if len(cfg.AllowedMethods) > 0 {
			c.Header("Access-Control-Allow-Methods", strings.Join(cfg.AllowedMethods, ", "))
		}

		// Set allowed headers
		if len(cfg.AllowedHeaders) > 0 {
			if containsWildcard(cfg.AllowedHeaders) {
				// If wildcard is present, echo back the requested headers
				if requestedHeaders := c.Request.Header.Get("Access-Control-Request-Headers"); requestedHeaders != "" {
					c.Header("Access-Control-Allow-Headers", requestedHeaders)
				} else {
					c.Header("Access-Control-Allow-Headers", "*")
				}
			} else {
				c.Header("Access-Control-Allow-Headers", strings.Join(cfg.AllowedHeaders, ", "))
			}
		}

		// Set exposed headers
		if len(cfg.ExposedHeaders) > 0 {
			c.Header("Access-Control-Expose-Headers", strings.Join(cfg.ExposedHeaders, ", "))
		}

		// Set credentials
		if cfg.AllowCredentials {
			c.Header("Access-Control-Allow-Credentials", "true")
		}

		// Set max age for preflight requests
		if cfg.MaxAge > 0 {
			c.Header("Access-Control-Max-Age", strconv.Itoa(cfg.MaxAge))
		}

		// Handle preflight OPTIONS request
		if c.Request.Method == "OPTIONS" {
			logger.Debug("handling CORS preflight request",
				zap.String("origin", origin),
				zap.String("method", c.Request.Header.Get("Access-Control-Request-Method")),
				zap.String("headers", c.Request.Header.Get("Access-Control-Request-Headers")))

			c.AbortWithStatus(http.StatusNoContent)
			return
		}

		c.Next()
	}
}

// CORSWithDefaults creates CORS middleware with sensible defaults for development
func CORSWithDefaults(logger *zap.Logger) gin.HandlerFunc {
	defaultConfig := &config.CORSConfig{
		AllowedOrigins: []string{
			"http://localhost:3000",
			"http://localhost:3001",
			"http://127.0.0.1:3000",
			"http://127.0.0.1:3001",
		},
		AllowedMethods: []string{
			"GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH",
		},
		AllowedHeaders: []string{
			"Origin", "Content-Type", "Accept", "Authorization",
			"X-Requested-With", "X-Request-ID",
		},
		ExposedHeaders: []string{
			"X-Request-ID", "X-Response-Time",
		},
		AllowCredentials: true,
		MaxAge:           86400, // 24 hours
	}

	return CORS(defaultConfig, logger)
}

// RestrictiveCORS creates CORS middleware with more restrictive settings for production
func RestrictiveCORS(allowedOrigins []string, logger *zap.Logger) gin.HandlerFunc {
	if len(allowedOrigins) == 0 {
		logger.Warn("no allowed origins specified for restrictive CORS, using localhost")
		allowedOrigins = []string{"http://localhost:3000"}
	}

	restrictiveConfig := &config.CORSConfig{
		AllowedOrigins: allowedOrigins,
		AllowedMethods: []string{
			"GET", "POST", "PUT", "DELETE", "OPTIONS",
		},
		AllowedHeaders: []string{
			"Origin", "Content-Type", "Accept", "Authorization",
		},
		ExposedHeaders: []string{
			"X-Request-ID",
		},
		AllowCredentials: true,
		MaxAge:           3600, // 1 hour
	}

	return CORS(restrictiveConfig, logger)
}

// SecurityHeaders adds security-related headers
func SecurityHeaders() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Security headers
		c.Header("X-Content-Type-Options", "nosniff")
		c.Header("X-Frame-Options", "DENY")
		c.Header("X-XSS-Protection", "1; mode=block")
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")

		// Don't cache sensitive endpoints
		if isSensitiveEndpoint(c.FullPath()) {
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			c.Header("Pragma", "no-cache")
			c.Header("Expires", "0")
		}

		c.Next()
	}
}

// CSPHeader adds Content Security Policy header
func CSPHeader(isDevelopment bool) gin.HandlerFunc {
	return func(c *gin.Context) {
		var csp string

		if isDevelopment {
			// More relaxed CSP for development
			csp = "default-src 'self' 'unsafe-inline' 'unsafe-eval' http://localhost:* ws://localhost:*; " +
				"connect-src 'self' http://localhost:* ws://localhost:*; " +
				"font-src 'self' data:; " +
				"img-src 'self' data: blob:; " +
				"style-src 'self' 'unsafe-inline'"
		} else {
			// Strict CSP for production
			csp = "default-src 'self'; " +
				"script-src 'self'; " +
				"style-src 'self' 'unsafe-inline'; " +
				"font-src 'self'; " +
				"img-src 'self' data:; " +
				"connect-src 'self'; " +
				"frame-ancestors 'none'"
		}

		c.Header("Content-Security-Policy", csp)
		c.Next()
	}
}

// Helper functions

func isOriginAllowed(origin string, allowedOrigins []string) bool {
	for _, allowed := range allowedOrigins {
		if allowed == "*" || allowed == origin {
			return true
		}

		// Support wildcard subdomains like *.example.com
		if strings.HasPrefix(allowed, "*.") {
			domain := strings.TrimPrefix(allowed, "*.")
			if strings.HasSuffix(origin, domain) {
				return true
			}
		}
	}
	return false
}

func containsWildcard(slice []string) bool {
	for _, item := range slice {
		if item == "*" {
			return true
		}
	}
	return false
}

func isSensitiveEndpoint(path string) bool {
	sensitivePatterns := []string{
		"/api/v1/auth/login",
		"/api/v1/auth/register",
		"/api/v1/admin",
		"/api/v1/verification",
		"/api/v1/blockchain",
		"/api/v1/user-roles",
	}

	for _, pattern := range sensitivePatterns {
		if strings.Contains(path, pattern) {
			return true
		}
	}
	return false
}
