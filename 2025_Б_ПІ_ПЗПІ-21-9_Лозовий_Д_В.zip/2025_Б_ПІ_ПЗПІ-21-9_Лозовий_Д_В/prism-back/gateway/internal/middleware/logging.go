package middleware

import (
	"bytes"
	"go.uber.org/zap/zapcore"
	"io"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"go.uber.org/zap"
)

// RequestIDMiddleware adds unique request ID to each request
func RequestID() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Check if request ID already exists (from external load balancer)
		requestID := c.GetHeader("X-Request-ID")
		if requestID == "" {
			requestID = uuid.New().String()
		}

		// Set request ID in context and headers
		c.Set("requestID", requestID)
		c.Header("X-Request-ID", requestID)

		c.Next()
	}
}

// RequestLogger creates a logging middleware with structured logging
func RequestLogger(logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		method := c.Request.Method

		// Get request ID
		requestID, _ := c.Get("requestID")

		// Get user information if available
		userID := c.GetUint("userID")

		// Create request-scoped logger
		requestLogger := logger.With(
			zap.String("request_id", requestID.(string)),
			zap.String("method", method),
			zap.String("path", path),
			zap.String("user_agent", c.Request.UserAgent()),
			zap.String("remote_ip", c.ClientIP()),
		)

		// Add user ID if authenticated
		if userID > 0 {
			requestLogger = requestLogger.With(zap.Uint("user_id", userID))
		}

		// Log request start for important endpoints
		if shouldLogRequestStart(path) {
			requestLogger.Info("request started",
				zap.String("query", c.Request.URL.RawQuery),
				zap.Int64("content_length", c.Request.ContentLength))
		}

		// Process request
		c.Next()

		// Calculate duration
		duration := time.Since(start)
		statusCode := c.Writer.Status()

		// Get response size
		responseSize := c.Writer.Size()
		if responseSize < 0 {
			responseSize = 0
		}

		// Set response time header
		c.Header("X-Response-Time", duration.String())

		// Determine log level based on status code
		logLevel := getLogLevel(statusCode)

		// Prepare log fields
		fields := []zap.Field{
			zap.Int("status", statusCode),
			zap.Duration("duration", duration),
			zap.Int("response_size", responseSize),
		}

		// Add error information if present
		if len(c.Errors) > 0 {
			fields = append(fields, zap.String("errors", c.Errors.String()))
		}

		// Log the request
		switch logLevel {
		case zap.ErrorLevel:
			requestLogger.Error("request completed with error", fields...)
		case zap.WarnLevel:
			requestLogger.Warn("request completed with warning", fields...)
		case zap.InfoLevel:
			requestLogger.Info("request completed", fields...)
		default:
			requestLogger.Debug("request completed", fields...)
		}
	}
}

// DetailedRequestLogger logs request and response bodies for debugging
func DetailedRequestLogger(logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		// Get request ID
		requestID, _ := c.Get("requestID")

		requestLogger := logger.With(
			zap.String("request_id", requestID.(string)),
			zap.String("method", c.Request.Method),
			zap.String("path", c.Request.URL.Path),
		)

		// Read and log request body for POST/PUT/PATCH requests
		var requestBody []byte
		if shouldLogRequestBody(c.Request.Method) {
			if c.Request.Body != nil {
				requestBody, _ = io.ReadAll(c.Request.Body)
				// Restore the body for further processing
				c.Request.Body = io.NopCloser(bytes.NewBuffer(requestBody))

				// Log request body (sanitized)
				if len(requestBody) > 0 {
					sanitizedBody := sanitizeLogData(string(requestBody))
					requestLogger.Debug("request body", zap.String("body", sanitizedBody))
				}
			}
		}

		// Capture response body
		responseBodyWriter := &responseBodyWriter{
			ResponseWriter: c.Writer,
			body:           &bytes.Buffer{},
		}
		c.Writer = responseBodyWriter

		// Process request
		c.Next()

		// Log response body for errors or debug mode
		statusCode := c.Writer.Status()
		if statusCode >= 400 || logger.Core().Enabled(zap.DebugLevel) {
			responseBody := responseBodyWriter.body.String()
			if responseBody != "" {
				sanitizedResponse := sanitizeLogData(responseBody)
				requestLogger.Debug("response body",
					zap.String("body", sanitizedResponse),
					zap.Int("status", statusCode))
			}
		}

		duration := time.Since(start)
		requestLogger.Info("detailed request completed",
			zap.Int("status", statusCode),
			zap.Duration("duration", duration),
			zap.Int("request_size", len(requestBody)),
			zap.Int("response_size", responseBodyWriter.body.Len()))
	}
}

// ErrorLogger middleware to log application errors
func ErrorLogger(logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Next()

		// Log any errors that occurred during request processing
		for _, err := range c.Errors {
			requestID, _ := c.Get("requestID")
			userID := c.GetUint("userID")

			errorLogger := logger.With(
				zap.String("request_id", requestID.(string)),
				zap.String("method", c.Request.Method),
				zap.String("path", c.Request.URL.Path),
				zap.Int("status", c.Writer.Status()),
			)

			if userID > 0 {
				errorLogger = errorLogger.With(zap.Uint("user_id", userID))
			}

			switch err.Type {
			case gin.ErrorTypeBind:
				errorLogger.Warn("request binding error", zap.Error(err.Err))
			case gin.ErrorTypePublic:
				errorLogger.Info("public error", zap.Error(err.Err))
			case gin.ErrorTypePrivate:
				errorLogger.Error("private error", zap.Error(err.Err))
			default:
				errorLogger.Error("unhandled error", zap.Error(err.Err))
			}
		}
	}
}

// PerformanceLogger logs slow requests
func PerformanceLogger(logger *zap.Logger, slowThreshold time.Duration) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		c.Next()

		duration := time.Since(start)

		// Log slow requests
		if duration > slowThreshold {
			requestID, _ := c.Get("requestID")

			logger.Warn("slow request detected",
				zap.String("request_id", requestID.(string)),
				zap.String("method", c.Request.Method),
				zap.String("path", c.Request.URL.Path),
				zap.Duration("duration", duration),
				zap.Duration("threshold", slowThreshold),
				zap.Int("status", c.Writer.Status()))
		}
	}
}

// Helper types and functions

type responseBodyWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w *responseBodyWriter) Write(b []byte) (int, error) {
	w.body.Write(b)
	return w.ResponseWriter.Write(b)
}

func getLogLevel(statusCode int) zapcore.Level {
	switch {
	case statusCode >= 500:
		return zap.ErrorLevel
	case statusCode >= 400:
		return zap.WarnLevel
	case statusCode >= 200:
		return zap.InfoLevel
	default:
		return zap.DebugLevel
	}
}

func shouldLogRequestStart(path string) bool {
	importantPaths := []string{
		"/api/v1/auth/login",
		"/api/v1/auth/register",
		"/api/v1/polls",
		"/api/v1/votes",
		"/api/v1/verification",
		"/api/v1/blockchain",
	}

	for _, importantPath := range importantPaths {
		if strings.HasPrefix(path, importantPath) {
			return true
		}
	}
	return false
}

func shouldLogRequestBody(method string) bool {
	return method == "POST" || method == "PUT" || method == "PATCH"
}

func sanitizeLogData(data string) string {
	// Remove sensitive information from logs
	sensitiveFields := []string{
		"password", "token", "secret", "key", "private_key",
		"authorization", "cookie", "session",
	}

	result := data
	for _, field := range sensitiveFields {
		// Simple regex-like replacement for JSON fields
		if strings.Contains(strings.ToLower(result), `"`+field+`"`) {
			// This is a simplified sanitization - in production you might want more sophisticated regex
			result = strings.ReplaceAll(result, field, "[REDACTED]")
		}
	}

	// Truncate very long data
	if len(result) > 1000 {
		result = result[:1000] + "... [TRUNCATED]"
	}

	return result
}
