package middleware

import (
	"fmt"
	"net/http"
	"strconv"
	"sync"
	"time"

	"gateway/internal/config"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"golang.org/x/time/rate"
)

// RateLimiter manages rate limiting for different keys
type RateLimiter struct {
	limiters map[string]*rate.Limiter
	mutex    sync.RWMutex
	rate     rate.Limit
	burst    int
	cleanup  time.Duration
	logger   *zap.Logger
}

// NewRateLimiter creates a new rate limiter
func NewRateLimiter(requestsPerSecond float64, burstSize int, logger *zap.Logger) *RateLimiter {
	rl := &RateLimiter{
		limiters: make(map[string]*rate.Limiter),
		rate:     rate.Limit(requestsPerSecond),
		burst:    burstSize,
		cleanup:  time.Minute * 5, // Clean up old limiters every 5 minutes
		logger:   logger,
	}

	// Start cleanup goroutine
	go rl.cleanupRoutine()

	return rl
}

// getLimiter returns a rate limiter for the given key
func (rl *RateLimiter) getLimiter(key string) *rate.Limiter {
	rl.mutex.RLock()
	limiter, exists := rl.limiters[key]
	rl.mutex.RUnlock()

	if exists {
		return limiter
	}

	// Create new limiter
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	// Double-check after acquiring write lock
	if limiter, exists := rl.limiters[key]; exists {
		return limiter
	}

	limiter = rate.NewLimiter(rl.rate, rl.burst)
	rl.limiters[key] = limiter
	return limiter
}

// cleanupRoutine removes old unused limiters
func (rl *RateLimiter) cleanupRoutine() {
	ticker := time.NewTicker(rl.cleanup)
	defer ticker.Stop()

	for range ticker.C {
		rl.mutex.Lock()
		for key, limiter := range rl.limiters {
			// Remove limiters that haven't been used recently
			if limiter.Tokens() == float64(rl.burst) {
				delete(rl.limiters, key)
			}
		}
		rl.mutex.Unlock()
	}
}

// RateLimit creates a rate limiting middleware
func RateLimit(cfg *config.RateLimitConfig, logger *zap.Logger) gin.HandlerFunc {
	if !cfg.Enabled {
		return func(c *gin.Context) {
			c.Next()
		}
	}

	limiter := NewRateLimiter(cfg.RequestsPerSecond, cfg.BurstSize, logger)

	return func(c *gin.Context) {
		// Use client IP as the key for rate limiting
		key := c.ClientIP()

		// Get rate limiter for this client
		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("client_ip", key),
				zap.String("path", c.Request.URL.Path),
				zap.String("method", c.Request.Method))

			c.Header("X-RateLimit-Limit", strconv.FormatFloat(cfg.RequestsPerSecond, 'f', 2, 64))
			c.Header("X-RateLimit-Remaining", "0")
			c.Header("X-RateLimit-Reset", strconv.FormatInt(time.Now().Add(time.Second).Unix(), 10))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_RATE_LIMIT_EXCEEDED",
					"message": "Rate limit exceeded. Please slow down your requests.",
				},
			})
			c.Abort()
			return
		}

		// Add rate limit headers
		remaining := int(clientLimiter.Tokens())
		c.Header("X-RateLimit-Limit", strconv.FormatFloat(cfg.RequestsPerSecond, 'f', 2, 64))
		c.Header("X-RateLimit-Remaining", strconv.Itoa(remaining))

		c.Next()
	}
}

// UserBasedRateLimit creates a rate limiter based on authenticated user ID
func UserBasedRateLimit(cfg *config.RateLimitConfig, logger *zap.Logger) gin.HandlerFunc {
	if !cfg.Enabled {
		return func(c *gin.Context) {
			c.Next()
		}
	}

	limiter := NewRateLimiter(cfg.RequestsPerSecond, cfg.BurstSize, logger)

	return func(c *gin.Context) {
		var key string

		// Try to get user ID from context (after auth middleware)
		if userID := c.GetUint("userID"); userID > 0 {
			key = fmt.Sprintf("user:%d", userID)
		} else {
			// Fall back to IP-based limiting for unauthenticated users
			key = fmt.Sprintf("ip:%s", c.ClientIP())
		}

		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("user rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("key", key),
				zap.String("path", c.Request.URL.Path))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_USER_RATE_LIMIT_EXCEEDED",
					"message": "User rate limit exceeded. Please slow down your requests.",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// EndpointSpecificRateLimit creates different rate limits for different endpoints
func EndpointSpecificRateLimit(logger *zap.Logger) gin.HandlerFunc {
	// Different limits for different endpoint categories
	limiters := map[string]*RateLimiter{
		"auth":         NewRateLimiter(5, 10, logger),   // 5 req/sec for auth endpoints
		"polls":        NewRateLimiter(20, 30, logger),  // 20 req/sec for polls
		"votes":        NewRateLimiter(10, 15, logger),  // 10 req/sec for voting
		"verification": NewRateLimiter(2, 5, logger),    // 2 req/sec for verification (crypto-heavy)
		"blockchain":   NewRateLimiter(1, 3, logger),    // 1 req/sec for blockchain operations
		"default":      NewRateLimiter(50, 100, logger), // Default limits
	}

	return func(c *gin.Context) {
		path := c.Request.URL.Path
		category := getEndpointCategory(path)

		limiter := limiters[category]
		if limiter == nil {
			limiter = limiters["default"]
		}

		// Use combination of user ID and endpoint category as key
		var key string
		if userID := c.GetUint("userID"); userID > 0 {
			key = fmt.Sprintf("%s:user:%d", category, userID)
		} else {
			key = fmt.Sprintf("%s:ip:%s", category, c.ClientIP())
		}

		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("endpoint-specific rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("category", category),
				zap.String("key", key),
				zap.String("path", path))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_ENDPOINT_RATE_LIMIT_EXCEEDED",
					"message": fmt.Sprintf("Rate limit exceeded for %s operations", category),
				},
			})
			c.Abort()
			return
		}

		// Add category-specific headers
		remaining := int(clientLimiter.Tokens())
		c.Header("X-RateLimit-Category", category)
		c.Header("X-RateLimit-Remaining", strconv.Itoa(remaining))

		c.Next()
	}
}

// BurstProtection provides additional protection against burst attacks
func BurstProtection(maxBurst int, windowDuration time.Duration, logger *zap.Logger) gin.HandlerFunc {
	type clientData struct {
		requests []time.Time
		mutex    sync.Mutex
	}

	clients := make(map[string]*clientData)
	clientsMutex := sync.RWMutex{}

	// Cleanup routine
	go func() {
		ticker := time.NewTicker(windowDuration)
		defer ticker.Stop()

		for range ticker.C {
			now := time.Now()
			clientsMutex.Lock()
			for key, data := range clients {
				data.mutex.Lock()
				// Remove old requests
				validRequests := []time.Time{}
				for _, req := range data.requests {
					if now.Sub(req) < windowDuration {
						validRequests = append(validRequests, req)
					}
				}
				data.requests = validRequests

				// Remove client if no recent requests
				if len(validRequests) == 0 {
					delete(clients, key)
				}
				data.mutex.Unlock()
			}
			clientsMutex.Unlock()
		}
	}()

	return func(c *gin.Context) {
		clientIP := c.ClientIP()
		now := time.Now()

		clientsMutex.RLock()
		client, exists := clients[clientIP]
		clientsMutex.RUnlock()

		if !exists {
			clientsMutex.Lock()
			client = &clientData{
				requests: []time.Time{},
			}
			clients[clientIP] = client
			clientsMutex.Unlock()
		}

		client.mutex.Lock()
		defer client.mutex.Unlock()

		// Remove old requests
		validRequests := []time.Time{}
		for _, req := range client.requests {
			if now.Sub(req) < windowDuration {
				validRequests = append(validRequests, req)
			}
		}
		client.requests = validRequests

		// Check if burst limit exceeded
		if len(client.requests) >= maxBurst {
			requestID, _ := c.Get("requestID")

			logger.Warn("burst protection triggered",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("client_ip", clientIP),
				zap.Int("requests_in_window", len(client.requests)),
				zap.Int("max_burst", maxBurst),
				zap.Duration("window", windowDuration))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_BURST_LIMIT_EXCEEDED",
					"message": "Too many requests in a short time. Please wait before retrying.",
				},
			})
			c.Abort()
			return
		}

		// Add current request
		client.requests = append(client.requests, now)

		c.Next()
	}
}

// Helper function to categorize endpoints
func getEndpointCategory(path string) string {
	switch {
	case contains(path, "/auth/"):
		return "auth"
	case contains(path, "/polls/"):
		return "polls"
	case contains(path, "/votes/"):
		return "votes"
	case contains(path, "/verification/"):
		return "verification"
	case contains(path, "/blockchain/"):
		return "blockchain"
	default:
		return "default"
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || (len(s) > len(substr) &&
		(s[:len(substr)] == substr || s[len(s)-len(substr):] == substr ||
			s[1:len(substr)+1] == substr)))
}
