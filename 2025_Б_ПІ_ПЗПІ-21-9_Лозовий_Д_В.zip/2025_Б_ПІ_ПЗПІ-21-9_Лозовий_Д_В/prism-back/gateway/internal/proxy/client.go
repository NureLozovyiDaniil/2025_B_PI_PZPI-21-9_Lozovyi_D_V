package proxy

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"gateway/internal/config"

	"go.uber.org/zap"
)

// ServiceClient represents a client for communicating with backend services
type ServiceClient struct {
	name         string
	baseURL      string
	httpClient   *http.Client
	config       config.ServiceConfig
	logger       *zap.Logger
	healthStatus sync.Map // map[string]bool for health status
}

// Client manages all service clients
type Client struct {
	services map[string]*ServiceClient
	logger   *zap.Logger
}

// NewClient creates a new proxy client with all configured services
func NewClient(servicesConfig config.ServicesConfig, logger *zap.Logger) *Client {
	client := &Client{
		services: make(map[string]*ServiceClient),
		logger:   logger,
	}

	// Initialize service clients
	client.services["identity"] = NewServiceClient("identity", servicesConfig.Identity, logger)
	client.services["poll"] = NewServiceClient("poll", servicesConfig.Poll, logger)
	client.services["verification"] = NewServiceClient("verification", servicesConfig.Verification, logger)
	client.services["blockchain"] = NewServiceClient("blockchain", servicesConfig.Blockchain, logger)

	// Start health check routine for all services
	client.startHealthChecks()

	return client
}

// NewServiceClient creates a new service client
func NewServiceClient(name string, cfg config.ServiceConfig, logger *zap.Logger) *ServiceClient {
	return &ServiceClient{
		name:    name,
		baseURL: cfg.BaseURL,
		config:  cfg,
		logger:  logger.With(zap.String("service", name)),
		httpClient: &http.Client{
			Timeout: cfg.Timeout,
			Transport: &http.Transport{
				MaxIdleConns:        100,
				MaxIdleConnsPerHost: 10,
				IdleConnTimeout:     90 * time.Second,
			},
		},
	}
}

// ProxyRequest forwards a request to the appropriate backend service
func (c *Client) ProxyRequest(serviceName string, originalReq *http.Request, requestID string) (*http.Response, error) {
	service, exists := c.services[serviceName]
	if !exists {
		return nil, fmt.Errorf("service %s not found", serviceName)
	}

	return service.ProxyRequest(originalReq, requestID)
}

// ProxyRequest forwards a request to the backend service with retry logic
func (sc *ServiceClient) ProxyRequest(originalReq *http.Request, requestID string) (*http.Response, error) {
	// Build target URL
	targetURL, err := sc.buildTargetURL(originalReq)
	if err != nil {
		return nil, fmt.Errorf("failed to build target URL: %w", err)
	}

	// Read and copy request body
	var bodyBytes []byte
	if originalReq.Body != nil {
		bodyBytes, err = io.ReadAll(originalReq.Body)
		if err != nil {
			return nil, fmt.Errorf("failed to read request body: %w", err)
		}
		originalReq.Body = io.NopCloser(bytes.NewReader(bodyBytes))
	}

	// Attempt request with retry logic
	var lastErr error
	for attempt := 0; attempt <= sc.config.MaxRetries; attempt++ {
		if attempt > 0 {
			sc.logger.Debug("retrying request",
				zap.String("request_id", requestID),
				zap.Int("attempt", attempt),
				zap.String("url", targetURL))

			time.Sleep(sc.config.RetryDelay)
		}

		// Create new request for each attempt
		req, err := sc.createProxyRequest(originalReq, targetURL, bodyBytes, requestID)
		if err != nil {
			lastErr = err
			continue
		}

		// Execute request
		resp, err := sc.httpClient.Do(req)
		if err != nil {
			lastErr = err
			sc.logger.Warn("request failed",
				zap.String("request_id", requestID),
				zap.Error(err),
				zap.Int("attempt", attempt+1))
			continue
		}

		// Check if we should retry based on status code
		if sc.shouldRetry(resp.StatusCode) && attempt < sc.config.MaxRetries {
			resp.Body.Close()
			lastErr = fmt.Errorf("received retryable status code: %d", resp.StatusCode)
			sc.logger.Warn("retryable response received",
				zap.String("request_id", requestID),
				zap.Int("status", resp.StatusCode),
				zap.Int("attempt", attempt+1))
			continue
		}

		// Success or non-retryable error
		sc.logger.Debug("request completed",
			zap.String("request_id", requestID),
			zap.String("method", originalReq.Method),
			zap.String("url", targetURL),
			zap.Int("status", resp.StatusCode),
			zap.Int("attempts", attempt+1))

		return resp, nil
	}

	return nil, fmt.Errorf("request failed after %d attempts: %w", sc.config.MaxRetries+1, lastErr)
}

// createProxyRequest creates a new HTTP request for proxying
func (sc *ServiceClient) createProxyRequest(originalReq *http.Request, targetURL string, bodyBytes []byte, requestID string) (*http.Request, error) {
	// Create new request
	var bodyReader io.Reader
	if len(bodyBytes) > 0 {
		bodyReader = bytes.NewReader(bodyBytes)
	}

	req, err := http.NewRequestWithContext(originalReq.Context(), originalReq.Method, targetURL, bodyReader)
	if err != nil {
		return nil, err
	}

	// Copy headers from original request
	sc.copyHeaders(originalReq, req)

	// Add proxy-specific headers
	req.Header.Set("X-Request-ID", requestID)
	req.Header.Set("X-Forwarded-For", originalReq.RemoteAddr)
	req.Header.Set("X-Forwarded-Proto", "http") // or https based on original
	req.Header.Set("X-Gateway-Service", sc.name)

	// Add service identification
	req.Header.Set("User-Agent", "api-gateway/1.0.0")

	return req, nil
}

// copyHeaders copies relevant headers from original request to proxy request
func (sc *ServiceClient) copyHeaders(from, to *http.Request) {
	// Headers to copy
	headersToProxy := []string{
		"Content-Type",
		"Content-Length",
		"Authorization",
		"Accept",
		"Accept-Encoding",
		"Accept-Language",
		"Cache-Control",
		"If-Match",
		"If-None-Match",
		"If-Modified-Since",
		"If-Unmodified-Since",
		"X-User-ID",
		"X-User-Roles",
	}

	for _, header := range headersToProxy {
		if value := from.Header.Get(header); value != "" {
			to.Header.Set(header, value)
		}
	}

	// Copy custom headers (X-* headers except those we set ourselves)
	for key, values := range from.Header {
		if strings.HasPrefix(key, "X-") &&
			key != "X-Request-ID" &&
			key != "X-Forwarded-For" &&
			key != "X-Forwarded-Proto" &&
			key != "X-Gateway-Service" {
			for _, value := range values {
				to.Header.Add(key, value)
			}
		}
	}
}

// buildTargetURL constructs the target URL for the backend service
func (sc *ServiceClient) buildTargetURL(req *http.Request) (string, error) {
	targetURL, err := url.Parse(sc.baseURL)
	if err != nil {
		return "", err
	}

	// Append the request path and query parameters
	targetURL.Path = req.URL.Path
	targetURL.RawQuery = req.URL.RawQuery

	return targetURL.String(), nil
}

// shouldRetry determines if a request should be retried based on status code
func (sc *ServiceClient) shouldRetry(statusCode int) bool {
	// Retry on server errors and specific client errors
	retryableStatuses := []int{
		http.StatusInternalServerError, // 500
		http.StatusBadGateway,          // 502
		http.StatusServiceUnavailable,  // 503
		http.StatusGatewayTimeout,      // 504
		http.StatusTooManyRequests,     // 429
	}

	for _, status := range retryableStatuses {
		if statusCode == status {
			return true
		}
	}

	return false
}

// HealthCheck performs a health check on the service
func (sc *ServiceClient) HealthCheck(ctx context.Context) error {
	healthURL := sc.baseURL + sc.config.HealthEndpoint

	req, err := http.NewRequestWithContext(ctx, "GET", healthURL, nil)
	if err != nil {
		return fmt.Errorf("failed to create health check request: %w", err)
	}

	// Set a shorter timeout for health checks
	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("health check request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		sc.healthStatus.Store("healthy", true)
		return nil
	}

	sc.healthStatus.Store("healthy", false)
	return fmt.Errorf("health check failed with status: %d", resp.StatusCode)
}

// IsHealthy returns the current health status of the service
func (sc *ServiceClient) IsHealthy() bool {
	if status, ok := sc.healthStatus.Load("healthy"); ok {
		return status.(bool)
	}
	return false
}

// startHealthChecks starts periodic health checks for all services
func (c *Client) startHealthChecks() {
	ticker := time.NewTicker(30 * time.Second) // Check every 30 seconds

	go func() {
		defer ticker.Stop()

		for range ticker.C {
			for name, service := range c.services {
				go func(serviceName string, svc *ServiceClient) {
					ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
					defer cancel()

					if err := svc.HealthCheck(ctx); err != nil {
						c.logger.Warn("service health check failed",
							zap.String("service", serviceName),
							zap.Error(err))
					} else {
						c.logger.Debug("service health check passed",
							zap.String("service", serviceName))
					}
				}(name, service)
			}
		}
	}()
}

// GetServiceHealth returns health status of all services
func (c *Client) GetServiceHealth() map[string]bool {
	health := make(map[string]bool)
	for name, service := range c.services {
		health[name] = service.IsHealthy()
	}
	return health
}

// Close closes all service clients
func (c *Client) Close() error {
	c.logger.Info("closing proxy clients")

	// Close HTTP clients
	for name, service := range c.services {
		if service.httpClient != nil {
			service.httpClient.CloseIdleConnections()
			c.logger.Debug("closed service client", zap.String("service", name))
		}
	}

	return nil
}

// GetService returns a specific service client
func (c *Client) GetService(name string) (*ServiceClient, bool) {
	service, exists := c.services[name]
	return service, exists
}
