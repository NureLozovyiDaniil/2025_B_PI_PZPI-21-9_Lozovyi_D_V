package config

import (
	"errors"
	"fmt"
	"time"

	"github.com/spf13/viper"
)

type Config struct {
	Environment   string          `mapstructure:"environment"`
	ServerAddress string          `mapstructure:"server_address"`
	LogLevel      string          `mapstructure:"log_level"`
	Server        ServerConfig    `mapstructure:"server"`
	JWT           JWTConfig       `mapstructure:"jwt"`
	RateLimit     RateLimitConfig `mapstructure:"rate_limit"`
	CORS          CORSConfig      `mapstructure:"cors"`
	Services      ServicesConfig  `mapstructure:"services"`
}

// ServerConfig contains HTTP server settings
type ServerConfig struct {
	ReadTimeout    int `mapstructure:"read_timeout"`
	WriteTimeout   int `mapstructure:"write_timeout"`
	IdleTimeout    int `mapstructure:"idle_timeout"`
	MaxHeaderBytes int `mapstructure:"max_header_bytes"`
}

// JWTConfig for token validation
type JWTConfig struct {
	SecretKey string `mapstructure:"secret_key"`
}

// RateLimitConfig for request rate limiting
type RateLimitConfig struct {
	RequestsPerSecond float64 `mapstructure:"requests_per_second"`
	BurstSize         int     `mapstructure:"burst_size"`
	Enabled           bool    `mapstructure:"enabled"`
}

// CORSConfig for CORS settings
type CORSConfig struct {
	AllowedOrigins   []string `mapstructure:"allowed_origins"`
	AllowedMethods   []string `mapstructure:"allowed_methods"`
	AllowedHeaders   []string `mapstructure:"allowed_headers"`
	ExposedHeaders   []string `mapstructure:"exposed_headers"`
	AllowCredentials bool     `mapstructure:"allow_credentials"`
	MaxAge           int      `mapstructure:"max_age"`
}

// ServicesConfig contains configuration for backend services
type ServicesConfig struct {
	Identity     ServiceConfig `mapstructure:"identity"`
	Poll         ServiceConfig `mapstructure:"poll"`
	Verification ServiceConfig `mapstructure:"verification"`
	Blockchain   ServiceConfig `mapstructure:"blockchain"`
}

// ServiceConfig contains configuration for individual service
type ServiceConfig struct {
	BaseURL        string        `mapstructure:"base_url"`
	Timeout        time.Duration `mapstructure:"timeout"`
	MaxRetries     int           `mapstructure:"max_retries"`
	RetryDelay     time.Duration `mapstructure:"retry_delay"`
	HealthEndpoint string        `mapstructure:"health_endpoint"`
}

// Load loads the configuration from config files and environment variables
func Load() (*Config, error) {
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")
	viper.AddConfigPath("internal/config")
	viper.AddConfigPath("./config")
	viper.AddConfigPath(".")

	// Set default values
	setDefaults()

	// Environment variables
	viper.AutomaticEnv()
	viper.SetEnvPrefix("GATEWAY")
	bindEnvironmentVariables()

	// Read config file
	if err := viper.ReadInConfig(); err != nil {
		var configFileNotFoundError viper.ConfigFileNotFoundError
		if !errors.As(err, &configFileNotFoundError) {
			return nil, fmt.Errorf("failed to read config file: %w", err)
		}
	}

	var cfg Config
	if err := viper.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}

	// Validate configuration
	if err := validateConfig(&cfg); err != nil {
		return nil, fmt.Errorf("invalid configuration: %w", err)
	}

	return &cfg, nil
}

// setDefaults sets default configuration values
func setDefaults() {
	// Server defaults
	viper.SetDefault("environment", "development")
	viper.SetDefault("server_address", ":8080")
	viper.SetDefault("log_level", "development")

	// Server timeouts
	viper.SetDefault("server.read_timeout", 30)
	viper.SetDefault("server.write_timeout", 30)
	viper.SetDefault("server.idle_timeout", 120)
	viper.SetDefault("server.max_header_bytes", 1048576) // 1MB

	// Rate limiting
	viper.SetDefault("rate_limit.enabled", true)
	viper.SetDefault("rate_limit.requests_per_second", 100.0)
	viper.SetDefault("rate_limit.burst_size", 50)

	// CORS defaults
	viper.SetDefault("cors.allowed_origins", []string{"*"})
	viper.SetDefault("cors.allowed_methods", []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"})
	viper.SetDefault("cors.allowed_headers", []string{"*"})
	viper.SetDefault("cors.allow_credentials", true)
	viper.SetDefault("cors.max_age", 86400) // 24 hours

	// Service defaults
	viper.SetDefault("services.identity.base_url", "http://localhost:8081")
	viper.SetDefault("services.identity.timeout", "30s")
	viper.SetDefault("services.identity.max_retries", 3)
	viper.SetDefault("services.identity.retry_delay", "1s")
	viper.SetDefault("services.identity.health_endpoint", "/health")

	viper.SetDefault("services.poll.base_url", "http://localhost:8082")
	viper.SetDefault("services.poll.timeout", "30s")
	viper.SetDefault("services.poll.max_retries", 3)
	viper.SetDefault("services.poll.retry_delay", "1s")
	viper.SetDefault("services.poll.health_endpoint", "/health")

	viper.SetDefault("services.verification.base_url", "http://localhost:8083")
	viper.SetDefault("services.verification.timeout", "60s") // Longer timeout for crypto operations
	viper.SetDefault("services.verification.max_retries", 2)
	viper.SetDefault("services.verification.retry_delay", "2s")
	viper.SetDefault("services.verification.health_endpoint", "/health")

	viper.SetDefault("services.blockchain.base_url", "http://localhost:8084")
	viper.SetDefault("services.blockchain.timeout", "60s") // Longer timeout for blockchain operations
	viper.SetDefault("services.blockchain.max_retries", 2)
	viper.SetDefault("services.blockchain.retry_delay", "3s")
	viper.SetDefault("services.blockchain.health_endpoint", "/health")
}

// bindEnvironmentVariables binds environment variables to viper keys
func bindEnvironmentVariables() {
	// Server
	viper.BindEnv("environment", "GATEWAY_ENVIRONMENT")
	viper.BindEnv("server_address", "GATEWAY_SERVER_ADDRESS")
	viper.BindEnv("log_level", "GATEWAY_LOG_LEVEL")

	// JWT
	viper.BindEnv("jwt.secret_key", "GATEWAY_JWT_SECRET")

	// Rate limiting
	viper.BindEnv("rate_limit.enabled", "GATEWAY_RATE_LIMIT_ENABLED")
	viper.BindEnv("rate_limit.requests_per_second", "GATEWAY_RATE_LIMIT_RPS")
	viper.BindEnv("rate_limit.burst_size", "GATEWAY_RATE_LIMIT_BURST")

	// Services
	viper.BindEnv("services.identity.base_url", "GATEWAY_IDENTITY_URL")
	viper.BindEnv("services.poll.base_url", "GATEWAY_POLL_URL")
	viper.BindEnv("services.verification.base_url", "GATEWAY_VERIFICATION_URL")
	viper.BindEnv("services.blockchain.base_url", "GATEWAY_BLOCKCHAIN_URL")
}

// validateConfig validates the configuration
func validateConfig(cfg *Config) error {
	if cfg.JWT.SecretKey == "" {
		return errors.New("JWT secret key is required")
	}

	if cfg.Services.Identity.BaseURL == "" {
		return errors.New("Identity service URL is required")
	}

	if cfg.Services.Poll.BaseURL == "" {
		return errors.New("Poll service URL is required")
	}

	if cfg.Services.Verification.BaseURL == "" {
		return errors.New("Verification service URL is required")
	}

	if cfg.Services.Blockchain.BaseURL == "" {
		return errors.New("Blockchain service URL is required")
	}

	if cfg.RateLimit.RequestsPerSecond <= 0 {
		return errors.New("rate limit requests per second must be positive")
	}

	if cfg.RateLimit.BurstSize <= 0 {
		return errors.New("rate limit burst size must be positive")
	}

	return nil
}
