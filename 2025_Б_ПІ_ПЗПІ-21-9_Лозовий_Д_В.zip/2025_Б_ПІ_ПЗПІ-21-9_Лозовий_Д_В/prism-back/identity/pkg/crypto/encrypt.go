package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"io"

	"github.com/ethereum/go-ethereum/crypto"
)

// EncryptionService handles encryption and decryption operations
type EncryptionService struct {
	serverKey string
}

// NewEncryptionService creates a new encryption service
func NewEncryptionService(serverKey string) *EncryptionService {
	return &EncryptionService{
		serverKey: serverKey,
	}
}

// Encrypt encrypts data using AES-GCM
func (s *EncryptionService) Encrypt(data string) (string, error) {
	// Convert key to 32 bytes for AES-256
	key := []byte(s.serverKey)
	if len(key) < 32 {
		// Pad the key if it's too short
		key = append(key, make([]byte, 32-len(key))...)
	} else if len(key) > 32 {
		// Truncate the key if it's too long
		key = key[:32]
	}

	plaintext := []byte(data)

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, 12)
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	ciphertext := aesgcm.Seal(nil, nonce, plaintext, nil)

	// Prepend nonce to ciphertext and encode to base64
	encrypted := make([]byte, len(nonce)+len(ciphertext))
	copy(encrypted, nonce)
	copy(encrypted[len(nonce):], ciphertext)

	return base64.StdEncoding.EncodeToString(encrypted), nil
}

// Decrypt decrypts data using AES-GCM
func (s *EncryptionService) Decrypt(encryptedData string) (string, error) {
	// Convert key to 32 bytes for AES-256
	key := []byte(s.serverKey)
	if len(key) < 32 {
		// Pad the key if it's too short
		key = append(key, make([]byte, 32-len(key))...)
	} else if len(key) > 32 {
		// Truncate the key if it's too long
		key = key[:32]
	}

	ciphertext, err := base64.StdEncoding.DecodeString(encryptedData)
	if err != nil {
		return "", err
	}

	// Ensure we have enough data (at least the nonce)
	if len(ciphertext) < 12 {
		return "", errors.New("ciphertext too short")
	}

	// Split nonce and ciphertext
	nonce, ciphertext := ciphertext[:12], ciphertext[12:]

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	plaintext, err := aesgcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}

	return string(plaintext), nil
}

// GenerateRSAKeyPair generates a new RSA key pair
func (s *EncryptionService) GenerateRSAKeyPair() (string, string, error) {
	// Generate a new RSA key pair
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return "", "", err
	}

	// Convert private key to PEM format
	privateKeyBytes := x509.MarshalPKCS1PrivateKey(privateKey)
	privateKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "RSA PRIVATE KEY",
			Bytes: privateKeyBytes,
		},
	)

	// Extract public key and convert to PEM format
	publicKeyBytes, err := x509.MarshalPKIXPublicKey(&privateKey.PublicKey)
	if err != nil {
		return "", "", err
	}
	publicKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "PUBLIC KEY",
			Bytes: publicKeyBytes,
		},
	)

	return string(publicKeyPEM), string(privateKeyPEM), nil
}

func (s *EncryptionService) GenerateECDSAKeyPair() (string, string, error) {
	privateKey, err := crypto.GenerateKey()
	if err != nil {
		return "", "", err
	}

	privateKeyBytes := crypto.FromECDSA(privateKey)
	privateKeyPEM := pem.EncodeToMemory(
		&pem.Block{
			Type:  "SECP256K1 PRIVATE KEY",
			Bytes: privateKeyBytes,
		},
	)

	publicKeyBytes := crypto.FromECDSAPub(&privateKey.PublicKey)
	publicKeyHex := hex.EncodeToString(publicKeyBytes[1:])

	return publicKeyHex, string(privateKeyPEM), nil
}
