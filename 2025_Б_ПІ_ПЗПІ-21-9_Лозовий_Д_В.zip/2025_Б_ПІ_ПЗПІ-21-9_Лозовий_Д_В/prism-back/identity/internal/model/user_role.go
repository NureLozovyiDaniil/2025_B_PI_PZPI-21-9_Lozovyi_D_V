package model

import "time"

// UserRole represents the many-to-many relationship between users and roles
type UserRole struct {
	UserID     uint       `gorm:"primaryKey" json:"user_id"`
	RoleID     uint       `gorm:"primaryKey" json:"role_id"`
	AssignedAt time.Time  `json:"assigned_at"`
	AssignedBy uint       `json:"assigned_by"`
	ExpiresAt  *time.Time `json:"expires_at"`
	IsActive   bool       `gorm:"default:true" json:"is_active"`
}

// UserRoleAssign is a DTO for assigning a role to a user
type UserRoleAssign struct {
	UserID    uint       `json:"user_id" binding:"required"`
	RoleID    uint       `json:"role_id" binding:"required"`
	ExpiresAt *time.Time `json:"expires_at"`
}

// UserRoleExtend is a DTO for extending a role expiration
type UserRoleExtend struct {
	ExpiresAt time.Time `json:"expires_at" binding:"required"`
}
