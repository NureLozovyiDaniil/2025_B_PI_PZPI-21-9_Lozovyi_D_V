package model

import "time"

// Role represents a role in the system
type Role struct {
	ID          uint      `gorm:"primaryKey" json:"id"`
	Code        string    `gorm:"uniqueIndex;size:50" json:"code"`
	Name        string    `gorm:"size:100" json:"name"`
	Description string    `gorm:"type:text" json:"description"`
	Permissions string    `gorm:"type:text" json:"permissions"` // JSON string with permissions
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	Users       []User    `gorm:"many2many:user_roles;" json:"-"`
}

// RoleCreate is a DTO for role creation
type RoleCreate struct {
	Code        string `json:"code" binding:"required,alphanum,max=50"`
	Name        string `json:"name" binding:"required,max=100"`
	Description string `json:"description"`
	Permissions string `json:"permissions"`
}

// RoleUpdate is a DTO for role update
type RoleUpdate struct {
	Name        string `json:"name" binding:"omitempty,max=100"`
	Description string `json:"description"`
	Permissions string `json:"permissions"`
}
