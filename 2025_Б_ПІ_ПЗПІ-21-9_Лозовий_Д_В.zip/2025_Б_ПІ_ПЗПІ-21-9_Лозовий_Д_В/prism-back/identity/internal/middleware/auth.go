package middleware

import (
	"identity-api/internal/service"
	"net/http"
	"strconv"
	"strings"

	"github.com/casbin/casbin/v2"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// Auth middleware for token validation
func Auth(authService service.AuthService) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Extract token from Authorization header
		header := c.GetHeader("Authorization")
		if header == "" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_MISSING_TOKEN",
					"message": "Authorization header is required",
				},
			})
			c.Abort()
			return
		}

		headerParts := strings.Split(header, " ")
		if len(headerParts) != 2 || headerParts[0] != "Bearer" {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN_FORMAT",
					"message": "Invalid authorization header format",
				},
			})
			c.Abort()
			return
		}

		token := headerParts[1]

		// Parse token and get user ID and roles
		userID, roles, err := authService.ParseToken(token)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN",
					"message": "Invalid or expired token",
				},
			})
			c.Abort()
			return
		}

		// Set user data in context for further use
		c.Set("userID", userID)
		c.Set("roles", roles)

		// Extract permissions from roles and set in context
		permissions := extractPermissionsFromRoles(roles)
		c.Set("permissions", permissions)

		c.Next()
	}
}

func InternalAPI(secretKey string) gin.HandlerFunc {
	return func(c *gin.Context) {
		apiKey := c.GetHeader("X-Internal-API-Key")
		if apiKey == secretKey {
			c.Next()
		} else {
			c.JSON(http.StatusUnauthorized, gin.H{})
		}
	}
}

// RequireRole middleware for checking specific roles
func RequireRole(requiredRole string) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		// Check if user has required role
		hasRole := false
		for _, role := range rolesList {
			if role == requiredRole {
				hasRole = true
				break
			}
		}

		if !hasRole {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": "Required role not found",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// RequirePermission middleware for checking specific permissions using Casbin
func RequirePermission(enforcer *casbin.Enforcer, resource, action string) gin.HandlerFunc {
	return func(c *gin.Context) {
		userID, exists := c.Get("userID")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_NO_ROLES",
					"message": "User has no roles assigned",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		// Check permission for each role using Casbin
		hasPermission := false
		for _, role := range rolesList {
			allowed, err := enforcer.Enforce(role, resource, action)
			if err != nil {
				// Log error but continue checking other roles
				continue
			}
			if allowed {
				hasPermission = true
				break
			}
		}

		// Also check direct user permissions if configured
		if !hasPermission {
			userIDStr := userID.(uint)
			allowed, err := enforcer.Enforce(userIDStr, resource, action)
			if err == nil && allowed {
				hasPermission = true
			}
		}

		if !hasPermission {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_PERMISSIONS",
					"message": "Insufficient permissions for this action",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// RequireAnyRole middleware for checking if user has any of the specified roles
func RequireAnyRole(requiredRoles ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		// Check if user has any of the required roles
		hasRole := false
		for _, userRole := range rolesList {
			for _, requiredRole := range requiredRoles {
				if userRole == requiredRole {
					hasRole = true
					break
				}
			}
			if hasRole {
				break
			}
		}

		if !hasRole {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": "Required role not found",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// RequireSelfOrAdmin middleware to allow access to own resources or admin
func RequireSelfOrAdmin() gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetUint("userID")
		if userID == 0 {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		// Get target user ID from URL parameter
		targetUserIDStr := c.Param("id")
		if targetUserIDStr == "" {
			// If no ID in URL, allow (probably accessing own resource like /me)
			c.Next()
			return
		}

		// Check if user is accessing their own resource
		if targetUserIDStr == "me" || targetUserIDStr == strconv.Itoa(int(userID)) {
			c.Next()
			return
		}

		// Check if user has admin role
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_ACCESS_DENIED",
					"message": "Access denied",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		isAdmin := false
		for _, role := range rolesList {
			if role == "admin" || role == "super_admin" {
				isAdmin = true
				break
			}
		}

		if !isAdmin {
			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_ACCESS_DENIED",
					"message": "Access denied: admin role required",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// extractPermissionsFromRoles extracts permissions from role data
func extractPermissionsFromRoles(roles []string) []string {
	// This is a simplified version - in real implementation,
	// you would fetch role permissions from database
	permissionMap := map[string][]string{
		"admin":       {"users:read", "users:write", "users:delete", "roles:read", "roles:write", "roles:delete"},
		"moderator":   {"users:read", "users:write", "roles:read"},
		"user":        {"users:read"},
		"premium":     {"users:read", "polls:create_private"},
		"super_admin": {"*:*"}, // All permissions
	}

	var permissions []string
	permissionSet := make(map[string]bool)

	for _, role := range roles {
		if rolePermissions, exists := permissionMap[role]; exists {
			for _, permission := range rolePermissions {
				if !permissionSet[permission] {
					permissions = append(permissions, permission)
					permissionSet[permission] = true
				}
			}
		}
	}

	return permissions
}

// AuthWithLogger creates auth middleware with logger
func AuthWithLogger(authService service.AuthService, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Extract token from Authorization header
		header := c.GetHeader("Authorization")
		if header == "" {
			logger.Warn("missing authorization header", zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_MISSING_TOKEN",
					"message": "Authorization header is required",
				},
			})
			c.Abort()
			return
		}

		headerParts := strings.Split(header, " ")
		if len(headerParts) != 2 || headerParts[0] != "Bearer" {
			logger.Warn("invalid token format", zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN_FORMAT",
					"message": "Invalid authorization header format",
				},
			})
			c.Abort()
			return
		}

		token := headerParts[1]
		userID, roles, err := authService.ParseToken(token)
		if err != nil {
			logger.Warn("invalid token", zap.Error(err), zap.String("path", c.FullPath()))
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN",
					"message": "Invalid or expired token",
				},
			})
			c.Abort()
			return
		}

		// Log successful authentication for critical operations
		if strings.Contains(c.FullPath(), "/roles") || strings.Contains(c.FullPath(), "/user-roles") {
			logger.Info("authenticated request",
				zap.Uint("user_id", userID),
				zap.Strings("roles", roles),
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))
		}

		c.Set("userID", userID)
		c.Set("roles", roles)
		c.Set("permissions", extractPermissionsFromRoles(roles))

		c.Next()
	}
}
