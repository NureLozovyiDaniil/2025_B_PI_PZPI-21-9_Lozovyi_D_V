package handler

import (
	"errors"
	"identity-api/internal/model"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (h *Handler) validateVoter(c *gin.Context) {
	userId := c.GetUint("userID")
	roles, exists := c.Get("roles")
	if !exists {
		h.handleAuthError(c, errors.New("no roles in context"))
		return
	}

	user, err := h.services.User.GetByID(c.Request.Context(), userId)
	if err != nil {
		h.handleUserError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"user_id":   userId,
		"email":     user.Email,
		"is_active": user.Status == model.UserStatusActive,
		"can_vote":  true, //change later
		"roles":     roles,
	})
}

// register handles user registration
// POST /auth/register
func (h *Handler) register(c *gin.Context) {
	var input model.UserCreate
	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid registration request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	user, err := h.services.User.Create(c.Request.Context(), input)
	if err != nil {
		h.handleAuthError(c, err)
		return
	}

	h.logger.Info("user registered successfully", zap.String("email", user.Email), zap.Uint("id", user.ID))

	c.JSON(http.StatusCreated, gin.H{
		"data":    user.ToResponse(),
		"message": "User registered successfully",
	})
}

// login handles user authentication
// POST /auth/login
func (h *Handler) login(c *gin.Context) {
	var input struct {
		Email    string `json:"email" binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		h.logger.Warn("invalid login request", zap.Error(err))
		c.JSON(http.StatusBadRequest, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_INPUT",
				"message": "Invalid input format",
			},
		})
		return
	}

	token, err := h.services.Auth.Login(c.Request.Context(), input.Email, input.Password)
	if err != nil {
		h.handleAuthError(c, err)
		return
	}

	h.logger.Info("user logged in successfully", zap.String("email", input.Email))

	c.JSON(http.StatusOK, gin.H{
		"data": gin.H{
			"token": token,
		},
		"message": "Login successful",
	})
}

// handleAuthError handles authentication-specific errors
func (h *Handler) handleAuthError(c *gin.Context, err error) {
	switch err {
	case model.ErrUserAlreadyExists:
		h.logger.Warn("registration failed - user exists", zap.Error(err))
		c.JSON(http.StatusConflict, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_EXISTS",
				"message": "User with this email already exists",
			},
		})
	case model.ErrInvalidCredentials:
		h.logger.Warn("login failed - invalid credentials", zap.Error(err))
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": gin.H{
				"code":    "ERR_INVALID_CREDENTIALS",
				"message": "Invalid email or password",
			},
		})
	case model.ErrUserBlocked:
		h.logger.Warn("login failed - user blocked", zap.Error(err))
		c.JSON(http.StatusForbidden, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_BLOCKED",
				"message": "User account is blocked",
			},
		})
	case model.ErrUserInactive:
		h.logger.Warn("login failed - user inactive", zap.Error(err))
		c.JSON(http.StatusForbidden, gin.H{
			"error": gin.H{
				"code":    "ERR_USER_INACTIVE",
				"message": "User account is inactive",
			},
		})
	default:
		h.logger.Error("authentication error", zap.Error(err))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": gin.H{
				"code":    "ERR_INTERNAL",
				"message": err.Error(),
			},
		})
	}
}
