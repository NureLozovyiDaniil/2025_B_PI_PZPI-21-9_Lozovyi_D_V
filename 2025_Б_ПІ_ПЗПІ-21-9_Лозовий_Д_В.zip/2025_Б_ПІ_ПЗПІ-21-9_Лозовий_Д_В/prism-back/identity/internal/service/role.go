package service

import (
	"context"
	"encoding/json"
	"errors"
	"identity-api/internal/model"
	"identity-api/internal/repository"
	"time"

	"github.com/casbin/casbin/v2"
	"go.uber.org/zap"
)

type RoleImpl struct {
	roleRepo     repository.RoleRepository
	userRoleRepo repository.UserRoleRepository
	enforcer     *casbin.Enforcer
	logger       *zap.Logger
}

func NewRoleImpl(
	roleRepo repository.RoleRepository,
	userRoleRepo repository.UserRoleRepository,
	enforcer *casbin.Enforcer,
	logger *zap.Logger,
) *RoleImpl {
	return &RoleImpl{
		roleRepo:     roleRepo,
		userRoleRepo: userRoleRepo,
		enforcer:     enforcer,
		logger:       logger,
	}
}

// Create creates a new role in the system
func (s *RoleImpl) Create(ctx context.Context, input model.RoleCreate) (*model.Role, error) {
	// Check if role with this code already exists
	existingRole, _ := s.roleRepo.GetByCode(ctx, input.Code)
	if existingRole != nil {
		return nil, errors.New("role with this code already exists")
	}

	// Validate permissions JSON format if provided
	if input.Permissions != "" {
		if !s.isValidPermissionsJSON(input.Permissions) {
			return nil, errors.New("invalid permissions format")
		}
	}

	// Create role entity
	role := &model.Role{
		Code:        input.Code,
		Name:        input.Name,
		Description: input.Description,
		Permissions: input.Permissions,
	}

	if err := s.roleRepo.Create(ctx, role); err != nil {
		s.logger.Error("failed to create role", zap.Error(err))
		return nil, errors.New("failed to create role")
	}

	// Update Casbin policies if permissions are provided
	if input.Permissions != "" {
		s.updateCasbinPolicies(role.Code, input.Permissions)
	}

	s.logger.Info("role created successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return role, nil
}

// GetByID retrieves a role by its ID
func (s *RoleImpl) GetByID(ctx context.Context, id uint) (*model.Role, error) {
	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	return role, nil
}

// GetByCode retrieves a role by its code
func (s *RoleImpl) GetByCode(ctx context.Context, code string) (*model.Role, error) {
	role, err := s.roleRepo.GetByCode(ctx, code)
	if err != nil {
		return nil, err
	}
	return role, nil
}

// Update updates an existing role
func (s *RoleImpl) Update(ctx context.Context, id uint, input model.RoleUpdate) (*model.Role, error) {
	// Get existing role
	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}

	// Update fields if provided
	if input.Name != "" {
		role.Name = input.Name
	}

	if input.Description != "" {
		role.Description = input.Description
	}

	if input.Permissions != "" {
		if !s.isValidPermissionsJSON(input.Permissions) {
			return nil, errors.New("invalid permissions format")
		}
		role.Permissions = input.Permissions
	}

	// Save updated role
	if err := s.roleRepo.Update(ctx, role); err != nil {
		s.logger.Error("failed to update role", zap.Error(err))
		return nil, errors.New("failed to update role")
	}

	// Update Casbin policies if permissions changed
	if input.Permissions != "" {
		s.updateCasbinPolicies(role.Code, input.Permissions)
	}

	s.logger.Info("role updated successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return role, nil
}

// Delete removes a role from the system
func (s *RoleImpl) Delete(ctx context.Context, id uint) error {
	// Get role to check if it exists and get its code for Casbin cleanup
	role, err := s.roleRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}

	// Delete the role (this will cascade delete user_role entries due to FK constraint)
	if err := s.roleRepo.Delete(ctx, id); err != nil {
		s.logger.Error("failed to delete role", zap.Error(err))
		return errors.New("failed to delete role")
	}

	// Remove Casbin policies for this role
	if s.enforcer != nil {
		_, err = s.enforcer.RemoveFilteredPolicy(0, role.Code)
		if err != nil {
			s.logger.Error("failed to remove filtered policy", zap.Error(err))
			return errors.New("failed to remove filtered policy")
		}
	} else {
		s.logger.Warn("casbin enforcer not initialized, skipping policy removal")
	}

	s.logger.Info("role deleted successfully",
		zap.Uint("role_id", role.ID),
		zap.String("code", role.Code))

	return nil
}

// List retrieves all roles in the system
func (s *RoleImpl) List(ctx context.Context) ([]model.Role, error) {
	roles, err := s.roleRepo.List(ctx)
	if err != nil {
		s.logger.Error("failed to list roles", zap.Error(err))
		return nil, errors.New("failed to retrieve roles")
	}

	return roles, nil
}

// AssignRole assigns a role to a user with optional expiration
func (s *RoleImpl) AssignRole(ctx context.Context, userID, roleID, assignedBy uint, expiresAt *time.Time) error {
	// Check if role exists
	_, err := s.roleRepo.GetByID(ctx, roleID)
	if err != nil {
		return err
	}

	// Create user role assignment
	userRole := &model.UserRole{
		UserID:     userID,
		RoleID:     roleID,
		AssignedAt: time.Now(),
		AssignedBy: assignedBy,
		ExpiresAt:  expiresAt,
		IsActive:   true,
	}

	if err := s.userRoleRepo.Assign(ctx, userRole); err != nil {
		s.logger.Error("failed to assign role to user",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to assign role")
	}

	s.logger.Info("role assigned successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID),
		zap.Uint("assigned_by", assignedBy))

	return nil
}

// RevokeRole removes a role from a user
func (s *RoleImpl) RevokeRole(ctx context.Context, userID, roleID uint) error {
	if err := s.userRoleRepo.Revoke(ctx, userID, roleID); err != nil {
		s.logger.Error("failed to revoke role from user",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to revoke role")
	}

	s.logger.Info("role revoked successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID))

	return nil
}

// GetUserRoles retrieves all active roles for a user
func (s *RoleImpl) GetUserRoles(ctx context.Context, userID uint) ([]model.Role, error) {
	roles, err := s.userRoleRepo.GetUserRoles(ctx, userID)
	if err != nil {
		s.logger.Error("failed to get user roles",
			zap.Error(err),
			zap.Uint("user_id", userID))
		return nil, errors.New("failed to get user roles")
	}

	return roles, nil
}

// HasRole checks if a user has a specific role
func (s *RoleImpl) HasRole(ctx context.Context, userID uint, roleCode string) (bool, error) {
	hasRole, err := s.userRoleRepo.HasRole(ctx, userID, roleCode)
	if err != nil {
		s.logger.Error("failed to check user role",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.String("role_code", roleCode))
		return false, errors.New("failed to check user role")
	}

	return hasRole, nil
}

// ExtendRoleExpiration extends the expiration time of a user's role
func (s *RoleImpl) ExtendRoleExpiration(ctx context.Context, userID, roleID uint, expiresAt time.Time) error {
	if err := s.userRoleRepo.ExtendExpiration(ctx, userID, roleID, expiresAt); err != nil {
		s.logger.Error("failed to extend role expiration",
			zap.Error(err),
			zap.Uint("user_id", userID),
			zap.Uint("role_id", roleID))
		return errors.New("failed to extend role expiration")
	}

	s.logger.Info("role expiration extended successfully",
		zap.Uint("user_id", userID),
		zap.Uint("role_id", roleID),
		zap.Time("expires_at", expiresAt))

	return nil
}

// DeactivateExpiredRoles deactivates all expired role assignments
func (s *RoleImpl) DeactivateExpiredRoles(ctx context.Context) error {
	now := time.Now()

	if err := s.userRoleRepo.DeactivateExpiredRoles(ctx, now); err != nil {
		s.logger.Error("failed to deactivate expired roles", zap.Error(err))
		return errors.New("failed to deactivate expired roles")
	}

	s.logger.Info("expired roles deactivated successfully")
	return nil
}

// CheckPermission checks if a user has permission to perform a specific action
func (s *RoleImpl) CheckPermission(ctx context.Context, userID uint, resource, action string) (bool, error) {
	// Get user roles
	roles, err := s.GetUserRoles(ctx, userID)
	if err != nil {
		return false, err
	}

	// Check permission for each role using Casbin
	for _, role := range roles {
		if allowed, _ := s.enforcer.Enforce(role.Code, resource, action); allowed {
			return true, nil
		}
	}

	return false, nil
}

// StartExpirationChecker starts a background goroutine to check for expired roles
func (s *RoleImpl) StartExpirationChecker(ctx context.Context, interval time.Duration) {
	ticker := time.NewTicker(interval)
	go func() {
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				if err := s.DeactivateExpiredRoles(ctx); err != nil {
					s.logger.Error("failed to deactivate expired roles in background task", zap.Error(err))
				}
			case <-ctx.Done():
				s.logger.Info("role expiration checker stopped")
				return
			}
		}
	}()

	s.logger.Info("role expiration checker started", zap.Duration("interval", interval))
}

// Helper methods

// isValidPermissionsJSON validates if the permissions string is valid JSON
func (s *RoleImpl) isValidPermissionsJSON(permissions string) bool {
	var js json.RawMessage
	return json.Unmarshal([]byte(permissions), &js) == nil
}

// updateCasbinPolicies updates Casbin policies based on role permissions
func (s *RoleImpl) updateCasbinPolicies(roleCode, permissions string) {
	if s.enforcer == nil {
		s.logger.Error("casbin enforcer is not initialized",
			zap.String("role_code", roleCode))
		return
	}

	// Remove existing policies for this role
	s.enforcer.RemoveFilteredPolicy(0, roleCode)

	// Parse permissions JSON and add new policies
	var perms []string
	if err := json.Unmarshal([]byte(permissions), &perms); err != nil {
		s.logger.Error("failed to parse permissions JSON",
			zap.Error(err),
			zap.String("role_code", roleCode))
		return
	}

	// Add policies to Casbin
	for _, perm := range perms {
		// Parse permission format: "resource:action" or "*"
		if perm == "*" {
			// Admin permission - allow everything
			s.enforcer.AddPolicy(roleCode, "*", "*")
		} else {
			// Specific permission
			parts := splitPermission(perm)
			if len(parts) == 2 {
				s.enforcer.AddPolicy(roleCode, parts[0], parts[1])
			}
		}
	}

	// Save policies
	s.enforcer.SavePolicy()

	s.logger.Info("Updated Casbin policies for role",
		zap.String("role_code", roleCode),
		zap.Any("permissions", perms))

	policies, err := s.enforcer.GetPolicy()
	s.logger.Info("All current policies", zap.Any("policies", policies), zap.Error(err))
}

// splitPermission splits a permission string like "users:read" into ["users", "read"]
func splitPermission(permission string) []string {
	// Simple implementation - you might want to make this more sophisticated
	parts := make([]string, 0, 2)
	if colon := findChar(permission, ':'); colon != -1 {
		parts = append(parts, permission[:colon])
		parts = append(parts, permission[colon+1:])
	}
	return parts
}

// findChar finds the index of a character in a string
func findChar(s string, ch byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == ch {
			return i
		}
	}
	return -1
}

// GetRolePermissions retrieves permissions for a specific role
func (s *RoleImpl) GetRolePermissions(ctx context.Context, roleCode string) ([]string, error) {
	role, err := s.roleRepo.GetByCode(ctx, roleCode)
	if err != nil {
		return nil, err
	}

	if role.Permissions == "" {
		return []string{}, nil
	}

	var permissions []string
	if err := json.Unmarshal([]byte(role.Permissions), &permissions); err != nil {
		s.logger.Error("failed to parse role permissions",
			zap.Error(err),
			zap.String("role_code", roleCode))
		return nil, errors.New("invalid permissions format")
	}

	return permissions, nil
}

// AssignTemporaryRole assigns a role to a user for a specific duration
func (s *RoleImpl) AssignTemporaryRole(ctx context.Context, userID, roleID, assignedBy uint, duration time.Duration) error {
	expiresAt := time.Now().Add(duration)
	return s.AssignRole(ctx, userID, roleID, assignedBy, &expiresAt)
}

// BulkAssignRole assigns a role to multiple users
func (s *RoleImpl) BulkAssignRole(ctx context.Context, userIDs []uint, roleID, assignedBy uint, expiresAt *time.Time) error {
	// Check if role exists
	_, err := s.roleRepo.GetByID(ctx, roleID)
	if err != nil {
		return err
	}

	successCount := 0
	for _, userID := range userIDs {
		if err := s.AssignRole(ctx, userID, roleID, assignedBy, expiresAt); err != nil {
			s.logger.Warn("failed to assign role to user in bulk operation",
				zap.Error(err),
				zap.Uint("user_id", userID),
				zap.Uint("role_id", roleID))
			continue
		}
		successCount++
	}

	s.logger.Info("bulk role assignment completed",
		zap.Int("success_count", successCount),
		zap.Int("total_count", len(userIDs)),
		zap.Uint("role_id", roleID))

	if successCount == 0 {
		return errors.New("failed to assign role to any user")
	}

	return nil
}

// GetUsersWithRole retrieves all users that have a specific role
func (s *RoleImpl) GetUsersWithRole(ctx context.Context, roleCode string) ([]uint, error) {
	// This would require additional repository method - simplified implementation
	role, err := s.roleRepo.GetByCode(ctx, roleCode)
	if err != nil {
		return nil, err
	}

	// For now, return empty slice - would need to implement in repository
	// In a real implementation, you'd add a method to userRoleRepo to get users by role
	s.logger.Info("getting users with role",
		zap.String("role_code", roleCode),
		zap.Uint("role_id", role.ID))

	return []uint{}, nil
}
