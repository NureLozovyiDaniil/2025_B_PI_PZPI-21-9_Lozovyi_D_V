package service

import (
	"context"
	"identity-api/internal/config"
	"identity-api/internal/model"
	"identity-api/internal/repository"
	"time"

	"github.com/casbin/casbin/v2"
	"go.uber.org/zap"
)

// AuthService defines methods for authentication
type AuthService interface {
	Register(ctx context.Context, input model.UserCreate) (*model.User, error)
	Login(ctx context.Context, email, password string) (string, error)
	ParseToken(token string) (uint, []string, error)
	GenerateToken(userID uint, roles []string) (string, error)
}

// UserService defines methods for user management
type UserService interface {
	Create(ctx context.Context, input model.UserCreate) (*model.User, error)
	
	GetByID(ctx context.Context, id uint) (*model.User, error)
	GetByEmail(ctx context.Context, email string) (*model.User, error)
	Update(ctx context.Context, id uint, input model.UserUpdate) (*model.User, error)
	Delete(ctx context.Context, id uint) error
	List(ctx context.Context, offset, limit int) ([]model.User, error)
	ChangePassword(ctx context.Context, id uint, oldPassword, newPassword string) error
	GenerateKeyPair(ctx context.Context, userID uint) error
}

// RoleService defines methods for role management
type RoleService interface {
	Create(ctx context.Context, input model.RoleCreate) (*model.Role, error)
	GetByID(ctx context.Context, id uint) (*model.Role, error)
	GetByCode(ctx context.Context, code string) (*model.Role, error)
	Update(ctx context.Context, id uint, input model.RoleUpdate) (*model.Role, error)
	Delete(ctx context.Context, id uint) error
	List(ctx context.Context) ([]model.Role, error)

	AssignRole(ctx context.Context, userID, roleID, assignedBy uint, expiresAt *time.Time) error
	RevokeRole(ctx context.Context, userID, roleID uint) error
	GetUserRoles(ctx context.Context, userID uint) ([]model.Role, error)
	HasRole(ctx context.Context, userID uint, roleCode string) (bool, error)
	ExtendRoleExpiration(ctx context.Context, userID, roleID uint, expiresAt time.Time) error
	DeactivateExpiredRoles(ctx context.Context) error
}

// KeyService defines methods for cryptographic key operations
type KeyService interface {
	GenerateKeyPair() (publicKey, privateKey string, err error)
	EncryptPrivateKey(privateKey string) (string, error)
	DecryptPrivateKey(encryptedKey string) (string, error)
}

// Service combines all service interfaces
type Service struct {
	Auth AuthService
	User UserService
	Role RoleService
	Key  KeyService
}

// NewService creates a new service with all implementations
func NewService(
	repos *repository.Repository,
	cfg *config.Config,
	logger *zap.Logger,
	enforcer *casbin.Enforcer,
) *Service {
	keySvc := NewKeyImpl(cfg.Crypto.ServerKey)

	return &Service{
		Auth: NewAuthImpl(repos.User, repos.UserRole, cfg.JWT, logger),
		User: NewUserImpl(repos.User, repos.UserRole, keySvc, logger),
		Role: NewRoleImpl(repos.Role, repos.UserRole, enforcer, logger),
		Key:  keySvc,
	}
}
