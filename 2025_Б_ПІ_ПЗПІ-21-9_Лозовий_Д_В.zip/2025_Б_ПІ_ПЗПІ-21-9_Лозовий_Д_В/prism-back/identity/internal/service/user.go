package service

import (
	"context"
	"errors"
	"identity-api/internal/model"
	"identity-api/internal/repository"
	"identity-api/pkg/util"
	"time"

	"go.uber.org/zap"
)

type UserImpl struct {
	userRepo     repository.UserRepository
	userRoleRepo repository.UserRoleRepository
	keyService   KeyService
	logger       *zap.Logger
}

func NewUserImpl(
	userRepo repository.UserRepository,
	userRoleRepo repository.UserRoleRepository,
	keyService KeyService,
	logger *zap.Logger) *UserImpl {
	return &UserImpl{
		userRepo:     userRepo,
		userRoleRepo: userRoleRepo,
		keyService:   keyService,
		logger:       logger,
	}
}

func (s *UserImpl) Create(ctx context.Context, input model.UserCreate) (*model.User, error) {
	// Check if user with such email already exists
	existingUser, _ := s.userRepo.GetByEmail(ctx, input.Email)
	if existingUser != nil {
		return nil, errors.New("user with this email already exists")
	}

	// Hash the password
	hashedPassword, err := util.HashPassword(input.Password)
	if err != nil {
		s.logger.Error("failed to hash password", zap.Error(err))
		return nil, errors.New("failed to process password")
	}

	pubKey, encPrvKey, err := s.getKeys()
	if err != nil {
		s.logger.Error("failed to get keys", zap.Error(err))
		return nil, err
	}

	// Create a user
	user := &model.User{
		Email:               input.Email,
		PhoneNumber:         input.PhoneNumber,
		CountryCode:         input.CountryCode,
		PasswordHash:        hashedPassword,
		PublicKey:           pubKey,
		EncryptedPrivateKey: encPrvKey,
		Status:              "active", // Default status pending
	}

	if err := s.userRepo.Create(ctx, user); err != nil {
		s.logger.Error("failed to create user", zap.Error(err))
		return nil, errors.New("failed to create user")
	}
	userRole := &model.UserRole{
		UserID:     user.ID,
		RoleID:     6,
		AssignedAt: time.Now().UTC(),
		AssignedBy: user.ID,
		IsActive:   true,
	}

	if err := s.userRoleRepo.Assign(ctx, userRole); err != nil {
		s.logger.Error("failed to assign user to role", zap.Error(err))
		return nil, errors.New("failed to assign user to role")
	}

	s.logger.Info("user created successfully", zap.Uint("user_id", user.ID), zap.String("email", user.Email))
	return user, nil
}

func (s *UserImpl) getKeys() (string, string, error) {
	public, private, err := s.keyService.GenerateKeyPair()
	if err != nil {
		s.logger.Error("failed to generate key pair", zap.Error(err))
		return "", "", err
	}
	encryptedPrv, err := s.keyService.EncryptPrivateKey(private)
	if err != nil {
		s.logger.Error("failed to encrypt private key", zap.Error(err))
		return "", "", err
	}

	return public, encryptedPrv, nil
}

func (s *UserImpl) GetByID(ctx context.Context, id uint) (*model.User, error) {
	user, err := s.userRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	return user, nil
}

func (s *UserImpl) GetByEmail(ctx context.Context, email string) (*model.User, error) {
	user, err := s.userRepo.GetByEmail(ctx, email)
	if err != nil {
		return nil, err
	}
	return user, nil
}

func (s *UserImpl) Update(ctx context.Context, id uint, input model.UserUpdate) (*model.User, error) {
	// Get the existing user
	user, err := s.userRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}

	// If the email is updated, check if it's unique
	if input.Email != "" && input.Email != user.Email {
		existingUser, _ := s.userRepo.GetByEmail(ctx, input.Email)
		if existingUser != nil {
			return nil, errors.New("user with this email already exists")
		}
		user.Email = input.Email
	}

	// Updating status if not specified
	if input.Status != nil && *input.Status != user.Status {
		user.Status = *input.Status
	}

	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to update user", zap.Error(err))
		return nil, errors.New("failed to update user")
	}

	s.logger.Info("user updated successfully", zap.Uint("user_id", user.ID))
	return user, nil
}

func (s *UserImpl) Delete(ctx context.Context, id uint) error {
	// Check if user exists
	_, err := s.userRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}

	if err := s.userRepo.Delete(ctx, id); err != nil {
		s.logger.Error("failed to delete user", zap.Error(err))
		return errors.New("failed to delete user")
	}

	s.logger.Info("user deleted successfully", zap.Uint("user_id", id))
	return nil
}

func (s *UserImpl) List(ctx context.Context, offset, limit int) ([]model.User, error) {
	// Set the rational limits
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	if offset < 0 {
		offset = 0
	}

	users, err := s.userRepo.List(ctx, offset, limit)
	if err != nil {
		s.logger.Error("failed to list users", zap.Error(err))
		return nil, errors.New("failed to retrieve users")
	}

	return users, nil
}

func (s *UserImpl) ChangePassword(ctx context.Context, id uint, oldPassword, newPassword string) error {
	user, err := s.userRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}

	// Check the old password
	if err := util.CheckPassword(user.PasswordHash, oldPassword); err != nil {
		return errors.New("incorrect old password")
	}

	// Hash the new password
	hashedPassword, err := util.HashPassword(newPassword)
	if err != nil {
		s.logger.Error("failed to hash new password", zap.Error(err))
		return errors.New("failed to process new password")
	}

	// Updating
	user.PasswordHash = hashedPassword
	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to update password", zap.Error(err))
		return errors.New("failed to update password")
	}

	s.logger.Info("password changed successfully", zap.Uint("user_id", user.ID))
	return nil
}

func (s *UserImpl) GenerateKeyPair(ctx context.Context, userID uint) error {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return err
	}

	// Generating keys
	publicKey, privateKey, err := s.keyService.GenerateKeyPair()
	if err != nil {
		s.logger.Error("failed to generate key pair", zap.Error(err))
		return errors.New("failed to generate cryptographic keys")
	}

	// Encrypting the key
	encryptedPrivateKey, err := s.keyService.EncryptPrivateKey(privateKey)
	if err != nil {
		s.logger.Error("failed to encrypt private key", zap.Error(err))
		return errors.New("failed to secure private key")
	}

	user.PublicKey = publicKey
	user.EncryptedPrivateKey = encryptedPrivateKey

	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to save keys", zap.Error(err))
		return errors.New("failed to save cryptographic keys")
	}

	s.logger.Info("key pair generated successfully", zap.Uint("user_id", user.ID))
	return nil
}

func (s *UserImpl) GetDecryptedPrivateKey(ctx context.Context, userID uint) (string, error) {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return "", err
	}

	if user.EncryptedPrivateKey == "" {
		return "", errors.New("user has no private key")
	}

	// Decrypting the key
	privateKey, err := s.keyService.DecryptPrivateKey(user.EncryptedPrivateKey)
	if err != nil {
		s.logger.Error("failed to decrypt private key", zap.Error(err))
		return "", errors.New("failed to access private key")
	}

	return privateKey, nil
}

func (s *UserImpl) ActivateUser(ctx context.Context, userID uint) error {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return err
	}

	user.Status = "active"
	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to activate user", zap.Error(err))
		return errors.New("failed to activate user")
	}

	s.logger.Info("user activated successfully", zap.Uint("user_id", user.ID))
	return nil
}

func (s *UserImpl) DeactivateUser(ctx context.Context, userID uint) error {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return err
	}

	user.Status = "inactive"
	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to deactivate user", zap.Error(err))
		return errors.New("failed to deactivate user")
	}

	s.logger.Info("user deactivated successfully", zap.Uint("user_id", user.ID))
	return nil
}

func (s *UserImpl) BlockUser(ctx context.Context, userID uint) error {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return err
	}

	user.Status = "blocked"
	if err := s.userRepo.Update(ctx, user); err != nil {
		s.logger.Error("failed to block user", zap.Error(err))
		return errors.New("failed to block user")
	}

	s.logger.Info("user blocked successfully", zap.Uint("user_id", user.ID))
	return nil
}

func (s *UserImpl) IsUserActive(ctx context.Context, userID uint) (bool, error) {
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return false, err
	}

	return user.Status == "active", nil
}
