package main

import (
	"context"
	"errors"
	"go.uber.org/zap/zapcore"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"identity-api/internal/config"
	"identity-api/internal/handler"
	"identity-api/internal/initialization"
	"identity-api/internal/repository"
	"identity-api/internal/service"

	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func main() {
	// Init config
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	// Init logger
	logger, err := setupLogger(cfg.LogLevel)
	if err != nil {
		log.Fatalf("Failed to setup logger: %v", err)
	}
	defer logger.Sync()

	logger.Info("Starting Identity Service", zap.String("version", "1.0.0"))

	// Connect to DB
	db, err := setupDatabase(cfg.Database)
	if err != nil {
		logger.Fatal("Failed to connect to database", zap.Error(err))
	}

	// Check database connection with retry logic
	if err := initialization.CheckDatabaseConnection(db, logger); err != nil {
		logger.Fatal("Database connection check failed", zap.Error(err))
	}
	logger.Info("Database connection established successfully")

	// Run migrations
	if err := repository.RunMigrations(db, "internal/migrations"); err != nil {
		logger.Fatal("Failed to run migrations", zap.Error(err))
	}
	logger.Info("Database migrations completed")

	// Setup Casbin enforcer
	enforcer, err := initialization.SetupCasbin(
		"internal/config/casbin_model.conf",
		"internal/config/casbin_policy.csv",
	)
	if err != nil {
		logger.Fatal("Failed to setup Casbin", zap.Error(err))
	}
	logger.Info("Casbin enforcer initialized")

	// Initialize repositories and services
	var (
		repos       = repository.NewRepository(db)
		services    = service.NewService(repos, cfg, logger, enforcer)
		handlers    = handler.NewHandler(services, logger, enforcer)
		initializer = initialization.NewSystemInitializer(logger)
	)

	// Initialize default roles
	if err := initializer.InitializeDefaultRoles(context.Background(), services.Role); err != nil {
		logger.Error("Failed to initialize default roles", zap.Error(err))
		// Don't fail startup - roles can be created manually
	}

	//TODO: DELETE
	//ctx := context.Background()
	//if roles, err := services.Role.List(ctx); err == nil {
	//	for _, role := range roles {
	//		err := services.Role.Delete(ctx, role.ID)
	//		logger.Info("Deleted existing role", zap.String("code", role.Code), zap.Error(err))
	//	}
	//}

	// Create HTTP server with configured routes
	engine := handlers.InitRoutes()
	srv := &http.Server{
		Addr:           cfg.ServerAddress,
		Handler:        engine.Handler(),
		ReadTimeout:    30 * time.Second,
		WriteTimeout:   30 * time.Second,
		IdleTimeout:    120 * time.Second,
		MaxHeaderBytes: 1 << 20, // 1MB
	}

	// Start background tasks
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	taskManager := initialization.NewBackgroundTaskManager(services, logger)
	go taskManager.StartBackgroundTasks(ctx)

	// Start HTTP server in goroutine
	go func() {
		logger.Info("Starting HTTP server", zap.String("address", cfg.ServerAddress))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatal("Failed to start HTTP server", zap.Error(err))
		}
	}()

	logger.Info("Identity Service started successfully", zap.String("address", cfg.ServerAddress))

	// Wait for interrupt signal for graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("Shutting down Identity Service...")

	// Cancel background tasks
	cancel()

	// Graceful shutdown with timeout
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer shutdownCancel()

	// Shutdown HTTP server
	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP server forced to shutdown", zap.Error(err))
	} else {
		logger.Info("HTTP server shut down gracefully")
	}

	// Close database connection
	if sqlDB, err := db.DB(); err == nil {
		if err := sqlDB.Close(); err != nil {
			logger.Error("Failed to close database connection", zap.Error(err))
		} else {
			logger.Info("Database connection closed")
		}
	}

	// Save Casbin policies if needed
	if err := enforcer.SavePolicy(); err != nil {
		logger.Error("Failed to save Casbin policies", zap.Error(err))
	}

	logger.Info("Identity Service shutdown completed")
}

// setupLogger initializes the logger based on environment
func setupLogger(level string) (*zap.Logger, error) {
	var cfg zap.Config

	if level == "production" {
		cfg = zap.NewProductionConfig()
		cfg.Level = zap.NewAtomicLevelAt(zap.InfoLevel)

		cfg.OutputPaths = []string{"app.log"}
		cfg.ErrorOutputPaths = []string{"error.log"}
	} else {
		cfg = zap.NewDevelopmentConfig()
		cfg.Level = zap.NewAtomicLevelAt(zap.DebugLevel)

		cfg.OutputPaths = []string{"stdout", "debug.log"}
		cfg.ErrorOutputPaths = []string{"stderr", "error.log"}
	}

	// Add caller information
	cfg.Development = level != "production"
	cfg.DisableCaller = level == "production"
	cfg.DisableStacktrace = level == "production"

	cfg.EncoderConfig.TimeKey = "timestamp"
	cfg.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	return cfg.Build()
}

// setupDatabase initializes database connection with proper settings
func setupDatabase(cfg config.DatabaseConfig) (*gorm.DB, error) {
	dsn := cfg.GetDSN()

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
		// Disable foreign key constraint when migrating
		DisableForeignKeyConstraintWhenMigrating: true,
		// Use prepared statements
		PrepareStmt: true,
	})
	if err != nil {
		return nil, err
	}

	// Configure connection pool
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	// Connection pool settings
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(100)
	sqlDB.SetConnMaxLifetime(time.Hour)

	return db, nil
}
