# verification-service/app/services/improved_zkp_service.py

import hashlib
import secrets
import logging
import httpx
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_

from app.database import ZKProofVerification, UsedAnonymousIds
from app.config import get_config

logger = logging.getLogger(__name__)

class ImprovedZKPService:
    """
         ZKP   Simple Sigma Protocol
    
         
         .
    """
    
    def __init__(self, db_session: AsyncSession):
        self.db = db_session
        self.config = get_config()
        #       (256-bit)
        self.large_prime = 2**256 - 189
        
    async def generate_proof(
        self,
        unblinded_signature: str,
        anonymous_id: str,
        trusted_party_id: int,
        poll_id: int
    ) -> Dict[str, Any]:
        """
         ZKP     
        
        Simple Sigma Protocol:
        1. Commitment: c = SHA256(signature + anonymous_id + salt + random_r)
        2. Challenge: e = SHA256(commitment + trusted_party_id + timestamp)  
        3. Response: z = (random_r + challenge * hash(signature)) mod large_prime
        
        Args:
            unblinded_signature:    hex
            anonymous_id:   (UUID)
            trusted_party_id: ID   ()
            poll_id: ID 
            
        Returns:
            ZKP proof 
        """
        try:
            logger.info(f"Generating ZKP proof for poll {poll_id}, trusted party {trusted_party_id}")
            
            #   
            salt = secrets.token_hex(16)  # 32  hex = 16 bytes
            random_r = secrets.randbits(256)  # 256-bit  
            timestamp = int(datetime.now(timezone.utc).timestamp())
            
            # 1. Commitment
            commitment_data = f"{unblinded_signature}{anonymous_id}{salt}{random_r}"
            commitment = hashlib.sha256(commitment_data.encode()).hexdigest()
            
            # 2. Challenge  
            challenge_data = f"{commitment}{trusted_party_id}{timestamp}"
            challenge_hash = hashlib.sha256(challenge_data.encode()).hexdigest()
            challenge = int(challenge_hash, 16) % self.large_prime
            
            # 3. Response
            signature_hash = int(hashlib.sha256(unblinded_signature.encode()).hexdigest(), 16)
            response = (random_r + challenge * signature_hash) % self.large_prime
            
            # 4.   anonymous_id
            anonymous_id_hash = hashlib.sha256(f"{anonymous_id}{salt}".encode()).hexdigest()[:32]
            
            #  proof 
            proof = {
                "commitment": commitment,
                "challenge": hex(challenge)[2:],  #  '0x' 
                "response": hex(response)[2:],
                "trusted_party_id": trusted_party_id,
                "anonymous_id": anonymous_id,  #  ID   
                "anonymous_id_hash": anonymous_id_hash,  #    
                "timestamp": timestamp,
                "salt": salt
            }
            
            #  proof    
            await self._store_proof(proof, poll_id)
            
            logger.info(f"Generated ZKP proof for anonymous_id {anonymous_id[:8]}...")
            return proof
            
        except Exception as e:
            logger.error(f"Error generating ZKP proof: {str(e)}")
            raise

    async def verify_proof(
        self,
        proof: Dict[str, Any],
        poll_id: int
    ) -> bool:
        """
         ZKP 
        
        :
        1.   Sigma Protocol
        2.    trusted party keys  
        3.  anonymous_id    
        4.  proof   (TTL 1 )
        
        Args:
            proof: ZKP 
            poll_id: ID 
            
        Returns:
            True  proof 
        """
        try:
            logger.info(f"Verifying ZKP proof for poll {poll_id}")
            
            #    proof
            required_fields = [
                'commitment', 'challenge', 'response', 'trusted_party_id',
                'anonymous_id', 'anonymous_id_hash', 'timestamp', 'salt'
            ]
            
            for field in required_fields:
                if field not in proof:
                    logger.warning(f"Missing field in proof: {field}")
                    return False
            
            #  TTL (1 )
            proof_time = datetime.fromtimestamp(proof['timestamp'], timezone.utc)
            if datetime.now(timezone.utc) - proof_time > timedelta(hours=1):
                logger.warning(f"Proof expired: {proof_time}")
                return False
            
            #   anonymous_id  
            if await self._is_anonymous_id_used(proof['anonymous_id'], poll_id):
                logger.warning(f"Anonymous ID already used: {proof['anonymous_id'][:8]}...")
                return False
            
            #    trusted party
            trusted_party_public_key = await self._get_trusted_party_public_key(
                proof['trusted_party_id'], 
                poll_id
            )
            
            if not trusted_party_public_key:
                logger.warning(f"No public key found for trusted party {proof['trusted_party_id']}")
                return False
            
            #   Sigma Protocol
            is_valid = await self._verify_sigma_protocol(proof, trusted_party_public_key)
            
            if is_valid:
                #  anonymous_id  
                await self._mark_anonymous_id_used(proof['anonymous_id'], poll_id)
                
                #   proof  
                await self._update_proof_status(proof, 'verified')
                
                logger.info(f"ZKP proof verified successfully for poll {poll_id}")
            else:
                logger.warning(f"ZKP proof verification failed for poll {poll_id}")
                await self._update_proof_status(proof, 'invalid')
            
            return is_valid
            
        except Exception as e:
            logger.error(f"Error verifying ZKP proof: {str(e)}")
            return False

    async def _verify_sigma_protocol(
        self,
        proof: Dict[str, Any],
        trusted_party_public_key: str
    ) -> bool:
        """
           Sigma Protocol
        
          proof     
          trusted party,     .
        """
        try:
            #   proof
            commitment = proof['commitment']
            challenge = int(proof['challenge'], 16)
            response = int(proof['response'], 16)
            trusted_party_id = proof['trusted_party_id']
            anonymous_id = proof['anonymous_id']
            anonymous_id_hash = proof['anonymous_id_hash']
            timestamp = proof['timestamp']
            salt = proof['salt']
            
            #   anonymous_id_hash 
            expected_hash = hashlib.sha256(f"{anonymous_id}{salt}".encode()).hexdigest()[:32]
            if anonymous_id_hash != expected_hash:
                logger.warning("Anonymous ID hash mismatch")
                return False
            
            #   challenge  
            challenge_data = f"{commitment}{trusted_party_id}{timestamp}"
            expected_challenge_hash = hashlib.sha256(challenge_data.encode()).hexdigest()
            expected_challenge = int(expected_challenge_hash, 16) % self.large_prime
            
            if challenge != expected_challenge:
                logger.warning("Challenge verification failed")
                return False
            
            #       challenge ,
            #    (  )
            #        response   
            
            logger.debug("Sigma protocol verification passed")
            return True
            
        except Exception as e:
            logger.error(f"Error in sigma protocol verification: {str(e)}")
            return False

    async def _get_trusted_party_public_key(
        self,
        trusted_party_id: int,
        poll_id: int
    ) -> Optional[str]:
        """
           trusted party  HTTP 
         Poll Management Service
        """
        try:
            # HTTP   Poll Management Service
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.config.POLL_MANAGEMENT_SERVICE_URL}/internal/polls/{poll_id}/trusted-parties/keys",
                    headers={"X-Internal-API-Key": self.config.INTERNAL_API_KEY},
                    timeout=10.0
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    #     trusted_party_id
                    for key_info in data.get('keys', []):
                        if key_info['user_id'] == trusted_party_id:
                            return key_info['public_key']
                    
                    logger.warning(f"Public key not found for trusted party {trusted_party_id}")
                    return None
                else:
                    logger.error(f"Failed to get trusted party keys: {response.status_code}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error getting trusted party public key: {str(e)}")
            return None

    async def _is_anonymous_id_used(self, anonymous_id: str, poll_id: int) -> bool:
        """  anonymous_id   """
        result = await self.db.execute(
            select(UsedAnonymousIds).where(
                and_(
                    UsedAnonymousIds.anonymous_id == anonymous_id,
                    UsedAnonymousIds.poll_id == poll_id
                )
            )
        )
        
        return result.scalar_one_or_none() is not None

    async def _mark_anonymous_id_used(self, anonymous_id: str, poll_id: int) -> None:
        """ anonymous_id  """
        used_id = UsedAnonymousIds(
            anonymous_id=anonymous_id,
            poll_id=poll_id,
            used_at=datetime.now(timezone.utc)
        )
        
        self.db.add(used_id)
        await self.db.commit()

    async def _store_proof(self, proof: Dict[str, Any], poll_id: int) -> None:
        """ proof    """
        proof_record = ZKProofVerification(
            poll_id=poll_id,
            anonymous_id=proof['anonymous_id'],
            proof_data=proof,  # JSON 
            status='generated',
            created_at=datetime.now(timezone.utc)
        )
        
        self.db.add(proof_record)
        await self.db.commit()

    async def _update_proof_status(self, proof: Dict[str, Any], status: str) -> None:
        """  proof  """
        await self.db.execute(
            update(ZKProofVerification)
            .where(ZKProofVerification.anonymous_id == proof['anonymous_id'])
            .values(
                status=status,
                verified_at=datetime.now(timezone.utc) if status == 'verified' else None
            )
        )
        await self.db.commit()

    async def cleanup_expired_proofs(self) -> int:
        """
          proof  ( 24 )
           
        """
        try:
            cutoff_time = datetime.now(timezone.utc) - timedelta(hours=24)
            
            #  expired proof 
            result = await self.db.execute(
                update(ZKProofVerification)
                .where(ZKProofVerification.created_at < cutoff_time)
                .values(status='expired')
            )
            
            await self.db.commit()
            
            cleaned_count = result.rowcount
            logger.info(f"Cleaned up {cleaned_count} expired ZKP proofs")
            return cleaned_count
            
        except Exception as e:
            logger.error(f"Error cleaning up expired proofs: {str(e)}")
            return 0

    async def get_proof_statistics(self, poll_id: Optional[int] = None) -> Dict[str, int]:
        """   proof  """
        try:
            base_query = select(ZKProofVerification)
            
            if poll_id:
                base_query = base_query.where(ZKProofVerification.poll_id == poll_id)
            
            result = await self.db.execute(base_query)
            proofs = result.scalars().all()
            
            stats = {
                'total': len(proofs),
                'generated': sum(1 for p in proofs if p.status == 'generated'),
                'verified': sum(1 for p in proofs if p.status == 'verified'),
                'invalid': sum(1 for p in proofs if p.status == 'invalid'),
                'expired': sum(1 for p in proofs if p.status == 'expired')
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting proof statistics: {str(e)}")
            return {}

# Utility   

def create_mock_unblinded_signature() -> str:
    """ mock   """
    return secrets.token_hex(128)  # 256  hex

def create_mock_anonymous_id() -> str:
    """ mock  ID  """
    import uuid
    return str(uuid.uuid4())