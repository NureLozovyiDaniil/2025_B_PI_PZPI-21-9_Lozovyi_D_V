# verification-service/app/services/blind_signature_service.py -  

import hashlib
import secrets
import logging
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.fernet import Fernet
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
import httpx

from app.database import (
    TrustedPartyKeys, 
    BlindSignatureRequest, 
    ZKProofVerification, 
    UsedAnonymousIds
)
from app.config import get_config

logger = logging.getLogger(__name__)

class BlindSignatureService:
    def __init__(self, db_session: AsyncSession):
        self.db = db_session
        self.config = get_config()
        # Master encryption key    
        self.encryption_key = self.config.MASTER_ENCRYPTION_KEY.encode()[:32]
        self.fernet = Fernet(Fernet.generate_key() if len(self.encryption_key) < 32 else 
                           Fernet.generate_key())

    async def create_signature_request(
        self, 
        poll_id: int, 
        requester_id: int, 
        blinded_message: str
    ) -> int:
        """
            
        
        Args:
            poll_id: ID 
            requester_id: ID 
            blinded_message:    hex
            
        Returns:
            request_id: ID  
        """
        try:
            #  
            await self._validate_poll_is_private(poll_id)
            
            #          
            existing_request = await self.db.execute(
                select(BlindSignatureRequest).where(
                    and_(
                        BlindSignatureRequest.requester_id == requester_id,
                        BlindSignatureRequest.poll_id == poll_id,
                        BlindSignatureRequest.status.in_(['pending', 'signed'])
                    )
                )
            )
            
            if existing_request.scalar_one_or_none():
                raise ValueError(f"User {requester_id} already has active request for poll {poll_id}")
            
            #  
            request = BlindSignatureRequest(
                poll_id=poll_id,
                requester_id=requester_id,
                blinded_message=blinded_message,
                status='pending',
                created_at=datetime.now(timezone.utc)
            )
            
            self.db.add(request)
            await self.db.commit()
            await self.db.refresh(request)
            
            logger.info(f"Created blind signature request {request.id} for user {requester_id}, poll {poll_id}")
            return request.id
            
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating signature request: {str(e)}")
            raise

    async def get_pending_requests(self, trusted_party_id: int) -> List[Dict[str, Any]]:
        """
         pending   trusted party
        
        Args:
            trusted_party_id: ID  
            
        Returns:
               
        """
        try:
            #      trusted party
            trusted_polls_query = await self.db.execute(
                select(TrustedPartyKeys.poll_id).where(
                    TrustedPartyKeys.user_id == trusted_party_id
                )
            )
            trusted_poll_ids = [row[0] for row in trusted_polls_query.fetchall()]
            
            if not trusted_poll_ids:
                return []
            
            #  pending    
            requests_query = await self.db.execute(
                select(BlindSignatureRequest).where(
                    and_(
                        BlindSignatureRequest.poll_id.in_(trusted_poll_ids),
                        BlindSignatureRequest.status == 'pending'
                    )
                ).order_by(BlindSignatureRequest.created_at.asc())
            )
            
            requests = requests_query.scalars().all()
            
            result = []
            for request in requests:
                result.append({
                    "request_id": request.id,
                    "poll_id": request.poll_id,
                    "requester_id": request.requester_id,
                    "blinded_message": request.blinded_message,
                    "status": request.status,
                    "created_at": request.created_at,
                    "processed_at": request.processed_at
                })
            
            logger.info(f"Found {len(result)} pending requests for trusted party {trusted_party_id}")
            return result
            
        except Exception as e:
            logger.error(f"Error getting pending requests: {str(e)}")
            raise

    async def process_signature_request(
        self, 
        request_id: int, 
        signer_id: int, 
        approved: bool,
        rejection_reason: Optional[str] = None
    ) -> None:
        """
            
        
        Args:
            request_id: ID 
            signer_id: ID  (trusted party)
            approved:   
            rejection_reason:  
        """
        try:
            #  
            request_query = await self.db.execute(
                select(BlindSignatureRequest).where(BlindSignatureRequest.id == request_id)
            )
            request = request_query.scalar_one_or_none()
            
            if not request:
                raise ValueError(f"Signature request {request_id} not found")
            
            if request.status != 'pending':
                raise ValueError(f"Request {request_id} is not pending (status: {request.status})")
            
            #   signer  trusted party   
            await self._validate_trusted_party(signer_id, request.poll_id)
            
            if approved:
                #  blinded message
                signature = await self._sign_blinded_message(
                    request.blinded_message, 
                    signer_id, 
                    request.poll_id
                )
                
                #  
                await self.db.execute(
                    update(BlindSignatureRequest)
                    .where(BlindSignatureRequest.id == request_id)
                    .values(
                        status='signed',
                        signer_id=signer_id,
                        blind_signature=signature,
                        processed_at=datetime.now(timezone.utc)
                    )
                )
                
                logger.info(f"Approved and signed request {request_id} by trusted party {signer_id}")
                
            else:
                #  
                await self.db.execute(
                    update(BlindSignatureRequest)
                    .where(BlindSignatureRequest.id == request_id)
                    .values(
                        status='rejected',
                        signer_id=signer_id,
                        rejection_reason=rejection_reason,
                        processed_at=datetime.now(timezone.utc)
                    )
                )
                
                logger.info(f"Rejected request {request_id} by trusted party {signer_id}: {rejection_reason}")
            
            await self.db.commit()
            
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error processing signature request: {str(e)}")
            raise

    async def get_signature_result(self, request_id: int) -> Dict[str, Any]:
        """
             
        
        Args:
            request_id: ID 
            
        Returns:
                 
        """
        try:
            request_query = await self.db.execute(
                select(BlindSignatureRequest).where(BlindSignatureRequest.id == request_id)
            )
            request = request_query.scalar_one_or_none()
            
            if not request:
                raise ValueError(f"Signature request {request_id} not found")
            
            result = {
                "status": request.status,
                "created_at": request.created_at,
                "processed_at": request.processed_at
            }
            
            if request.status == 'signed' and request.blind_signature:
                result["blind_signature"] = request.blind_signature
                
            if request.status == 'rejected' and request.rejection_reason:
                result["rejection_reason"] = request.rejection_reason
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting signature result: {str(e)}")
            raise

    async def get_user_requests(self, user_id: int) -> List[Dict[str, Any]]:
        """
            ( )
        
        Args:
            user_id: ID 
            
        Returns:
               
        """
        try:
            requests_query = await self.db.execute(
                select(BlindSignatureRequest).where(
                    BlindSignatureRequest.requester_id == user_id
                ).order_by(BlindSignatureRequest.created_at.desc())
            )
            
            requests = requests_query.scalars().all()
            
            result = []
            for request in requests:
                result.append({
                    "request_id": request.id,
                    "poll_id": request.poll_id,
                    "requester_id": request.requester_id,
                    "blinded_message": request.blinded_message[:32] + "...",  #   
                    "status": request.status,
                    "created_at": request.created_at,
                    "processed_at": request.processed_at
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Error getting user requests: {str(e)}")
            raise

    async def _sign_blinded_message(
        self, 
        blinded_message: str, 
        signer_id: int, 
        poll_id: int
    ) -> str:
        """
             trusted party
        
        Args:
            blinded_message:    hex
            signer_id: ID 
            poll_id: ID 
            
        Returns:
              hex 
        """
        try:
            #    trusted party
            keys_query = await self.db.execute(
                select(TrustedPartyKeys).where(
                    and_(
                        TrustedPartyKeys.user_id == signer_id,
                        TrustedPartyKeys.poll_id == poll_id
                    )
                )
            )
            keys = keys_query.scalar_one_or_none()
            
            if not keys:
                raise ValueError(f"Keys not found for trusted party {signer_id}, poll {poll_id}")
            
            #   
            encrypted_private_key = keys.encrypted_private_key.encode()
            private_key_pem = self.fernet.decrypt(encrypted_private_key)
            
            #   
            private_key = serialization.load_pem_private_key(
                private_key_pem, 
                password=None
            )
            
            #  hex  bytes
            blinded_bytes = bytes.fromhex(blinded_message)
            
            #    RSA PKCS1v15
            signature = private_key.sign(
                blinded_bytes,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            
            #    hex 
            return signature.hex()
            
        except Exception as e:
            logger.error(f"Error signing blinded message: {str(e)}")
            raise

    #   (    Poll Management Service)
    
    async def _validate_poll_is_private(self, poll_id: int) -> None:
        """      """
        # TODO: HTTP   Poll Management Service
        # GET /internal/polls/{poll_id}/info
        logger.debug(f"Validating poll {poll_id} is private (mock)")
        
    async def _validate_trusted_party(self, user_id: int, poll_id: int) -> None:
        """    trusted party  """
        keys_query = await self.db.execute(
            select(TrustedPartyKeys).where(
                and_(
                    TrustedPartyKeys.user_id == user_id,
                    TrustedPartyKeys.poll_id == poll_id
                )
            )
        )
        
        keys = keys_query.scalar_one_or_none()
        if not keys:
            raise ValueError(f"User {user_id} is not a trusted party for poll {poll_id}")

    #     (    )
    
    async def generate_and_store_rsa_keys(self, user_id: int, poll_id: int) -> str:
        """   RSA   trusted party"""
        #    
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        
        public_key = private_key.public_key()
        
        #  
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        #   
        encrypted_private_key = self.fernet.encrypt(private_pem)
        
        #  hex   
        public_key_hex = public_pem.hex()
        
        #   
        keys_record = TrustedPartyKeys(
            user_id=user_id,
            poll_id=poll_id,
            public_key=public_key_hex,
            encrypted_private_key=encrypted_private_key.decode(),
            created_at=datetime.now(timezone.utc)
        )
        
        self.db.add(keys_record)
        await self.db.commit()
        
        logger.info(f"Generated and stored RSA keys for user {user_id}, poll {poll_id}")
        return public_key_hex