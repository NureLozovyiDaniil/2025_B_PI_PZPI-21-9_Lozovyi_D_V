# verification-service/app/main.py - 

import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import time

from app.config import get_config
from app.database import init_database, close_database
from app.api.health import router as health_router
from app.api.blind_signatures import router as blind_signatures_router
from app.api.zkp import router as zkp_router

#  
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('verification-service.log')
    ]
)

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle manager  FastAPI """
    # Startup
    config = get_config()
    logger.info(f"Starting Verification Service on port {config.SERVER_PORT}")
    logger.info(f"Environment: {config.ENVIRONMENT}")
    logger.info(f"Database: {config.DATABASE_URL[:20]}...")
    
    #   
    await init_database()
    logger.info("Database initialized successfully")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Verification Service")
    await close_database()

#  FastAPI 
app = FastAPI(
    title="Verification Service",
    description="Service for blind signatures and ZKP verification for anonymous voting",
    version="1.0.0-phase2",
    lifespan=lifespan
)

# CORS middleware    Go 
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8080",  # Poll Management Service
        "http://localhost:8081",  # Blockchain Service  
        "http://localhost:3000",  # Frontend ( )
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Middleware   
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """ HTTP """
    start_time = time.time()
    
    #  request ID  
    request_id = f"{int(time.time() * 1000)}-{hash(str(request.url)) % 10000}"
    
    logger.info(
        f"Request {request_id}: {request.method} {request.url.path} "
        f"from {request.client.host if request.client else 'unknown'}"
    )
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    logger.info(
        f"Response {request_id}: {response.status_code} "
        f"in {process_time:.3f}s"
    )
    
    return response

#   
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """  """
    logger.error(
        f"Unhandled exception in {request.method} {request.url.path}: "
        f"{type(exc).__name__}: {str(exc)}"
    )
    
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "internal_server_error",
            "message": "An internal server error occurred"
        }
    )

#  
app.include_router(health_router)
app.include_router(blind_signatures_router)
app.include_router(zkp_router)  # ✅    4

@app.get("/")
async def root():
    """ endpoint    """
    config = get_config()
    return {
        "service": "verification-service",
        "version": "1.0.0-phase2",
        "status": "running",
        "environment": config.ENVIRONMENT,
        "features": [
            "Blind Signatures for anonymous verification",
            "ZKP verification for anonymous voting",
            "Integration with Poll Management Service",
            "RSA-2048 key management for trusted parties"
        ],
        "endpoints": {
            "health": "/api/health",
            "blind_signatures": "/api/blind-signatures/*",
            "zkp": "/api/zkp/* - ZKP generation and verification"
        }
    }

if __name__ == "__main__":
    config = get_config()
    
    #   development vs production
    if config.ENVIRONMENT == "development":
        uvicorn.run(
            "app.main:app",
            host="0.0.0.0",
            port=config.SERVER_PORT,
            reload=True,
            log_level="info"
        )
    else:
        uvicorn.run(
            app,
            host="0.0.0.0", 
            port=config.SERVER_PORT,
            log_level="warning"
        )