"""
Response models for Verification Service API
"""
from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field


class BlindSignatureResponse(BaseModel):
    """Response for blind signature request"""
    request_id: str = Field(..., description="Unique request identifier")
    status: str = Field(..., description="Request status: pending, signed, rejected")
    message: str = Field(..., description="Human readable message")
    created_at: Optional[datetime] = Field(None, description="Request creation timestamp")


class PendingRequestResponse(BaseModel):
    """Response for pending blind signature requests"""
    request_id: str = Field(..., description="Unique request identifier")
    poll_id: int = Field(..., description="ID of the poll")
    poll_title: str = Field(..., description="Title of the poll")
    requester_info: str = Field(..., description="Anonymous requester information")
    blinded_message: str = Field(..., description="Blinded message to sign")
    created_at: str = Field(..., description="Request creation timestamp")


class SignatureResultResponse(BaseModel):
    """Response for signature request result"""
    request_id: str = Field(..., description="Unique request identifier")
    status: str = Field(..., description="Request status: pending, signed, rejected")
    signature: Optional[str] = Field(None, description="Blind signature if approved")
    reason: Optional[str] = Field(None, description="Rejection reason if rejected")
    signed_at: Optional[str] = Field(None, description="Signature timestamp")
    signer_id: Optional[int] = Field(None, description="ID of the signer")


class ZKPVerificationResponse(BaseModel):
    """Response for ZKP verification"""
    is_valid: bool = Field(..., description="Whether the proof is valid")
    anonymous_id: str = Field(..., description="Anonymous identifier")
    poll_id: int = Field(..., description="ID of the poll")
    message: str = Field(..., description="Verification result message")
    verified_at: Optional[datetime] = Field(None, description="Verification timestamp")


class TrustedPartyKeysResponse(BaseModel):
    """Response for trusted party keys"""
    trusted_party_id: int = Field(..., description="ID of the trusted party")
    poll_id: int = Field(..., description="ID of the poll")
    public_key: str = Field(..., description="RSA public key in PEM format")
    key_hash: str = Field(..., description="SHA256 hash of the public key")
    created_at: datetime = Field(..., description="Key creation timestamp")


class ErrorResponse(BaseModel):
    """Standard error response"""
    error: str = Field(..., description="Error code")
    message: str = Field(..., description="Error message")
    details: Optional[str] = Field(None, description="Additional error details")


class SuccessResponse(BaseModel):
    """Standard success response"""
    success: bool = Field(True, description="Operation success indicator")
    message: str = Field(..., description="Success message")
    data: Optional[dict] = Field(None, description="Additional response data")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = Field(..., description="Service status")
    service: str = Field(..., description="Service name")
    version: str = Field(..., description="Service version")
    timestamp: str = Field(..., description="Response timestamp")
    components: Optional[dict] = Field(None, description="Component health status")