# verification-service/app/models/requests.py - 

from pydantic import BaseModel, Field, validator
from typing import Optional
import re

class BlindSignatureRequestModel(BaseModel):
    """    """
    poll_id: int = Field(..., gt=0, description="ID ")
    requester_id: int = Field(..., gt=0, description="ID ,  ")
    blinded_message: str = Field(..., description="   hex ")
    
    @validator('blinded_message')
    def validate_blinded_message(cls, v):
        if not re.match(r'^[0-9a-fA-F]+$', v):
            raise ValueError('Blinded message must be valid hex string')
        if len(v) < 64:  #  32 
            raise ValueError('Blinded message too short')
        return v.lower()

class ProcessBlindSignatureRequest(BaseModel):
    """     trusted party"""
    signer_id: int = Field(..., gt=0, description="ID trusted party")
    approved: bool = Field(..., description="   ")
    rejection_reason: Optional[str] = Field(None, max_length=500, description=" ")
    
    @validator('rejection_reason')
    def validate_rejection_reason(cls, v, values):
        if not values.get('approved') and not v:
            raise ValueError('Rejection reason is required when request is not approved')
        return v

class GenerateKeysRequest(BaseModel):
    """   RSA   trusted party"""
    user_id: int = Field(..., gt=0, description="ID ")
    poll_id: int = Field(..., gt=0, description="ID ")

class ZKProofVerificationRequest(BaseModel):
    """   ZKP (   4)"""
    poll_id: int = Field(..., gt=0, description="ID ")
    proof: dict = Field(..., description="ZKP ")
    anonymous_id: str = Field(..., description=" ")
    
    @validator('anonymous_id')
    def validate_anonymous_id(cls, v):
        if len(v) < 32:
            raise ValueError('Anonymous ID too short')
        return v

# verification-service/app/models/responses.py - 

from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class SuccessResponse(BaseModel):
    """  """
    success: bool = True
    message: str

class BlindSignatureRequestResponse(BaseModel):
    """     """
    success: bool
    request_id: int
    status: str
    message: str

class BlindSignatureRequestInfo(BaseModel):
    """    """
    request_id: int
    poll_id: int
    requester_id: int
    blinded_message: str
    status: str
    created_at: datetime
    processed_at: Optional[datetime] = None

class BlindSignatureListResponse(BaseModel):
    """   """
    success: bool
    requests: List[BlindSignatureRequestInfo]
    count: int
    message: str

class BlindSignatureResultResponse(BaseModel):
    """   """
    success: bool
    request_id: int
    status: str
    blind_signature: Optional[str] = None
    rejection_reason: Optional[str] = None
    created_at: datetime
    processed_at: Optional[datetime] = None
    message: str

class GenerateKeysResponse(BaseModel):
    """   RSA """
    success: bool
    user_id: int
    poll_id: int
    public_key: str
    message: str

class ZKProofVerificationResponse(BaseModel):
    """   ZKP (   4)"""
    success: bool
    valid: bool
    proof_id: Optional[int] = None
    anonymous_id: str
    message: str

class HealthResponse(BaseModel):
    """Health check """
    status: str
    timestamp: datetime
    service: str
    database: str
    dependencies: Dict[str, Any]