# verification-service/app/api/blind_signatures.py

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
import logging

from app.database import get_db_session
from app.services.blind_signature_service import BlindSignatureService
from app.models.requests import (
    BlindSignatureRequestModel, 
    ProcessBlindSignatureRequest,
    GenerateKeysRequest
)
from app.models.responses import (
    BlindSignatureRequestResponse,
    BlindSignatureListResponse, 
    BlindSignatureResultResponse,
    GenerateKeysResponse,
    SuccessResponse
)

router = APIRouter(prefix="/api/blind-signatures", tags=["Blind Signatures"])
logger = logging.getLogger(__name__)

async def get_blind_signature_service(db: AsyncSession = Depends(get_db_session)) -> BlindSignatureService:
    """Dependency   BlindSignatureService"""
    return BlindSignatureService(db)

@router.post("/request", response_model=BlindSignatureRequestResponse)
async def request_blind_signature(
    request: BlindSignatureRequestModel,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
         
    
    :
    1.       
    2.   requester   
    3.  blinded_message     'pending'
    4.  request_id  
    """
    try:
        logger.info(f"Creating blind signature request for poll {request.poll_id} by user {request.requester_id}")
        
        #    
        request_id = await service.create_signature_request(
            poll_id=request.poll_id,
            requester_id=request.requester_id,
            blinded_message=request.blinded_message
        )
        
        return BlindSignatureRequestResponse(
            success=True,
            request_id=request_id,
            status="pending",
            message="Blind signature request created successfully. Waiting for trusted party approval."
        )
        
    except ValueError as e:
        logger.warning(f"Validation error in blind signature request: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error creating blind signature request: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating blind signature request"
        )

@router.get("/pending/{trusted_party_id}", response_model=BlindSignatureListResponse)
async def get_pending_requests(
    trusted_party_id: int,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
      pending   trusted party
    
       trusted party :
    1.   ,  
    2.  blinded_message  
    """
    try:
        logger.info(f"Getting pending requests for trusted party {trusted_party_id}")
        
        pending_requests = await service.get_pending_requests(trusted_party_id)
        
        return BlindSignatureListResponse(
            success=True,
            requests=pending_requests,
            count=len(pending_requests),
            message=f"Found {len(pending_requests)} pending requests"
        )
        
    except ValueError as e:
        logger.warning(f"Validation error getting pending requests: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error getting pending requests: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting pending requests"
        )

@router.post("/sign/{request_id}", response_model=SuccessResponse)
async def process_blind_signature(
    request_id: int,
    process_request: ProcessBlindSignatureRequest,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
         trusted party
    
    :
    1.   signer  trusted party   
    2.  :  blinded_message  
    3.  :   'rejected'
    4.    
    """
    try:
        logger.info(f"Processing blind signature request {request_id} by signer {process_request.signer_id}")
        
        #    
        await service.process_signature_request(
            request_id=request_id,
            signer_id=process_request.signer_id,
            approved=process_request.approved,
            rejection_reason=process_request.rejection_reason
        )
        
        status_msg = "approved and signed" if process_request.approved else "rejected"
        return SuccessResponse(
            success=True,
            message=f"Blind signature request {status_msg} successfully"
        )
        
    except ValueError as e:
        logger.warning(f"Validation error processing blind signature: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error processing blind signature request: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while processing blind signature request"
        )

@router.get("/result/{request_id}", response_model=BlindSignatureResultResponse)
async def get_signature_result(
    request_id: int,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
         
    
    :
    1.   (pending/signed/rejected/used)
    2.  signed -   unblinding  
    3.  rejected -  
    """
    try:
        logger.info(f"Getting signature result for request {request_id}")
        
        result = await service.get_signature_result(request_id)
        
        return BlindSignatureResultResponse(
            success=True,
            request_id=request_id,
            status=result["status"],
            blind_signature=result.get("blind_signature"),
            rejection_reason=result.get("rejection_reason"),
            created_at=result["created_at"],
            processed_at=result.get("processed_at"),
            message=f"Request status: {result['status']}"
        )
        
    except ValueError as e:
        logger.warning(f"Validation error getting signature result: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Request not found: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error getting signature result: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting signature result"
        )

@router.post("/generate-keys", response_model=GenerateKeysResponse)
async def generate_trusted_party_keys(
    request: GenerateKeysRequest,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
     RSA    trusted party
    
    :
    1.  RSA-2048  
    2.    master encryption key
    3.       user_id
    4.       
    """
    try:
        logger.info(f"Generating RSA keys for trusted party {request.user_id}")
        
        public_key_hex = await service.generate_and_store_rsa_keys(
            user_id=request.user_id,
            poll_id=request.poll_id
        )
        
        return GenerateKeysResponse(
            success=True,
            user_id=request.user_id,
            poll_id=request.poll_id,
            public_key=public_key_hex,
            message="RSA keys generated and stored successfully"
        )
        
    except ValueError as e:
        logger.warning(f"Validation error generating keys: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error generating trusted party keys: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while generating keys"
        )

@router.get("/requests/user/{user_id}", response_model=BlindSignatureListResponse) 
async def get_user_requests(
    user_id: int,
    service: BlindSignatureService = Depends(get_blind_signature_service)
):
    """
        (   )
    """
    try:
        logger.info(f"Getting signature requests for user {user_id}")
        
        user_requests = await service.get_user_requests(user_id)
        
        return BlindSignatureListResponse(
            success=True,
            requests=user_requests,
            count=len(user_requests),
            message=f"Found {len(user_requests)} requests for user"
        )
        
    except Exception as e:
        logger.error(f"Error getting user requests: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting user requests"
        )