"""
Health check endpoints for Verification Service
"""
import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db, health_check
from app.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health")
async def health_endpoint():
    """Basic health check"""
    return {
        "status": "healthy",
        "service": "verification-service",
        "version": "1.0.0-phase2",
        "timestamp": datetime.utcnow().isoformat(),
        "port": settings.port
    }


@router.get("/health/detailed")
async def detailed_health_check(db: AsyncSession = Depends(get_db)):
    """Detailed health check including database"""
    
    # Check database
    db_healthy = await health_check()
    
    # Check external services (basic connectivity)
    external_services = {
        "identity_service": settings.identity_service_url,
        "poll_service": settings.poll_service_url
    }
    
    health_status = {
        "status": "healthy" if db_healthy else "unhealthy",
        "service": "verification-service",
        "version": "1.0.0-phase2",
        "timestamp": datetime.utcnow().isoformat(),
        "components": {
            "database": {
                "status": "healthy" if db_healthy else "unhealthy",
                "url": f"{settings.db_host}:{settings.db_port}/{settings.db_name}"
            },
            "cryptography": {
                "status": "healthy",
                "rsa_key_size": settings.rsa_key_size
            },
            "external_services": external_services
        },
        "configuration": {
            "debug": settings.debug,
            "max_requests_per_minute": settings.max_requests_per_minute,
            "blind_signature_cache_ttl": settings.blind_signature_cache_ttl
        }
    }
    
    if not db_healthy:
        raise HTTPException(status_code=503, detail=health_status)
    
    return health_status


@router.get("/ready")
async def readiness_check(db: AsyncSession = Depends(get_db)):
    """Readiness check for Kubernetes/Docker"""
    
    db_healthy = await health_check()
    
    if not db_healthy:
        raise HTTPException(
            status_code=503,
            detail={
                "status": "not_ready",
                "reason": "database_unavailable"
            }
        )
    
    return {
        "status": "ready",
        "timestamp": datetime.utcnow().isoformat()
    }