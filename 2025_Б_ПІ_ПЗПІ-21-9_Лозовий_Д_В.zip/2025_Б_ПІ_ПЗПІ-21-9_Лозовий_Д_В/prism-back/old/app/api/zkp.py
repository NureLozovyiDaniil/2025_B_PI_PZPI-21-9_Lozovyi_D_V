# verification-service/app/api/zkp.py

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, Any, Optional
import logging

from app.database import get_db_session
from app.services.improved_zkp_service import ImprovedZKPService
from app.models.requests import ZKProofVerificationRequest
from app.models.responses import ZKProofVerificationResponse, SuccessResponse

router = APIRouter(prefix="/api/zkp", tags=["ZKP Verification"])
logger = logging.getLogger(__name__)

async def get_zkp_service(db: AsyncSession = Depends(get_db_session)) -> ImprovedZKPService:
    """Dependency   ZKPService"""
    return ImprovedZKPService(db)

@router.post("/generate", response_model=Dict[str, Any])
async def generate_zkp_proof(
    unblinded_signature: str,
    anonymous_id: str,
    trusted_party_id: int,
    poll_id: int,
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
     ZKP    
    
        unblinded_signature
           .
    
    Args:
        unblinded_signature:    trusted party
        anonymous_id:    
        trusted_party_id: ID   (  )
        poll_id: ID 
        
    Returns:
        ZKP proof     
    """
    try:
        logger.info(f"Generating ZKP proof for poll {poll_id}, trusted party {trusted_party_id}")
        
        #   
        if not unblinded_signature or len(unblinded_signature) < 64:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid unblinded signature"
            )
        
        if not anonymous_id or len(anonymous_id) < 16:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid anonymous ID"
            )
        
        if poll_id <= 0 or trusted_party_id <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid poll_id or trusted_party_id"
            )
        
        #  ZKP proof
        proof = await service.generate_proof(
            unblinded_signature=unblinded_signature,
            anonymous_id=anonymous_id,
            trusted_party_id=trusted_party_id,
            poll_id=poll_id
        )
        
        return {
            "success": True,
            "proof": proof,
            "message": "ZKP proof generated successfully"
        }
        
    except ValueError as e:
        logger.warning(f"Validation error generating ZKP proof: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error generating ZKP proof: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while generating ZKP proof"
        )

@router.post("/verify", response_model=ZKProofVerificationResponse)
async def verify_zkp_proof(
    request: ZKProofVerificationRequest,
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
     ZKP    
    
     Poll Management Service    
         .
    
    Args:
        request: ZKP   
        
    Returns:
           proof_id  
    """
    try:
        logger.info(f"Verifying ZKP proof for poll {request.poll_id}")
        
        #  proof
        is_valid = await service.verify_proof(
            proof=request.proof,
            poll_id=request.poll_id
        )
        
        if is_valid:
            return ZKProofVerificationResponse(
                success=True,
                valid=True,
                anonymous_id=request.anonymous_id,
                message="ZKP proof verified successfully. Anonymous voting authorized."
            )
        else:
            return ZKProofVerificationResponse(
                success=True,
                valid=False,
                anonymous_id=request.anonymous_id,
                message="ZKP proof verification failed. Anonymous voting denied."
            )
        
    except ValueError as e:
        logger.warning(f"Validation error verifying ZKP proof: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error verifying ZKP proof: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while verifying ZKP proof"
        )

@router.get("/statistics/{poll_id}", response_model=Dict[str, Any])
async def get_zkp_statistics(
    poll_id: int,
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
      ZKP   
    
         .
    """
    try:
        logger.info(f"Getting ZKP statistics for poll {poll_id}")
        
        stats = await service.get_proof_statistics(poll_id)
        
        return {
            "success": True,
            "poll_id": poll_id,
            "statistics": stats,
            "message": "ZKP statistics retrieved successfully"
        }
        
    except Exception as e:
        logger.error(f"Error getting ZKP statistics: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting ZKP statistics"
        )

@router.get("/statistics", response_model=Dict[str, Any])
async def get_all_zkp_statistics(
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
       ZKP   
    """
    try:
        logger.info("Getting overall ZKP statistics")
        
        stats = await service.get_proof_statistics()
        
        return {
            "success": True,
            "statistics": stats,
            "message": "Overall ZKP statistics retrieved successfully"
        }
        
    except Exception as e:
        logger.error(f"Error getting overall ZKP statistics: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting overall ZKP statistics"
        )

@router.post("/cleanup", response_model=SuccessResponse)
async def cleanup_expired_proofs(
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
      ZKP  ( endpoint)
    
     proof   24     .
    """
    try:
        logger.info("Starting ZKP proof cleanup")
        
        cleaned_count = await service.cleanup_expired_proofs()
        
        return SuccessResponse(
            success=True,
            message=f"Cleaned up {cleaned_count} expired ZKP proofs"
        )
        
    except Exception as e:
        logger.error(f"Error during ZKP cleanup: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error during ZKP cleanup"
        )

@router.post("/test/generate-mock", response_model=Dict[str, Any])
async def generate_mock_zkp_proof(
    poll_id: int,
    trusted_party_id: int,
    service: ImprovedZKPService = Depends(get_zkp_service)
):
    """
     mock ZKP proof   (development only)
    
         
         blind signatures.
    """
    try:
        logger.info(f"Generating mock ZKP proof for testing")
        
        #  utility 
        from app.services.improved_zkp_service import (
            create_mock_unblinded_signature,
            create_mock_anonymous_id
        )
        
        #  mock 
        mock_signature = create_mock_unblinded_signature()
        mock_anonymous_id = create_mock_anonymous_id()
        
        #  proof
        proof = await service.generate_proof(
            unblinded_signature=mock_signature,
            anonymous_id=mock_anonymous_id,
            trusted_party_id=trusted_party_id,
            poll_id=poll_id
        )
        
        return {
            "success": True,
            "proof": proof,
            "mock_data": {
                "unblinded_signature": mock_signature[:32] + "...",  #   
                "anonymous_id": mock_anonymous_id
            },
            "message": "Mock ZKP proof generated for testing"
        }
        
    except Exception as e:
        logger.error(f"Error generating mock ZKP proof: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while generating mock ZKP proof"
        )