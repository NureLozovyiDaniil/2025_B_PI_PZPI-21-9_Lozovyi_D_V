"""
API routers for Verification Service
"""
from .health import router as health_router
from .blind_signatures import router as blind_signature_router  
from .zkp import router as zkp_router

__all__ = ["health_router", "blind_signature_router", "zkp_router"]