package api

import (
	"context"
	"fmt"
	"go.uber.org/zap"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"blockchain-service/internal/service"
	"blockchain-service/internal/utils"
)

type Handler struct {
	blockchainService *service.BlockchainService
}

type ErrorResponse struct {
	Error   string `json:"error"`
	Message string `json:"message"`
	Code    int    `json:"code"`
}

type SuccessResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data"`
	Message string      `json:"message,omitempty"`
}

func NewHandler(blockchainService *service.BlockchainService) *Handler {
	return &Handler{
		blockchainService: blockchainService,
	}
}

func (h *Handler) RegisterPoll(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	utils.Info(ctx, "Received poll registration request")

	var req service.RegisterPollRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		//utils.Warn(ctx, "Invalid request format", "error", err.Error())
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "Invalid request format: " + err.Error(),
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithPollID(ctx, req.PollID)
	ctx = utils.WithUserID(ctx, req.CreatorID)

	//utils.Info(ctx, "Processing poll registration",
	//	utils.PollIDKey, req.PollID,
	//	"title", req.Title,
	//	"category", req.Category,
	//	utils.UserIDKey, req.CreatorID)

	response, err := h.blockchainService.RegisterPollOnBlockchain(ctx, req)
	if err != nil {
		utils.Error(ctx, "Poll registration failed", err)
		c.JSON(http.StatusInternalServerError, ErrorResponse{
			Error:   "registration_failed",
			Message: "Failed to register poll: " + err.Error(),
			Code:    http.StatusInternalServerError,
		})
		return
	}

	//utils.Info(ctx, "Poll registration completed",
	//	"tx_hash", response.TxHash,
	//	"status", response.Status)

	//c.JSON(http.StatusOK, SuccessResponse{
	//	Success: true,
	//	Data:    response,
	//	Message: "Poll registration initiated successfully",
	//})
	c.JSON(http.StatusOK, response)
}

func (h *Handler) GetPollById(c *gin.Context) {
	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	utils.Info(ctx, "Received poll request")

	pollStrId := c.Param("id")
	pollId, err := strconv.Atoi(pollStrId)
	if err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "Invalid poll id format: " + err.Error(),
			Code:    http.StatusBadRequest,
		})
	}

	res, err := h.blockchainService.GetPollById(ctx, uint(pollId))
	if err != nil {
		utils.Error(ctx, "Poll retrieval failed", err)
		c.JSON(http.StatusInternalServerError, ErrorResponse{
			Error:   "poll_retrieval_failed",
			Message: "Poll retrieval failed: " + err.Error(),
			Code:    http.StatusInternalServerError,
		})
	}

	c.JSON(http.StatusOK, SuccessResponse{
		Success: true,
		Data:    res,
		Message: "Poll retrieved successfully",
	})
}

func (h *Handler) RecordVote(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	utils.Info(ctx, "Received vote recording request")

	var req service.RecordVoteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		//utils.Warn(ctx, "Invalid request format", "error", err.Error())
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "Invalid request format: " + err.Error(),
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithPollID(ctx, req.PollID)
	ctx = utils.WithUserID(ctx, req.UserID)

	//utils.Info(ctx, "Processing vote recording",
	//	utils.PollIDKey, req.PollID,
	//	"option_id", req.OptionID,
	//	utils.UserIDKey, req.UserID)

	response, err := h.blockchainService.RecordVoteOnBlockchain(ctx, req)
	if err != nil {
		utils.Error(ctx, "Vote recording failed", err)

		statusCode := http.StatusInternalServerError
		errorCode := "recording_failed"

		if err.Error() == "user already voted in this poll" {
			statusCode = http.StatusConflict
			errorCode = "already_voted"
		}

		c.JSON(statusCode, ErrorResponse{
			Error:   errorCode,
			Message: "Failed to record vote: " + err.Error(),
			Code:    statusCode,
		})
		return
	}

	//utils.Info(ctx, "Vote recording completed",
	//	"tx_hash", response.TxHash,
	//	"status", response.Status)

	c.JSON(http.StatusOK, response)
}

func (h *Handler) RecordAnonymousVote(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	utils.Info(ctx, "Received anonymous vote recording request")

	var req service.RecordVoteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "Invalid request format: " + err.Error(),
			Code:    http.StatusBadRequest,
		})
		return
	}

	if req.AnonymousID == nil || *req.AnonymousID == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "AnonymousID is required for anonymous voting",
			Code:    http.StatusBadRequest,
		})
		return
	}

	anonymousID := *req.AnonymousID
	if len(anonymousID) != 64 {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "AnonymousID must be 64 characters long",
			Code:    http.StatusBadRequest,
		})
		return
	}

	for _, char := range anonymousID {
		if !((char >= '0' && char <= '9') || (char >= 'a' && char <= 'f') || (char >= 'A' && char <= 'F')) {
			c.JSON(http.StatusBadRequest, ErrorResponse{
				Error:   "validation_error",
				Message: "AnonymousID must be a valid hex string",
				Code:    http.StatusBadRequest,
			})
			return
		}
	}

	if req.UserID != 0 {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "UserID must not be specified for anonymous voting",
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithPollID(ctx, req.PollID)
	ctx = utils.WithAnonymousID(ctx, anonymousID)

	response, err := h.blockchainService.RecordAnonymousVoteOnBlockchain(ctx, req)
	if err != nil {
		utils.Error(ctx, "Anonymous vote recording failed", err)

		statusCode := http.StatusInternalServerError
		errorCode := "recording_failed"

		if err.Error() == "anonymous ID already used in this poll" {
			statusCode = http.StatusConflict
			errorCode = "already_voted"
		}

		c.JSON(statusCode, ErrorResponse{
			Error:   errorCode,
			Message: "Failed to record anonymous vote: " + err.Error(),
			Code:    statusCode,
		})
		return
	}

	c.JSON(http.StatusOK, response)
}

func (h *Handler) GetTransactionStatus(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()

	txHash := c.Param("hash")
	if txHash == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "missing_parameter",
			Message: "Transaction hash is required",
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithTransaction(ctx, txHash)
	utils.Debug(ctx, "Getting transaction status", zap.String("txn_hash", txHash))

	response, err := h.blockchainService.GetTransactionStatus(ctx, txHash)
	if err != nil {
		utils.Error(ctx, "Failed to get transaction status", err)
		c.JSON(http.StatusInternalServerError, ErrorResponse{
			Error:   "status_check_failed",
			Message: "Failed to get transaction status: " + err.Error(),
			Code:    http.StatusInternalServerError,
		})
		return
	}

	utils.Debug(ctx, "Transaction status retrieved",
		zap.String("status", response.Status),
	)

	c.JSON(http.StatusOK, SuccessResponse{
		Success: true,
		Data:    response,
	})
}

func (h *Handler) StoreResults(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	utils.Info(ctx, "Received results storage request")

	var req service.StoreResultsRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		//utils.Warn(ctx, "Invalid request format", "error", err.Error())
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "validation_error",
			Message: "Invalid request format: " + err.Error(),
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithPollID(ctx, req.PollID)

	//utils.Info(ctx, "Processing results storage",
	//	utils.PollIDKey, req.PollID,
	//	"option_counts", req.OptionCounts)

	response, err := h.blockchainService.StoreResultsOnBlockchain(ctx, req)
	if err != nil {
		utils.Error(ctx, "Results storage failed", err)
		c.JSON(http.StatusInternalServerError, ErrorResponse{
			Error:   "storage_failed",
			Message: "Failed to store results: " + err.Error(),
			Code:    http.StatusInternalServerError,
		})
		return
	}

	//utils.Info(ctx, "Results storage completed",
	//	"tx_hash", response.TxHash,
	//	"status", response.Status)

	c.JSON(http.StatusOK, response)
}

func (h *Handler) GetPollResults(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	pollIDStr := c.Param("id")
	if pollIDStr == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "missing_parameter",
			Message: "Poll ID is required",
			Code:    http.StatusBadRequest,
		})
		return
	}

	pollID, err := strconv.ParseUint(pollIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "invalid_parameter",
			Message: "Invalid poll ID format",
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithPollID(ctx, uint(pollID))
	//utils.Debug(ctx, "Getting poll results", utils.PollIDKey, uint(pollID))

	response, err := h.blockchainService.GetPollResultsFromBlockchain(ctx, uint(pollID))
	if err != nil {
		utils.Error(ctx, "Failed to get poll results", err)

		statusCode := http.StatusInternalServerError
		errorCode := "get_results_failed"

		if err.Error() == "results not found for poll" {
			statusCode = http.StatusNotFound
			errorCode = "results_not_found"
		}

		c.JSON(statusCode, ErrorResponse{
			Error:   errorCode,
			Message: "Failed to get poll results: " + err.Error(),
			Code:    statusCode,
		})
		return
	}

	//utils.Debug(ctx, "Poll results retrieved",
	//	"total_votes", response.TotalVotes,
	//	"winner_option", response.WinnerOption)

	c.JSON(http.StatusOK, response)
}

func (h *Handler) Health(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()

	utils.Debug(ctx, "Health check requested")

	health := h.blockchainService.Health(ctx)

	statusCode := http.StatusOK
	if health["overall_status"] != "healthy" {
		statusCode = http.StatusServiceUnavailable
	}

	health["timestamp"] = time.Now().Unix()
	health["service"] = "blockchain-service"
	health["version"] = "1.0.0-phase1"

	//utils.Debug(ctx, "Health check completed",
	//	"overall_status", health["overall_status"])

	c.JSON(statusCode, health)
}

func (h *Handler) GetUserAddress(c *gin.Context) {

	requestID := uuid.New().String()
	ctx := utils.WithRequestID(c.Request.Context(), requestID)

	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	userIDStr := c.Param("id")
	if userIDStr == "" {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "missing_parameter",
			Message: "User ID is required",
			Code:    http.StatusBadRequest,
		})
		return
	}

	userID, err := strconv.ParseUint(userIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Error:   "invalid_parameter",
			Message: "Invalid user ID format",
			Code:    http.StatusBadRequest,
		})
		return
	}

	ctx = utils.WithUserID(ctx, uint(userID))
	//utils.Debug(ctx, "Getting user address", utils.UserIDKey, uint(userID))

	c.JSON(http.StatusNotImplemented, ErrorResponse{
		Error:   "not_implemented",
		Message: "This endpoint is not implemented yet",
		Code:    http.StatusNotImplemented,
	})
}

func RequestLoggerMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		requestID := uuid.New().String()
		ctx := utils.WithRequestID(c.Request.Context(), requestID)
		c.Request = c.Request.WithContext(ctx)

		c.Header("X-Request-ID", requestID)

		//utils.Info(ctx, "HTTP request started",
		//	"method", c.Request.Method,
		//	"path", c.Request.URL.Path,
		//	"client_ip", c.ClientIP(),
		//	"user_agent", c.Request.UserAgent())

		c.Next()

		duration := time.Since(start)
		utils.LogAPIRequest(ctx, c.Request.Method, c.Request.URL.Path, c.Writer.Status(), duration)
	}
}

func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Request-ID")
		c.Header("Access-Control-Expose-Headers", "X-Request-ID")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusOK)
			return
		}

		c.Next()
	}
}

func RecoveryMiddleware() gin.HandlerFunc {
	return gin.CustomRecovery(func(c *gin.Context, recovered interface{}) {
		ctx := c.Request.Context()
		utils.Error(ctx, "Handler panic recovered",
			fmt.Errorf("panic: %v", recovered))

		c.JSON(http.StatusInternalServerError, ErrorResponse{
			Error:   "internal_error",
			Message: "Internal server error occurred",
			Code:    http.StatusInternalServerError,
		})
	})
}
