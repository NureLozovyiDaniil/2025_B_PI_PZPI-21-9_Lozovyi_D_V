package config

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/spf13/viper"
)

type Config struct {
	Server     ServerConfig     `mapstructure:"server"`
	Blockchain BlockchainConfig `mapstructure:"blockchain"`
	Identity   IdentityConfig   `mapstructure:"identity"`
	Logging    LoggingConfig    `mapstructure:"logging"`
}

type ServerConfig struct {
	Port         string        `mapstructure:"port"`
	ReadTimeout  time.Duration `mapstructure:"read_timeout"`
	WriteTimeout time.Duration `mapstructure:"write_timeout"`
	IdleTimeout  time.Duration `mapstructure:"idle_timeout"`
}

type BlockchainConfig struct {
	RpcURL             string        `mapstructure:"rpc_url"`
	PrivateKey         string        `mapstructure:"private_key"`
	ChainID            int64         `mapstructure:"chain_id"`
	GasLimit           uint64        `mapstructure:"gas_limit"`
	GasPrice           int64         `mapstructure:"gas_price"` // wei, 0 = auto
	TransactionTimeout time.Duration `mapstructure:"transaction_timeout"`
	ConfirmationBlocks uint64        `mapstructure:"confirmation_blocks"`
	RetryAttempts      int           `mapstructure:"retry_attempts"`
	RetryDelay         time.Duration `mapstructure:"retry_delay"`

	PollRegistryAddress  string `mapstructure:"poll_registry_address"`
	VoteVerifierAddress  string `mapstructure:"vote_verifier_address"`
	ResultStorageAddress string `mapstructure:"result_storage_address"`
}

type IdentityConfig struct {
	BaseURL        string        `mapstructure:"base_url"`
	InternalApiKey string        `mapstructure:"internal_api_key"`
	Timeout        time.Duration `mapstructure:"timeout"`
	RetryAttempts  int           `mapstructure:"retry_attempts"`
	RetryDelay     time.Duration `mapstructure:"retry_delay"`
	CacheEnabled   bool          `mapstructure:"cache_enabled"`
	CacheTTL       time.Duration `mapstructure:"cache_ttl"`
}

type LoggingConfig struct {
	Level      string `mapstructure:"level"`  // debug, info, warn, error
	Format     string `mapstructure:"format"` // json, console
	Output     string `mapstructure:"output"` // stdout, file, both
	Filename   string `mapstructure:"filename"`
	MaxSize    int    `mapstructure:"max_size"` // MB
	MaxBackups int    `mapstructure:"max_backups"`
	MaxAge     int    `mapstructure:"max_age"`
}

func LoadConfig(configPath string) (*Config, error) {
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(configPath)
	viper.AddConfigPath("internal/config")
	viper.AddConfigPath(".")

	setDefaults()

	if err := viper.ReadInConfig(); err != nil {
		var configFileNotFoundError viper.ConfigFileNotFoundError
		if !errors.As(err, &configFileNotFoundError) {
			return nil, fmt.Errorf("error reading config file: %w", err)
		}

	}

	viper.SetEnvPrefix("BLOCKCHAIN")
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	viper.AutomaticEnv()

	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		return nil, fmt.Errorf("error unmarshaling config: %w", err)
	}

	if err := validateConfig(&config); err != nil {
		return nil, fmt.Errorf("config validation error: %w", err)
	}

	return &config, nil
}

func setDefaults() {
	// Server defaults
	viper.SetDefault("server.port", "8081")
	viper.SetDefault("server.read_timeout", "60s")
	viper.SetDefault("server.write_timeout", "60s")
	viper.SetDefault("server.idle_timeout", "120s")

	// Blockchain defaults (Hardhat local network)
	viper.SetDefault("blockchain.rpc_url", "http://localhost:8545")
	viper.SetDefault("blockchain.chain_id", 31337) // Hardhat
	viper.SetDefault("blockchain.gas_limit", 3000000)
	viper.SetDefault("blockchain.gas_price", 0) // auto
	viper.SetDefault("blockchain.transaction_timeout", "120s")
	viper.SetDefault("blockchain.confirmation_blocks", 1)
	viper.SetDefault("blockchain.retry_attempts", 3)
	viper.SetDefault("blockchain.retry_delay", "5s")

	// Identity Service defaults
	viper.SetDefault("identity.base_url", "http://localhost:8080")
	viper.SetDefault("identity.timeout", "30s")
	viper.SetDefault("identity.retry_attempts", 3)
	viper.SetDefault("identity.retry_delay", "2s")
	viper.SetDefault("identity.cache_enabled", true)
	viper.SetDefault("identity.cache_ttl", "5m")

	// Logging defaults
	viper.SetDefault("logging.level", "info")
	viper.SetDefault("logging.format", "json")
	viper.SetDefault("logging.output", "stdout")
	viper.SetDefault("logging.filename", "logs/blockchain-service.log")
	viper.SetDefault("logging.max_size", 100)
	viper.SetDefault("logging.max_backups", 10)
	viper.SetDefault("logging.max_age", 30)
}

func validateConfig(config *Config) error {

	if config.Blockchain.RpcURL == "" {
		return fmt.Errorf("blockchain.rpc_url is required")
	}

	if config.Blockchain.PrivateKey == "" {
		return fmt.Errorf("blockchain.private_key is required")
	}

	privateKey := strings.TrimPrefix(config.Blockchain.PrivateKey, "0x")
	if len(privateKey) != 64 {
		return fmt.Errorf("blockchain.private_key must be 64 characters (32 bytes)")
	}

	if config.Identity.BaseURL == "" {
		return fmt.Errorf("identity.base_url is required")
	}

	if !strings.HasPrefix(config.Blockchain.RpcURL, "http://") &&
		!strings.HasPrefix(config.Blockchain.RpcURL, "https://") &&
		!strings.HasPrefix(config.Blockchain.RpcURL, "ws://") &&
		!strings.HasPrefix(config.Blockchain.RpcURL, "wss://") {
		return fmt.Errorf("blockchain.rpc_url must start with http://, https://, ws://, or wss://")
	}

	if !strings.HasPrefix(config.Identity.BaseURL, "http://") &&
		!strings.HasPrefix(config.Identity.BaseURL, "https://") {
		return fmt.Errorf("identity.base_url must start with http:// or https://")
	}

	switch config.Blockchain.ChainID {
	case 31337: // Hardhat
		// OK
	case 80001: // Polygon Mumbai
		// OK
	case 137: // Polygon Mainnet
		// OK
	case 1: // Ethereum Mainnet
		// OK
	default:

	}

	return nil
}

func (c *Config) GetNetworkName() string {
	switch c.Blockchain.ChainID {
	case 31337:
		return "Hardhat Local"
	case 80001:
		return "Polygon Mumbai"
	case 137:
		return "Polygon Mainnet"
	case 1:
		return "Ethereum Mainnet"
	default:
		return fmt.Sprintf("Unknown Network (Chain ID: %d)", c.Blockchain.ChainID)
	}
}

func (c *Config) IsProduction() bool {
	return c.Blockchain.ChainID == 137 || c.Blockchain.ChainID == 1
}

func (c *Config) IsDevelopment() bool {
	return c.Blockchain.ChainID == 31337
}

func (c *Config) IsTestnet() bool {
	return c.Blockchain.ChainID == 80001
}

func (c *BlockchainConfig) HasContractAddresses() bool {
	return c.PollRegistryAddress != "" &&
		c.VoteVerifierAddress != "" &&
		c.ResultStorageAddress != ""
}
