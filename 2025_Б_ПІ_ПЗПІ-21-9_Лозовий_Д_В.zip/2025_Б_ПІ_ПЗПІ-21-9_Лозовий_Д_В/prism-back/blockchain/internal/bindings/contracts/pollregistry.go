// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package contracts

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// PollRegistryPollMetadata is an auto generated low-level Go binding around an user-defined struct.
type PollRegistryPollMetadata struct {
	PollId      *big.Int
	Title       string
	Category    string
	OptionsHash [32]byte
	Creator     common.Address
	StartTime   *big.Int
	EndTime     *big.Int
	IsPrivate   bool
	Status      uint8
	CreatedAt   *big.Int
}

// PollRegistryMetaData contains all meta data concerning the PollRegistry contract.
var PollRegistryMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"initialOwner\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"EnforcedPause\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ExpectedPause\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"}],\"name\":\"OwnableInvalidOwner\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"OwnableUnauthorizedAccount\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ReentrancyGuardReentrantCall\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Paused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"finalStatus\",\"type\":\"uint8\"}],\"name\":\"PollFinalized\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"creator\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"title\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"category\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"bool\",\"name\":\"isPrivate\",\"type\":\"bool\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"startTime\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"endTime\",\"type\":\"uint256\"}],\"name\":\"PollRegistered\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"oldStatus\",\"type\":\"uint8\"},{\"indexed\":false,\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"newStatus\",\"type\":\"uint8\"}],\"name\":\"PollStatusUpdated\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Unpaused\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"MAX_CATEGORY_LENGTH\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"MAX_TITLE_LENGTH\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"canModifyPoll\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"categoryPolls\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"creatorPolls\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"_category\",\"type\":\"string\"}],\"name\":\"getCategoryPollCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"_category\",\"type\":\"string\"}],\"name\":\"getCategoryPolls\",\"outputs\":[{\"internalType\":\"uint256[]\",\"name\":\"\",\"type\":\"uint256[]\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_creator\",\"type\":\"address\"}],\"name\":\"getCreatorPollCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_creator\",\"type\":\"address\"}],\"name\":\"getCreatorPolls\",\"outputs\":[{\"internalType\":\"uint256[]\",\"name\":\"\",\"type\":\"uint256[]\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getPoll\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"string\",\"name\":\"title\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"category\",\"type\":\"string\"},{\"internalType\":\"bytes32\",\"name\":\"optionsHash\",\"type\":\"bytes32\"},{\"internalType\":\"address\",\"name\":\"creator\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"startTime\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"endTime\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isPrivate\",\"type\":\"bool\"},{\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"status\",\"type\":\"uint8\"},{\"internalType\":\"uint256\",\"name\":\"createdAt\",\"type\":\"uint256\"}],\"internalType\":\"structPollRegistry.PollMetadata\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"isPollActive\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"pollExists\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"polls\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"string\",\"name\":\"title\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"category\",\"type\":\"string\"},{\"internalType\":\"bytes32\",\"name\":\"optionsHash\",\"type\":\"bytes32\"},{\"internalType\":\"address\",\"name\":\"creator\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"startTime\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"endTime\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isPrivate\",\"type\":\"bool\"},{\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"status\",\"type\":\"uint8\"},{\"internalType\":\"uint256\",\"name\":\"createdAt\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"string\",\"name\":\"_title\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"_category\",\"type\":\"string\"},{\"internalType\":\"bytes32\",\"name\":\"_optionsHash\",\"type\":\"bytes32\"},{\"internalType\":\"address\",\"name\":\"_creator\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"_startTime\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_endTime\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"_isPrivate\",\"type\":\"bool\"}],\"name\":\"registerPoll\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"totalPolls\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"enumPollRegistry.PollStatus\",\"name\":\"_newStatus\",\"type\":\"uint8\"}],\"name\":\"updatePollStatus\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"}]",
}

// PollRegistryABI is the input ABI used to generate the binding from.
// Deprecated: Use PollRegistryMetaData.ABI instead.
var PollRegistryABI = PollRegistryMetaData.ABI

// PollRegistry is an auto generated Go binding around an Ethereum contract.
type PollRegistry struct {
	PollRegistryCaller     // Read-only binding to the contract
	PollRegistryTransactor // Write-only binding to the contract
	PollRegistryFilterer   // Log filterer for contract events
}

// PollRegistryCaller is an auto generated read-only Go binding around an Ethereum contract.
type PollRegistryCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// PollRegistryTransactor is an auto generated write-only Go binding around an Ethereum contract.
type PollRegistryTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// PollRegistryFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type PollRegistryFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// PollRegistrySession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type PollRegistrySession struct {
	Contract     *PollRegistry     // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// PollRegistryCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type PollRegistryCallerSession struct {
	Contract *PollRegistryCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts       // Call options to use throughout this session
}

// PollRegistryTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type PollRegistryTransactorSession struct {
	Contract     *PollRegistryTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts       // Transaction auth options to use throughout this session
}

// PollRegistryRaw is an auto generated low-level Go binding around an Ethereum contract.
type PollRegistryRaw struct {
	Contract *PollRegistry // Generic contract binding to access the raw methods on
}

// PollRegistryCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type PollRegistryCallerRaw struct {
	Contract *PollRegistryCaller // Generic read-only contract binding to access the raw methods on
}

// PollRegistryTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type PollRegistryTransactorRaw struct {
	Contract *PollRegistryTransactor // Generic write-only contract binding to access the raw methods on
}

// NewPollRegistry creates a new instance of PollRegistry, bound to a specific deployed contract.
func NewPollRegistry(address common.Address, backend bind.ContractBackend) (*PollRegistry, error) {
	contract, err := bindPollRegistry(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &PollRegistry{PollRegistryCaller: PollRegistryCaller{contract: contract}, PollRegistryTransactor: PollRegistryTransactor{contract: contract}, PollRegistryFilterer: PollRegistryFilterer{contract: contract}}, nil
}

// NewPollRegistryCaller creates a new read-only instance of PollRegistry, bound to a specific deployed contract.
func NewPollRegistryCaller(address common.Address, caller bind.ContractCaller) (*PollRegistryCaller, error) {
	contract, err := bindPollRegistry(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &PollRegistryCaller{contract: contract}, nil
}

// NewPollRegistryTransactor creates a new write-only instance of PollRegistry, bound to a specific deployed contract.
func NewPollRegistryTransactor(address common.Address, transactor bind.ContractTransactor) (*PollRegistryTransactor, error) {
	contract, err := bindPollRegistry(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &PollRegistryTransactor{contract: contract}, nil
}

// NewPollRegistryFilterer creates a new log filterer instance of PollRegistry, bound to a specific deployed contract.
func NewPollRegistryFilterer(address common.Address, filterer bind.ContractFilterer) (*PollRegistryFilterer, error) {
	contract, err := bindPollRegistry(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &PollRegistryFilterer{contract: contract}, nil
}

// bindPollRegistry binds a generic wrapper to an already deployed contract.
func bindPollRegistry(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := PollRegistryMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_PollRegistry *PollRegistryRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _PollRegistry.Contract.PollRegistryCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_PollRegistry *PollRegistryRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _PollRegistry.Contract.PollRegistryTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_PollRegistry *PollRegistryRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _PollRegistry.Contract.PollRegistryTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_PollRegistry *PollRegistryCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _PollRegistry.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_PollRegistry *PollRegistryTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _PollRegistry.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_PollRegistry *PollRegistryTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _PollRegistry.Contract.contract.Transact(opts, method, params...)
}

// MAXCATEGORYLENGTH is a free data retrieval call binding the contract method 0xe3348063.
//
// Solidity: function MAX_CATEGORY_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistryCaller) MAXCATEGORYLENGTH(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "MAX_CATEGORY_LENGTH")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// MAXCATEGORYLENGTH is a free data retrieval call binding the contract method 0xe3348063.
//
// Solidity: function MAX_CATEGORY_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistrySession) MAXCATEGORYLENGTH() (*big.Int, error) {
	return _PollRegistry.Contract.MAXCATEGORYLENGTH(&_PollRegistry.CallOpts)
}

// MAXCATEGORYLENGTH is a free data retrieval call binding the contract method 0xe3348063.
//
// Solidity: function MAX_CATEGORY_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) MAXCATEGORYLENGTH() (*big.Int, error) {
	return _PollRegistry.Contract.MAXCATEGORYLENGTH(&_PollRegistry.CallOpts)
}

// MAXTITLELENGTH is a free data retrieval call binding the contract method 0x2ef9a160.
//
// Solidity: function MAX_TITLE_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistryCaller) MAXTITLELENGTH(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "MAX_TITLE_LENGTH")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// MAXTITLELENGTH is a free data retrieval call binding the contract method 0x2ef9a160.
//
// Solidity: function MAX_TITLE_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistrySession) MAXTITLELENGTH() (*big.Int, error) {
	return _PollRegistry.Contract.MAXTITLELENGTH(&_PollRegistry.CallOpts)
}

// MAXTITLELENGTH is a free data retrieval call binding the contract method 0x2ef9a160.
//
// Solidity: function MAX_TITLE_LENGTH() view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) MAXTITLELENGTH() (*big.Int, error) {
	return _PollRegistry.Contract.MAXTITLELENGTH(&_PollRegistry.CallOpts)
}

// CanModifyPoll is a free data retrieval call binding the contract method 0x828fd3b5.
//
// Solidity: function canModifyPoll(uint256 _pollId, address _user) view returns(bool)
func (_PollRegistry *PollRegistryCaller) CanModifyPoll(opts *bind.CallOpts, _pollId *big.Int, _user common.Address) (bool, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "canModifyPoll", _pollId, _user)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// CanModifyPoll is a free data retrieval call binding the contract method 0x828fd3b5.
//
// Solidity: function canModifyPoll(uint256 _pollId, address _user) view returns(bool)
func (_PollRegistry *PollRegistrySession) CanModifyPoll(_pollId *big.Int, _user common.Address) (bool, error) {
	return _PollRegistry.Contract.CanModifyPoll(&_PollRegistry.CallOpts, _pollId, _user)
}

// CanModifyPoll is a free data retrieval call binding the contract method 0x828fd3b5.
//
// Solidity: function canModifyPoll(uint256 _pollId, address _user) view returns(bool)
func (_PollRegistry *PollRegistryCallerSession) CanModifyPoll(_pollId *big.Int, _user common.Address) (bool, error) {
	return _PollRegistry.Contract.CanModifyPoll(&_PollRegistry.CallOpts, _pollId, _user)
}

// CategoryPolls is a free data retrieval call binding the contract method 0x53eb06eb.
//
// Solidity: function categoryPolls(string , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistryCaller) CategoryPolls(opts *bind.CallOpts, arg0 string, arg1 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "categoryPolls", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// CategoryPolls is a free data retrieval call binding the contract method 0x53eb06eb.
//
// Solidity: function categoryPolls(string , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistrySession) CategoryPolls(arg0 string, arg1 *big.Int) (*big.Int, error) {
	return _PollRegistry.Contract.CategoryPolls(&_PollRegistry.CallOpts, arg0, arg1)
}

// CategoryPolls is a free data retrieval call binding the contract method 0x53eb06eb.
//
// Solidity: function categoryPolls(string , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) CategoryPolls(arg0 string, arg1 *big.Int) (*big.Int, error) {
	return _PollRegistry.Contract.CategoryPolls(&_PollRegistry.CallOpts, arg0, arg1)
}

// CreatorPolls is a free data retrieval call binding the contract method 0x8439e976.
//
// Solidity: function creatorPolls(address , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistryCaller) CreatorPolls(opts *bind.CallOpts, arg0 common.Address, arg1 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "creatorPolls", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// CreatorPolls is a free data retrieval call binding the contract method 0x8439e976.
//
// Solidity: function creatorPolls(address , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistrySession) CreatorPolls(arg0 common.Address, arg1 *big.Int) (*big.Int, error) {
	return _PollRegistry.Contract.CreatorPolls(&_PollRegistry.CallOpts, arg0, arg1)
}

// CreatorPolls is a free data retrieval call binding the contract method 0x8439e976.
//
// Solidity: function creatorPolls(address , uint256 ) view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) CreatorPolls(arg0 common.Address, arg1 *big.Int) (*big.Int, error) {
	return _PollRegistry.Contract.CreatorPolls(&_PollRegistry.CallOpts, arg0, arg1)
}

// GetCategoryPollCount is a free data retrieval call binding the contract method 0x82167cf9.
//
// Solidity: function getCategoryPollCount(string _category) view returns(uint256)
func (_PollRegistry *PollRegistryCaller) GetCategoryPollCount(opts *bind.CallOpts, _category string) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "getCategoryPollCount", _category)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetCategoryPollCount is a free data retrieval call binding the contract method 0x82167cf9.
//
// Solidity: function getCategoryPollCount(string _category) view returns(uint256)
func (_PollRegistry *PollRegistrySession) GetCategoryPollCount(_category string) (*big.Int, error) {
	return _PollRegistry.Contract.GetCategoryPollCount(&_PollRegistry.CallOpts, _category)
}

// GetCategoryPollCount is a free data retrieval call binding the contract method 0x82167cf9.
//
// Solidity: function getCategoryPollCount(string _category) view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) GetCategoryPollCount(_category string) (*big.Int, error) {
	return _PollRegistry.Contract.GetCategoryPollCount(&_PollRegistry.CallOpts, _category)
}

// GetCategoryPolls is a free data retrieval call binding the contract method 0x720a8ad4.
//
// Solidity: function getCategoryPolls(string _category) view returns(uint256[])
func (_PollRegistry *PollRegistryCaller) GetCategoryPolls(opts *bind.CallOpts, _category string) ([]*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "getCategoryPolls", _category)

	if err != nil {
		return *new([]*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new([]*big.Int)).(*[]*big.Int)

	return out0, err

}

// GetCategoryPolls is a free data retrieval call binding the contract method 0x720a8ad4.
//
// Solidity: function getCategoryPolls(string _category) view returns(uint256[])
func (_PollRegistry *PollRegistrySession) GetCategoryPolls(_category string) ([]*big.Int, error) {
	return _PollRegistry.Contract.GetCategoryPolls(&_PollRegistry.CallOpts, _category)
}

// GetCategoryPolls is a free data retrieval call binding the contract method 0x720a8ad4.
//
// Solidity: function getCategoryPolls(string _category) view returns(uint256[])
func (_PollRegistry *PollRegistryCallerSession) GetCategoryPolls(_category string) ([]*big.Int, error) {
	return _PollRegistry.Contract.GetCategoryPolls(&_PollRegistry.CallOpts, _category)
}

// GetCreatorPollCount is a free data retrieval call binding the contract method 0x3c9a7918.
//
// Solidity: function getCreatorPollCount(address _creator) view returns(uint256)
func (_PollRegistry *PollRegistryCaller) GetCreatorPollCount(opts *bind.CallOpts, _creator common.Address) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "getCreatorPollCount", _creator)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetCreatorPollCount is a free data retrieval call binding the contract method 0x3c9a7918.
//
// Solidity: function getCreatorPollCount(address _creator) view returns(uint256)
func (_PollRegistry *PollRegistrySession) GetCreatorPollCount(_creator common.Address) (*big.Int, error) {
	return _PollRegistry.Contract.GetCreatorPollCount(&_PollRegistry.CallOpts, _creator)
}

// GetCreatorPollCount is a free data retrieval call binding the contract method 0x3c9a7918.
//
// Solidity: function getCreatorPollCount(address _creator) view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) GetCreatorPollCount(_creator common.Address) (*big.Int, error) {
	return _PollRegistry.Contract.GetCreatorPollCount(&_PollRegistry.CallOpts, _creator)
}

// GetCreatorPolls is a free data retrieval call binding the contract method 0xec81a17a.
//
// Solidity: function getCreatorPolls(address _creator) view returns(uint256[])
func (_PollRegistry *PollRegistryCaller) GetCreatorPolls(opts *bind.CallOpts, _creator common.Address) ([]*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "getCreatorPolls", _creator)

	if err != nil {
		return *new([]*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new([]*big.Int)).(*[]*big.Int)

	return out0, err

}

// GetCreatorPolls is a free data retrieval call binding the contract method 0xec81a17a.
//
// Solidity: function getCreatorPolls(address _creator) view returns(uint256[])
func (_PollRegistry *PollRegistrySession) GetCreatorPolls(_creator common.Address) ([]*big.Int, error) {
	return _PollRegistry.Contract.GetCreatorPolls(&_PollRegistry.CallOpts, _creator)
}

// GetCreatorPolls is a free data retrieval call binding the contract method 0xec81a17a.
//
// Solidity: function getCreatorPolls(address _creator) view returns(uint256[])
func (_PollRegistry *PollRegistryCallerSession) GetCreatorPolls(_creator common.Address) ([]*big.Int, error) {
	return _PollRegistry.Contract.GetCreatorPolls(&_PollRegistry.CallOpts, _creator)
}

// GetPoll is a free data retrieval call binding the contract method 0x1a8cbcaa.
//
// Solidity: function getPoll(uint256 _pollId) view returns((uint256,string,string,bytes32,address,uint256,uint256,bool,uint8,uint256))
func (_PollRegistry *PollRegistryCaller) GetPoll(opts *bind.CallOpts, _pollId *big.Int) (PollRegistryPollMetadata, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "getPoll", _pollId)

	if err != nil {
		return *new(PollRegistryPollMetadata), err
	}

	out0 := *abi.ConvertType(out[0], new(PollRegistryPollMetadata)).(*PollRegistryPollMetadata)

	return out0, err

}

// GetPoll is a free data retrieval call binding the contract method 0x1a8cbcaa.
//
// Solidity: function getPoll(uint256 _pollId) view returns((uint256,string,string,bytes32,address,uint256,uint256,bool,uint8,uint256))
func (_PollRegistry *PollRegistrySession) GetPoll(_pollId *big.Int) (PollRegistryPollMetadata, error) {
	return _PollRegistry.Contract.GetPoll(&_PollRegistry.CallOpts, _pollId)
}

// GetPoll is a free data retrieval call binding the contract method 0x1a8cbcaa.
//
// Solidity: function getPoll(uint256 _pollId) view returns((uint256,string,string,bytes32,address,uint256,uint256,bool,uint8,uint256))
func (_PollRegistry *PollRegistryCallerSession) GetPoll(_pollId *big.Int) (PollRegistryPollMetadata, error) {
	return _PollRegistry.Contract.GetPoll(&_PollRegistry.CallOpts, _pollId)
}

// IsPollActive is a free data retrieval call binding the contract method 0x2ec15480.
//
// Solidity: function isPollActive(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistryCaller) IsPollActive(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "isPollActive", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// IsPollActive is a free data retrieval call binding the contract method 0x2ec15480.
//
// Solidity: function isPollActive(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistrySession) IsPollActive(_pollId *big.Int) (bool, error) {
	return _PollRegistry.Contract.IsPollActive(&_PollRegistry.CallOpts, _pollId)
}

// IsPollActive is a free data retrieval call binding the contract method 0x2ec15480.
//
// Solidity: function isPollActive(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistryCallerSession) IsPollActive(_pollId *big.Int) (bool, error) {
	return _PollRegistry.Contract.IsPollActive(&_PollRegistry.CallOpts, _pollId)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_PollRegistry *PollRegistryCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_PollRegistry *PollRegistrySession) Owner() (common.Address, error) {
	return _PollRegistry.Contract.Owner(&_PollRegistry.CallOpts)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_PollRegistry *PollRegistryCallerSession) Owner() (common.Address, error) {
	return _PollRegistry.Contract.Owner(&_PollRegistry.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_PollRegistry *PollRegistryCaller) Paused(opts *bind.CallOpts) (bool, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "paused")

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_PollRegistry *PollRegistrySession) Paused() (bool, error) {
	return _PollRegistry.Contract.Paused(&_PollRegistry.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_PollRegistry *PollRegistryCallerSession) Paused() (bool, error) {
	return _PollRegistry.Contract.Paused(&_PollRegistry.CallOpts)
}

// PollExists is a free data retrieval call binding the contract method 0x88d21ff3.
//
// Solidity: function pollExists(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistryCaller) PollExists(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "pollExists", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// PollExists is a free data retrieval call binding the contract method 0x88d21ff3.
//
// Solidity: function pollExists(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistrySession) PollExists(_pollId *big.Int) (bool, error) {
	return _PollRegistry.Contract.PollExists(&_PollRegistry.CallOpts, _pollId)
}

// PollExists is a free data retrieval call binding the contract method 0x88d21ff3.
//
// Solidity: function pollExists(uint256 _pollId) view returns(bool)
func (_PollRegistry *PollRegistryCallerSession) PollExists(_pollId *big.Int) (bool, error) {
	return _PollRegistry.Contract.PollExists(&_PollRegistry.CallOpts, _pollId)
}

// Polls is a free data retrieval call binding the contract method 0xac2f0074.
//
// Solidity: function polls(uint256 ) view returns(uint256 pollId, string title, string category, bytes32 optionsHash, address creator, uint256 startTime, uint256 endTime, bool isPrivate, uint8 status, uint256 createdAt)
func (_PollRegistry *PollRegistryCaller) Polls(opts *bind.CallOpts, arg0 *big.Int) (struct {
	PollId      *big.Int
	Title       string
	Category    string
	OptionsHash [32]byte
	Creator     common.Address
	StartTime   *big.Int
	EndTime     *big.Int
	IsPrivate   bool
	Status      uint8
	CreatedAt   *big.Int
}, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "polls", arg0)

	outstruct := new(struct {
		PollId      *big.Int
		Title       string
		Category    string
		OptionsHash [32]byte
		Creator     common.Address
		StartTime   *big.Int
		EndTime     *big.Int
		IsPrivate   bool
		Status      uint8
		CreatedAt   *big.Int
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.PollId = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.Title = *abi.ConvertType(out[1], new(string)).(*string)
	outstruct.Category = *abi.ConvertType(out[2], new(string)).(*string)
	outstruct.OptionsHash = *abi.ConvertType(out[3], new([32]byte)).(*[32]byte)
	outstruct.Creator = *abi.ConvertType(out[4], new(common.Address)).(*common.Address)
	outstruct.StartTime = *abi.ConvertType(out[5], new(*big.Int)).(**big.Int)
	outstruct.EndTime = *abi.ConvertType(out[6], new(*big.Int)).(**big.Int)
	outstruct.IsPrivate = *abi.ConvertType(out[7], new(bool)).(*bool)
	outstruct.Status = *abi.ConvertType(out[8], new(uint8)).(*uint8)
	outstruct.CreatedAt = *abi.ConvertType(out[9], new(*big.Int)).(**big.Int)

	return *outstruct, err

}

// Polls is a free data retrieval call binding the contract method 0xac2f0074.
//
// Solidity: function polls(uint256 ) view returns(uint256 pollId, string title, string category, bytes32 optionsHash, address creator, uint256 startTime, uint256 endTime, bool isPrivate, uint8 status, uint256 createdAt)
func (_PollRegistry *PollRegistrySession) Polls(arg0 *big.Int) (struct {
	PollId      *big.Int
	Title       string
	Category    string
	OptionsHash [32]byte
	Creator     common.Address
	StartTime   *big.Int
	EndTime     *big.Int
	IsPrivate   bool
	Status      uint8
	CreatedAt   *big.Int
}, error) {
	return _PollRegistry.Contract.Polls(&_PollRegistry.CallOpts, arg0)
}

// Polls is a free data retrieval call binding the contract method 0xac2f0074.
//
// Solidity: function polls(uint256 ) view returns(uint256 pollId, string title, string category, bytes32 optionsHash, address creator, uint256 startTime, uint256 endTime, bool isPrivate, uint8 status, uint256 createdAt)
func (_PollRegistry *PollRegistryCallerSession) Polls(arg0 *big.Int) (struct {
	PollId      *big.Int
	Title       string
	Category    string
	OptionsHash [32]byte
	Creator     common.Address
	StartTime   *big.Int
	EndTime     *big.Int
	IsPrivate   bool
	Status      uint8
	CreatedAt   *big.Int
}, error) {
	return _PollRegistry.Contract.Polls(&_PollRegistry.CallOpts, arg0)
}

// TotalPolls is a free data retrieval call binding the contract method 0xa2eeeb2f.
//
// Solidity: function totalPolls() view returns(uint256)
func (_PollRegistry *PollRegistryCaller) TotalPolls(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "totalPolls")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// TotalPolls is a free data retrieval call binding the contract method 0xa2eeeb2f.
//
// Solidity: function totalPolls() view returns(uint256)
func (_PollRegistry *PollRegistrySession) TotalPolls() (*big.Int, error) {
	return _PollRegistry.Contract.TotalPolls(&_PollRegistry.CallOpts)
}

// TotalPolls is a free data retrieval call binding the contract method 0xa2eeeb2f.
//
// Solidity: function totalPolls() view returns(uint256)
func (_PollRegistry *PollRegistryCallerSession) TotalPolls() (*big.Int, error) {
	return _PollRegistry.Contract.TotalPolls(&_PollRegistry.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_PollRegistry *PollRegistryCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _PollRegistry.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_PollRegistry *PollRegistrySession) Version() (string, error) {
	return _PollRegistry.Contract.Version(&_PollRegistry.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_PollRegistry *PollRegistryCallerSession) Version() (string, error) {
	return _PollRegistry.Contract.Version(&_PollRegistry.CallOpts)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_PollRegistry *PollRegistryTransactor) Pause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "pause")
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_PollRegistry *PollRegistrySession) Pause() (*types.Transaction, error) {
	return _PollRegistry.Contract.Pause(&_PollRegistry.TransactOpts)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_PollRegistry *PollRegistryTransactorSession) Pause() (*types.Transaction, error) {
	return _PollRegistry.Contract.Pause(&_PollRegistry.TransactOpts)
}

// RegisterPoll is a paid mutator transaction binding the contract method 0xfd42be25.
//
// Solidity: function registerPoll(uint256 _pollId, string _title, string _category, bytes32 _optionsHash, address _creator, uint256 _startTime, uint256 _endTime, bool _isPrivate) returns()
func (_PollRegistry *PollRegistryTransactor) RegisterPoll(opts *bind.TransactOpts, _pollId *big.Int, _title string, _category string, _optionsHash [32]byte, _creator common.Address, _startTime *big.Int, _endTime *big.Int, _isPrivate bool) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "registerPoll", _pollId, _title, _category, _optionsHash, _creator, _startTime, _endTime, _isPrivate)
}

// RegisterPoll is a paid mutator transaction binding the contract method 0xfd42be25.
//
// Solidity: function registerPoll(uint256 _pollId, string _title, string _category, bytes32 _optionsHash, address _creator, uint256 _startTime, uint256 _endTime, bool _isPrivate) returns()
func (_PollRegistry *PollRegistrySession) RegisterPoll(_pollId *big.Int, _title string, _category string, _optionsHash [32]byte, _creator common.Address, _startTime *big.Int, _endTime *big.Int, _isPrivate bool) (*types.Transaction, error) {
	return _PollRegistry.Contract.RegisterPoll(&_PollRegistry.TransactOpts, _pollId, _title, _category, _optionsHash, _creator, _startTime, _endTime, _isPrivate)
}

// RegisterPoll is a paid mutator transaction binding the contract method 0xfd42be25.
//
// Solidity: function registerPoll(uint256 _pollId, string _title, string _category, bytes32 _optionsHash, address _creator, uint256 _startTime, uint256 _endTime, bool _isPrivate) returns()
func (_PollRegistry *PollRegistryTransactorSession) RegisterPoll(_pollId *big.Int, _title string, _category string, _optionsHash [32]byte, _creator common.Address, _startTime *big.Int, _endTime *big.Int, _isPrivate bool) (*types.Transaction, error) {
	return _PollRegistry.Contract.RegisterPoll(&_PollRegistry.TransactOpts, _pollId, _title, _category, _optionsHash, _creator, _startTime, _endTime, _isPrivate)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_PollRegistry *PollRegistryTransactor) RenounceOwnership(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "renounceOwnership")
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_PollRegistry *PollRegistrySession) RenounceOwnership() (*types.Transaction, error) {
	return _PollRegistry.Contract.RenounceOwnership(&_PollRegistry.TransactOpts)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_PollRegistry *PollRegistryTransactorSession) RenounceOwnership() (*types.Transaction, error) {
	return _PollRegistry.Contract.RenounceOwnership(&_PollRegistry.TransactOpts)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_PollRegistry *PollRegistryTransactor) TransferOwnership(opts *bind.TransactOpts, newOwner common.Address) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "transferOwnership", newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_PollRegistry *PollRegistrySession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _PollRegistry.Contract.TransferOwnership(&_PollRegistry.TransactOpts, newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_PollRegistry *PollRegistryTransactorSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _PollRegistry.Contract.TransferOwnership(&_PollRegistry.TransactOpts, newOwner)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_PollRegistry *PollRegistryTransactor) Unpause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "unpause")
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_PollRegistry *PollRegistrySession) Unpause() (*types.Transaction, error) {
	return _PollRegistry.Contract.Unpause(&_PollRegistry.TransactOpts)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_PollRegistry *PollRegistryTransactorSession) Unpause() (*types.Transaction, error) {
	return _PollRegistry.Contract.Unpause(&_PollRegistry.TransactOpts)
}

// UpdatePollStatus is a paid mutator transaction binding the contract method 0x040200a3.
//
// Solidity: function updatePollStatus(uint256 _pollId, uint8 _newStatus) returns()
func (_PollRegistry *PollRegistryTransactor) UpdatePollStatus(opts *bind.TransactOpts, _pollId *big.Int, _newStatus uint8) (*types.Transaction, error) {
	return _PollRegistry.contract.Transact(opts, "updatePollStatus", _pollId, _newStatus)
}

// UpdatePollStatus is a paid mutator transaction binding the contract method 0x040200a3.
//
// Solidity: function updatePollStatus(uint256 _pollId, uint8 _newStatus) returns()
func (_PollRegistry *PollRegistrySession) UpdatePollStatus(_pollId *big.Int, _newStatus uint8) (*types.Transaction, error) {
	return _PollRegistry.Contract.UpdatePollStatus(&_PollRegistry.TransactOpts, _pollId, _newStatus)
}

// UpdatePollStatus is a paid mutator transaction binding the contract method 0x040200a3.
//
// Solidity: function updatePollStatus(uint256 _pollId, uint8 _newStatus) returns()
func (_PollRegistry *PollRegistryTransactorSession) UpdatePollStatus(_pollId *big.Int, _newStatus uint8) (*types.Transaction, error) {
	return _PollRegistry.Contract.UpdatePollStatus(&_PollRegistry.TransactOpts, _pollId, _newStatus)
}

// PollRegistryOwnershipTransferredIterator is returned from FilterOwnershipTransferred and is used to iterate over the raw logs and unpacked data for OwnershipTransferred events raised by the PollRegistry contract.
type PollRegistryOwnershipTransferredIterator struct {
	Event *PollRegistryOwnershipTransferred // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryOwnershipTransferredIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryOwnershipTransferred)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryOwnershipTransferred)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryOwnershipTransferredIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryOwnershipTransferredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryOwnershipTransferred represents a OwnershipTransferred event raised by the PollRegistry contract.
type PollRegistryOwnershipTransferred struct {
	PreviousOwner common.Address
	NewOwner      common.Address
	Raw           types.Log // Blockchain specific contextual infos
}

// FilterOwnershipTransferred is a free log retrieval operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_PollRegistry *PollRegistryFilterer) FilterOwnershipTransferred(opts *bind.FilterOpts, previousOwner []common.Address, newOwner []common.Address) (*PollRegistryOwnershipTransferredIterator, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return &PollRegistryOwnershipTransferredIterator{contract: _PollRegistry.contract, event: "OwnershipTransferred", logs: logs, sub: sub}, nil
}

// WatchOwnershipTransferred is a free log subscription operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_PollRegistry *PollRegistryFilterer) WatchOwnershipTransferred(opts *bind.WatchOpts, sink chan<- *PollRegistryOwnershipTransferred, previousOwner []common.Address, newOwner []common.Address) (event.Subscription, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryOwnershipTransferred)
				if err := _PollRegistry.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseOwnershipTransferred is a log parse operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_PollRegistry *PollRegistryFilterer) ParseOwnershipTransferred(log types.Log) (*PollRegistryOwnershipTransferred, error) {
	event := new(PollRegistryOwnershipTransferred)
	if err := _PollRegistry.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// PollRegistryPausedIterator is returned from FilterPaused and is used to iterate over the raw logs and unpacked data for Paused events raised by the PollRegistry contract.
type PollRegistryPausedIterator struct {
	Event *PollRegistryPaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryPausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryPaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryPaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryPausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryPausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryPaused represents a Paused event raised by the PollRegistry contract.
type PollRegistryPaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterPaused is a free log retrieval operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_PollRegistry *PollRegistryFilterer) FilterPaused(opts *bind.FilterOpts) (*PollRegistryPausedIterator, error) {

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return &PollRegistryPausedIterator{contract: _PollRegistry.contract, event: "Paused", logs: logs, sub: sub}, nil
}

// WatchPaused is a free log subscription operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_PollRegistry *PollRegistryFilterer) WatchPaused(opts *bind.WatchOpts, sink chan<- *PollRegistryPaused) (event.Subscription, error) {

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryPaused)
				if err := _PollRegistry.contract.UnpackLog(event, "Paused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePaused is a log parse operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_PollRegistry *PollRegistryFilterer) ParsePaused(log types.Log) (*PollRegistryPaused, error) {
	event := new(PollRegistryPaused)
	if err := _PollRegistry.contract.UnpackLog(event, "Paused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// PollRegistryPollFinalizedIterator is returned from FilterPollFinalized and is used to iterate over the raw logs and unpacked data for PollFinalized events raised by the PollRegistry contract.
type PollRegistryPollFinalizedIterator struct {
	Event *PollRegistryPollFinalized // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryPollFinalizedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryPollFinalized)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryPollFinalized)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryPollFinalizedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryPollFinalizedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryPollFinalized represents a PollFinalized event raised by the PollRegistry contract.
type PollRegistryPollFinalized struct {
	PollId      *big.Int
	FinalStatus uint8
	Raw         types.Log // Blockchain specific contextual infos
}

// FilterPollFinalized is a free log retrieval operation binding the contract event 0xe51b8a29c0c801defadfb75083546cc61d149df76efc8ea1ad6c08acb5ccd331.
//
// Solidity: event PollFinalized(uint256 indexed pollId, uint8 finalStatus)
func (_PollRegistry *PollRegistryFilterer) FilterPollFinalized(opts *bind.FilterOpts, pollId []*big.Int) (*PollRegistryPollFinalizedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "PollFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &PollRegistryPollFinalizedIterator{contract: _PollRegistry.contract, event: "PollFinalized", logs: logs, sub: sub}, nil
}

// WatchPollFinalized is a free log subscription operation binding the contract event 0xe51b8a29c0c801defadfb75083546cc61d149df76efc8ea1ad6c08acb5ccd331.
//
// Solidity: event PollFinalized(uint256 indexed pollId, uint8 finalStatus)
func (_PollRegistry *PollRegistryFilterer) WatchPollFinalized(opts *bind.WatchOpts, sink chan<- *PollRegistryPollFinalized, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "PollFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryPollFinalized)
				if err := _PollRegistry.contract.UnpackLog(event, "PollFinalized", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePollFinalized is a log parse operation binding the contract event 0xe51b8a29c0c801defadfb75083546cc61d149df76efc8ea1ad6c08acb5ccd331.
//
// Solidity: event PollFinalized(uint256 indexed pollId, uint8 finalStatus)
func (_PollRegistry *PollRegistryFilterer) ParsePollFinalized(log types.Log) (*PollRegistryPollFinalized, error) {
	event := new(PollRegistryPollFinalized)
	if err := _PollRegistry.contract.UnpackLog(event, "PollFinalized", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// PollRegistryPollRegisteredIterator is returned from FilterPollRegistered and is used to iterate over the raw logs and unpacked data for PollRegistered events raised by the PollRegistry contract.
type PollRegistryPollRegisteredIterator struct {
	Event *PollRegistryPollRegistered // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryPollRegisteredIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryPollRegistered)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryPollRegistered)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryPollRegisteredIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryPollRegisteredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryPollRegistered represents a PollRegistered event raised by the PollRegistry contract.
type PollRegistryPollRegistered struct {
	PollId    *big.Int
	Creator   common.Address
	Title     string
	Category  string
	IsPrivate bool
	StartTime *big.Int
	EndTime   *big.Int
	Raw       types.Log // Blockchain specific contextual infos
}

// FilterPollRegistered is a free log retrieval operation binding the contract event 0xbe66cc1f06cf6286c5d6ecd4d2648745e0e66f7407631b822d107ef178c2a773.
//
// Solidity: event PollRegistered(uint256 indexed pollId, address indexed creator, string title, string category, bool isPrivate, uint256 startTime, uint256 endTime)
func (_PollRegistry *PollRegistryFilterer) FilterPollRegistered(opts *bind.FilterOpts, pollId []*big.Int, creator []common.Address) (*PollRegistryPollRegisteredIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var creatorRule []interface{}
	for _, creatorItem := range creator {
		creatorRule = append(creatorRule, creatorItem)
	}

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "PollRegistered", pollIdRule, creatorRule)
	if err != nil {
		return nil, err
	}
	return &PollRegistryPollRegisteredIterator{contract: _PollRegistry.contract, event: "PollRegistered", logs: logs, sub: sub}, nil
}

// WatchPollRegistered is a free log subscription operation binding the contract event 0xbe66cc1f06cf6286c5d6ecd4d2648745e0e66f7407631b822d107ef178c2a773.
//
// Solidity: event PollRegistered(uint256 indexed pollId, address indexed creator, string title, string category, bool isPrivate, uint256 startTime, uint256 endTime)
func (_PollRegistry *PollRegistryFilterer) WatchPollRegistered(opts *bind.WatchOpts, sink chan<- *PollRegistryPollRegistered, pollId []*big.Int, creator []common.Address) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var creatorRule []interface{}
	for _, creatorItem := range creator {
		creatorRule = append(creatorRule, creatorItem)
	}

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "PollRegistered", pollIdRule, creatorRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryPollRegistered)
				if err := _PollRegistry.contract.UnpackLog(event, "PollRegistered", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePollRegistered is a log parse operation binding the contract event 0xbe66cc1f06cf6286c5d6ecd4d2648745e0e66f7407631b822d107ef178c2a773.
//
// Solidity: event PollRegistered(uint256 indexed pollId, address indexed creator, string title, string category, bool isPrivate, uint256 startTime, uint256 endTime)
func (_PollRegistry *PollRegistryFilterer) ParsePollRegistered(log types.Log) (*PollRegistryPollRegistered, error) {
	event := new(PollRegistryPollRegistered)
	if err := _PollRegistry.contract.UnpackLog(event, "PollRegistered", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// PollRegistryPollStatusUpdatedIterator is returned from FilterPollStatusUpdated and is used to iterate over the raw logs and unpacked data for PollStatusUpdated events raised by the PollRegistry contract.
type PollRegistryPollStatusUpdatedIterator struct {
	Event *PollRegistryPollStatusUpdated // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryPollStatusUpdatedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryPollStatusUpdated)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryPollStatusUpdated)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryPollStatusUpdatedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryPollStatusUpdatedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryPollStatusUpdated represents a PollStatusUpdated event raised by the PollRegistry contract.
type PollRegistryPollStatusUpdated struct {
	PollId    *big.Int
	OldStatus uint8
	NewStatus uint8
	Raw       types.Log // Blockchain specific contextual infos
}

// FilterPollStatusUpdated is a free log retrieval operation binding the contract event 0x3e4a743f9d37ea3234eb7aeee1b74a22e813592767349a5ce486a0f2a385d05e.
//
// Solidity: event PollStatusUpdated(uint256 indexed pollId, uint8 oldStatus, uint8 newStatus)
func (_PollRegistry *PollRegistryFilterer) FilterPollStatusUpdated(opts *bind.FilterOpts, pollId []*big.Int) (*PollRegistryPollStatusUpdatedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "PollStatusUpdated", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &PollRegistryPollStatusUpdatedIterator{contract: _PollRegistry.contract, event: "PollStatusUpdated", logs: logs, sub: sub}, nil
}

// WatchPollStatusUpdated is a free log subscription operation binding the contract event 0x3e4a743f9d37ea3234eb7aeee1b74a22e813592767349a5ce486a0f2a385d05e.
//
// Solidity: event PollStatusUpdated(uint256 indexed pollId, uint8 oldStatus, uint8 newStatus)
func (_PollRegistry *PollRegistryFilterer) WatchPollStatusUpdated(opts *bind.WatchOpts, sink chan<- *PollRegistryPollStatusUpdated, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "PollStatusUpdated", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryPollStatusUpdated)
				if err := _PollRegistry.contract.UnpackLog(event, "PollStatusUpdated", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePollStatusUpdated is a log parse operation binding the contract event 0x3e4a743f9d37ea3234eb7aeee1b74a22e813592767349a5ce486a0f2a385d05e.
//
// Solidity: event PollStatusUpdated(uint256 indexed pollId, uint8 oldStatus, uint8 newStatus)
func (_PollRegistry *PollRegistryFilterer) ParsePollStatusUpdated(log types.Log) (*PollRegistryPollStatusUpdated, error) {
	event := new(PollRegistryPollStatusUpdated)
	if err := _PollRegistry.contract.UnpackLog(event, "PollStatusUpdated", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// PollRegistryUnpausedIterator is returned from FilterUnpaused and is used to iterate over the raw logs and unpacked data for Unpaused events raised by the PollRegistry contract.
type PollRegistryUnpausedIterator struct {
	Event *PollRegistryUnpaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *PollRegistryUnpausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(PollRegistryUnpaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(PollRegistryUnpaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *PollRegistryUnpausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *PollRegistryUnpausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// PollRegistryUnpaused represents a Unpaused event raised by the PollRegistry contract.
type PollRegistryUnpaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterUnpaused is a free log retrieval operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_PollRegistry *PollRegistryFilterer) FilterUnpaused(opts *bind.FilterOpts) (*PollRegistryUnpausedIterator, error) {

	logs, sub, err := _PollRegistry.contract.FilterLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return &PollRegistryUnpausedIterator{contract: _PollRegistry.contract, event: "Unpaused", logs: logs, sub: sub}, nil
}

// WatchUnpaused is a free log subscription operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_PollRegistry *PollRegistryFilterer) WatchUnpaused(opts *bind.WatchOpts, sink chan<- *PollRegistryUnpaused) (event.Subscription, error) {

	logs, sub, err := _PollRegistry.contract.WatchLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(PollRegistryUnpaused)
				if err := _PollRegistry.contract.UnpackLog(event, "Unpaused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseUnpaused is a log parse operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_PollRegistry *PollRegistryFilterer) ParseUnpaused(log types.Log) (*PollRegistryUnpaused, error) {
	event := new(PollRegistryUnpaused)
	if err := _PollRegistry.contract.UnpackLog(event, "Unpaused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
