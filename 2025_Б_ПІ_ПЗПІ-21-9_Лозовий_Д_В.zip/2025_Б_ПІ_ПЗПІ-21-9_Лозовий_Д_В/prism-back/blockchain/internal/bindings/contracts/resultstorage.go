// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package contracts

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// ResultStoragePollResult is an auto generated low-level Go binding around an user-defined struct.
type ResultStoragePollResult struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	OptionCounts   []*big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}

// ResultStorageMetaData contains all meta data concerning the ResultStorage contract.
var ResultStorageMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"initialOwner\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_pollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_voteVerifier\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"EnforcedPause\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ExpectedPause\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"}],\"name\":\"OwnableInvalidOwner\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"OwnableUnauthorizedAccount\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ReentrancyGuardReentrantCall\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Paused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"}],\"name\":\"ResultsFinalized\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"}],\"name\":\"ResultsStored\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"bool\",\"name\":\"isValid\",\"type\":\"bool\"}],\"name\":\"ResultsVerified\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Unpaused\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"MAX_OPTIONS_STORAGE\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"finalizeResults\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getResults\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"optionCounts\",\"type\":\"uint256[]\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"internalType\":\"structResultStorage.PollResult\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"_resultsHash\",\"type\":\"bytes32\"}],\"name\":\"getResultsByHash\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"optionCounts\",\"type\":\"uint256[]\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"internalType\":\"structResultStorage.PollResult\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getResultsSummary\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"getTotalPublishedResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"hasResults\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pollRegistry\",\"outputs\":[{\"internalType\":\"contractPollRegistry\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"pollResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"resultsByHash\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"resultsExist\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"_optionCounts\",\"type\":\"uint256[]\"}],\"name\":\"storeResults\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"totalPublishedResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newPollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_newVoteVerifier\",\"type\":\"address\"}],\"name\":\"updateContracts\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"verifyResults\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"voteVerifier\",\"outputs\":[{\"internalType\":\"contractVoteVerifier\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"}]",
}

// ResultStorageABI is the input ABI used to generate the binding from.
// Deprecated: Use ResultStorageMetaData.ABI instead.
var ResultStorageABI = ResultStorageMetaData.ABI

// ResultStorage is an auto generated Go binding around an Ethereum contract.
type ResultStorage struct {
	ResultStorageCaller     // Read-only binding to the contract
	ResultStorageTransactor // Write-only binding to the contract
	ResultStorageFilterer   // Log filterer for contract events
}

// ResultStorageCaller is an auto generated read-only Go binding around an Ethereum contract.
type ResultStorageCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// ResultStorageTransactor is an auto generated write-only Go binding around an Ethereum contract.
type ResultStorageTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// ResultStorageFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type ResultStorageFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// ResultStorageSession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type ResultStorageSession struct {
	Contract     *ResultStorage    // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// ResultStorageCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type ResultStorageCallerSession struct {
	Contract *ResultStorageCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts        // Call options to use throughout this session
}

// ResultStorageTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type ResultStorageTransactorSession struct {
	Contract     *ResultStorageTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts        // Transaction auth options to use throughout this session
}

// ResultStorageRaw is an auto generated low-level Go binding around an Ethereum contract.
type ResultStorageRaw struct {
	Contract *ResultStorage // Generic contract binding to access the raw methods on
}

// ResultStorageCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type ResultStorageCallerRaw struct {
	Contract *ResultStorageCaller // Generic read-only contract binding to access the raw methods on
}

// ResultStorageTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type ResultStorageTransactorRaw struct {
	Contract *ResultStorageTransactor // Generic write-only contract binding to access the raw methods on
}

// NewResultStorage creates a new instance of ResultStorage, bound to a specific deployed contract.
func NewResultStorage(address common.Address, backend bind.ContractBackend) (*ResultStorage, error) {
	contract, err := bindResultStorage(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &ResultStorage{ResultStorageCaller: ResultStorageCaller{contract: contract}, ResultStorageTransactor: ResultStorageTransactor{contract: contract}, ResultStorageFilterer: ResultStorageFilterer{contract: contract}}, nil
}

// NewResultStorageCaller creates a new read-only instance of ResultStorage, bound to a specific deployed contract.
func NewResultStorageCaller(address common.Address, caller bind.ContractCaller) (*ResultStorageCaller, error) {
	contract, err := bindResultStorage(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &ResultStorageCaller{contract: contract}, nil
}

// NewResultStorageTransactor creates a new write-only instance of ResultStorage, bound to a specific deployed contract.
func NewResultStorageTransactor(address common.Address, transactor bind.ContractTransactor) (*ResultStorageTransactor, error) {
	contract, err := bindResultStorage(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &ResultStorageTransactor{contract: contract}, nil
}

// NewResultStorageFilterer creates a new log filterer instance of ResultStorage, bound to a specific deployed contract.
func NewResultStorageFilterer(address common.Address, filterer bind.ContractFilterer) (*ResultStorageFilterer, error) {
	contract, err := bindResultStorage(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &ResultStorageFilterer{contract: contract}, nil
}

// bindResultStorage binds a generic wrapper to an already deployed contract.
func bindResultStorage(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := ResultStorageMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_ResultStorage *ResultStorageRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _ResultStorage.Contract.ResultStorageCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_ResultStorage *ResultStorageRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.Contract.ResultStorageTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_ResultStorage *ResultStorageRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _ResultStorage.Contract.ResultStorageTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_ResultStorage *ResultStorageCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _ResultStorage.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_ResultStorage *ResultStorageTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_ResultStorage *ResultStorageTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _ResultStorage.Contract.contract.Transact(opts, method, params...)
}

// MAXOPTIONSSTORAGE is a free data retrieval call binding the contract method 0xe42e30be.
//
// Solidity: function MAX_OPTIONS_STORAGE() view returns(uint256)
func (_ResultStorage *ResultStorageCaller) MAXOPTIONSSTORAGE(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "MAX_OPTIONS_STORAGE")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// MAXOPTIONSSTORAGE is a free data retrieval call binding the contract method 0xe42e30be.
//
// Solidity: function MAX_OPTIONS_STORAGE() view returns(uint256)
func (_ResultStorage *ResultStorageSession) MAXOPTIONSSTORAGE() (*big.Int, error) {
	return _ResultStorage.Contract.MAXOPTIONSSTORAGE(&_ResultStorage.CallOpts)
}

// MAXOPTIONSSTORAGE is a free data retrieval call binding the contract method 0xe42e30be.
//
// Solidity: function MAX_OPTIONS_STORAGE() view returns(uint256)
func (_ResultStorage *ResultStorageCallerSession) MAXOPTIONSSTORAGE() (*big.Int, error) {
	return _ResultStorage.Contract.MAXOPTIONSSTORAGE(&_ResultStorage.CallOpts)
}

// GetResults is a free data retrieval call binding the contract method 0x81a60c0d.
//
// Solidity: function getResults(uint256 _pollId) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageCaller) GetResults(opts *bind.CallOpts, _pollId *big.Int) (ResultStoragePollResult, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResults", _pollId)

	if err != nil {
		return *new(ResultStoragePollResult), err
	}

	out0 := *abi.ConvertType(out[0], new(ResultStoragePollResult)).(*ResultStoragePollResult)

	return out0, err

}

// GetResults is a free data retrieval call binding the contract method 0x81a60c0d.
//
// Solidity: function getResults(uint256 _pollId) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageSession) GetResults(_pollId *big.Int) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResults(&_ResultStorage.CallOpts, _pollId)
}

// GetResults is a free data retrieval call binding the contract method 0x81a60c0d.
//
// Solidity: function getResults(uint256 _pollId) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageCallerSession) GetResults(_pollId *big.Int) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResults(&_ResultStorage.CallOpts, _pollId)
}

// GetResultsByHash is a free data retrieval call binding the contract method 0x14414fea.
//
// Solidity: function getResultsByHash(bytes32 _resultsHash) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageCaller) GetResultsByHash(opts *bind.CallOpts, _resultsHash [32]byte) (ResultStoragePollResult, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResultsByHash", _resultsHash)

	if err != nil {
		return *new(ResultStoragePollResult), err
	}

	out0 := *abi.ConvertType(out[0], new(ResultStoragePollResult)).(*ResultStoragePollResult)

	return out0, err

}

// GetResultsByHash is a free data retrieval call binding the contract method 0x14414fea.
//
// Solidity: function getResultsByHash(bytes32 _resultsHash) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageSession) GetResultsByHash(_resultsHash [32]byte) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResultsByHash(&_ResultStorage.CallOpts, _resultsHash)
}

// GetResultsByHash is a free data retrieval call binding the contract method 0x14414fea.
//
// Solidity: function getResultsByHash(bytes32 _resultsHash) view returns((uint256,uint256,uint256,uint256[],bytes32,uint256,bool,address))
func (_ResultStorage *ResultStorageCallerSession) GetResultsByHash(_resultsHash [32]byte) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResultsByHash(&_ResultStorage.CallOpts, _resultsHash)
}

// GetResultsSummary is a free data retrieval call binding the contract method 0xdd9874c9.
//
// Solidity: function getResultsSummary(uint256 _pollId) view returns(uint256 totalVotes, uint256 winnerOptionId, bool isFinalized)
func (_ResultStorage *ResultStorageCaller) GetResultsSummary(opts *bind.CallOpts, _pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResultsSummary", _pollId)

	outstruct := new(struct {
		TotalVotes     *big.Int
		WinnerOptionId *big.Int
		IsFinalized    bool
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.TotalVotes = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.WinnerOptionId = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.IsFinalized = *abi.ConvertType(out[2], new(bool)).(*bool)

	return *outstruct, err

}

// GetResultsSummary is a free data retrieval call binding the contract method 0xdd9874c9.
//
// Solidity: function getResultsSummary(uint256 _pollId) view returns(uint256 totalVotes, uint256 winnerOptionId, bool isFinalized)
func (_ResultStorage *ResultStorageSession) GetResultsSummary(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	return _ResultStorage.Contract.GetResultsSummary(&_ResultStorage.CallOpts, _pollId)
}

// GetResultsSummary is a free data retrieval call binding the contract method 0xdd9874c9.
//
// Solidity: function getResultsSummary(uint256 _pollId) view returns(uint256 totalVotes, uint256 winnerOptionId, bool isFinalized)
func (_ResultStorage *ResultStorageCallerSession) GetResultsSummary(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	return _ResultStorage.Contract.GetResultsSummary(&_ResultStorage.CallOpts, _pollId)
}

// GetTotalPublishedResults is a free data retrieval call binding the contract method 0x6d1d1262.
//
// Solidity: function getTotalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageCaller) GetTotalPublishedResults(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getTotalPublishedResults")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetTotalPublishedResults is a free data retrieval call binding the contract method 0x6d1d1262.
//
// Solidity: function getTotalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageSession) GetTotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.GetTotalPublishedResults(&_ResultStorage.CallOpts)
}

// GetTotalPublishedResults is a free data retrieval call binding the contract method 0x6d1d1262.
//
// Solidity: function getTotalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageCallerSession) GetTotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.GetTotalPublishedResults(&_ResultStorage.CallOpts)
}

// HasResults is a free data retrieval call binding the contract method 0x0070bf54.
//
// Solidity: function hasResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageCaller) HasResults(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "hasResults", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// HasResults is a free data retrieval call binding the contract method 0x0070bf54.
//
// Solidity: function hasResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageSession) HasResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.HasResults(&_ResultStorage.CallOpts, _pollId)
}

// HasResults is a free data retrieval call binding the contract method 0x0070bf54.
//
// Solidity: function hasResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageCallerSession) HasResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.HasResults(&_ResultStorage.CallOpts, _pollId)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_ResultStorage *ResultStorageCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_ResultStorage *ResultStorageSession) Owner() (common.Address, error) {
	return _ResultStorage.Contract.Owner(&_ResultStorage.CallOpts)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_ResultStorage *ResultStorageCallerSession) Owner() (common.Address, error) {
	return _ResultStorage.Contract.Owner(&_ResultStorage.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_ResultStorage *ResultStorageCaller) Paused(opts *bind.CallOpts) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "paused")

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_ResultStorage *ResultStorageSession) Paused() (bool, error) {
	return _ResultStorage.Contract.Paused(&_ResultStorage.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_ResultStorage *ResultStorageCallerSession) Paused() (bool, error) {
	return _ResultStorage.Contract.Paused(&_ResultStorage.CallOpts)
}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_ResultStorage *ResultStorageCaller) PollRegistry(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "pollRegistry")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_ResultStorage *ResultStorageSession) PollRegistry() (common.Address, error) {
	return _ResultStorage.Contract.PollRegistry(&_ResultStorage.CallOpts)
}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_ResultStorage *ResultStorageCallerSession) PollRegistry() (common.Address, error) {
	return _ResultStorage.Contract.PollRegistry(&_ResultStorage.CallOpts)
}

// PollResults is a free data retrieval call binding the contract method 0x213e7ba8.
//
// Solidity: function pollResults(uint256 ) view returns(uint256 pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, uint256 publishedAt, bool isFinalized, address publishedBy)
func (_ResultStorage *ResultStorageCaller) PollResults(opts *bind.CallOpts, arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "pollResults", arg0)

	outstruct := new(struct {
		PollId         *big.Int
		TotalVotes     *big.Int
		WinnerOptionId *big.Int
		ResultsHash    [32]byte
		PublishedAt    *big.Int
		IsFinalized    bool
		PublishedBy    common.Address
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.PollId = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.TotalVotes = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.WinnerOptionId = *abi.ConvertType(out[2], new(*big.Int)).(**big.Int)
	outstruct.ResultsHash = *abi.ConvertType(out[3], new([32]byte)).(*[32]byte)
	outstruct.PublishedAt = *abi.ConvertType(out[4], new(*big.Int)).(**big.Int)
	outstruct.IsFinalized = *abi.ConvertType(out[5], new(bool)).(*bool)
	outstruct.PublishedBy = *abi.ConvertType(out[6], new(common.Address)).(*common.Address)

	return *outstruct, err

}

// PollResults is a free data retrieval call binding the contract method 0x213e7ba8.
//
// Solidity: function pollResults(uint256 ) view returns(uint256 pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, uint256 publishedAt, bool isFinalized, address publishedBy)
func (_ResultStorage *ResultStorageSession) PollResults(arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	return _ResultStorage.Contract.PollResults(&_ResultStorage.CallOpts, arg0)
}

// PollResults is a free data retrieval call binding the contract method 0x213e7ba8.
//
// Solidity: function pollResults(uint256 ) view returns(uint256 pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, uint256 publishedAt, bool isFinalized, address publishedBy)
func (_ResultStorage *ResultStorageCallerSession) PollResults(arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	return _ResultStorage.Contract.PollResults(&_ResultStorage.CallOpts, arg0)
}

// ResultsByHash is a free data retrieval call binding the contract method 0x8d473acb.
//
// Solidity: function resultsByHash(bytes32 ) view returns(uint256)
func (_ResultStorage *ResultStorageCaller) ResultsByHash(opts *bind.CallOpts, arg0 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "resultsByHash", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// ResultsByHash is a free data retrieval call binding the contract method 0x8d473acb.
//
// Solidity: function resultsByHash(bytes32 ) view returns(uint256)
func (_ResultStorage *ResultStorageSession) ResultsByHash(arg0 [32]byte) (*big.Int, error) {
	return _ResultStorage.Contract.ResultsByHash(&_ResultStorage.CallOpts, arg0)
}

// ResultsByHash is a free data retrieval call binding the contract method 0x8d473acb.
//
// Solidity: function resultsByHash(bytes32 ) view returns(uint256)
func (_ResultStorage *ResultStorageCallerSession) ResultsByHash(arg0 [32]byte) (*big.Int, error) {
	return _ResultStorage.Contract.ResultsByHash(&_ResultStorage.CallOpts, arg0)
}

// ResultsExist is a free data retrieval call binding the contract method 0x7b398132.
//
// Solidity: function resultsExist(uint256 ) view returns(bool)
func (_ResultStorage *ResultStorageCaller) ResultsExist(opts *bind.CallOpts, arg0 *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "resultsExist", arg0)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// ResultsExist is a free data retrieval call binding the contract method 0x7b398132.
//
// Solidity: function resultsExist(uint256 ) view returns(bool)
func (_ResultStorage *ResultStorageSession) ResultsExist(arg0 *big.Int) (bool, error) {
	return _ResultStorage.Contract.ResultsExist(&_ResultStorage.CallOpts, arg0)
}

// ResultsExist is a free data retrieval call binding the contract method 0x7b398132.
//
// Solidity: function resultsExist(uint256 ) view returns(bool)
func (_ResultStorage *ResultStorageCallerSession) ResultsExist(arg0 *big.Int) (bool, error) {
	return _ResultStorage.Contract.ResultsExist(&_ResultStorage.CallOpts, arg0)
}

// TotalPublishedResults is a free data retrieval call binding the contract method 0x2dde846f.
//
// Solidity: function totalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageCaller) TotalPublishedResults(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "totalPublishedResults")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// TotalPublishedResults is a free data retrieval call binding the contract method 0x2dde846f.
//
// Solidity: function totalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageSession) TotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.TotalPublishedResults(&_ResultStorage.CallOpts)
}

// TotalPublishedResults is a free data retrieval call binding the contract method 0x2dde846f.
//
// Solidity: function totalPublishedResults() view returns(uint256)
func (_ResultStorage *ResultStorageCallerSession) TotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.TotalPublishedResults(&_ResultStorage.CallOpts)
}

// VerifyResults is a free data retrieval call binding the contract method 0x263bab53.
//
// Solidity: function verifyResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageCaller) VerifyResults(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "verifyResults", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// VerifyResults is a free data retrieval call binding the contract method 0x263bab53.
//
// Solidity: function verifyResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageSession) VerifyResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.VerifyResults(&_ResultStorage.CallOpts, _pollId)
}

// VerifyResults is a free data retrieval call binding the contract method 0x263bab53.
//
// Solidity: function verifyResults(uint256 _pollId) view returns(bool)
func (_ResultStorage *ResultStorageCallerSession) VerifyResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.VerifyResults(&_ResultStorage.CallOpts, _pollId)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_ResultStorage *ResultStorageCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_ResultStorage *ResultStorageSession) Version() (string, error) {
	return _ResultStorage.Contract.Version(&_ResultStorage.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_ResultStorage *ResultStorageCallerSession) Version() (string, error) {
	return _ResultStorage.Contract.Version(&_ResultStorage.CallOpts)
}

// VoteVerifier is a free data retrieval call binding the contract method 0x99d74c71.
//
// Solidity: function voteVerifier() view returns(address)
func (_ResultStorage *ResultStorageCaller) VoteVerifier(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "voteVerifier")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// VoteVerifier is a free data retrieval call binding the contract method 0x99d74c71.
//
// Solidity: function voteVerifier() view returns(address)
func (_ResultStorage *ResultStorageSession) VoteVerifier() (common.Address, error) {
	return _ResultStorage.Contract.VoteVerifier(&_ResultStorage.CallOpts)
}

// VoteVerifier is a free data retrieval call binding the contract method 0x99d74c71.
//
// Solidity: function voteVerifier() view returns(address)
func (_ResultStorage *ResultStorageCallerSession) VoteVerifier() (common.Address, error) {
	return _ResultStorage.Contract.VoteVerifier(&_ResultStorage.CallOpts)
}

// FinalizeResults is a paid mutator transaction binding the contract method 0x1978e0d3.
//
// Solidity: function finalizeResults(uint256 _pollId) returns()
func (_ResultStorage *ResultStorageTransactor) FinalizeResults(opts *bind.TransactOpts, _pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "finalizeResults", _pollId)
}

// FinalizeResults is a paid mutator transaction binding the contract method 0x1978e0d3.
//
// Solidity: function finalizeResults(uint256 _pollId) returns()
func (_ResultStorage *ResultStorageSession) FinalizeResults(_pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.FinalizeResults(&_ResultStorage.TransactOpts, _pollId)
}

// FinalizeResults is a paid mutator transaction binding the contract method 0x1978e0d3.
//
// Solidity: function finalizeResults(uint256 _pollId) returns()
func (_ResultStorage *ResultStorageTransactorSession) FinalizeResults(_pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.FinalizeResults(&_ResultStorage.TransactOpts, _pollId)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_ResultStorage *ResultStorageTransactor) Pause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "pause")
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_ResultStorage *ResultStorageSession) Pause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Pause(&_ResultStorage.TransactOpts)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_ResultStorage *ResultStorageTransactorSession) Pause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Pause(&_ResultStorage.TransactOpts)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_ResultStorage *ResultStorageTransactor) RenounceOwnership(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "renounceOwnership")
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_ResultStorage *ResultStorageSession) RenounceOwnership() (*types.Transaction, error) {
	return _ResultStorage.Contract.RenounceOwnership(&_ResultStorage.TransactOpts)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_ResultStorage *ResultStorageTransactorSession) RenounceOwnership() (*types.Transaction, error) {
	return _ResultStorage.Contract.RenounceOwnership(&_ResultStorage.TransactOpts)
}

// StoreResults is a paid mutator transaction binding the contract method 0xfd307ce2.
//
// Solidity: function storeResults(uint256 _pollId, uint256[] _optionCounts) returns()
func (_ResultStorage *ResultStorageTransactor) StoreResults(opts *bind.TransactOpts, _pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "storeResults", _pollId, _optionCounts)
}

// StoreResults is a paid mutator transaction binding the contract method 0xfd307ce2.
//
// Solidity: function storeResults(uint256 _pollId, uint256[] _optionCounts) returns()
func (_ResultStorage *ResultStorageSession) StoreResults(_pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.StoreResults(&_ResultStorage.TransactOpts, _pollId, _optionCounts)
}

// StoreResults is a paid mutator transaction binding the contract method 0xfd307ce2.
//
// Solidity: function storeResults(uint256 _pollId, uint256[] _optionCounts) returns()
func (_ResultStorage *ResultStorageTransactorSession) StoreResults(_pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.StoreResults(&_ResultStorage.TransactOpts, _pollId, _optionCounts)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_ResultStorage *ResultStorageTransactor) TransferOwnership(opts *bind.TransactOpts, newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "transferOwnership", newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_ResultStorage *ResultStorageSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.TransferOwnership(&_ResultStorage.TransactOpts, newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_ResultStorage *ResultStorageTransactorSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.TransferOwnership(&_ResultStorage.TransactOpts, newOwner)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_ResultStorage *ResultStorageTransactor) Unpause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "unpause")
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_ResultStorage *ResultStorageSession) Unpause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Unpause(&_ResultStorage.TransactOpts)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_ResultStorage *ResultStorageTransactorSession) Unpause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Unpause(&_ResultStorage.TransactOpts)
}

// UpdateContracts is a paid mutator transaction binding the contract method 0xe692c49f.
//
// Solidity: function updateContracts(address _newPollRegistry, address _newVoteVerifier) returns()
func (_ResultStorage *ResultStorageTransactor) UpdateContracts(opts *bind.TransactOpts, _newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "updateContracts", _newPollRegistry, _newVoteVerifier)
}

// UpdateContracts is a paid mutator transaction binding the contract method 0xe692c49f.
//
// Solidity: function updateContracts(address _newPollRegistry, address _newVoteVerifier) returns()
func (_ResultStorage *ResultStorageSession) UpdateContracts(_newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.UpdateContracts(&_ResultStorage.TransactOpts, _newPollRegistry, _newVoteVerifier)
}

// UpdateContracts is a paid mutator transaction binding the contract method 0xe692c49f.
//
// Solidity: function updateContracts(address _newPollRegistry, address _newVoteVerifier) returns()
func (_ResultStorage *ResultStorageTransactorSession) UpdateContracts(_newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.UpdateContracts(&_ResultStorage.TransactOpts, _newPollRegistry, _newVoteVerifier)
}

// ResultStorageOwnershipTransferredIterator is returned from FilterOwnershipTransferred and is used to iterate over the raw logs and unpacked data for OwnershipTransferred events raised by the ResultStorage contract.
type ResultStorageOwnershipTransferredIterator struct {
	Event *ResultStorageOwnershipTransferred // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStorageOwnershipTransferredIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageOwnershipTransferred)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageOwnershipTransferred)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStorageOwnershipTransferredIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStorageOwnershipTransferredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStorageOwnershipTransferred represents a OwnershipTransferred event raised by the ResultStorage contract.
type ResultStorageOwnershipTransferred struct {
	PreviousOwner common.Address
	NewOwner      common.Address
	Raw           types.Log // Blockchain specific contextual infos
}

// FilterOwnershipTransferred is a free log retrieval operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_ResultStorage *ResultStorageFilterer) FilterOwnershipTransferred(opts *bind.FilterOpts, previousOwner []common.Address, newOwner []common.Address) (*ResultStorageOwnershipTransferredIterator, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageOwnershipTransferredIterator{contract: _ResultStorage.contract, event: "OwnershipTransferred", logs: logs, sub: sub}, nil
}

// WatchOwnershipTransferred is a free log subscription operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_ResultStorage *ResultStorageFilterer) WatchOwnershipTransferred(opts *bind.WatchOpts, sink chan<- *ResultStorageOwnershipTransferred, previousOwner []common.Address, newOwner []common.Address) (event.Subscription, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStorageOwnershipTransferred)
				if err := _ResultStorage.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseOwnershipTransferred is a log parse operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_ResultStorage *ResultStorageFilterer) ParseOwnershipTransferred(log types.Log) (*ResultStorageOwnershipTransferred, error) {
	event := new(ResultStorageOwnershipTransferred)
	if err := _ResultStorage.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// ResultStoragePausedIterator is returned from FilterPaused and is used to iterate over the raw logs and unpacked data for Paused events raised by the ResultStorage contract.
type ResultStoragePausedIterator struct {
	Event *ResultStoragePaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStoragePausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStoragePaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStoragePaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStoragePausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStoragePausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStoragePaused represents a Paused event raised by the ResultStorage contract.
type ResultStoragePaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterPaused is a free log retrieval operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_ResultStorage *ResultStorageFilterer) FilterPaused(opts *bind.FilterOpts) (*ResultStoragePausedIterator, error) {

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return &ResultStoragePausedIterator{contract: _ResultStorage.contract, event: "Paused", logs: logs, sub: sub}, nil
}

// WatchPaused is a free log subscription operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_ResultStorage *ResultStorageFilterer) WatchPaused(opts *bind.WatchOpts, sink chan<- *ResultStoragePaused) (event.Subscription, error) {

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStoragePaused)
				if err := _ResultStorage.contract.UnpackLog(event, "Paused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePaused is a log parse operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_ResultStorage *ResultStorageFilterer) ParsePaused(log types.Log) (*ResultStoragePaused, error) {
	event := new(ResultStoragePaused)
	if err := _ResultStorage.contract.UnpackLog(event, "Paused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// ResultStorageResultsFinalizedIterator is returned from FilterResultsFinalized and is used to iterate over the raw logs and unpacked data for ResultsFinalized events raised by the ResultStorage contract.
type ResultStorageResultsFinalizedIterator struct {
	Event *ResultStorageResultsFinalized // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStorageResultsFinalizedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsFinalized)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsFinalized)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStorageResultsFinalizedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStorageResultsFinalizedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStorageResultsFinalized represents a ResultsFinalized event raised by the ResultStorage contract.
type ResultStorageResultsFinalized struct {
	PollId      *big.Int
	ResultsHash [32]byte
	Raw         types.Log // Blockchain specific contextual infos
}

// FilterResultsFinalized is a free log retrieval operation binding the contract event 0xf9deee94a96e488d275ba933f5fdbd20d85587fc51970341ecdb75eef62aba8f.
//
// Solidity: event ResultsFinalized(uint256 indexed pollId, bytes32 resultsHash)
func (_ResultStorage *ResultStorageFilterer) FilterResultsFinalized(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsFinalizedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsFinalizedIterator{contract: _ResultStorage.contract, event: "ResultsFinalized", logs: logs, sub: sub}, nil
}

// WatchResultsFinalized is a free log subscription operation binding the contract event 0xf9deee94a96e488d275ba933f5fdbd20d85587fc51970341ecdb75eef62aba8f.
//
// Solidity: event ResultsFinalized(uint256 indexed pollId, bytes32 resultsHash)
func (_ResultStorage *ResultStorageFilterer) WatchResultsFinalized(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsFinalized, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStorageResultsFinalized)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsFinalized", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseResultsFinalized is a log parse operation binding the contract event 0xf9deee94a96e488d275ba933f5fdbd20d85587fc51970341ecdb75eef62aba8f.
//
// Solidity: event ResultsFinalized(uint256 indexed pollId, bytes32 resultsHash)
func (_ResultStorage *ResultStorageFilterer) ParseResultsFinalized(log types.Log) (*ResultStorageResultsFinalized, error) {
	event := new(ResultStorageResultsFinalized)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsFinalized", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// ResultStorageResultsStoredIterator is returned from FilterResultsStored and is used to iterate over the raw logs and unpacked data for ResultsStored events raised by the ResultStorage contract.
type ResultStorageResultsStoredIterator struct {
	Event *ResultStorageResultsStored // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStorageResultsStoredIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsStored)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsStored)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStorageResultsStoredIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStorageResultsStoredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStorageResultsStored represents a ResultsStored event raised by the ResultStorage contract.
type ResultStorageResultsStored struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedBy    common.Address
	PublishedAt    *big.Int
	Raw            types.Log // Blockchain specific contextual infos
}

// FilterResultsStored is a free log retrieval operation binding the contract event 0x300614e429e78f4edce37ca91df29aec28d6fe6aac90dddae95a350b50abcb50.
//
// Solidity: event ResultsStored(uint256 indexed pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, address publishedBy, uint256 publishedAt)
func (_ResultStorage *ResultStorageFilterer) FilterResultsStored(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsStoredIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsStored", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsStoredIterator{contract: _ResultStorage.contract, event: "ResultsStored", logs: logs, sub: sub}, nil
}

// WatchResultsStored is a free log subscription operation binding the contract event 0x300614e429e78f4edce37ca91df29aec28d6fe6aac90dddae95a350b50abcb50.
//
// Solidity: event ResultsStored(uint256 indexed pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, address publishedBy, uint256 publishedAt)
func (_ResultStorage *ResultStorageFilterer) WatchResultsStored(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsStored, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsStored", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStorageResultsStored)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsStored", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseResultsStored is a log parse operation binding the contract event 0x300614e429e78f4edce37ca91df29aec28d6fe6aac90dddae95a350b50abcb50.
//
// Solidity: event ResultsStored(uint256 indexed pollId, uint256 totalVotes, uint256 winnerOptionId, bytes32 resultsHash, address publishedBy, uint256 publishedAt)
func (_ResultStorage *ResultStorageFilterer) ParseResultsStored(log types.Log) (*ResultStorageResultsStored, error) {
	event := new(ResultStorageResultsStored)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsStored", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// ResultStorageResultsVerifiedIterator is returned from FilterResultsVerified and is used to iterate over the raw logs and unpacked data for ResultsVerified events raised by the ResultStorage contract.
type ResultStorageResultsVerifiedIterator struct {
	Event *ResultStorageResultsVerified // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStorageResultsVerifiedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsVerified)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsVerified)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStorageResultsVerifiedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStorageResultsVerifiedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStorageResultsVerified represents a ResultsVerified event raised by the ResultStorage contract.
type ResultStorageResultsVerified struct {
	PollId      *big.Int
	ResultsHash [32]byte
	IsValid     bool
	Raw         types.Log // Blockchain specific contextual infos
}

// FilterResultsVerified is a free log retrieval operation binding the contract event 0x5e920022daf53081c45ae51b2bdef48e4f86dfeddfb2a7eae769a4aec0dc88be.
//
// Solidity: event ResultsVerified(uint256 indexed pollId, bytes32 resultsHash, bool isValid)
func (_ResultStorage *ResultStorageFilterer) FilterResultsVerified(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsVerifiedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsVerified", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsVerifiedIterator{contract: _ResultStorage.contract, event: "ResultsVerified", logs: logs, sub: sub}, nil
}

// WatchResultsVerified is a free log subscription operation binding the contract event 0x5e920022daf53081c45ae51b2bdef48e4f86dfeddfb2a7eae769a4aec0dc88be.
//
// Solidity: event ResultsVerified(uint256 indexed pollId, bytes32 resultsHash, bool isValid)
func (_ResultStorage *ResultStorageFilterer) WatchResultsVerified(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsVerified, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsVerified", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStorageResultsVerified)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsVerified", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseResultsVerified is a log parse operation binding the contract event 0x5e920022daf53081c45ae51b2bdef48e4f86dfeddfb2a7eae769a4aec0dc88be.
//
// Solidity: event ResultsVerified(uint256 indexed pollId, bytes32 resultsHash, bool isValid)
func (_ResultStorage *ResultStorageFilterer) ParseResultsVerified(log types.Log) (*ResultStorageResultsVerified, error) {
	event := new(ResultStorageResultsVerified)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsVerified", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// ResultStorageUnpausedIterator is returned from FilterUnpaused and is used to iterate over the raw logs and unpacked data for Unpaused events raised by the ResultStorage contract.
type ResultStorageUnpausedIterator struct {
	Event *ResultStorageUnpaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *ResultStorageUnpausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageUnpaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageUnpaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *ResultStorageUnpausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *ResultStorageUnpausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// ResultStorageUnpaused represents a Unpaused event raised by the ResultStorage contract.
type ResultStorageUnpaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterUnpaused is a free log retrieval operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_ResultStorage *ResultStorageFilterer) FilterUnpaused(opts *bind.FilterOpts) (*ResultStorageUnpausedIterator, error) {

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return &ResultStorageUnpausedIterator{contract: _ResultStorage.contract, event: "Unpaused", logs: logs, sub: sub}, nil
}

// WatchUnpaused is a free log subscription operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_ResultStorage *ResultStorageFilterer) WatchUnpaused(opts *bind.WatchOpts, sink chan<- *ResultStorageUnpaused) (event.Subscription, error) {

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(ResultStorageUnpaused)
				if err := _ResultStorage.contract.UnpackLog(event, "Unpaused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseUnpaused is a log parse operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_ResultStorage *ResultStorageFilterer) ParseUnpaused(log types.Log) (*ResultStorageUnpaused, error) {
	event := new(ResultStorageUnpaused)
	if err := _ResultStorage.contract.UnpackLog(event, "Unpaused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
