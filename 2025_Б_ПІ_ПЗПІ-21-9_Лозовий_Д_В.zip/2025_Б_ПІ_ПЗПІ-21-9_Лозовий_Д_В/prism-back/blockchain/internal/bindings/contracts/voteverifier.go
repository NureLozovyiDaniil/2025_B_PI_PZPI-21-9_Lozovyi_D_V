// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package contracts

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// VoteVerifierVote is an auto generated low-level Go binding around an user-defined struct.
type VoteVerifierVote struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}

// VoteVerifierMetaData contains all meta data concerning the VoteVerifier contract.
var VoteVerifierMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"initialOwner\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_pollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_authorizedService\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"EnforcedPause\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ExpectedPause\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"}],\"name\":\"OwnableInvalidOwner\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"OwnableUnauthorizedAccount\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ReentrancyGuardReentrantCall\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":true,\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"}],\"name\":\"AnonymousVoteRecorded\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"oldService\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"newService\",\"type\":\"address\"}],\"name\":\"AuthorizedServiceUpdated\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Paused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Unpaused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"}],\"name\":\"VoteRecorded\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"MAX_OPTIONS_PER_POLL\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"anonymousVoterChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"authorizedService\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"}],\"name\":\"getAnonymousChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"}],\"name\":\"getOptionVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_maxOptions\",\"type\":\"uint256\"}],\"name\":\"getPollResults\",\"outputs\":[{\"internalType\":\"uint256[]\",\"name\":\"\",\"type\":\"uint256[]\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getPollStatistics\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"totalVotes_\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"openVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"anonymousVotes\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getPollVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"getUserChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"_voteHash\",\"type\":\"bytes32\"}],\"name\":\"getVoteByHash\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"internalType\":\"bool\",\"name\":\"isAnonymous\",\"type\":\"bool\"}],\"internalType\":\"structVoteVerifier.Vote\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"}],\"name\":\"hasAnonymousIdVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"hasUserVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"name\":\"hasVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"optionVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pollRegistry\",\"outputs\":[{\"internalType\":\"contractPollRegistry\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"pollVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"bytes32\",\"name\":\"_optionsHash\",\"type\":\"bytes32\"}],\"name\":\"recordAnonymousVote\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_optionsHash\",\"type\":\"bytes32\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"recordVote\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"totalVotes\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newAuthorizedService\",\"type\":\"address\"}],\"name\":\"updateAuthorizedService\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newPollRegistry\",\"type\":\"address\"}],\"name\":\"updatePollRegistry\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"usedAnonymousIds\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"name\":\"voterChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"votesByHash\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"internalType\":\"bool\",\"name\":\"isAnonymous\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"}]",
}

// VoteVerifierABI is the input ABI used to generate the binding from.
// Deprecated: Use VoteVerifierMetaData.ABI instead.
var VoteVerifierABI = VoteVerifierMetaData.ABI

// VoteVerifier is an auto generated Go binding around an Ethereum contract.
type VoteVerifier struct {
	VoteVerifierCaller     // Read-only binding to the contract
	VoteVerifierTransactor // Write-only binding to the contract
	VoteVerifierFilterer   // Log filterer for contract events
}

// VoteVerifierCaller is an auto generated read-only Go binding around an Ethereum contract.
type VoteVerifierCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// VoteVerifierTransactor is an auto generated write-only Go binding around an Ethereum contract.
type VoteVerifierTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// VoteVerifierFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type VoteVerifierFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// VoteVerifierSession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type VoteVerifierSession struct {
	Contract     *VoteVerifier     // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// VoteVerifierCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type VoteVerifierCallerSession struct {
	Contract *VoteVerifierCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts       // Call options to use throughout this session
}

// VoteVerifierTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type VoteVerifierTransactorSession struct {
	Contract     *VoteVerifierTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts       // Transaction auth options to use throughout this session
}

// VoteVerifierRaw is an auto generated low-level Go binding around an Ethereum contract.
type VoteVerifierRaw struct {
	Contract *VoteVerifier // Generic contract binding to access the raw methods on
}

// VoteVerifierCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type VoteVerifierCallerRaw struct {
	Contract *VoteVerifierCaller // Generic read-only contract binding to access the raw methods on
}

// VoteVerifierTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type VoteVerifierTransactorRaw struct {
	Contract *VoteVerifierTransactor // Generic write-only contract binding to access the raw methods on
}

// NewVoteVerifier creates a new instance of VoteVerifier, bound to a specific deployed contract.
func NewVoteVerifier(address common.Address, backend bind.ContractBackend) (*VoteVerifier, error) {
	contract, err := bindVoteVerifier(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &VoteVerifier{VoteVerifierCaller: VoteVerifierCaller{contract: contract}, VoteVerifierTransactor: VoteVerifierTransactor{contract: contract}, VoteVerifierFilterer: VoteVerifierFilterer{contract: contract}}, nil
}

// NewVoteVerifierCaller creates a new read-only instance of VoteVerifier, bound to a specific deployed contract.
func NewVoteVerifierCaller(address common.Address, caller bind.ContractCaller) (*VoteVerifierCaller, error) {
	contract, err := bindVoteVerifier(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierCaller{contract: contract}, nil
}

// NewVoteVerifierTransactor creates a new write-only instance of VoteVerifier, bound to a specific deployed contract.
func NewVoteVerifierTransactor(address common.Address, transactor bind.ContractTransactor) (*VoteVerifierTransactor, error) {
	contract, err := bindVoteVerifier(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierTransactor{contract: contract}, nil
}

// NewVoteVerifierFilterer creates a new log filterer instance of VoteVerifier, bound to a specific deployed contract.
func NewVoteVerifierFilterer(address common.Address, filterer bind.ContractFilterer) (*VoteVerifierFilterer, error) {
	contract, err := bindVoteVerifier(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierFilterer{contract: contract}, nil
}

// bindVoteVerifier binds a generic wrapper to an already deployed contract.
func bindVoteVerifier(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := VoteVerifierMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_VoteVerifier *VoteVerifierRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _VoteVerifier.Contract.VoteVerifierCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_VoteVerifier *VoteVerifierRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.Contract.VoteVerifierTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_VoteVerifier *VoteVerifierRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _VoteVerifier.Contract.VoteVerifierTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_VoteVerifier *VoteVerifierCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _VoteVerifier.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_VoteVerifier *VoteVerifierTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_VoteVerifier *VoteVerifierTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _VoteVerifier.Contract.contract.Transact(opts, method, params...)
}

// MAXOPTIONSPERPOLL is a free data retrieval call binding the contract method 0x1b1a2e6c.
//
// Solidity: function MAX_OPTIONS_PER_POLL() view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) MAXOPTIONSPERPOLL(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "MAX_OPTIONS_PER_POLL")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// MAXOPTIONSPERPOLL is a free data retrieval call binding the contract method 0x1b1a2e6c.
//
// Solidity: function MAX_OPTIONS_PER_POLL() view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) MAXOPTIONSPERPOLL() (*big.Int, error) {
	return _VoteVerifier.Contract.MAXOPTIONSPERPOLL(&_VoteVerifier.CallOpts)
}

// MAXOPTIONSPERPOLL is a free data retrieval call binding the contract method 0x1b1a2e6c.
//
// Solidity: function MAX_OPTIONS_PER_POLL() view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) MAXOPTIONSPERPOLL() (*big.Int, error) {
	return _VoteVerifier.Contract.MAXOPTIONSPERPOLL(&_VoteVerifier.CallOpts)
}

// AnonymousVoterChoice is a free data retrieval call binding the contract method 0x06a87948.
//
// Solidity: function anonymousVoterChoice(uint256 , bytes32 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) AnonymousVoterChoice(opts *bind.CallOpts, arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "anonymousVoterChoice", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// AnonymousVoterChoice is a free data retrieval call binding the contract method 0x06a87948.
//
// Solidity: function anonymousVoterChoice(uint256 , bytes32 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) AnonymousVoterChoice(arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.AnonymousVoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

// AnonymousVoterChoice is a free data retrieval call binding the contract method 0x06a87948.
//
// Solidity: function anonymousVoterChoice(uint256 , bytes32 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) AnonymousVoterChoice(arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.AnonymousVoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

// AuthorizedService is a free data retrieval call binding the contract method 0x5d1dd797.
//
// Solidity: function authorizedService() view returns(address)
func (_VoteVerifier *VoteVerifierCaller) AuthorizedService(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "authorizedService")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// AuthorizedService is a free data retrieval call binding the contract method 0x5d1dd797.
//
// Solidity: function authorizedService() view returns(address)
func (_VoteVerifier *VoteVerifierSession) AuthorizedService() (common.Address, error) {
	return _VoteVerifier.Contract.AuthorizedService(&_VoteVerifier.CallOpts)
}

// AuthorizedService is a free data retrieval call binding the contract method 0x5d1dd797.
//
// Solidity: function authorizedService() view returns(address)
func (_VoteVerifier *VoteVerifierCallerSession) AuthorizedService() (common.Address, error) {
	return _VoteVerifier.Contract.AuthorizedService(&_VoteVerifier.CallOpts)
}

// GetAnonymousChoice is a free data retrieval call binding the contract method 0xc9e6ed95.
//
// Solidity: function getAnonymousChoice(uint256 _pollId, bytes32 _anonymousId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) GetAnonymousChoice(opts *bind.CallOpts, _pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getAnonymousChoice", _pollId, _anonymousId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetAnonymousChoice is a free data retrieval call binding the contract method 0xc9e6ed95.
//
// Solidity: function getAnonymousChoice(uint256 _pollId, bytes32 _anonymousId) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) GetAnonymousChoice(_pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.GetAnonymousChoice(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

// GetAnonymousChoice is a free data retrieval call binding the contract method 0xc9e6ed95.
//
// Solidity: function getAnonymousChoice(uint256 _pollId, bytes32 _anonymousId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) GetAnonymousChoice(_pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.GetAnonymousChoice(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

// GetOptionVoteCount is a free data retrieval call binding the contract method 0x63e9a61d.
//
// Solidity: function getOptionVoteCount(uint256 _pollId, uint256 _optionId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) GetOptionVoteCount(opts *bind.CallOpts, _pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getOptionVoteCount", _pollId, _optionId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetOptionVoteCount is a free data retrieval call binding the contract method 0x63e9a61d.
//
// Solidity: function getOptionVoteCount(uint256 _pollId, uint256 _optionId) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) GetOptionVoteCount(_pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetOptionVoteCount(&_VoteVerifier.CallOpts, _pollId, _optionId)
}

// GetOptionVoteCount is a free data retrieval call binding the contract method 0x63e9a61d.
//
// Solidity: function getOptionVoteCount(uint256 _pollId, uint256 _optionId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) GetOptionVoteCount(_pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetOptionVoteCount(&_VoteVerifier.CallOpts, _pollId, _optionId)
}

// GetPollResults is a free data retrieval call binding the contract method 0x425cdbb5.
//
// Solidity: function getPollResults(uint256 _pollId, uint256 _maxOptions) view returns(uint256[])
func (_VoteVerifier *VoteVerifierCaller) GetPollResults(opts *bind.CallOpts, _pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollResults", _pollId, _maxOptions)

	if err != nil {
		return *new([]*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new([]*big.Int)).(*[]*big.Int)

	return out0, err

}

// GetPollResults is a free data retrieval call binding the contract method 0x425cdbb5.
//
// Solidity: function getPollResults(uint256 _pollId, uint256 _maxOptions) view returns(uint256[])
func (_VoteVerifier *VoteVerifierSession) GetPollResults(_pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	return _VoteVerifier.Contract.GetPollResults(&_VoteVerifier.CallOpts, _pollId, _maxOptions)
}

// GetPollResults is a free data retrieval call binding the contract method 0x425cdbb5.
//
// Solidity: function getPollResults(uint256 _pollId, uint256 _maxOptions) view returns(uint256[])
func (_VoteVerifier *VoteVerifierCallerSession) GetPollResults(_pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	return _VoteVerifier.Contract.GetPollResults(&_VoteVerifier.CallOpts, _pollId, _maxOptions)
}

// GetPollStatistics is a free data retrieval call binding the contract method 0x030bb77d.
//
// Solidity: function getPollStatistics(uint256 _pollId) view returns(uint256 totalVotes_, uint256 openVotes, uint256 anonymousVotes)
func (_VoteVerifier *VoteVerifierCaller) GetPollStatistics(opts *bind.CallOpts, _pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollStatistics", _pollId)

	outstruct := new(struct {
		TotalVotes     *big.Int
		OpenVotes      *big.Int
		AnonymousVotes *big.Int
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.TotalVotes = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.OpenVotes = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.AnonymousVotes = *abi.ConvertType(out[2], new(*big.Int)).(**big.Int)

	return *outstruct, err

}

// GetPollStatistics is a free data retrieval call binding the contract method 0x030bb77d.
//
// Solidity: function getPollStatistics(uint256 _pollId) view returns(uint256 totalVotes_, uint256 openVotes, uint256 anonymousVotes)
func (_VoteVerifier *VoteVerifierSession) GetPollStatistics(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	return _VoteVerifier.Contract.GetPollStatistics(&_VoteVerifier.CallOpts, _pollId)
}

// GetPollStatistics is a free data retrieval call binding the contract method 0x030bb77d.
//
// Solidity: function getPollStatistics(uint256 _pollId) view returns(uint256 totalVotes_, uint256 openVotes, uint256 anonymousVotes)
func (_VoteVerifier *VoteVerifierCallerSession) GetPollStatistics(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	return _VoteVerifier.Contract.GetPollStatistics(&_VoteVerifier.CallOpts, _pollId)
}

// GetPollVoteCount is a free data retrieval call binding the contract method 0x48892213.
//
// Solidity: function getPollVoteCount(uint256 _pollId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) GetPollVoteCount(opts *bind.CallOpts, _pollId *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollVoteCount", _pollId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetPollVoteCount is a free data retrieval call binding the contract method 0x48892213.
//
// Solidity: function getPollVoteCount(uint256 _pollId) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) GetPollVoteCount(_pollId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetPollVoteCount(&_VoteVerifier.CallOpts, _pollId)
}

// GetPollVoteCount is a free data retrieval call binding the contract method 0x48892213.
//
// Solidity: function getPollVoteCount(uint256 _pollId) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) GetPollVoteCount(_pollId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetPollVoteCount(&_VoteVerifier.CallOpts, _pollId)
}

// GetUserChoice is a free data retrieval call binding the contract method 0x0eeef26a.
//
// Solidity: function getUserChoice(uint256 _pollId, address _voter) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) GetUserChoice(opts *bind.CallOpts, _pollId *big.Int, _voter common.Address) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getUserChoice", _pollId, _voter)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetUserChoice is a free data retrieval call binding the contract method 0x0eeef26a.
//
// Solidity: function getUserChoice(uint256 _pollId, address _voter) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) GetUserChoice(_pollId *big.Int, _voter common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.GetUserChoice(&_VoteVerifier.CallOpts, _pollId, _voter)
}

// GetUserChoice is a free data retrieval call binding the contract method 0x0eeef26a.
//
// Solidity: function getUserChoice(uint256 _pollId, address _voter) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) GetUserChoice(_pollId *big.Int, _voter common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.GetUserChoice(&_VoteVerifier.CallOpts, _pollId, _voter)
}

// GetVoteByHash is a free data retrieval call binding the contract method 0x711a53d4.
//
// Solidity: function getVoteByHash(bytes32 _voteHash) view returns((uint256,uint256,address,bytes32,uint256,bytes32,bool))
func (_VoteVerifier *VoteVerifierCaller) GetVoteByHash(opts *bind.CallOpts, _voteHash [32]byte) (VoteVerifierVote, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getVoteByHash", _voteHash)

	if err != nil {
		return *new(VoteVerifierVote), err
	}

	out0 := *abi.ConvertType(out[0], new(VoteVerifierVote)).(*VoteVerifierVote)

	return out0, err

}

// GetVoteByHash is a free data retrieval call binding the contract method 0x711a53d4.
//
// Solidity: function getVoteByHash(bytes32 _voteHash) view returns((uint256,uint256,address,bytes32,uint256,bytes32,bool))
func (_VoteVerifier *VoteVerifierSession) GetVoteByHash(_voteHash [32]byte) (VoteVerifierVote, error) {
	return _VoteVerifier.Contract.GetVoteByHash(&_VoteVerifier.CallOpts, _voteHash)
}

// GetVoteByHash is a free data retrieval call binding the contract method 0x711a53d4.
//
// Solidity: function getVoteByHash(bytes32 _voteHash) view returns((uint256,uint256,address,bytes32,uint256,bytes32,bool))
func (_VoteVerifier *VoteVerifierCallerSession) GetVoteByHash(_voteHash [32]byte) (VoteVerifierVote, error) {
	return _VoteVerifier.Contract.GetVoteByHash(&_VoteVerifier.CallOpts, _voteHash)
}

// HasAnonymousIdVoted is a free data retrieval call binding the contract method 0xf72bf136.
//
// Solidity: function hasAnonymousIdVoted(uint256 _pollId, bytes32 _anonymousId) view returns(bool)
func (_VoteVerifier *VoteVerifierCaller) HasAnonymousIdVoted(opts *bind.CallOpts, _pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasAnonymousIdVoted", _pollId, _anonymousId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// HasAnonymousIdVoted is a free data retrieval call binding the contract method 0xf72bf136.
//
// Solidity: function hasAnonymousIdVoted(uint256 _pollId, bytes32 _anonymousId) view returns(bool)
func (_VoteVerifier *VoteVerifierSession) HasAnonymousIdVoted(_pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	return _VoteVerifier.Contract.HasAnonymousIdVoted(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

// HasAnonymousIdVoted is a free data retrieval call binding the contract method 0xf72bf136.
//
// Solidity: function hasAnonymousIdVoted(uint256 _pollId, bytes32 _anonymousId) view returns(bool)
func (_VoteVerifier *VoteVerifierCallerSession) HasAnonymousIdVoted(_pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	return _VoteVerifier.Contract.HasAnonymousIdVoted(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

// HasUserVoted is a free data retrieval call binding the contract method 0xdc296ae1.
//
// Solidity: function hasUserVoted(uint256 _pollId, address _voter) view returns(bool)
func (_VoteVerifier *VoteVerifierCaller) HasUserVoted(opts *bind.CallOpts, _pollId *big.Int, _voter common.Address) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasUserVoted", _pollId, _voter)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// HasUserVoted is a free data retrieval call binding the contract method 0xdc296ae1.
//
// Solidity: function hasUserVoted(uint256 _pollId, address _voter) view returns(bool)
func (_VoteVerifier *VoteVerifierSession) HasUserVoted(_pollId *big.Int, _voter common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasUserVoted(&_VoteVerifier.CallOpts, _pollId, _voter)
}

// HasUserVoted is a free data retrieval call binding the contract method 0xdc296ae1.
//
// Solidity: function hasUserVoted(uint256 _pollId, address _voter) view returns(bool)
func (_VoteVerifier *VoteVerifierCallerSession) HasUserVoted(_pollId *big.Int, _voter common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasUserVoted(&_VoteVerifier.CallOpts, _pollId, _voter)
}

// HasVoted is a free data retrieval call binding the contract method 0x43859632.
//
// Solidity: function hasVoted(uint256 , address ) view returns(bool)
func (_VoteVerifier *VoteVerifierCaller) HasVoted(opts *bind.CallOpts, arg0 *big.Int, arg1 common.Address) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasVoted", arg0, arg1)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// HasVoted is a free data retrieval call binding the contract method 0x43859632.
//
// Solidity: function hasVoted(uint256 , address ) view returns(bool)
func (_VoteVerifier *VoteVerifierSession) HasVoted(arg0 *big.Int, arg1 common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasVoted(&_VoteVerifier.CallOpts, arg0, arg1)
}

// HasVoted is a free data retrieval call binding the contract method 0x43859632.
//
// Solidity: function hasVoted(uint256 , address ) view returns(bool)
func (_VoteVerifier *VoteVerifierCallerSession) HasVoted(arg0 *big.Int, arg1 common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasVoted(&_VoteVerifier.CallOpts, arg0, arg1)
}

// OptionVoteCount is a free data retrieval call binding the contract method 0xa0de0b17.
//
// Solidity: function optionVoteCount(uint256 , uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) OptionVoteCount(opts *bind.CallOpts, arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "optionVoteCount", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// OptionVoteCount is a free data retrieval call binding the contract method 0xa0de0b17.
//
// Solidity: function optionVoteCount(uint256 , uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) OptionVoteCount(arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.OptionVoteCount(&_VoteVerifier.CallOpts, arg0, arg1)
}

// OptionVoteCount is a free data retrieval call binding the contract method 0xa0de0b17.
//
// Solidity: function optionVoteCount(uint256 , uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) OptionVoteCount(arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.OptionVoteCount(&_VoteVerifier.CallOpts, arg0, arg1)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_VoteVerifier *VoteVerifierCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_VoteVerifier *VoteVerifierSession) Owner() (common.Address, error) {
	return _VoteVerifier.Contract.Owner(&_VoteVerifier.CallOpts)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_VoteVerifier *VoteVerifierCallerSession) Owner() (common.Address, error) {
	return _VoteVerifier.Contract.Owner(&_VoteVerifier.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_VoteVerifier *VoteVerifierCaller) Paused(opts *bind.CallOpts) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "paused")

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_VoteVerifier *VoteVerifierSession) Paused() (bool, error) {
	return _VoteVerifier.Contract.Paused(&_VoteVerifier.CallOpts)
}

// Paused is a free data retrieval call binding the contract method 0x5c975abb.
//
// Solidity: function paused() view returns(bool)
func (_VoteVerifier *VoteVerifierCallerSession) Paused() (bool, error) {
	return _VoteVerifier.Contract.Paused(&_VoteVerifier.CallOpts)
}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_VoteVerifier *VoteVerifierCaller) PollRegistry(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "pollRegistry")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_VoteVerifier *VoteVerifierSession) PollRegistry() (common.Address, error) {
	return _VoteVerifier.Contract.PollRegistry(&_VoteVerifier.CallOpts)
}

// PollRegistry is a free data retrieval call binding the contract method 0xbde0e132.
//
// Solidity: function pollRegistry() view returns(address)
func (_VoteVerifier *VoteVerifierCallerSession) PollRegistry() (common.Address, error) {
	return _VoteVerifier.Contract.PollRegistry(&_VoteVerifier.CallOpts)
}

// PollVoteCount is a free data retrieval call binding the contract method 0x61981b68.
//
// Solidity: function pollVoteCount(uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) PollVoteCount(opts *bind.CallOpts, arg0 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "pollVoteCount", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// PollVoteCount is a free data retrieval call binding the contract method 0x61981b68.
//
// Solidity: function pollVoteCount(uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) PollVoteCount(arg0 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.PollVoteCount(&_VoteVerifier.CallOpts, arg0)
}

// PollVoteCount is a free data retrieval call binding the contract method 0x61981b68.
//
// Solidity: function pollVoteCount(uint256 ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) PollVoteCount(arg0 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.PollVoteCount(&_VoteVerifier.CallOpts, arg0)
}

// TotalVotes is a free data retrieval call binding the contract method 0x0d15fd77.
//
// Solidity: function totalVotes() view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) TotalVotes(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "totalVotes")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// TotalVotes is a free data retrieval call binding the contract method 0x0d15fd77.
//
// Solidity: function totalVotes() view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) TotalVotes() (*big.Int, error) {
	return _VoteVerifier.Contract.TotalVotes(&_VoteVerifier.CallOpts)
}

// TotalVotes is a free data retrieval call binding the contract method 0x0d15fd77.
//
// Solidity: function totalVotes() view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) TotalVotes() (*big.Int, error) {
	return _VoteVerifier.Contract.TotalVotes(&_VoteVerifier.CallOpts)
}

// UsedAnonymousIds is a free data retrieval call binding the contract method 0x505cf482.
//
// Solidity: function usedAnonymousIds(uint256 , bytes32 ) view returns(bool)
func (_VoteVerifier *VoteVerifierCaller) UsedAnonymousIds(opts *bind.CallOpts, arg0 *big.Int, arg1 [32]byte) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "usedAnonymousIds", arg0, arg1)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

// UsedAnonymousIds is a free data retrieval call binding the contract method 0x505cf482.
//
// Solidity: function usedAnonymousIds(uint256 , bytes32 ) view returns(bool)
func (_VoteVerifier *VoteVerifierSession) UsedAnonymousIds(arg0 *big.Int, arg1 [32]byte) (bool, error) {
	return _VoteVerifier.Contract.UsedAnonymousIds(&_VoteVerifier.CallOpts, arg0, arg1)
}

// UsedAnonymousIds is a free data retrieval call binding the contract method 0x505cf482.
//
// Solidity: function usedAnonymousIds(uint256 , bytes32 ) view returns(bool)
func (_VoteVerifier *VoteVerifierCallerSession) UsedAnonymousIds(arg0 *big.Int, arg1 [32]byte) (bool, error) {
	return _VoteVerifier.Contract.UsedAnonymousIds(&_VoteVerifier.CallOpts, arg0, arg1)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_VoteVerifier *VoteVerifierCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_VoteVerifier *VoteVerifierSession) Version() (string, error) {
	return _VoteVerifier.Contract.Version(&_VoteVerifier.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_VoteVerifier *VoteVerifierCallerSession) Version() (string, error) {
	return _VoteVerifier.Contract.Version(&_VoteVerifier.CallOpts)
}

// VoterChoice is a free data retrieval call binding the contract method 0x51477141.
//
// Solidity: function voterChoice(uint256 , address ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCaller) VoterChoice(opts *bind.CallOpts, arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "voterChoice", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// VoterChoice is a free data retrieval call binding the contract method 0x51477141.
//
// Solidity: function voterChoice(uint256 , address ) view returns(uint256)
func (_VoteVerifier *VoteVerifierSession) VoterChoice(arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.VoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

// VoterChoice is a free data retrieval call binding the contract method 0x51477141.
//
// Solidity: function voterChoice(uint256 , address ) view returns(uint256)
func (_VoteVerifier *VoteVerifierCallerSession) VoterChoice(arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.VoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

// VotesByHash is a free data retrieval call binding the contract method 0x55d45dd9.
//
// Solidity: function votesByHash(bytes32 ) view returns(uint256 pollId, uint256 optionId, address voter, bytes32 anonymousId, uint256 timestamp, bytes32 voteHash, bool isAnonymous)
func (_VoteVerifier *VoteVerifierCaller) VotesByHash(opts *bind.CallOpts, arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "votesByHash", arg0)

	outstruct := new(struct {
		PollId      *big.Int
		OptionId    *big.Int
		Voter       common.Address
		AnonymousId [32]byte
		Timestamp   *big.Int
		VoteHash    [32]byte
		IsAnonymous bool
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.PollId = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.OptionId = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.Voter = *abi.ConvertType(out[2], new(common.Address)).(*common.Address)
	outstruct.AnonymousId = *abi.ConvertType(out[3], new([32]byte)).(*[32]byte)
	outstruct.Timestamp = *abi.ConvertType(out[4], new(*big.Int)).(**big.Int)
	outstruct.VoteHash = *abi.ConvertType(out[5], new([32]byte)).(*[32]byte)
	outstruct.IsAnonymous = *abi.ConvertType(out[6], new(bool)).(*bool)

	return *outstruct, err

}

// VotesByHash is a free data retrieval call binding the contract method 0x55d45dd9.
//
// Solidity: function votesByHash(bytes32 ) view returns(uint256 pollId, uint256 optionId, address voter, bytes32 anonymousId, uint256 timestamp, bytes32 voteHash, bool isAnonymous)
func (_VoteVerifier *VoteVerifierSession) VotesByHash(arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	return _VoteVerifier.Contract.VotesByHash(&_VoteVerifier.CallOpts, arg0)
}

// VotesByHash is a free data retrieval call binding the contract method 0x55d45dd9.
//
// Solidity: function votesByHash(bytes32 ) view returns(uint256 pollId, uint256 optionId, address voter, bytes32 anonymousId, uint256 timestamp, bytes32 voteHash, bool isAnonymous)
func (_VoteVerifier *VoteVerifierCallerSession) VotesByHash(arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	return _VoteVerifier.Contract.VotesByHash(&_VoteVerifier.CallOpts, arg0)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_VoteVerifier *VoteVerifierTransactor) Pause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "pause")
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_VoteVerifier *VoteVerifierSession) Pause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Pause(&_VoteVerifier.TransactOpts)
}

// Pause is a paid mutator transaction binding the contract method 0x8456cb59.
//
// Solidity: function pause() returns()
func (_VoteVerifier *VoteVerifierTransactorSession) Pause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Pause(&_VoteVerifier.TransactOpts)
}

// RecordAnonymousVote is a paid mutator transaction binding the contract method 0x377e5ed0.
//
// Solidity: function recordAnonymousVote(uint256 _pollId, uint256 _optionId, bytes32 _anonymousId, bytes32 _optionsHash) returns()
func (_VoteVerifier *VoteVerifierTransactor) RecordAnonymousVote(opts *bind.TransactOpts, _pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "recordAnonymousVote", _pollId, _optionId, _anonymousId, _optionsHash)
}

// RecordAnonymousVote is a paid mutator transaction binding the contract method 0x377e5ed0.
//
// Solidity: function recordAnonymousVote(uint256 _pollId, uint256 _optionId, bytes32 _anonymousId, bytes32 _optionsHash) returns()
func (_VoteVerifier *VoteVerifierSession) RecordAnonymousVote(_pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordAnonymousVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _anonymousId, _optionsHash)
}

// RecordAnonymousVote is a paid mutator transaction binding the contract method 0x377e5ed0.
//
// Solidity: function recordAnonymousVote(uint256 _pollId, uint256 _optionId, bytes32 _anonymousId, bytes32 _optionsHash) returns()
func (_VoteVerifier *VoteVerifierTransactorSession) RecordAnonymousVote(_pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordAnonymousVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _anonymousId, _optionsHash)
}

// RecordVote is a paid mutator transaction binding the contract method 0xe79ceda2.
//
// Solidity: function recordVote(uint256 _pollId, uint256 _optionId, bytes32 _optionsHash, address _voter) returns()
func (_VoteVerifier *VoteVerifierTransactor) RecordVote(opts *bind.TransactOpts, _pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "recordVote", _pollId, _optionId, _optionsHash, _voter)
}

// RecordVote is a paid mutator transaction binding the contract method 0xe79ceda2.
//
// Solidity: function recordVote(uint256 _pollId, uint256 _optionId, bytes32 _optionsHash, address _voter) returns()
func (_VoteVerifier *VoteVerifierSession) RecordVote(_pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _optionsHash, _voter)
}

// RecordVote is a paid mutator transaction binding the contract method 0xe79ceda2.
//
// Solidity: function recordVote(uint256 _pollId, uint256 _optionId, bytes32 _optionsHash, address _voter) returns()
func (_VoteVerifier *VoteVerifierTransactorSession) RecordVote(_pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _optionsHash, _voter)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_VoteVerifier *VoteVerifierTransactor) RenounceOwnership(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "renounceOwnership")
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_VoteVerifier *VoteVerifierSession) RenounceOwnership() (*types.Transaction, error) {
	return _VoteVerifier.Contract.RenounceOwnership(&_VoteVerifier.TransactOpts)
}

// RenounceOwnership is a paid mutator transaction binding the contract method 0x715018a6.
//
// Solidity: function renounceOwnership() returns()
func (_VoteVerifier *VoteVerifierTransactorSession) RenounceOwnership() (*types.Transaction, error) {
	return _VoteVerifier.Contract.RenounceOwnership(&_VoteVerifier.TransactOpts)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_VoteVerifier *VoteVerifierTransactor) TransferOwnership(opts *bind.TransactOpts, newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "transferOwnership", newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_VoteVerifier *VoteVerifierSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.TransferOwnership(&_VoteVerifier.TransactOpts, newOwner)
}

// TransferOwnership is a paid mutator transaction binding the contract method 0xf2fde38b.
//
// Solidity: function transferOwnership(address newOwner) returns()
func (_VoteVerifier *VoteVerifierTransactorSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.TransferOwnership(&_VoteVerifier.TransactOpts, newOwner)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_VoteVerifier *VoteVerifierTransactor) Unpause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "unpause")
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_VoteVerifier *VoteVerifierSession) Unpause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Unpause(&_VoteVerifier.TransactOpts)
}

// Unpause is a paid mutator transaction binding the contract method 0x3f4ba83a.
//
// Solidity: function unpause() returns()
func (_VoteVerifier *VoteVerifierTransactorSession) Unpause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Unpause(&_VoteVerifier.TransactOpts)
}

// UpdateAuthorizedService is a paid mutator transaction binding the contract method 0x63ae6aa3.
//
// Solidity: function updateAuthorizedService(address _newAuthorizedService) returns()
func (_VoteVerifier *VoteVerifierTransactor) UpdateAuthorizedService(opts *bind.TransactOpts, _newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "updateAuthorizedService", _newAuthorizedService)
}

// UpdateAuthorizedService is a paid mutator transaction binding the contract method 0x63ae6aa3.
//
// Solidity: function updateAuthorizedService(address _newAuthorizedService) returns()
func (_VoteVerifier *VoteVerifierSession) UpdateAuthorizedService(_newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdateAuthorizedService(&_VoteVerifier.TransactOpts, _newAuthorizedService)
}

// UpdateAuthorizedService is a paid mutator transaction binding the contract method 0x63ae6aa3.
//
// Solidity: function updateAuthorizedService(address _newAuthorizedService) returns()
func (_VoteVerifier *VoteVerifierTransactorSession) UpdateAuthorizedService(_newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdateAuthorizedService(&_VoteVerifier.TransactOpts, _newAuthorizedService)
}

// UpdatePollRegistry is a paid mutator transaction binding the contract method 0xbaf452bf.
//
// Solidity: function updatePollRegistry(address _newPollRegistry) returns()
func (_VoteVerifier *VoteVerifierTransactor) UpdatePollRegistry(opts *bind.TransactOpts, _newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "updatePollRegistry", _newPollRegistry)
}

// UpdatePollRegistry is a paid mutator transaction binding the contract method 0xbaf452bf.
//
// Solidity: function updatePollRegistry(address _newPollRegistry) returns()
func (_VoteVerifier *VoteVerifierSession) UpdatePollRegistry(_newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdatePollRegistry(&_VoteVerifier.TransactOpts, _newPollRegistry)
}

// UpdatePollRegistry is a paid mutator transaction binding the contract method 0xbaf452bf.
//
// Solidity: function updatePollRegistry(address _newPollRegistry) returns()
func (_VoteVerifier *VoteVerifierTransactorSession) UpdatePollRegistry(_newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdatePollRegistry(&_VoteVerifier.TransactOpts, _newPollRegistry)
}

// VoteVerifierAnonymousVoteRecordedIterator is returned from FilterAnonymousVoteRecorded and is used to iterate over the raw logs and unpacked data for AnonymousVoteRecorded events raised by the VoteVerifier contract.
type VoteVerifierAnonymousVoteRecordedIterator struct {
	Event *VoteVerifierAnonymousVoteRecorded // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierAnonymousVoteRecordedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierAnonymousVoteRecorded)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierAnonymousVoteRecorded)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierAnonymousVoteRecordedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierAnonymousVoteRecordedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierAnonymousVoteRecorded represents a AnonymousVoteRecorded event raised by the VoteVerifier contract.
type VoteVerifierAnonymousVoteRecorded struct {
	PollId      *big.Int
	AnonymousId [32]byte
	OptionId    *big.Int
	VoteHash    [32]byte
	Timestamp   *big.Int
	Raw         types.Log // Blockchain specific contextual infos
}

// FilterAnonymousVoteRecorded is a free log retrieval operation binding the contract event 0x72bc177e47280ce2624483cbe59db3811295315102eae949256fc1ccbad53680.
//
// Solidity: event AnonymousVoteRecorded(uint256 indexed pollId, bytes32 indexed anonymousId, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) FilterAnonymousVoteRecorded(opts *bind.FilterOpts, pollId []*big.Int, anonymousId [][32]byte, optionId []*big.Int) (*VoteVerifierAnonymousVoteRecordedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var anonymousIdRule []interface{}
	for _, anonymousIdItem := range anonymousId {
		anonymousIdRule = append(anonymousIdRule, anonymousIdItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "AnonymousVoteRecorded", pollIdRule, anonymousIdRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierAnonymousVoteRecordedIterator{contract: _VoteVerifier.contract, event: "AnonymousVoteRecorded", logs: logs, sub: sub}, nil
}

// WatchAnonymousVoteRecorded is a free log subscription operation binding the contract event 0x72bc177e47280ce2624483cbe59db3811295315102eae949256fc1ccbad53680.
//
// Solidity: event AnonymousVoteRecorded(uint256 indexed pollId, bytes32 indexed anonymousId, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) WatchAnonymousVoteRecorded(opts *bind.WatchOpts, sink chan<- *VoteVerifierAnonymousVoteRecorded, pollId []*big.Int, anonymousId [][32]byte, optionId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var anonymousIdRule []interface{}
	for _, anonymousIdItem := range anonymousId {
		anonymousIdRule = append(anonymousIdRule, anonymousIdItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "AnonymousVoteRecorded", pollIdRule, anonymousIdRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierAnonymousVoteRecorded)
				if err := _VoteVerifier.contract.UnpackLog(event, "AnonymousVoteRecorded", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseAnonymousVoteRecorded is a log parse operation binding the contract event 0x72bc177e47280ce2624483cbe59db3811295315102eae949256fc1ccbad53680.
//
// Solidity: event AnonymousVoteRecorded(uint256 indexed pollId, bytes32 indexed anonymousId, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) ParseAnonymousVoteRecorded(log types.Log) (*VoteVerifierAnonymousVoteRecorded, error) {
	event := new(VoteVerifierAnonymousVoteRecorded)
	if err := _VoteVerifier.contract.UnpackLog(event, "AnonymousVoteRecorded", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// VoteVerifierAuthorizedServiceUpdatedIterator is returned from FilterAuthorizedServiceUpdated and is used to iterate over the raw logs and unpacked data for AuthorizedServiceUpdated events raised by the VoteVerifier contract.
type VoteVerifierAuthorizedServiceUpdatedIterator struct {
	Event *VoteVerifierAuthorizedServiceUpdated // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierAuthorizedServiceUpdated)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierAuthorizedServiceUpdated)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierAuthorizedServiceUpdated represents a AuthorizedServiceUpdated event raised by the VoteVerifier contract.
type VoteVerifierAuthorizedServiceUpdated struct {
	OldService common.Address
	NewService common.Address
	Raw        types.Log // Blockchain specific contextual infos
}

// FilterAuthorizedServiceUpdated is a free log retrieval operation binding the contract event 0x7a0eb7473758ed3c0b89cb21d14f8f5a9e53bb9065c390671c9f94f9743cb1a6.
//
// Solidity: event AuthorizedServiceUpdated(address oldService, address newService)
func (_VoteVerifier *VoteVerifierFilterer) FilterAuthorizedServiceUpdated(opts *bind.FilterOpts) (*VoteVerifierAuthorizedServiceUpdatedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "AuthorizedServiceUpdated")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierAuthorizedServiceUpdatedIterator{contract: _VoteVerifier.contract, event: "AuthorizedServiceUpdated", logs: logs, sub: sub}, nil
}

// WatchAuthorizedServiceUpdated is a free log subscription operation binding the contract event 0x7a0eb7473758ed3c0b89cb21d14f8f5a9e53bb9065c390671c9f94f9743cb1a6.
//
// Solidity: event AuthorizedServiceUpdated(address oldService, address newService)
func (_VoteVerifier *VoteVerifierFilterer) WatchAuthorizedServiceUpdated(opts *bind.WatchOpts, sink chan<- *VoteVerifierAuthorizedServiceUpdated) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "AuthorizedServiceUpdated")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierAuthorizedServiceUpdated)
				if err := _VoteVerifier.contract.UnpackLog(event, "AuthorizedServiceUpdated", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseAuthorizedServiceUpdated is a log parse operation binding the contract event 0x7a0eb7473758ed3c0b89cb21d14f8f5a9e53bb9065c390671c9f94f9743cb1a6.
//
// Solidity: event AuthorizedServiceUpdated(address oldService, address newService)
func (_VoteVerifier *VoteVerifierFilterer) ParseAuthorizedServiceUpdated(log types.Log) (*VoteVerifierAuthorizedServiceUpdated, error) {
	event := new(VoteVerifierAuthorizedServiceUpdated)
	if err := _VoteVerifier.contract.UnpackLog(event, "AuthorizedServiceUpdated", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// VoteVerifierOwnershipTransferredIterator is returned from FilterOwnershipTransferred and is used to iterate over the raw logs and unpacked data for OwnershipTransferred events raised by the VoteVerifier contract.
type VoteVerifierOwnershipTransferredIterator struct {
	Event *VoteVerifierOwnershipTransferred // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierOwnershipTransferredIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierOwnershipTransferred)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierOwnershipTransferred)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierOwnershipTransferredIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierOwnershipTransferredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierOwnershipTransferred represents a OwnershipTransferred event raised by the VoteVerifier contract.
type VoteVerifierOwnershipTransferred struct {
	PreviousOwner common.Address
	NewOwner      common.Address
	Raw           types.Log // Blockchain specific contextual infos
}

// FilterOwnershipTransferred is a free log retrieval operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_VoteVerifier *VoteVerifierFilterer) FilterOwnershipTransferred(opts *bind.FilterOpts, previousOwner []common.Address, newOwner []common.Address) (*VoteVerifierOwnershipTransferredIterator, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierOwnershipTransferredIterator{contract: _VoteVerifier.contract, event: "OwnershipTransferred", logs: logs, sub: sub}, nil
}

// WatchOwnershipTransferred is a free log subscription operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_VoteVerifier *VoteVerifierFilterer) WatchOwnershipTransferred(opts *bind.WatchOpts, sink chan<- *VoteVerifierOwnershipTransferred, previousOwner []common.Address, newOwner []common.Address) (event.Subscription, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierOwnershipTransferred)
				if err := _VoteVerifier.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseOwnershipTransferred is a log parse operation binding the contract event 0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0.
//
// Solidity: event OwnershipTransferred(address indexed previousOwner, address indexed newOwner)
func (_VoteVerifier *VoteVerifierFilterer) ParseOwnershipTransferred(log types.Log) (*VoteVerifierOwnershipTransferred, error) {
	event := new(VoteVerifierOwnershipTransferred)
	if err := _VoteVerifier.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// VoteVerifierPausedIterator is returned from FilterPaused and is used to iterate over the raw logs and unpacked data for Paused events raised by the VoteVerifier contract.
type VoteVerifierPausedIterator struct {
	Event *VoteVerifierPaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierPausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierPaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierPaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierPausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierPausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierPaused represents a Paused event raised by the VoteVerifier contract.
type VoteVerifierPaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterPaused is a free log retrieval operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_VoteVerifier *VoteVerifierFilterer) FilterPaused(opts *bind.FilterOpts) (*VoteVerifierPausedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierPausedIterator{contract: _VoteVerifier.contract, event: "Paused", logs: logs, sub: sub}, nil
}

// WatchPaused is a free log subscription operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_VoteVerifier *VoteVerifierFilterer) WatchPaused(opts *bind.WatchOpts, sink chan<- *VoteVerifierPaused) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierPaused)
				if err := _VoteVerifier.contract.UnpackLog(event, "Paused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParsePaused is a log parse operation binding the contract event 0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258.
//
// Solidity: event Paused(address account)
func (_VoteVerifier *VoteVerifierFilterer) ParsePaused(log types.Log) (*VoteVerifierPaused, error) {
	event := new(VoteVerifierPaused)
	if err := _VoteVerifier.contract.UnpackLog(event, "Paused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// VoteVerifierUnpausedIterator is returned from FilterUnpaused and is used to iterate over the raw logs and unpacked data for Unpaused events raised by the VoteVerifier contract.
type VoteVerifierUnpausedIterator struct {
	Event *VoteVerifierUnpaused // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierUnpausedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierUnpaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierUnpaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierUnpausedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierUnpausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierUnpaused represents a Unpaused event raised by the VoteVerifier contract.
type VoteVerifierUnpaused struct {
	Account common.Address
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterUnpaused is a free log retrieval operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_VoteVerifier *VoteVerifierFilterer) FilterUnpaused(opts *bind.FilterOpts) (*VoteVerifierUnpausedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierUnpausedIterator{contract: _VoteVerifier.contract, event: "Unpaused", logs: logs, sub: sub}, nil
}

// WatchUnpaused is a free log subscription operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_VoteVerifier *VoteVerifierFilterer) WatchUnpaused(opts *bind.WatchOpts, sink chan<- *VoteVerifierUnpaused) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierUnpaused)
				if err := _VoteVerifier.contract.UnpackLog(event, "Unpaused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseUnpaused is a log parse operation binding the contract event 0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa.
//
// Solidity: event Unpaused(address account)
func (_VoteVerifier *VoteVerifierFilterer) ParseUnpaused(log types.Log) (*VoteVerifierUnpaused, error) {
	event := new(VoteVerifierUnpaused)
	if err := _VoteVerifier.contract.UnpackLog(event, "Unpaused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// VoteVerifierVoteRecordedIterator is returned from FilterVoteRecorded and is used to iterate over the raw logs and unpacked data for VoteRecorded events raised by the VoteVerifier contract.
type VoteVerifierVoteRecordedIterator struct {
	Event *VoteVerifierVoteRecorded // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *VoteVerifierVoteRecordedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierVoteRecorded)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierVoteRecorded)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *VoteVerifierVoteRecordedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *VoteVerifierVoteRecordedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// VoteVerifierVoteRecorded represents a VoteRecorded event raised by the VoteVerifier contract.
type VoteVerifierVoteRecorded struct {
	PollId    *big.Int
	Voter     common.Address
	OptionId  *big.Int
	VoteHash  [32]byte
	Timestamp *big.Int
	Raw       types.Log // Blockchain specific contextual infos
}

// FilterVoteRecorded is a free log retrieval operation binding the contract event 0xb3c857ef5f54769ec2c6081a529c133a4f3be2e35d7788ddbd8ddfb4d887ded7.
//
// Solidity: event VoteRecorded(uint256 indexed pollId, address indexed voter, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) FilterVoteRecorded(opts *bind.FilterOpts, pollId []*big.Int, voter []common.Address, optionId []*big.Int) (*VoteVerifierVoteRecordedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var voterRule []interface{}
	for _, voterItem := range voter {
		voterRule = append(voterRule, voterItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "VoteRecorded", pollIdRule, voterRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierVoteRecordedIterator{contract: _VoteVerifier.contract, event: "VoteRecorded", logs: logs, sub: sub}, nil
}

// WatchVoteRecorded is a free log subscription operation binding the contract event 0xb3c857ef5f54769ec2c6081a529c133a4f3be2e35d7788ddbd8ddfb4d887ded7.
//
// Solidity: event VoteRecorded(uint256 indexed pollId, address indexed voter, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) WatchVoteRecorded(opts *bind.WatchOpts, sink chan<- *VoteVerifierVoteRecorded, pollId []*big.Int, voter []common.Address, optionId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var voterRule []interface{}
	for _, voterItem := range voter {
		voterRule = append(voterRule, voterItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "VoteRecorded", pollIdRule, voterRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(VoteVerifierVoteRecorded)
				if err := _VoteVerifier.contract.UnpackLog(event, "VoteRecorded", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseVoteRecorded is a log parse operation binding the contract event 0xb3c857ef5f54769ec2c6081a529c133a4f3be2e35d7788ddbd8ddfb4d887ded7.
//
// Solidity: event VoteRecorded(uint256 indexed pollId, address indexed voter, uint256 indexed optionId, bytes32 voteHash, uint256 timestamp)
func (_VoteVerifier *VoteVerifierFilterer) ParseVoteRecorded(log types.Log) (*VoteVerifierVoteRecorded, error) {
	event := new(VoteVerifierVoteRecorded)
	if err := _VoteVerifier.contract.UnpackLog(event, "VoteRecorded", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
