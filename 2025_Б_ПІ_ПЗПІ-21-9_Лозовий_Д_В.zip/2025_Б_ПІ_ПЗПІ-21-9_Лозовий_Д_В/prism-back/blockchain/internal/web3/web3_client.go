package web3

import (
	"blockchain-service/internal/utils"
	"context"
	"crypto/ecdsa"
	"fmt"
	"math/big"
	"strings"
	"time"

	"go.uber.org/zap"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"

	"blockchain-service/internal/config"
)

type Web3Client struct {
	client     *ethclient.Client
	privateKey *ecdsa.PrivateKey
	address    common.Address
	chainID    *big.Int
	cfg        *config.BlockchainConfig
}

type TransactionReceipt struct {
	TxHash      common.Hash
	BlockNumber uint64
	GasUsed     uint64
	Status      uint64
	Error       string
}

type NetworkInfo struct {
	ChainID     *big.Int
	BlockNumber uint64
	GasPrice    *big.Int
	NetworkName string
}

func NewWeb3Client(cfg *config.BlockchainConfig) (*Web3Client, error) {

	client, err := ethclient.Dial(cfg.RpcURL)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to ethereum client: %w", err)
	}

	privateKey, err := parsePrivateKey(cfg.PrivateKey)
	if err != nil {
		return nil, fmt.Errorf("failed to parse private key: %w", err)
	}

	address := crypto.PubkeyToAddress(privateKey.PublicKey)

	chainID := big.NewInt(cfg.ChainID)

	web3Client := &Web3Client{
		client:     client,
		privateKey: privateKey,
		address:    address,
		chainID:    chainID,
		cfg:        cfg,
	}

	if err := web3Client.validateConnection(context.Background()); err != nil {
		return nil, fmt.Errorf("failed to validate connection: %w", err)
	}

	return web3Client, nil
}

func parsePrivateKey(privateKeyHex string) (*ecdsa.PrivateKey, error) {

	privateKeyHex = strings.TrimPrefix(privateKeyHex, "0x")

	if len(privateKeyHex) != 64 {
		return nil, fmt.Errorf("invalid private key length: expected 64 characters, got %d", len(privateKeyHex))
	}

	privateKey, err := crypto.HexToECDSA(privateKeyHex)
	if err != nil {
		return nil, fmt.Errorf("failed to parse private key: %w", err)
	}

	return privateKey, nil
}

func (w *Web3Client) validateConnection(ctx context.Context) error {

	networkChainID, err := w.client.NetworkID(ctx)
	if err != nil {
		return fmt.Errorf("failed to get network ID: %w", err)
	}

	if networkChainID.Cmp(w.chainID) != 0 {
		return fmt.Errorf("chain ID mismatch: expected %s, got %s", w.chainID.String(), networkChainID.String())
	}

	_, err = w.client.BlockNumber(ctx)
	if err != nil {
		return fmt.Errorf("failed to get latest block number: %w", err)
	}

	return nil
}

func (w *Web3Client) GetTransactor(ctx context.Context) (*bind.TransactOpts, error) {

	nonce, err := w.client.PendingNonceAt(ctx, w.address)
	if err != nil {
		return nil, fmt.Errorf("failed to get nonce: %w", err)
	}

	gasPrice, err := w.getGasPrice(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get gas price: %w", err)
	}

	auth, err := bind.NewKeyedTransactorWithChainID(w.privateKey, w.chainID)
	if err != nil {
		return nil, fmt.Errorf("failed to create transactor: %w", err)
	}

	auth.Nonce = big.NewInt(int64(nonce))
	auth.Value = big.NewInt(0)
	auth.GasLimit = w.cfg.GasLimit
	auth.GasPrice = gasPrice
	auth.Context = ctx

	return auth, nil
}

func (w *Web3Client) getGasPrice(ctx context.Context) (*big.Int, error) {

	if w.cfg.GasPrice > 0 {
		return big.NewInt(w.cfg.GasPrice), nil
	}

	gasPrice, err := w.client.SuggestGasPrice(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to suggest gas price: %w", err)
	}

	if w.cfg.ChainID == 31337 {

		return big.NewInt(20000000000), nil
	}

	return gasPrice, nil
}

func (w *Web3Client) WaitForTransaction(ctx context.Context, txHash common.Hash) (*TransactionReceipt, error) {

	timeoutCtx, cancel := context.WithTimeout(ctx, w.cfg.TransactionTimeout)
	defer cancel()

	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-timeoutCtx.Done():
			return nil, fmt.Errorf("transaction %s confirmation timeout after %v", txHash.Hex(), w.cfg.TransactionTimeout)

		case <-ticker.C:
			receipt, err := w.client.TransactionReceipt(timeoutCtx, txHash)
			if err != nil {
				if strings.Contains(err.Error(), "not found") {

					continue
				}
				return nil, fmt.Errorf("failed to get transaction receipt: %w", err)
			}

			currentBlock, err := w.client.BlockNumber(timeoutCtx)
			if err != nil {
				return nil, fmt.Errorf("failed to get current block number: %w", err)
			}

			confirmations := currentBlock - receipt.BlockNumber.Uint64()
			if confirmations < w.cfg.ConfirmationBlocks {
				continue
			}

			result := &TransactionReceipt{
				TxHash:      txHash,
				BlockNumber: receipt.BlockNumber.Uint64(),
				GasUsed:     receipt.GasUsed,
				Status:      receipt.Status,
			}

			if receipt.Status == 0 {
				result.Error = "transaction failed (status = 0)"
			}

			return result, nil
		}
	}
}

func (w *Web3Client) EstimateGas(ctx context.Context, to *common.Address, data []byte) (uint64, error) {
	msg := ethereum.CallMsg{
		From: w.address,
		To:   to,
		Data: data,
	}

	gasLimit, err := w.client.EstimateGas(ctx, msg)
	if err != nil {
		return 0, fmt.Errorf("failed to estimate gas: %w", err)
	}

	gasLimitWithBuffer := gasLimit * 120 / 100

	if gasLimitWithBuffer > w.cfg.GasLimit {
		gasLimitWithBuffer = w.cfg.GasLimit
	}

	return gasLimitWithBuffer, nil
}

func (w *Web3Client) GetBalance(ctx context.Context, address common.Address) (*big.Int, error) {
	balance, err := w.client.BalanceAt(ctx, address, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to get balance: %w", err)
	}
	return balance, nil
}

func (w *Web3Client) GetBlockNumber(ctx context.Context) (uint64, error) {
	blockNumber, err := w.client.BlockNumber(ctx)
	if err != nil {
		return 0, fmt.Errorf("failed to get block number: %w", err)
	}
	return blockNumber, nil
}

func (w *Web3Client) GetNetworkInfo(ctx context.Context) (*NetworkInfo, error) {

	chainID, err := w.client.NetworkID(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get chain ID: %w", err)
	}

	blockNumber, err := w.client.BlockNumber(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get block number: %w", err)
	}

	gasPrice, err := w.client.SuggestGasPrice(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get gas price: %w", err)
	}

	networkName := getNetworkName(chainID.Int64())

	return &NetworkInfo{
		ChainID:     chainID,
		BlockNumber: blockNumber,
		GasPrice:    gasPrice,
		NetworkName: networkName,
	}, nil
}

func getNetworkName(chainID int64) string {
	switch chainID {
	case 1:
		return "Ethereum Mainnet"
	case 137:
		return "Polygon Mainnet"
	case 80001:
		return "Polygon Mumbai"
	case 31337:
		return "Hardhat Local"
	default:
		return fmt.Sprintf("Unknown Network (Chain ID: %d)", chainID)
	}
}

func (w *Web3Client) GetClient() *ethclient.Client {
	return w.client
}

func (w *Web3Client) GetAddress() common.Address {
	return w.address
}

func (w *Web3Client) GetChainID() *big.Int {
	return w.chainID
}

func (w *Web3Client) Health(ctx context.Context) map[string]interface{} {
	result := map[string]interface{}{
		"connected": false,
		"address":   w.address.Hex(),
		"chain_id":  w.chainID.Int64(),
	}

	if err := w.validateConnection(ctx); err != nil {
		result["error"] = err.Error()
		return result
	}

	result["connected"] = true

	if networkInfo, err := w.GetNetworkInfo(ctx); err == nil {
		result["network_name"] = networkInfo.NetworkName
		result["block_number"] = networkInfo.BlockNumber
		result["gas_price"] = networkInfo.GasPrice.String()
	}

	if balance, err := w.GetBalance(ctx, w.address); err == nil {
		result["balance_wei"] = balance.String()

		balanceEth := new(big.Float).Quo(new(big.Float).SetInt(balance), big.NewFloat(1e18))
		result["balance_eth"] = balanceEth.String()
	}

	return result
}

func (w *Web3Client) Close() {
	if w.client != nil {
		w.client.Close()
	}
}

func (w *Web3Client) SendTransaction(ctx context.Context, tx *types.Transaction) error {
	err := w.client.SendTransaction(ctx, tx)
	if err != nil {
		return fmt.Errorf("failed to send transaction: %w", err)
	}
	return nil
}

func (w *Web3Client) GetTransactionByHash(ctx context.Context, hash common.Hash) (*types.Transaction, bool, error) {
	blockNumber, err := w.client.BlockNumber(ctx)
	if err != nil {
		utils.Debug(ctx, "Error getting block number", zap.Error(err))
	}
	utils.Info(ctx, "Current block", zap.Uint64("block", blockNumber))

	tx, isPending, err := w.client.TransactionByHash(ctx, hash)
	if err != nil {
		return nil, false, fmt.Errorf("failed to get transaction: %w", err)
	}
	return tx, isPending, nil
}

func (w *Web3Client) GetNonce(ctx context.Context, address common.Address) (uint64, error) {
	nonce, err := w.client.PendingNonceAt(ctx, address)
	if err != nil {
		return 0, fmt.Errorf("failed to get nonce: %w", err)
	}
	return nonce, nil
}
