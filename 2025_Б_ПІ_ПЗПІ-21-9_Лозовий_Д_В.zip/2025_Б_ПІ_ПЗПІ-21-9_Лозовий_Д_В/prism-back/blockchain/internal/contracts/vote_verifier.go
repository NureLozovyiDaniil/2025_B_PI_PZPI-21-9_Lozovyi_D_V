package contracts

import (
	"context"
	"fmt"
	"math/big"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"

	"blockchain-service/internal/utils"
	"blockchain-service/internal/web3"

	"blockchain-service/internal/bindings/contracts"
)

type VoteVerifierManager struct {
	web3Client      *web3.Web3Client
	contractAddress common.Address

	contract *contracts.VoteVerifier
}

type RecordVoteRequest struct {
	PollID      uint
	OptionID    uint
	VoterAddr   common.Address
	OptionsHash string
}

type RecordAnonymousVoteRequest struct {
	PollID      uint
	OptionID    uint
	AnonymousID common.Hash
	OptionsHash string
}

type Vote struct {
	PollID    *big.Int
	OptionID  *big.Int
	Voter     common.Address
	Timestamp *big.Int
	VoteHash  [32]byte
}

func NewVoteVerifierManager(web3Client *web3.Web3Client, contractAddress string) (*VoteVerifierManager, error) {
	if !utils.ValidateEthereumAddress(contractAddress) {
		return nil, fmt.Errorf("invalid contract address: %s", contractAddress)
	}

	addr := common.HexToAddress(contractAddress)

	contract, err := contracts.NewVoteVerifier(addr, web3Client.GetClient())
	if err != nil {
		return nil, fmt.Errorf("failed to instantiate VoteVerifier contract: %w", err)
	}

	return &VoteVerifierManager{
		web3Client:      web3Client,
		contractAddress: addr,
		contract:        contract,
	}, nil
}

func (v *VoteVerifierManager) RecordVote(ctx context.Context, req RecordVoteRequest) (string, error) {
	//utils.Debug(ctx, "Recording vote in blockchain",
	//	map[string]interface{}{
	//		"poll_id":   req.PollID,
	//		"option_id": req.OptionID,
	//		"voter":     req.VoterAddr.Hex(),
	//	})

	if err := v.validateRecordVoteRequest(req); err != nil {
		return "", fmt.Errorf("validation failed: %w", err)
	}

	optionsHash, err := v.parseOptionsHash(req.OptionsHash)
	if err != nil {
		return "", fmt.Errorf("invalid options hash: %w", err)
	}

	auth, err := v.web3Client.GetTransactor(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	pollID := big.NewInt(int64(req.PollID))
	optionID := big.NewInt(int64(req.OptionID))

	tx, err := v.contract.RecordVote(auth, pollID, optionID, optionsHash, req.VoterAddr)
	if err != nil {
		return "", fmt.Errorf("failed to record vote: %w", err)
	}

	utils.LogTransactionSent(ctx, tx.Hash().Hex(), "record_vote",
		auth.GasLimit, auth.GasPrice.Int64())

	return tx.Hash().Hex(), nil

}

func (vm *VoteVerifierManager) RecordAnonymousVote(
	ctx context.Context,
	req RecordAnonymousVoteRequest,
) (string, error) {

	auth, err := vm.web3Client.GetTransactor(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	optionsHash := common.HexToHash(req.OptionsHash)

	tx, err := vm.contract.RecordAnonymousVote(
		auth,
		big.NewInt(int64(req.PollID)),
		big.NewInt(int64(req.OptionID)),
		req.AnonymousID,
		optionsHash,
	)
	if err != nil {
		return "", fmt.Errorf("failed to call recordAnonymousVote: %w", err)
	}

	return tx.Hash().Hex(), nil
}

func (v *VoteVerifierManager) HasUserVoted(ctx context.Context, pollID uint, voterAddr common.Address) (bool, error) {
	if pollID == 0 {
		return false, fmt.Errorf("poll ID cannot be zero")
	}

	if utils.IsZeroAddress(voterAddr) {
		return false, fmt.Errorf("voter address cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	hasVoted, err := v.contract.HasUserVoted(callOpts, pollIDBig, voterAddr)
	if err != nil {
		return false, fmt.Errorf("failed to check if user voted: %w. User addr: %s", err, voterAddr.Hex())
	}

	//utils.Debug(ctx, "Checked user vote status",
	//	map[string]interface{}{
	//		"poll_id":   pollID,
	//		"voter":     voterAddr.Hex(),
	//		"has_voted": hasVoted,
	//	})

	return hasVoted, nil

}

func (vm *VoteVerifierManager) HasAnonymousIdVoted(
	ctx context.Context,
	pollID uint,
	anonymousID common.Hash,
) (bool, error) {

	opts := &bind.CallOpts{Context: ctx}

	hasVoted, err := vm.contract.HasAnonymousIdVoted(opts, big.NewInt(int64(pollID)), anonymousID)
	if err != nil {
		return false, fmt.Errorf("failed to check anonymous ID voted status: %w", err)
	}

	return hasVoted, nil
}

func (v *VoteVerifierManager) GetUserChoice(ctx context.Context, pollID uint, voterAddr common.Address) (uint, error) {
	if pollID == 0 {
		return 0, fmt.Errorf("poll ID cannot be zero")
	}

	if utils.IsZeroAddress(voterAddr) {
		return 0, fmt.Errorf("voter address cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	optionID, err := v.contract.GetUserChoice(callOpts, pollIDBig, voterAddr)
	if err != nil {
		return 0, fmt.Errorf("failed to get user choice: %w", err)
	}

	return uint(optionID.Uint64()), nil

}

func (v *VoteVerifierManager) GetPollVoteCount(ctx context.Context, pollID uint) (uint, error) {
	if pollID == 0 {
		return 0, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	voteCount, err := v.contract.GetPollVoteCount(callOpts, pollIDBig)
	if err != nil {
		return 0, fmt.Errorf("failed to get poll vote count: %w", err)
	}

	//utils.Debug(ctx, "Retrieved poll vote count",
	//	map[string]interface{}{
	//		"poll_id":    pollID,
	//		"vote_count": voteCount.Uint64(),
	//	})

	return uint(voteCount.Uint64()), nil

}

func (v *VoteVerifierManager) GetOptionVoteCount(ctx context.Context, pollID, optionID uint) (uint, error) {
	if pollID == 0 {
		return 0, fmt.Errorf("poll ID cannot be zero")
	}

	if optionID == 0 {
		return 0, fmt.Errorf("option ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))
	optionIDBig := big.NewInt(int64(optionID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	voteCount, err := v.contract.GetOptionVoteCount(callOpts, pollIDBig, optionIDBig)
	if err != nil {
		return 0, fmt.Errorf("failed to get option vote count: %w", err)
	}

	return uint(voteCount.Uint64()), nil

}

func (v *VoteVerifierManager) GetPollResults(ctx context.Context, pollID uint, maxOptions uint) ([]uint, error) {
	if pollID == 0 {
		return nil, fmt.Errorf("poll ID cannot be zero")
	}

	if maxOptions == 0 || maxOptions > 20 {
		return nil, fmt.Errorf("max options must be between 1 and 20")
	}

	pollIDBig := big.NewInt(int64(pollID))
	maxOptionsBig := big.NewInt(int64(maxOptions))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	results, err := v.contract.GetPollResults(callOpts, pollIDBig, maxOptionsBig)
	if err != nil {
		return nil, fmt.Errorf("failed to get poll results: %w", err)
	}

	resultUints := make([]uint, len(results))
	for i, result := range results {
		resultUints[i] = uint(result.Uint64())
	}

	utils.LogPollOperation(ctx, pollID, "get_poll_results", map[string]interface{}{
		"max_options": maxOptions,
		"results":     resultUints,
	})

	return resultUints, nil

}

func (v *VoteVerifierManager) GetVoteByHash(ctx context.Context, voteHash [32]byte) (*Vote, error) {
	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	voteData, err := v.contract.GetVoteByHash(callOpts, voteHash)
	if err != nil {
		return nil, fmt.Errorf("failed to get vote by hash: %w", err)
	}

	vote := &Vote{
		PollID:    voteData.PollId,
		OptionID:  voteData.OptionId,
		Voter:     voteData.Voter,
		Timestamp: voteData.Timestamp,
		VoteHash:  voteData.VoteHash,
	}

	return vote, nil

}

func (v *VoteVerifierManager) validateRecordVoteRequest(req RecordVoteRequest) error {
	if req.PollID == 0 {
		return fmt.Errorf("poll ID cannot be zero")
	}

	if req.OptionID == 0 {
		return fmt.Errorf("option ID cannot be zero")
	}

	if utils.IsZeroAddress(req.VoterAddr) {
		return fmt.Errorf("voter address cannot be zero")
	}

	if len(req.OptionsHash) != 64 {
		return fmt.Errorf("options hash must be exactly 64 characters")
	}

	return nil
}

func (v *VoteVerifierManager) parseOptionsHash(hexStr string) ([32]byte, error) {
	var hash [32]byte

	if len(hexStr) == 66 && hexStr[:2] == "0x" {
		hexStr = hexStr[2:]
	}

	if len(hexStr) != 64 {
		return hash, fmt.Errorf("hash must be exactly 64 hex characters")
	}

	bytes := common.FromHex("0x" + hexStr)
	if len(bytes) != 32 {
		return hash, fmt.Errorf("invalid hex hash")
	}

	copy(hash[:], bytes)
	return hash, nil
}

func (v *VoteVerifierManager) GetContractAddress() common.Address {
	return v.contractAddress
}

func IsVoteHashValid(voteHash [32]byte) bool {

	emptyHash := [32]byte{}
	return voteHash != emptyHash
}
