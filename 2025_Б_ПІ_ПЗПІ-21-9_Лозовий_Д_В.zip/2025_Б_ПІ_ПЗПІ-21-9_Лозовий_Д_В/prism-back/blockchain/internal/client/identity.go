package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"

	"blockchain-service/internal/config"
	"blockchain-service/internal/utils"
)

type IdentityClient struct {
	baseURL    string
	httpClient *http.Client
	cfg        *config.IdentityConfig

	cache      map[uint]cachedPublicKey
	cacheMutex sync.RWMutex
}

type cachedPublicKey struct {
	PublicKey string
	ExpiresAt time.Time
}

type UserInfo struct {
	UserID    uint     `json:"user_id"`
	Email     string   `json:"email"`
	PublicKey string   `json:"public_key"`
	IsActive  bool     `json:"is_active"`
	Roles     []string `json:"roles"`
}

type GetUserPublicKeyRequest struct {
	UserID uint `json:"user_id"`
}

type GetUserPublicKeyResponse struct {
	UserID    uint   `json:"user_id"`
	PublicKey string `json:"public_key"`
}

type ValidateUserRequest struct {
	UserID uint `json:"user_id"`
}

type ValidateUserResponse struct {
	UserID   uint     `json:"user_id"`
	Email    string   `json:"email"`
	IsActive bool     `json:"is_active"`
	CanVote  bool     `json:"can_vote"`
	Roles    []string `json:"roles"`
}

type BatchPublicKeysRequest struct {
	UserIDs []uint `json:"user_ids"`
}

type BatchPublicKeysResponse struct {
	PublicKeys map[uint]string `json:"public_keys"` // userID -> publicKey
	NotFound   []uint          `json:"not_found"`
}

type HealthResponse struct {
	Status    string `json:"status"`
	Timestamp string `json:"timestamp"`
	Version   string `json:"version"`
}

func NewIdentityClient(cfg *config.IdentityConfig) *IdentityClient {
	return &IdentityClient{
		baseURL: cfg.BaseURL,
		httpClient: &http.Client{
			Timeout: cfg.Timeout,
		},
		cfg:   cfg,
		cache: make(map[uint]cachedPublicKey),
	}
}

func (c *IdentityClient) GetUserPublicKey(ctx context.Context, userID uint) (string, error) {

	if c.cfg.CacheEnabled {
		if cachedKey := c.getCachedPublicKey(userID); cachedKey != "" {
			return cachedKey, nil
		}
	}

	start := time.Now()

	var publicKey string
	var err error

	for attempt := 1; attempt <= c.cfg.RetryAttempts; attempt++ {
		publicKey, err = c.doGetUserPublicKey(ctx, userID)
		if err == nil {
			break
		}

		if attempt < c.cfg.RetryAttempts {
			select {
			case <-ctx.Done():
				return "", ctx.Err()
			case <-time.After(c.cfg.RetryDelay):

			}
		}
	}

	duration := time.Since(start)

	if err != nil {
		utils.LogIdentityServiceCall(ctx, "/users/public-key", userID, duration, err)
		return "", fmt.Errorf("failed to get user public key after %d attempts: %w", c.cfg.RetryAttempts, err)
	}

	if c.cfg.CacheEnabled {
		c.setCachedPublicKey(userID, publicKey)
	}

	utils.LogIdentityServiceCall(ctx, "/users/public-key", userID, duration, nil)
	return publicKey, nil
}

func (c *IdentityClient) doGetUserPublicKey(ctx context.Context, userID uint) (string, error) {
	url := fmt.Sprintf("%s/internal/user/%d/public-key", c.baseURL, userID)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return "", fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Internal-API-Key", c.cfg.InternalApiKey)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusNotFound {
		return "", fmt.Errorf("user %d not found", userID)
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var response GetUserPublicKeyResponse
	if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
		return "", fmt.Errorf("decoding response: %w", err)
	}

	if err := utils.ValidatePublicKey(response.PublicKey); err != nil {
		return "", fmt.Errorf("invalid public key from identity service: %w", err)
	}

	return response.PublicKey, nil
}

func (c *IdentityClient) ValidateUser(ctx context.Context, userID uint) (*ValidateUserResponse, error) {
	start := time.Now()

	var result *ValidateUserResponse
	var err error

	for attempt := 1; attempt <= c.cfg.RetryAttempts; attempt++ {
		result, err = c.doValidateUser(ctx, userID)
		if err == nil {
			break
		}

		if attempt < c.cfg.RetryAttempts {
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(c.cfg.RetryDelay):

			}
		}
	}

	duration := time.Since(start)
	utils.LogIdentityServiceCall(ctx, "/users/validate", userID, duration, err)

	if err != nil {
		return nil, fmt.Errorf("failed to validate user after %d attempts: %w", c.cfg.RetryAttempts, err)
	}

	return result, nil
}

func (c *IdentityClient) doValidateUser(ctx context.Context, userID uint) (*ValidateUserResponse, error) {
	url := fmt.Sprintf("%s/api/users/%d/validate", c.baseURL, userID)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("user %d not found", userID)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var response ValidateUserResponse
	if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &response, nil
}

func (c *IdentityClient) GetMultiplePublicKeys(ctx context.Context, userIDs []uint) (map[uint]string, error) {
	if len(userIDs) == 0 {
		return make(map[uint]string), nil
	}

	result := make(map[uint]string)
	var uncachedIDs []uint

	if c.cfg.CacheEnabled {
		for _, userID := range userIDs {
			if cachedKey := c.getCachedPublicKey(userID); cachedKey != "" {
				result[userID] = cachedKey
			} else {
				uncachedIDs = append(uncachedIDs, userID)
			}
		}
	} else {
		uncachedIDs = userIDs
	}

	if len(uncachedIDs) == 0 {
		return result, nil
	}

	start := time.Now()

	requestBody := BatchPublicKeysRequest{UserIDs: uncachedIDs}
	bodyBytes, err := json.Marshal(requestBody)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	url := fmt.Sprintf("%s/api/users/public-keys/batch", c.baseURL)

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	duration := time.Since(start)

	if resp.StatusCode != http.StatusOK {
		utils.LogIdentityServiceCall(ctx, "/users/public-keys/batch", 0, duration,
			fmt.Errorf("status code: %d", resp.StatusCode))
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var response BatchPublicKeysResponse
	if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
		utils.LogIdentityServiceCall(ctx, "/users/public-keys/batch", 0, duration, err)
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	for userID, publicKey := range response.PublicKeys {

		if err := utils.ValidatePublicKey(publicKey); err != nil {
			continue
		}

		result[userID] = publicKey

		if c.cfg.CacheEnabled {
			c.setCachedPublicKey(userID, publicKey)
		}
	}

	utils.LogIdentityServiceCall(ctx, "/users/public-keys/batch", 0, duration, nil)

	return result, nil
}

func (c *IdentityClient) Health(ctx context.Context) (*HealthResponse, error) {
	url := fmt.Sprintf("%s/api/health", c.baseURL)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var response HealthResponse
	if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &response, nil
}

func (c *IdentityClient) getCachedPublicKey(userID uint) string {
	c.cacheMutex.RLock()
	defer c.cacheMutex.RUnlock()

	cached, exists := c.cache[userID]
	if !exists || time.Now().After(cached.ExpiresAt) {
		return ""
	}

	return cached.PublicKey
}

func (c *IdentityClient) setCachedPublicKey(userID uint, publicKey string) {
	c.cacheMutex.Lock()
	defer c.cacheMutex.Unlock()

	c.cache[userID] = cachedPublicKey{
		PublicKey: publicKey,
		ExpiresAt: time.Now().Add(c.cfg.CacheTTL),
	}
}

func (c *IdentityClient) ClearCache() {
	c.cacheMutex.Lock()
	defer c.cacheMutex.Unlock()

	c.cache = make(map[uint]cachedPublicKey)
}

func (c *IdentityClient) GetCacheStats() map[string]interface{} {
	c.cacheMutex.RLock()
	defer c.cacheMutex.RUnlock()

	var validEntries, expiredEntries int
	now := time.Now()

	for _, cached := range c.cache {
		if now.After(cached.ExpiresAt) {
			expiredEntries++
		} else {
			validEntries++
		}
	}

	return map[string]interface{}{
		"total_entries":   len(c.cache),
		"valid_entries":   validEntries,
		"expired_entries": expiredEntries,
		"cache_enabled":   c.cfg.CacheEnabled,
		"cache_ttl":       c.cfg.CacheTTL.String(),
	}
}
