from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class CreateUUIDVerificationRequest(BaseModel):
    """Request to create UUID verification session"""
    poll_id: int = Field(..., gt=0)
    verification_type: str = Field(default="mobile_confirmation", max_length=50)
    expires_in_minutes: int = Field(default=10, ge=1, le=60)
    verification_request_uuid: Optional[str] = Field(None, description="Link to existing verification request")


class QRCodeData(BaseModel):
    """QR Code data structure"""
    uuid: str
    type: str = Field(default="verification")
    poll_id: int
    expires_at: datetime
    verification_type: Optional[str] = None
    verification_request_uuid: Optional[str] = None


class DeviceInfo(BaseModel):
    """Device information from mobile app"""
    device_model: str = Field(..., max_length=100)
    os_version: str = Field(..., max_length=50)
    app_version: str = Field(..., max_length=20)
    timestamp: datetime


class ScanQRCodeRequest(BaseModel):
    """Request to scan QR code"""
    device_info: Optional[DeviceInfo] = None


class ConfirmVerificationRequest(BaseModel):
    """Request to confirm verification"""
    notes: Optional[str] = Field(None, max_length=1000)


class UUIDVerificationResponse(BaseModel):
    """UUID Verification Session response"""
    uuid: str
    status: str
    verification_type: str
    created_at: datetime
    expires_at: datetime
    scanned_at: Optional[datetime]
    completed_at: Optional[datetime]
    poll_id: Optional[int]
    user_id: Optional[int]
    trusted_party_id: Optional[int]
    verification_request_uuid: Optional[str]

    class Config:
        from_attributes = True


class UUIDVerificationStatusResponse(BaseModel):
    """Status response for UUID verification"""
    uuid: str
    status: str
    poll_id: Optional[int]
    expires_at: datetime
    time_left_seconds: int
    is_expired: bool