"""
User Verification Service
Handles verification requests for anonymous voting
"""
import logging
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
import hashlib
import base64

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from fastapi import UploadFile, HTTPException

from models.database_models import UserVerificationRequest, VerificationDocument
from models.verification_requests import (
    CreateVerificationRequest, VerificationRequestResponse,
    VerificationRequestSummary, ProcessVerificationRequest,
    VerificationRequestCreated, PendingVerificationRequest,
    PendingVerificationsResponse, VerificationData,
    UserVerificationRequestsResponse, UserVerificationSummary
)
from utils.encryption import encryption_service
from utils.poll_client import get_poll_client, PollNotFoundError
from database import get_session
from config import settings

logger = logging.getLogger(__name__)

# File validation constants
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
ALLOWED_CONTENT_TYPES = ["image/jpeg", "image/png", "image/webp"]
REQUIRED_DOCUMENT_TYPES = ["passport", "selfie"]


class UserVerificationService:
    """Service for handling user verification requests"""

    async def create_verification_request(
            self,
            user_id: int,
            request: CreateVerificationRequest,
            passport_file: UploadFile,
            selfie_file: UploadFile,
            ip_address: Optional[str] = None,
            user_agent: Optional[str] = None
    ) -> VerificationRequestCreated:
        """Create a new verification request with documents"""

        # Validate poll exists and is private
        poll_client = get_poll_client()
        try:
            poll_info = await poll_client.get_poll_info(request.poll_id)
            if not poll_info.get("is_private"):
                raise ValueError("Verification is only required for private polls")
        except PollNotFoundError:
            raise ValueError(f"Poll {request.poll_id} not found")

        # Validate files
        self._validate_uploaded_file(passport_file, "passport")
        self._validate_uploaded_file(selfie_file, "selfie")

        async with get_session() as db:
            # Check for existing pending request
            existing = await self._get_existing_pending_request(db, user_id, request.poll_id)
            if existing:
                raise ValueError("You already have a pending verification request for this poll")

            # Create verification request
            request_uuid = str(uuid.uuid4())
            expires_at = datetime.utcnow() + timedelta(hours=24)

            # Encrypt sensitive data
            encrypted_data = self._encrypt_verification_data(request.verification_data)

            verification_req = UserVerificationRequest(
                request_uuid=request_uuid,
                user_id=user_id,
                poll_id=request.poll_id,
                expires_at=expires_at,
                ip_address=ip_address,
                user_agent=user_agent,
                **encrypted_data
            )

            db.add(verification_req)
            await db.flush()  # Get the ID

            # Save documents
            documents_uploaded = 0
            for file, doc_type in [(passport_file, "passport"), (selfie_file, "selfie")]:
                doc = await self._save_document(file, verification_req.id, doc_type)
                db.add(doc)
                documents_uploaded += 1

            await db.commit()

            logger.info(f"Verification request created: {request_uuid} for user {user_id}")

            return VerificationRequestCreated(
                request_uuid=request_uuid,
                expires_at=expires_at,
                documents_uploaded=documents_uploaded
            )

    async def get_pending_requests_for_trusted_party(
            self,
            trusted_party_id: int,
            poll_id: Optional[int] = None
    ) -> PendingVerificationsResponse:
        """Get pending verification requests for trusted party"""

        async with get_session() as db:
            # Get polls where user is trusted party
            poll_client = get_poll_client()

            if poll_id:
                # Check specific poll
                trusted_parties = await poll_client.get_trusted_parties_for_poll(poll_id)
                valid_polls = [poll_id] if any(tp["user_id"] == trusted_party_id for tp in trusted_parties) else []
            else:
                # This would need a new endpoint in poll client to get all polls for trusted party
                # For now, simplified approach
                valid_polls = []  # Would be populated by poll client

            if not valid_polls:
                return PendingVerificationsResponse(
                    message="No pending verification requests",
                    requests=[],
                    total_count=0,
                    trusted_party_id=trusted_party_id
                )

            # Get pending requests
            query = select(UserVerificationRequest).where(
                and_(
                    UserVerificationRequest.status == "pending",
                    UserVerificationRequest.poll_id.in_(valid_polls),
                    UserVerificationRequest.expires_at > datetime.utcnow()
                )
            ).order_by(UserVerificationRequest.created_at.asc())

            result = await db.execute(query)
            requests = result.scalars().all()

            # Decrypt and format requests
            formatted_requests = []
            for req in requests:
                decrypted_data = self._decrypt_verification_data(req)

                # Count documents
                doc_count_query = select(func.count(VerificationDocument.id)).where(
                    VerificationDocument.verification_request_id == req.id
                )
                doc_count_result = await db.execute(doc_count_query)
                doc_count = doc_count_result.scalar()

                formatted_requests.append(PendingVerificationRequest(
                    request_uuid=req.request_uuid,
                    user_id=req.user_id,
                    poll_id=req.poll_id,
                    full_name=f"{decrypted_data['first_name']} {decrypted_data['last_name']}",
                    document_type=decrypted_data['document_type'],
                    country=decrypted_data['country'],
                    created_at=req.created_at,
                    expires_at=req.expires_at,
                    documents_count=doc_count
                ))

            return PendingVerificationsResponse(
                message=f"Found {len(formatted_requests)} pending requests",
                requests=formatted_requests,
                total_count=len(formatted_requests),
                trusted_party_id=trusted_party_id
            )

    async def get_verification_request_details(
            self,
            request_uuid: str,
            jwt_token: str
    ) -> VerificationRequestResponse:
        """Get full verification request details for trusted party review"""

        async with get_session() as db:
            # Get verification request
            query = select(UserVerificationRequest).where(
                UserVerificationRequest.request_uuid == request_uuid
            )
            result = await db.execute(query)
            req = result.scalar_one_or_none()

            if not req:
                raise ValueError("Verification request not found")

            # Validate JWT token and get user info through Poll Management Service
            poll_client = get_poll_client()
            try:
                # This would be a new method in poll_client that validates JWT
                # and returns user information
                user_info = await poll_client.validate_user_token(jwt_token)
                trusted_party_user_id = user_info.get("user_id")

                if not trusted_party_user_id:
                    raise ValueError("Invalid token: user ID not found")

            except Exception as e:
                logger.error(f"JWT validation failed: {e}")
                raise ValueError("Invalid or expired token")

            # Verify trusted party has access to this poll
            try:
                trusted_parties = await poll_client.get_trusted_parties_for_poll(req.poll_id)
                is_trusted_party = any(tp["user_id"] == trusted_party_user_id for tp in trusted_parties)

                if not is_trusted_party:
                    raise ValueError("Access denied: not a trusted party for this poll")

            except Exception as e:
                logger.error(f"Failed to verify trusted party access: {e}")
                raise ValueError("Failed to verify access permissions")

            # Get documents
            doc_query = select(VerificationDocument).where(
                VerificationDocument.verification_request_id == req.id
            )
            doc_result = await db.execute(doc_query)
            documents = doc_result.scalars().all()

            # Decrypt verification data
            decrypted_data = self._decrypt_verification_data(req)

            # Decrypt and format documents
            formatted_docs = []
            for doc in documents:
                # Decrypt file content
                decrypted_content = encryption_service.decrypt_file_content(doc.content_base64)

                formatted_docs.append({
                    "document_type": doc.document_type,
                    "original_filename": doc.original_filename,
                    "content_type": doc.content_type,
                    "file_size": doc.file_size,
                    "uploaded_at": doc.uploaded_at,
                    "content_base64": decrypted_content  # Decrypted for trusted party
                })

            logger.info(
                f"Verification details provided for request {request_uuid} to trusted party {trusted_party_user_id}")

            return VerificationRequestResponse(
                request_uuid=req.request_uuid,
                user_id=req.user_id,
                poll_id=req.poll_id,
                status=req.status,
                verification_data=VerificationData(**decrypted_data),
                documents=formatted_docs,
                created_at=req.created_at,
                expires_at=req.expires_at,
                verified_at=req.verified_at,
                verified_by=req.verified_by,
                reject_reason=req.reject_reason
            )

    async def process_verification_request(
            self,
            request_uuid: str,
            jwt_token: str,
            decision: ProcessVerificationRequest
    ) -> Dict[str, Any]:
        """Process verification request (approve/deny)"""

        async with get_session() as db:
            # Get verification request
            query = select(UserVerificationRequest).where(
                and_(
                    UserVerificationRequest.request_uuid == request_uuid,
                    UserVerificationRequest.status == "pending"
                )
            )
            result = await db.execute(query)
            req = result.scalar_one_or_none()

            if not req:
                raise ValueError("Verification request not found or already processed")

            if req.expires_at <= datetime.utcnow():
                req.status = "expired"
                await db.commit()
                raise ValueError("Verification request has expired")

            # Validate JWT token and get trusted party user ID
            poll_client = get_poll_client()
            try:
                user_info = await poll_client.validate_user_token(jwt_token)
                trusted_party_user_id = user_info.get("user_id")

                if not trusted_party_user_id:
                    raise ValueError("Invalid token: user ID not found")

            except Exception as e:
                logger.error(f"JWT validation failed: {e}")
                raise ValueError("Invalid or expired token")

            # Verify trusted party access
            try:
                trusted_parties = await poll_client.get_trusted_parties_for_poll(req.poll_id)
                is_trusted_party = any(tp["user_id"] == trusted_party_user_id for tp in trusted_parties)

                if not is_trusted_party:
                    raise ValueError("Access denied: not a trusted party for this poll")

            except Exception as e:
                logger.error(f"Failed to verify trusted party access: {e}")
                raise ValueError("Failed to verify access permissions")

            # Update request
            req.status = "confirmed" if decision.approved else "denied"
            req.verified_by = trusted_party_user_id
            req.verified_at = datetime.utcnow()
            if not decision.approved:
                req.reject_reason = decision.reject_reason

            await db.commit()

            status = "approved" if decision.approved else "denied"
            logger.info(f"Verification request {request_uuid} {status} by trusted party {trusted_party_user_id}")

            return {
                "success": True,
                "message": f"Verification request {status}",
                "request_uuid": request_uuid,
                "status": req.status,
                "verified_at": req.verified_at,
                "verified_by": trusted_party_user_id
            }

    async def cleanup_expired_requests(self) -> Dict[str, int]:
        """Cleanup expired verification requests and their documents"""

        async with get_session() as db:
            # Find expired requests
            expired_query = select(UserVerificationRequest).where(
                and_(
                    UserVerificationRequest.status == "pending",
                    UserVerificationRequest.expires_at <= datetime.utcnow()
                )
            )
            result = await db.execute(expired_query)
            expired_requests = result.scalars().all()

            expired_count = 0
            for req in expired_requests:
                req.status = "expired"
                expired_count += 1

            await db.commit()

            logger.info(f"Marked {expired_count} verification requests as expired")

            return {
                "expired_requests": expired_count
            }

    def _validate_uploaded_file(self, file: UploadFile, expected_type: str):
        """Validate uploaded file"""
        if not file.content_type in ALLOWED_CONTENT_TYPES:
            raise ValueError(f"Invalid file type for {expected_type}. Allowed: {ALLOWED_CONTENT_TYPES}")

        if file.size and file.size > MAX_FILE_SIZE:
            raise ValueError(f"File too large for {expected_type}. Max size: {MAX_FILE_SIZE} bytes")

    async def _save_document(
            self,
            file: UploadFile,
            verification_request_id: int,
            document_type: str
    ) -> VerificationDocument:
        """Save uploaded document with encryption"""

        # Read file content
        content = await file.read()

        # Convert to base64
        content_base64 = base64.b64encode(content).decode('utf-8')

        # Encrypt content
        encrypted_content = encryption_service.encrypt_file_content(content_base64)

        # Calculate hash for integrity
        content_hash = hashlib.sha256(content).hexdigest()

        return VerificationDocument(
            verification_request_id=verification_request_id,
            document_type=document_type,
            original_filename=file.filename,
            content_type=file.content_type,
            file_size=len(content),
            content_base64=encrypted_content,
            content_hash=content_hash
        )

    def _encrypt_verification_data(self, data: VerificationData) -> Dict[str, Any]:
        """Encrypt sensitive verification data"""
        return {
            "country": data.country,  # Not sensitive
            "document_type": data.document_type,  # Not sensitive
            "first_name": encryption_service.encrypt(data.first_name),
            "last_name": encryption_service.encrypt(data.last_name),
            "middle_name": encryption_service.encrypt(data.middle_name or ""),
            "gender": encryption_service.encrypt(data.gender),
            "birth_date": datetime.strptime(data.birth_date, '%Y-%m-%d').date(),
            "passport_series": encryption_service.encrypt(data.passport_series or ""),
            "passport_number": encryption_service.encrypt(data.passport_number),
            "department_code": encryption_service.encrypt(data.department_code or ""),
            "issued_by": encryption_service.encrypt(data.issued_by),
            "issue_date": datetime.strptime(data.issue_date, '%Y-%m-%d').date(),
            "registration_address": encryption_service.encrypt(data.registration_address)
        }

    def _decrypt_verification_data(self, req: UserVerificationRequest) -> Dict[str, Any]:
        """Decrypt verification data for trusted party view"""
        return {
            "country": req.country,
            "document_type": req.document_type,
            "first_name": encryption_service.decrypt(req.first_name),
            "last_name": encryption_service.decrypt(req.last_name),
            "middle_name": encryption_service.decrypt(req.middle_name),
            "gender": encryption_service.decrypt(req.gender),
            "birth_date": req.birth_date.strftime('%Y-%m-%d'),
            "passport_series": encryption_service.decrypt(req.passport_series),
            "passport_number": encryption_service.decrypt(req.passport_number),
            "department_code": encryption_service.decrypt(req.department_code),
            "issued_by": encryption_service.decrypt(req.issued_by),
            "issue_date": req.issue_date.strftime('%Y-%m-%d'),
            "registration_address": encryption_service.decrypt(req.registration_address)
        }

    async def _get_existing_pending_request(
            self,
            db: AsyncSession,
            user_id: int,
            poll_id: int
    ) -> Optional[UserVerificationRequest]:
        """Check for existing pending request"""
        query = select(UserVerificationRequest).where(
            and_(
                UserVerificationRequest.user_id == user_id,
                UserVerificationRequest.poll_id == poll_id,
                UserVerificationRequest.status == "pending",
                UserVerificationRequest.expires_at > datetime.utcnow()
            )
        )
        result = await db.execute(query)
        return result.scalar_one_or_none()

    async def get_user_verification_requests(
            self,
            user_id: int
    ) -> UserVerificationRequestsResponse:
        """Get all verification requests for a specific user"""

        async with get_session() as db:
            # Get all requests for user
            query = select(UserVerificationRequest).where(
                UserVerificationRequest.user_id == user_id
            ).order_by(UserVerificationRequest.created_at.desc())

            result = await db.execute(query)
            requests = result.scalars().all()

            if not requests:
                return UserVerificationRequestsResponse(
                    message="No verification requests found",
                    user_id=user_id,
                    requests=[],
                    total_count=0,
                    pending_count=0,
                    confirmed_count=0,
                    denied_count=0,
                    expired_count=0
                )

            # Get poll information for each request
            poll_client = get_poll_client()
            poll_info_cache = {}

            formatted_requests = []
            status_counts = {"pending": 0, "confirmed": 0, "denied": 0, "expired": 0}

            for req in requests:
                # Check if expired
                is_expired = req.expires_at <= datetime.utcnow() and req.status == "pending"
                if is_expired and req.status == "pending":
                    # Update status in database
                    req.status = "expired"
                    await db.commit()

                # Get poll title (cached)
                poll_title = None
                if req.poll_id not in poll_info_cache:
                    try:
                        poll_info = await poll_client.get_poll_info(req.poll_id, use_cache=True)
                        poll_info_cache[req.poll_id] = poll_info.get("title", f"Poll {req.poll_id}")
                    except Exception:
                        poll_info_cache[req.poll_id] = f"Poll {req.poll_id}"

                poll_title = poll_info_cache[req.poll_id]

                # Determine if user can resubmit
                can_resubmit = req.status in ["denied", "expired"]

                # Update status counts
                current_status = "expired" if is_expired else req.status
                if current_status in status_counts:
                    status_counts[current_status] += 1

                formatted_requests.append(UserVerificationSummary(
                    request_uuid=req.request_uuid,
                    poll_id=req.poll_id,
                    poll_title=poll_title,
                    status=current_status,
                    created_at=req.created_at,
                    expires_at=req.expires_at,
                    verified_at=req.verified_at,
                    is_expired=is_expired,
                    can_resubmit=can_resubmit
                ))

            return UserVerificationRequestsResponse(
                message=f"Found {len(formatted_requests)} verification requests",
                user_id=user_id,
                requests=formatted_requests,
                total_count=len(formatted_requests),
                pending_count=status_counts["pending"],
                confirmed_count=status_counts["confirmed"],
                denied_count=status_counts["denied"],
                expired_count=status_counts["expired"]
            )

    async def get_user_verification_status(
            self,
            user_id: int,
            poll_id: int
    ) -> Dict[str, Any]:
        """Get verification status for specific user and poll"""

        async with get_session() as db:
            # Get most recent request for this poll
            query = select(UserVerificationRequest).where(
                and_(
                    UserVerificationRequest.user_id == user_id,
                    UserVerificationRequest.poll_id == poll_id
                )
            ).order_by(UserVerificationRequest.created_at.desc()).limit(1)

            result = await db.execute(query)
            req = result.scalar_one_or_none()

            if not req:
                return {
                    "verified": False,
                    "status": "not_requested",
                    "message": "No verification request found for this poll",
                    "can_request": True
                }

            # Check if expired
            is_expired = req.expires_at <= datetime.utcnow() and req.status == "pending"
            if is_expired:
                req.status = "expired"
                await db.commit()

            current_status = "expired" if is_expired else req.status

            return {
                "verified": current_status == "confirmed",
                "status": current_status,
                "request_uuid": req.request_uuid,
                "created_at": req.created_at,
                "expires_at": req.expires_at if current_status == "pending" else None,
                "verified_at": req.verified_at,
                "reject_reason": req.reject_reason if current_status == "denied" else None,
                "can_request": current_status in ["denied", "expired"],
                "message": self._get_status_message(current_status)
            }

    def _get_status_message(self, status: str) -> str:
        """Get user-friendly status message"""
        messages = {
            "pending": "Your verification request is pending review by a trusted party",
            "confirmed": "Your verification has been approved - you can now participate in this poll",
            "denied": "Your verification was denied - you can submit a new request",
            "expired": "Your verification request expired - you can submit a new request",
            "not_requested": "You haven't requested verification for this poll yet"
        }
        return messages.get(status, "Unknown status")


# Global service instance
user_verification_service = UserVerificationService()
