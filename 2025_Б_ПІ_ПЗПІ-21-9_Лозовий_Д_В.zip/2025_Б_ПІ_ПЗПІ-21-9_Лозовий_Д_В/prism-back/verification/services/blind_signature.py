"""
Blind Signature Service for anonymous voting verification
Handles RSA blind signatures for TrustedParty verification
"""
import logging
import hashlib
import base64
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature
from sqlalchemy import select, update, and_
from sqlalchemy.ext.asyncio import AsyncSession

from models.database_models import BlindSignature, TrustedPartyKeysCache
from models.requests import BlindSignatureRequest, ProcessSignatureRequest
from models.responses import (
    BlindSignatureResponse, SignatureResultResponse, PendingSignatureItem,
    PendingSignaturesResponse
)
from database import get_session
from utils.crypto import generate_rsa_keypair, validate_rsa_public_key
from utils.poll_client import PollManagementClient
from config import settings

logger = logging.getLogger(__name__)


class BlindSignatureService:
    """
    Service for handling blind signature operations
    Supports anonymous voting through RSA blind signatures
    """
    
    def __init__(self):
        self.poll_client = PollManagementClient()
        self.master_key = settings.master_encryption_key or "default_dev_key"
    
    async def request_blind_signature(
        self, 
        request: BlindSignatureRequest
    ) -> BlindSignatureResponse:
        """
        Create a new blind signature request
        TrustedParty will know the requester for verification
        """
        async with get_session() as session:
            # Validate poll exists and is private
            poll_info = await self.poll_client.get_poll_info(request.poll_id)
            if not poll_info.get("is_private", False):
                raise ValueError("Blind signatures only available for private polls")
            
            # Check if user already has a request for this poll
            existing = await self._get_existing_request(
                session, request.requester_id, request.poll_id
            )
            if existing:
                if existing.status == "pending":
                    return BlindSignatureResponse(
                        success=True,
                        message="Request already exists",
                        request_id=existing.id,
                        status=existing.status,
                        expires_at=existing.expires_at
                    )
                elif existing.status == "signed":
                    raise ValueError("User already has approved signature for this poll")
            
            # Create new request
            blind_signature = BlindSignature(
                requester_id=request.requester_id,
                trusted_party_id=await self._get_default_trusted_party(request.poll_id),
                poll_id=request.poll_id,
                blinded_anonymous_id=request.blinded_anonymous_id,
                trusted_party_session=request.trusted_party_session,
                status="pending",
                expires_at=datetime.utcnow() + timedelta(hours=settings.signature_expiry_hours)
            )
            
            session.add(blind_signature)
            await session.commit()
            await session.refresh(blind_signature)
            
            logger.info(f"Blind signature request created: {blind_signature.id}")
            
            return BlindSignatureResponse(
                success=True,
                message="Blind signature request created",
                request_id=blind_signature.id,
                status=blind_signature.status,
                expires_at=blind_signature.expires_at
            )
    
    async def get_pending_requests(
        self, 
        trusted_party_id: int,
        poll_id: Optional[int] = None
    ) -> PendingSignaturesResponse:
        """
        Get pending signature requests for a TrustedParty
        """
        async with get_session() as session:
            query = select(BlindSignature).where(
                and_(
                    BlindSignature.trusted_party_id == trusted_party_id,
                    BlindSignature.status == "pending",
                    BlindSignature.expires_at > datetime.utcnow()
                )
            )
            
            if poll_id:
                query = query.where(BlindSignature.poll_id == poll_id)
            
            result = await session.execute(query.order_by(BlindSignature.created_at))
            requests = result.scalars().all()
            
            pending_items = [
                PendingSignatureItem(
                    request_id=req.id,
                    requester_id=req.requester_id,
                    poll_id=req.poll_id,
                    blinded_anonymous_id=req.blinded_anonymous_id,
                    created_at=req.created_at,
                    trusted_party_session=req.trusted_party_session
                )
                for req in requests
            ]
            
            return PendingSignaturesResponse(
                success=True,
                message=f"Found {len(pending_items)} pending requests",
                requests=pending_items,
                total_count=len(pending_items),
                trusted_party_id=trusted_party_id
            )
    
    async def process_signature_request(
        self,
        request_id: int,
        trusted_party_id: int,
        decision: ProcessSignatureRequest
    ) -> SignatureResultResponse:
        """
        Process a blind signature request (approve or reject)
        """
        async with get_session() as session:
            # Get the request
            blind_request = await self._get_request_by_id(session, request_id)
            if not blind_request:
                raise ValueError("Request not found")
            
            if blind_request.trusted_party_id != trusted_party_id:
                raise ValueError("Unauthorized: not your request to process")
            
            if not blind_request.can_be_processed():
                raise ValueError("Request cannot be processed (expired or already processed)")
            
            # Process decision
            if decision.approved:
                # Generate signature
                signature = await self._sign_blinded_message(
                    blind_request.blinded_anonymous_id,
                    trusted_party_id,
                    blind_request.poll_id
                )
                
                # Update request
                await session.execute(
                    update(BlindSignature)
                    .where(BlindSignature.id == request_id)
                    .values(
                        status="signed",
                        signature=signature,
                        processed_at=datetime.utcnow(),
                        trusted_party_session=decision.trusted_party_session
                    )
                )
                
                logger.info(f"Blind signature approved: {request_id}")
                
            else:
                # Reject request
                await session.execute(
                    update(BlindSignature)
                    .where(BlindSignature.id == request_id)
                    .values(
                        status="rejected",
                        reject_reason=decision.reject_reason,
                        processed_at=datetime.utcnow(),
                        trusted_party_session=decision.trusted_party_session
                    )
                )
                
                logger.info(f"Blind signature rejected: {request_id}")
            
            await session.commit()
            
            # Get updated request
            await session.refresh(blind_request)
            
            return SignatureResultResponse(
                success=True,
                message="Request processed successfully",
                request_id=request_id,
                status=blind_request.status,
                signature=blind_request.signature if decision.approved else None,
                reject_reason=blind_request.reject_reason,
                processed_at=blind_request.processed_at,
                expires_at=blind_request.expires_at
            )
    
    async def get_signature_result(
        self,
        request_id: int,
        requester_id: int
    ) -> SignatureResultResponse:
        """
        Get the result of a signature request
        """
        async with get_session() as session:
            blind_request = await self._get_request_by_id(session, request_id)
            if not blind_request:
                raise ValueError("Request not found")
            
            if blind_request.requester_id != requester_id:
                raise ValueError("Unauthorized: not your request")
            
            return SignatureResultResponse(
                success=True,
                message="Request result retrieved",
                request_id=request_id,
                status=blind_request.status,
                signature=blind_request.signature,
                reject_reason=blind_request.reject_reason,
                processed_at=blind_request.processed_at,
                expires_at=blind_request.expires_at
            )
    
    async def _get_existing_request(
        self,
        session: AsyncSession,
        requester_id: int,
        poll_id: int
    ) -> Optional[BlindSignature]:
        """Get existing request for user and poll"""
        result = await session.execute(
            select(BlindSignature).where(
                and_(
                    BlindSignature.requester_id == requester_id,
                    BlindSignature.poll_id == poll_id
                )
            ).order_by(BlindSignature.created_at.desc())
        )
        return result.scalars().first()
    
    async def _get_request_by_id(
        self,
        session: AsyncSession,
        request_id: int
    ) -> Optional[BlindSignature]:
        """Get request by ID"""
        result = await session.execute(
            select(BlindSignature).where(BlindSignature.id == request_id)
        )
        return result.scalars().first()
    
    async def _get_default_trusted_party(self, poll_id: int) -> int:
        """Get default trusted party for poll (poll creator)"""
        # In real implementation, get from Poll Management Service
        # For now, return 1 as default
        return 1
    
    async def _sign_blinded_message(
        self,
        blinded_message: str,
        trusted_party_id: int,
        poll_id: int
    ) -> str:
        """
        Sign a blinded message with TrustedParty's private key
        In production, this would use actual RSA signing
        """
        # Get or generate trusted party keys
        private_key = await self._get_trusted_party_private_key(trusted_party_id, poll_id)
        
        try:
            # Decode blinded message
            blinded_bytes = base64.b64decode(blinded_message)
            
            # Sign with private key
            signature = private_key.sign(
                blinded_bytes,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            
            # Return base64 encoded signature
            return base64.b64encode(signature).decode('utf-8')
            
        except Exception as e:
            logger.error(f"Failed to sign blinded message: {e}")
            raise ValueError("Failed to create signature")
    
    async def _get_trusted_party_private_key(
        self,
        trusted_party_id: int,
        poll_id: int
    ) -> rsa.RSAPrivateKey:
        """
        Get or generate private key for trusted party
        In production, this would be stored securely
        """
        # For demo purposes, generate a deterministic key
        # In production, this should be properly managed
        
        # Generate deterministic private key based on trusted_party_id and poll_id
        seed = f"{trusted_party_id}:{poll_id}:{self.master_key}"
        hash_bytes = hashlib.sha256(seed.encode()).digest()
        
        # Use first 4 bytes as seed for key generation
        seed_int = int.from_bytes(hash_bytes[:4], byteorder='big')
        
        # Generate RSA key with deterministic seed
        # Note: This is for demo only, real implementation should use proper key storage
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=settings.rsa_key_size
        )
        
        return private_key
    
    async def get_trusted_party_public_key(
        self,
        trusted_party_id: int,
        poll_id: int
    ) -> str:
        """
        Get public key for trusted party in PEM format
        """
        private_key = await self._get_trusted_party_private_key(trusted_party_id, poll_id)
        public_key = private_key.public_key()
        
        pem_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return pem_bytes.decode('utf-8')
    
    async def cleanup_expired_requests(self) -> Dict[str, int]:
        """Cleanup expired signature requests"""
        async with get_session() as session:
            # Mark expired pending requests as expired
            result = await session.execute(
                update(BlindSignature)
                .where(
                    and_(
                        BlindSignature.status == "pending",
                        BlindSignature.expires_at < datetime.utcnow()
                    )
                )
                .values(status="expired")
            )
            
            expired_count = result.rowcount
            await session.commit()
            
            logger.info(f"Marked {expired_count} requests as expired")
            return {"expired_requests": expired_count}