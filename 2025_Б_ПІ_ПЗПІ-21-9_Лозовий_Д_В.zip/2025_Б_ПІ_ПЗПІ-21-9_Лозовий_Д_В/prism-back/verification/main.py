"""
Main FastAPI application for Verification Service
Handles anonymous voting verification through blind signatures and ZKP
"""
import asyncio
import logging
import logging.config
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import uvicorn

from config import settings, get_log_config, is_production
from database import (
    create_database_engine, create_session_factory, create_tables,
    close_database_connections, check_database_health
)
from utils.poll_client import close_poll_client
from api.health import router as health_router
from api.blind_signatures import router as blind_signatures_router
from api.zkp import router as zkp_router
from api.user_verification import router as user_verification_router

# Configure logging
logging.config.dictConfig(get_log_config())
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for FastAPI application
    Handles startup and shutdown events
    """
    # Startup
    logger.info("Starting Verification Service...")
    logger.info("Verification cleanup task started")
    
    try:
        # Initialize database
        await create_database_engine()
        await create_session_factory()
        await create_tables()
        
        # Check database health
        db_health = await check_database_health()
        if db_health["status"] != "healthy":
            logger.error(f"Database health check failed: {db_health}")
            raise Exception("Database initialization failed")
        
        logger.info("Database initialized successfully")
        logger.info(f"Verification Service started on port {settings.port}")
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to start Verification Service: {e}")
        raise
    
    finally:
        # Shutdown
        logger.info("Shutting down Verification Service...")
        
        try:
            await close_poll_client()
            await close_database_connections()
            logger.info("Verification Service shutdown complete")
        
        except Exception as e:
            logger.error(f"Error during shutdown: {e}")


# Create FastAPI application
app = FastAPI(
    title="Verification Service",
    description="Anonymous voting verification through blind signatures and ZKP",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Add security middleware
if is_production():
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["localhost", "127.0.0.1", "verification-service"]
    )

# Add CORS middleware for development
if not is_production():
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3000", "http://localhost:8080", "http://localhost:8082"],
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

# Add request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all HTTP requests"""
    start_time = request.state.start_time = request.state.__dict__.get("start_time", 0)
    
    # Skip logging for health checks in production
    if is_production() and request.url.path in ["/health", "/ready"]:
        return await call_next(request)
    
    logger.info(f"Request: {request.method} {request.url.path}")
    
    try:
        response = await call_next(request)
        process_time = getattr(request.state, "start_time", 0)
        
        logger.info(
            f"Response: {request.method} {request.url.path} - "
            f"Status: {response.status_code} - Time: {process_time:.3f}s"
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Request failed: {request.method} {request.url.path} - Error: {e}")
        raise


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle all unhandled exceptions"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": "http_error",
                "message": exc.detail,
                "status_code": exc.status_code
            }
        )
    
    # Don't expose internal errors in production
    if is_production():
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_error",
                "message": "An internal error occurred"
            }
        )
    else:
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_error",
                "message": str(exc),
                "type": type(exc).__name__
            }
        )


# Include API routers
app.include_router(
    health_router,
    tags=["Health"]
)

app.include_router(
    blind_signatures_router,
    prefix="/api/v1/blind-signatures",
    tags=["Blind Signatures"]
)

app.include_router(
    zkp_router,
    prefix="/api/v1/zkp",
    tags=["Zero-Knowledge Proofs"]
)

app.include_router(
    user_verification_router,
    prefix="/api/v1/verification",
    tags=["User Verification"]
)


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with service information"""
    return {
        "service": "verification-service",
        "version": "1.0.0",
        "description": "Anonymous voting verification through blind signatures and ZKP",
        "environment": settings.environment,
        "status": "running",
        "endpoints": {
            "health": "/health",
            "blind_signatures": "/api/v1/blind-signatures",
            "zkp": "/api/v1/zkp",
            "docs": "/docs" if not is_production() else "disabled"
        }
    }


# Application factory for different environments
def create_app() -> FastAPI:
    """Factory function to create configured FastAPI app"""
    return app


# Development server runner
def run_dev_server():
    """Run development server with hot reload"""
    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=True,
        log_level=settings.log_level.lower(),
        access_log=not is_production()
    )


# Production server runner
def run_prod_server():
    """Run production server"""
    uvicorn.run(
        app,
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.lower(),
        access_log=False,
        server_header=False,
        date_header=False
    )


if __name__ == "__main__":
    if is_production():
        run_prod_server()
    else:
        run_dev_server()