"""
Health check endpoints for Verification Service
Provides health status and readiness checks for monitoring
"""
import logging
from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from models.responses import HealthResponse
from database import DatabaseSession, check_database_health, get_database_statistics
from utils.poll_client import get_poll_client
from config import settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Basic health check endpoint
    Returns service status without external dependencies
    """
    return HealthResponse(
        status="healthy",
        timestamp=datetime.utcnow(),
        version="1.0.0",
        environment=settings.environment,
        database={"status": "not_checked"},
        external_services={"status": "not_checked"}
    )


@router.get("/ready", response_model=HealthResponse)
async def readiness_check(db: AsyncSession = Depends(DatabaseSession)):
    """
    Readiness check endpoint with full dependency validation
    Checks database and external services connectivity
    """
    # Check database health
    db_health = await check_database_health()
    
    # Check Poll Management Service health
    poll_client = get_poll_client()
    poll_service_health = await poll_client.health_check()
    
    # Determine overall status
    is_ready = (
        db_health["status"] == "healthy" and
        poll_service_health["status"] == "healthy"
    )
    
    overall_status = "ready" if is_ready else "not_ready"
    
    # Get database statistics
    try:
        db_stats = await get_database_statistics()
    except Exception as e:
        logger.warning(f"Failed to get database statistics: {e}")
        db_stats = {"error": str(e)}
    
    external_services = {
        "poll_management_service": poll_service_health,
        "database_statistics": db_stats
    }
    
    return HealthResponse(
        status=overall_status,
        timestamp=datetime.utcnow(),
        version="1.0.0",
        environment=settings.environment,
        database=db_health,
        external_services=external_services
    )


@router.get("/status")
async def detailed_status():
    """
    Detailed status endpoint for debugging and monitoring
    Returns comprehensive service information
    """
    try:
        # Database health
        db_health = await check_database_health()
        db_stats = await get_database_statistics()
        
        # External services health
        poll_client = get_poll_client()
        poll_health = await poll_client.health_check()
        
        return {
            "service": "verification-service",
            "version": "1.0.0",
            "timestamp": datetime.utcnow().isoformat(),
            "environment": settings.environment,
            "uptime": "calculated_from_startup",  # TODO: implement actual uptime
            "status": {
                "overall": "healthy" if db_health["status"] == "healthy" else "degraded",
                "database": db_health,
                "external_services": {
                    "poll_management": poll_health
                }
            },
            "statistics": db_stats,
            "configuration": {
                "host": settings.host,
                "port": settings.port,
                "debug": settings.debug,
                "database_pool_size": settings.database_pool_size,
                "signature_expiry_hours": settings.signature_expiry_hours,
                "zkp_proof_expiry_hours": settings.zkp_proof_expiry_hours
            },
            "features": {
                "blind_signatures": True,
                "zkp_verification": True,
                "anonymous_voting": True,
                "trusted_party_verification": True
            }
        }
        
    except Exception as e:
        logger.error(f"Error in detailed status endpoint: {e}")
        return {
            "service": "verification-service",
            "status": "error",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }


@router.get("/metrics")
async def get_metrics():
    """
    Prometheus-style metrics endpoint
    Returns metrics in simple format for monitoring
    """
    try:
        db_stats = await get_database_statistics()
        
        metrics = []
        
        # Service info
        metrics.append('# HELP verification_service_info Service information')
        metrics.append('# TYPE verification_service_info gauge')
        metrics.append(f'verification_service_info{{version="1.0.0",environment="{settings.environment}"}} 1')
        
        # Database metrics
        if "blind_signatures_total" in db_stats:
            metrics.append('# HELP verification_blind_signatures_total Total blind signature requests')
            metrics.append('# TYPE verification_blind_signatures_total counter')
            metrics.append(f'verification_blind_signatures_total {db_stats["blind_signatures_total"]}')
        
        if "blind_signatures_pending" in db_stats:
            metrics.append('# HELP verification_blind_signatures_pending Pending blind signature requests')
            metrics.append('# TYPE verification_blind_signatures_pending gauge')
            metrics.append(f'verification_blind_signatures_pending {db_stats["blind_signatures_pending"]}')
        
        if "zkp_verifications_total" in db_stats:
            metrics.append('# HELP verification_zkp_proofs_total Total ZKP proofs generated')
            metrics.append('# TYPE verification_zkp_proofs_total counter')
            metrics.append(f'verification_zkp_proofs_total {db_stats["zkp_verifications_total"]}')
        
        if "used_anonymous_ids_total" in db_stats:
            metrics.append('# HELP verification_anonymous_ids_used Total anonymous IDs used for voting')
            metrics.append('# TYPE verification_anonymous_ids_used counter')
            metrics.append(f'verification_anonymous_ids_used {db_stats["used_anonymous_ids_total"]}')
        
        return "\n".join(metrics)
        
    except Exception as e:
        logger.error(f"Error generating metrics: {e}")
        return f"# Error generating metrics: {e}"


@router.get("/version")
async def get_version():
    """Simple version endpoint"""
    return {
        "service": "verification-service",
        "version": "1.0.0",
        "build": "development",
        "environment": settings.environment,
        "features": {
            "phase": "Phase 2 - Anonymous Voting",
            "zkp_protocol": "simplified_sigma_protocol",
            "blind_signatures": "RSA-2048",
            "anonymity": "guaranteed"
        }
    }