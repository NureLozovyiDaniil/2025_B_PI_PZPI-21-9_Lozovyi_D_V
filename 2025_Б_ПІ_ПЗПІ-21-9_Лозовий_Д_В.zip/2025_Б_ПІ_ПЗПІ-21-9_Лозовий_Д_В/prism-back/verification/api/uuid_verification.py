from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.websockets import WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session
from typing import List, Optional, Dict
from datetime import datetime, timedelta
import json
import uuid as uuid_lib

from database import DatabaseSession
from core.websocket import uuid_verification_manager
from models.uuid_verification import UUIDVerificationSession
from schemas.uuid_verification import (
    CreateUUIDVerificationRequest,
    UUIDVerificationResponse,
    ScanQRCodeRequest,
    ConfirmVerificationRequest,
    UUIDVerificationStatusResponse,
    QRCodeData
)
from app.core.auth import get_current_user
from models.user import User

router = APIRouter()


@router.post("/create", response_model=UUIDVerificationResponse)
async def create_uuid_verification_session(
        request: CreateUUIDVerificationRequest,
        db: Session = DatabaseSession,
        current_user: User = Depends(get_current_user)
):
    """Create new UUID verification session for mobile app integration"""

    # Check if poll exists and user has permissions
    # This would integrate with your existing poll management system

    expires_at = datetime.utcnow() + timedelta(minutes=request.expires_in_minutes)

    session = UUIDVerificationSession(
        poll_id=request.poll_id,
        user_id=current_user.id,
        verification_type=request.verification_type,
        expires_at=expires_at,
        verification_request_uuid=request.verification_request_uuid  # Link to existing verification request
    )

    # Generate QR data
    qr_data = QRCodeData(
        uuid=str(session.uuid),
        poll_id=request.poll_id,
        expires_at=expires_at,
        verification_type=request.verification_type,
        verification_request_uuid=request.verification_request_uuid
    )
    session.qr_data = qr_data.json()

    db.add(session)
    db.commit()
    db.refresh(session)

    return UUIDVerificationResponse.from_orm(session)


@router.get("/{uuid}/status", response_model=UUIDVerificationStatusResponse)
async def get_verification_status(
        uuid: str,
        db: Session = Depends(get_db)
):
    """Get verification session status (public endpoint for polling)"""

    session = db.query(UUIDVerificationSession).filter(
        UUIDVerificationSession.uuid == uuid
    ).first()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Verification session not found"
        )

    # Update status if expired
    if session.is_expired() and session.status != "expired":
        session.status = "expired"
        db.commit()

    time_left = max(0, int((session.expires_at - datetime.utcnow()).total_seconds()))

    return UUIDVerificationStatusResponse(
        uuid=str(session.uuid),
        status=session.status,
        poll_id=session.poll_id,
        expires_at=session.expires_at,
        time_left_seconds=time_left,
        is_expired=session.is_expired()
    )


@router.post("/{uuid}/scan", response_model=UUIDVerificationResponse)
async def scan_qr_code(
        uuid: str,
        request: ScanQRCodeRequest,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """Scan QR code - called from mobile app"""

    session = db.query(UUIDVerificationSession).filter(
        UUIDVerificationSession.uuid == uuid
    ).first()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Verification session not found"
        )

    if not session.can_be_scanned():
        if session.is_expired():
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail="QR code has expired"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"QR code cannot be scanned in current status: {session.status}"
            )

    # Update session
    session.status = "scanned"
    session.scanned_at = datetime.utcnow()
    session.trusted_party_id = current_user.id

    # Store device info if provided
    if request.device_info:
        session.device_model = request.device_info.device_model
        session.os_version = request.device_info.os_version
        session.app_version = request.device_info.app_version

    db.commit()
    db.refresh(session)

    # Notify frontend via WebSocket
    await uuid_verification_manager.send_status_update(
        uuid=str(session.uuid),
        status=session.status,
        data={
            "trusted_party_id": current_user.id,
            "scanned_at": session.scanned_at.isoformat()
        }
    )

    return UUIDVerificationResponse.from_orm(session)


@router.post("/{uuid}/confirm")
async def confirm_verification(
        uuid: str,
        request: ConfirmVerificationRequest,
        db: Session = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    """Confirm verification - final step that updates linked verification request"""

    session = db.query(UUIDVerificationSession).filter(
        UUIDVerificationSession.uuid == uuid
    ).first()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Verification session not found"
        )

    if not session.can_be_completed():
        if session.is_expired():
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail="Verification session has expired"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Verification cannot be completed in current status: {session.status}"
            )

    # Check if current user is the trusted party who scanned
    if (session.trusted_party_id and
            session.trusted_party_id != current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the trusted party who scanned can confirm"
        )

    # Update session
    session.status = "completed"
    session.completed_at = datetime.utcnow()
    if request.notes:
        session.notes = request.notes

    # If linked to verification request, update it using existing API logic
    if session.verification_request_uuid:
        # Import and use existing verification processing logic
        from api.verification import process_verification_request
        from schemas.verification import ProcessVerificationRequest

        try:
            verification_request = ProcessVerificationRequest(
                approved=True,
                notes=f"Verified via mobile app UUID: {uuid}. {request.notes or ''}"
            )

            # Call existing verification processing endpoint
            await process_verification_request(
                request_uuid=session.verification_request_uuid,
                trusted_party_id=current_user.id,
                request=verification_request,
                db=db
            )
        except Exception as e:
            # Log error but don't fail the UUID confirmation
            print(f"Error updating verification request: {e}")

    db.commit()

    # Notify frontend via WebSocket
    await uuid_verification_manager.send_status_update(
        uuid=str(session.uuid),
        status=session.status,
        data={
            "completed_at": session.completed_at.isoformat(),
            "verification_request_uuid": session.verification_request_uuid
        }
    )

    return {
        "success": True,
        "message": "Verification completed successfully",
        "uuid": str(session.uuid),
        "status": session.status,
        "verification_request_uuid": session.verification_request_uuid
    }


@router.websocket("/ws/{uuid}")
async def websocket_endpoint(websocket: WebSocket, uuid: str):
    """WebSocket endpoint for real-time updates"""
    await uuid_verification_manager.connect(websocket, uuid)
    try:
        while True:
            # Keep connection alive and handle any incoming messages
            data = await websocket.receive_text()
            # Echo back or handle specific commands if needed
            await websocket.send_text(f"Echo: {data}")
    except WebSocketDisconnect:
        uuid_verification_manager.disconnect(websocket, uuid)