"""
User Verification API endpoints
Handles verification requests for anonymous voting
"""
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Form, File, UploadFile, Request, Query, Header
from sqlalchemy.ext.asyncio import AsyncSession

from models.verification_requests import (
    CreateVerificationRequest, VerificationData, ProcessVerificationRequest,
    VerificationRequestCreated, PendingVerificationsResponse,
    VerificationRequestResponse,
    UserVerificationRequestsResponse
)
from services.user_verification import user_verification_service
from database import DatabaseSession

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/request", response_model=VerificationRequestCreated)
async def create_verification_request(
    request: Request,
    poll_id: int,
    metadata: str = Form(...),  # JSON string with VerificationData
    passport_file: UploadFile = File(...),
    selfie_file: UploadFile = File(...),
    user_id: int = Query(...),  # From JWT in real implementation
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Create verification request for private poll participation
    
    User submits their document data and files for trusted party verification.
    Request expires after 24 hours if not processed.
    """
    try:
        import json
        
        # Parse verification data from form
        verification_data = VerificationData.parse_raw(metadata)
        
        create_request = CreateVerificationRequest(
            poll_id=poll_id,
            verification_data=verification_data
        )
        
        # Get client info for audit
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        logger.info(f"Verification request from user {user_id} for poll {poll_id}")
        
        result = await user_verification_service.create_verification_request(
            user_id=user_id,
            request=create_request,
            passport_file=passport_file,
            selfie_file=selfie_file,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        logger.info(f"Verification request created: {result.request_uuid}")
        return result
        
    except json.JSONDecodeError:
        logger.warning("Invalid JSON in metadata field")
        raise HTTPException(status_code=400, detail="Invalid JSON in metadata field")
    
    except ValueError as e:
        logger.warning(f"Invalid verification request: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to create verification request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/pending/{trusted_party_id}", response_model=PendingVerificationsResponse)
async def get_pending_requests(
    trusted_party_id: int,
    poll_id: Optional[int] = Query(None, description="Filter by specific poll"),
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get pending verification requests for trusted party
    
    Trusted party can see all pending verification requests for polls
    where they are authorized to verify users.
    """
    try:
        if trusted_party_id <= 0:
            raise ValueError("Invalid trusted party ID")
        
        logger.info(f"Getting pending verification requests for trusted party {trusted_party_id}")
        
        result = await user_verification_service.get_pending_requests_for_trusted_party(
            trusted_party_id=trusted_party_id,
            poll_id=poll_id
        )
        
        logger.info(f"Found {result.total_count} pending requests for trusted party {trusted_party_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid request for pending verifications: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to get pending verification requests: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/request/{request_uuid}", response_model=VerificationRequestResponse)
async def get_verification_request_details(
        request_uuid: str,
        authorization: str = Header(..., description="Bearer JWT token"),
        db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get detailed verification request for trusted party review

    Returns full user data and documents for verification decision.
    Access is restricted to authorized trusted parties only.
    """
    try:
        # Validate Authorization header format
        if not authorization.startswith("Bearer "):
            raise ValueError("Invalid authorization header format")

        jwt_token = authorization[7:]  # Remove "Bearer " prefix

        logger.info(f"Getting verification details for request {request_uuid}")

        result = await user_verification_service.get_verification_request_details(
            request_uuid=request_uuid,
            jwt_token=jwt_token
        )

        return result

    except ValueError as e:
        logger.warning(f"Invalid request for verification details: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        logger.error(f"Failed to get verification request details: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/process/{request_uuid}")
async def process_verification_request(
        request_uuid: str,
        decision: ProcessVerificationRequest,
        authorization: str = Header(..., description="Bearer JWT token"),
        db: AsyncSession = Depends(DatabaseSession)
):
    """
    Process verification request (approve or deny)

    Trusted party makes decision on user verification after reviewing
    submitted documents and personal data.
    """
    try:
        # Validate Authorization header format
        if not authorization.startswith("Bearer "):
            raise ValueError("Invalid authorization header format")

        jwt_token = authorization[7:]  # Remove "Bearer " prefix

        logger.info(f"Processing verification request {request_uuid}")

        result = await user_verification_service.process_verification_request(
            request_uuid=request_uuid,
            jwt_token=jwt_token,
            decision=decision
        )

        status = "approved" if decision.approved else "denied"
        logger.info(f"Verification request {request_uuid} {status}")

        return result

    except ValueError as e:
        logger.warning(f"Invalid verification processing request: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        logger.error(f"Failed to process verification request: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/my-requests/{user_id}", response_model=UserVerificationRequestsResponse)
async def get_user_verification_requests(
    user_id: int,
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Get verification requests for specific user
    
    User can check status of their verification requests.
    Only returns summary data, not sensitive details.
    """
    try:
        if user_id <= 0:
            raise ValueError("Invalid user ID")
        
        logger.info(f"Getting verification requests for user {user_id}")
        
        result = await user_verification_service.get_user_verification_requests(user_id)
        
        logger.info(f"Found {result.total_count} verification requests for user {user_id}")
        return result
        
    except ValueError as e:
        logger.warning(f"Invalid request for user verification requests: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    
    except Exception as e:
        logger.error(f"Failed to get user verification requests: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/cleanup")
async def cleanup_expired_verification_requests(
    db: AsyncSession = Depends(DatabaseSession)
):
    """
    Cleanup expired verification requests
    
    Administrative endpoint for maintenance.
    Marks expired requests and can delete old data.
    """
    try:
        logger.info("Starting cleanup of expired verification requests")
        
        result = await user_verification_service.cleanup_expired_requests()
        
        logger.info(f"Verification cleanup completed: {result}")
        
        return {
            "success": True,
            "message": f"Cleanup completed: {result['expired_requests']} expired requests processed",
            **result
        }
        
    except Exception as e:
        logger.error(f"Failed to cleanup expired verification requests: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/statistics")
async def get_verification_statistics():
    """
    Get verification statistics for monitoring
    
    Returns aggregated data with no personally identifiable information.
    """
    try:
        from database import get_database_statistics
        
        db_stats = await get_database_statistics()
        
        return {
            "success": True,
            "message": "Verification statistics retrieved",
            "statistics": {
                "total_requests": db_stats.get("verification_requests_total", 0),
                "pending_requests": db_stats.get("verification_requests_pending", 0),
                "confirmed_requests": db_stats.get("verification_requests_confirmed", 0),
                "denied_requests": db_stats.get("verification_requests_denied", 0),
                "expired_requests": db_stats.get("verification_requests_expired", 0),
                "total_documents": db_stats.get("verification_documents_total", 0)
            },
            "privacy_note": "All statistics are aggregated and anonymized"
        }
        
    except Exception as e:
        logger.error(f"Failed to get verification statistics: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

