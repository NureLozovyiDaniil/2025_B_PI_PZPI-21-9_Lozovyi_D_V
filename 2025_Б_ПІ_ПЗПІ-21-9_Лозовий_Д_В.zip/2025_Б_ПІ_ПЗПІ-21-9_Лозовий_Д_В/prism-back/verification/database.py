"""
Database connection and session management for Verification Service
Async SQLAlchemy setup with PostgreSQL
"""
import logging
from typing import AsyncGenerator, Optional
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool
from sqlalchemy import text

from config import settings, get_database_url
from models.database_models import Base

logger = logging.getLogger(__name__)

# Global variables for database engine and session factory
engine = None
async_session_factory = None


async def create_database_engine():
    """Create async database engine with connection pooling"""
    global engine
    
    if engine is not None:
        return engine
    
    database_url = get_database_url()
    
    # Configure engine based on environment
    engine_kwargs = {
        "echo": settings.database_echo,
        "pool_size": settings.database_pool_size,
        "max_overflow": settings.database_max_overflow,
        "pool_pre_ping": True,  # Validate connections before use
        "pool_recycle": 3600,   # Recycle connections every hour
    }
    
    # Special configuration for testing
    if settings.environment == "testing":
        engine_kwargs.update({
            "poolclass": StaticPool,
            "connect_args": {"check_same_thread": False}
        })
    
    engine = create_async_engine(database_url, **engine_kwargs)
    
    logger.info(f"Database engine created for {settings.environment} environment")
    return engine


async def create_session_factory():
    """Create async session factory"""
    global async_session_factory
    
    if async_session_factory is not None:
        return async_session_factory
    
    if engine is None:
        await create_database_engine()
    
    async_session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False
    )
    
    logger.info("Async session factory created")
    return async_session_factory


async def get_database_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for getting database session in FastAPI endpoints
    Yields an async session and handles cleanup
    """
    if async_session_factory is None:
        await create_session_factory()
    
    async with async_session_factory() as session:
        try:
            yield session
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_session():
    """
    Context manager for getting database session in services
    """
    if async_session_factory is None:
        await create_session_factory()
    
    async with async_session_factory() as session:
        try:
            yield session
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            await session.close()


async def create_tables():
    """Create all database tables"""
    if engine is None:
        await create_database_engine()
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info("Database tables created")


async def drop_tables():
    """Drop all database tables (for testing)"""
    if engine is None:
        await create_database_engine()
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    
    logger.info("Database tables dropped")


async def check_database_health() -> dict:
    """
    Check database connectivity and return health status
    """
    try:
        if engine is None:
            await create_database_engine()
        
        async with engine.begin() as conn:
            result = await conn.execute(text("SELECT 1"))
            result.fetchone()
        
        return {
            "status": "healthy",
            "message": "Database connection successful",
            "pool_size": engine.pool.size(),
            "checked_out": engine.pool.checkedout(),
            "overflow": engine.pool.overflow(),
        }
    
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return {
            "status": "unhealthy",
            "message": f"Database connection failed: {str(e)}",
            "error": str(e)
        }


async def execute_raw_sql(query: str, params: Optional[dict] = None) -> list:
    """
    Execute raw SQL query (for maintenance tasks)
    Use with caution and only for administrative purposes
    """
    if async_session_factory is None:
        await create_session_factory()
    
    async with async_session_factory() as session:
        try:
            result = await session.execute(text(query), params or {})
            await session.commit()
            return result.fetchall()
        except Exception as e:
            await session.rollback()
            logger.error(f"Raw SQL execution failed: {e}")
            raise


async def cleanup_expired_records():
    """
    Cleanup expired records from all tables
    Should be called periodically by background tasks
    """
    cleanup_queries = [
        "DELETE FROM blind_signatures WHERE expires_at < NOW()",
        "DELETE FROM zkp_verifications WHERE expires_at < NOW()",
        "DELETE FROM trusted_party_keys_cache WHERE expires_at < NOW()",
        "DELETE FROM used_anonymous_ids WHERE used_at < NOW() - INTERVAL '7 days'",
        "UPDATE user_verification_requests SET status = 'expired' WHERE status = 'pending' AND expires_at < NOW()",
    ]
    
    deleted_counts = {}
    
    async with get_session() as session:
        try:
            for query in cleanup_queries:
                result = await session.execute(text(query))
                table_name = query.split("FROM ")[1].split(" WHERE")[0]
                deleted_counts[table_name] = result.rowcount
            
            await session.commit()
            logger.info(f"Cleanup completed: {deleted_counts}")
            return deleted_counts
        
        except Exception as e:
            await session.rollback()
            logger.error(f"Cleanup failed: {e}")
            raise


async def get_database_statistics() -> dict:
    """Get database statistics for monitoring"""
    stats_queries = {
        "blind_signatures_total": "SELECT COUNT(*) FROM blind_signatures",
        "blind_signatures_pending": "SELECT COUNT(*) FROM blind_signatures WHERE status = 'pending'",
        "zkp_verifications_total": "SELECT COUNT(*) FROM zkp_verifications",
        "used_anonymous_ids_total": "SELECT COUNT(*) FROM used_anonymous_ids",
        "cached_keys_total": "SELECT COUNT(*) FROM trusted_party_keys_cache",
    }
    
    statistics = {}
    
    async with get_session() as session:
        try:
            for key, query in stats_queries.items():
                result = await session.execute(text(query))
                statistics[key] = result.scalar()
            
            return statistics
        
        except Exception as e:
            logger.error(f"Failed to get database statistics: {e}")
            return {"error": str(e)}


async def close_database_connections():
    """Close all database connections (for shutdown)"""
    global engine, async_session_factory
    
    if engine is not None:
        await engine.dispose()
        engine = None
        logger.info("Database engine disposed")
    
    async_session_factory = None
    logger.info("Database connections closed")


# Dependency for FastAPI
DatabaseSession = get_database_session