"""
Configuration module for Verification Service
Handles environment variables and service settings
"""
import os
from typing import List, Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables
    """
    
    # Server configuration
    host: str = "0.0.0.0"
    port: int = 8084
    debug: bool = False
    environment: str = "development"  # development, production, testing
    
    # Database configuration
    database_url: str = "postgresql+asyncpg://postgres:adminpwd@localhost:5432/verification"
    database_pool_size: int = 10
    database_max_overflow: int = 20
    database_echo: bool = False  # SQL logging
    
    # Security
    internal_api_key: str = "super_secret_key"
    master_encryption_key: Optional[str] = None  # For encrypting private keys
    
    # External services
    poll_management_url: str = "http://localhost:8082"
    poll_management_timeout: int = 30
    
    # Cryptography settings
    rsa_key_size: int = 2048
    signature_expiry_hours: int = 24
    zkp_proof_expiry_hours: int = 1

    # Verification settings
    verification_encryption_key: str = "super_secret_verification_key_change_in_production"
    verification_request_expiry_hours: int = 24
    max_verification_file_size: int = 5 * 1024 * 1024  # 5MB
    allowed_verification_file_types: List[str] = ["image/jpeg", "image/png", "image/webp"]
    
    # Caching
    trusted_party_keys_cache_ttl: int = 3600  # 1 hour
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "json"  # json or console
    
    class Config:
        env_prefix = "VERIFICATION_"
        env_file = ".env"
        case_sensitive = False


# Global settings instance
settings = Settings()


def get_database_url() -> str:
    """Get the database URL for SQLAlchemy"""
    return settings.database_url


def is_production() -> bool:
    """Check if running in production environment"""
    return settings.environment.lower() == "production"


def is_development() -> bool:
    """Check if running in development environment"""
    return settings.environment.lower() == "development"


def is_testing() -> bool:
    """Check if running in testing environment"""
    return settings.environment.lower() == "testing"


def get_log_config() -> dict:
    """Get logging configuration based on environment"""
    if settings.log_format == "json":
        return {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "json": {
                    "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
                    "format": "%(asctime)s %(name)s %(levelname)s %(message)s"
                }
            },
            "handlers": {
                "default": {
                    "formatter": "json",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout"
                }
            },
            "root": {
                "level": settings.log_level,
                "handlers": ["default"]
            },
            "loggers": {
                "uvicorn": {"level": "INFO"},
                "uvicorn.error": {"level": "INFO"},
                "uvicorn.access": {"level": "INFO"},
                "sqlalchemy.engine": {"level": "INFO" if settings.database_echo else "WARNING"}
            }
        }
    else:
        return {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                }
            },
            "handlers": {
                "default": {
                    "formatter": "default",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout"
                }
            },
            "root": {
                "level": settings.log_level,
                "handlers": ["default"]
            }
        }