"""
Request/Response models for user verification
"""
from datetime import datetime, date
from typing import List, Optional
from pydantic import BaseModel, Field, validator
from fastapi import UploadFile


class VerificationData(BaseModel):
    """User verification document data"""
    country: str = Field(..., min_length=2, max_length=3)
    document_type: str = Field(..., max_length=50)
    first_name: str = Field(..., max_length=100)
    last_name: str = Field(..., max_length=100)
    middle_name: Optional[str] = Field(None, max_length=100)
    gender: str = Field(..., pattern=r'^(male|female|other)$')
    birth_date: str = Field(..., pattern=r'^\d{4}-\d{2}-\d{2}$')
    passport_series: Optional[str] = Field(None, max_length=10)
    passport_number: str = Field(..., max_length=20)
    department_code: Optional[str] = Field(None, max_length=10)
    issued_by: str = Field(..., max_length=200)
    issue_date: str = Field(..., pattern=r'^\d{4}-\d{2}-\d{2}$')
    registration_address: str = Field(..., max_length=500)

    @validator('birth_date', 'issue_date')
    def validate_date_format(cls, v):
        try:
            datetime.strptime(v, '%Y-%m-%d')
            return v
        except ValueError:
            raise ValueError('Date must be in YYYY-MM-DD format')


class CreateVerificationRequest(BaseModel):
    """Request to create verification request"""
    poll_id: int = Field(..., gt=0)
    verification_data: VerificationData


class VerificationDocument(BaseModel):
    """Document information"""
    document_type: str = Field(..., description="passport, selfie, or additional")
    original_filename: Optional[str] = None
    content_type: str
    file_size: int
    uploaded_at: datetime


class VerificationRequestResponse(BaseModel):
    """Response with verification request details"""
    request_uuid: str
    user_id: int
    poll_id: int
    status: str
    verification_data: VerificationData
    documents: List[VerificationDocument]
    created_at: datetime
    expires_at: datetime
    verified_at: Optional[datetime] = None
    verified_by: Optional[int] = None
    reject_reason: Optional[str] = None


class VerificationRequestSummary(BaseModel):
    """Summary of verification request for listing"""
    request_uuid: str
    user_id: int
    poll_id: int
    status: str
    full_name: str  # first_name + last_name (decrypted)
    document_type: str
    created_at: datetime
    expires_at: datetime


class ProcessVerificationRequest(BaseModel):
    """Request to process verification (approve/deny)"""
    approved: bool
    reject_reason: Optional[str] = Field(None, max_length=500)
    notes: Optional[str] = Field(None, max_length=1000)

    @validator('reject_reason')
    def validate_reject_reason(cls, v, values):
        if not values.get('approved') and not v:
            raise ValueError('Reject reason is required when denying verification')
        return v


class VerificationRequestCreated(BaseModel):
    """Response after creating verification request"""
    success: bool = True
    message: str = "Verification request created successfully"
    request_uuid: str
    expires_at: datetime
    documents_uploaded: int


class PendingVerificationRequest(BaseModel):
    """Pending verification request for trusted party"""
    request_uuid: str
    user_id: int
    poll_id: int
    full_name: str
    document_type: str
    country: str
    created_at: datetime
    expires_at: datetime
    documents_count: int


class PendingVerificationsResponse(BaseModel):
    """List of pending verification requests"""
    success: bool = True
    message: str
    requests: List[PendingVerificationRequest]
    total_count: int
    trusted_party_id: int

class UserVerificationSummary(BaseModel):
    """Summary of user's verification request (no sensitive data)"""
    request_uuid: str
    poll_id: int
    poll_title: Optional[str] = None  # If available from poll service
    status: str
    created_at: datetime
    expires_at: datetime
    verified_at: Optional[datetime] = None
    is_expired: bool
    can_resubmit: bool


class UserVerificationRequestsResponse(BaseModel):
    """Response with user's verification requests"""
    success: bool = True
    message: str
    user_id: int
    requests: List[UserVerificationSummary]
    total_count: int
    pending_count: int
    confirmed_count: int
    denied_count: int
    expired_count: int