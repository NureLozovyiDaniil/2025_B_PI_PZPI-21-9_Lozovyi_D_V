"""
Models package for Verification Service
Contains database models, request/response schemas, and data structures
"""

from .database_models import (
    Base,
    BlindSignature,
    UsedAnonymousId,
    TrustedPartyKeysCache,
    ZKProofVerification
)

from .requests import (
    BlindSignatureRequest,
    ProcessSignatureRequest,
    ZKPGenerationRequest,
    ZKPVerificationRequest,
    AnonymousIdUsageRequest,
    BatchPublicKeysRequest,
    TrustedPartyKeyRequest,
    PollInfoRequest,
    TrustedPartyInfoRequest
)

from .responses import (
    BaseResponse,
    ErrorResponse,
    HealthResponse,
    BlindSignatureResponse,
    SignatureResultResponse,
    PendingSignatureItem,
    PendingSignaturesResponse,
    ZKProofData,
    ZKPGenerationResponse,
    ZKPVerificationResponse,
    TrustedPartyKey,
    BatchPublicKeysResponse,
    StatisticsData,
    StatisticsResponse,
    AnonymousIdUsageResponse,
    ValidationResult,
    ProcessingStatus
)

__all__ = [
    # Database models
    "Base",
    "BlindSignature",
    "UsedAnonymousId", 
    "TrustedPartyKeysCache",
    "ZKProofVerification",
    
    # Request models
    "BlindSignatureRequest",
    "ProcessSignatureRequest", 
    "ZKPGenerationRequest",
    "ZKPVerificationRequest",
    "AnonymousIdUsageRequest",
    "BatchPublicKeysRequest",
    "TrustedPartyKeyRequest",
    "PollInfoRequest",
    "TrustedPartyInfoRequest",
    
    # Response models
    "BaseResponse",
    "ErrorResponse",
    "HealthResponse",
    "BlindSignatureResponse",
    "SignatureResultResponse",
    "PendingSignatureItem",
    "PendingSignaturesResponse",
    "ZKProofData",
    "ZKPGenerationResponse", 
    "ZKPVerificationResponse",
    "TrustedPartyKey",
    "BatchPublicKeysResponse",
    "StatisticsData",
    "StatisticsResponse",
    "AnonymousIdUsageResponse",
    "ValidationResult",
    "ProcessingStatus"
]