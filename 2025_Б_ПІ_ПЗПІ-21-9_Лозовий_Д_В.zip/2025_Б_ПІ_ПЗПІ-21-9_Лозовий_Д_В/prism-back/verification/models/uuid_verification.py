from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
import uuid as uuid_lib


class UUIDVerificationSession(BaseModel):
    """UUID Verification Session for mobile app integration"""
    tablename = "uuid_verification_sessions"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(UUID(as_uuid=True), unique=True, index=True, default=uuid_lib.uuid4)
    status = Column(String(20), default="pending")  # pending, scanned, completed, expired
    verification_type = Column(String(50), default="mobile_confirmation")

    # Relationships to existing models
    poll_id = Column(Integer, nullable=True)  # Will link to your poll system
    user_id = Column(Integer, nullable=True)  # Will link to your user system
    trusted_party_id = Column(Integer, nullable=True)
    verification_request_uuid = Column(String, nullable=True)  # Link to existing verification request

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    scanned_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    # Device info from mobile app
    device_model = Column(String(100), nullable=True)
    os_version = Column(String(50), nullable=True)
    app_version = Column(String(20), nullable=True)

    # Additional data
    qr_data = Column(Text, nullable=True)  # JSON with QR code data
    notes = Column(Text, nullable=True)

    def is_expired(self) -> bool:
        return datetime.utcnow() > self.expires_at

    def can_be_scanned(self) -> bool:
        return self.status == "pending" and not self.is_expired()

    def can_be_completed(self) -> bool:
        return self.status in ["pending", "scanned"] and not self.is_expired()