from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List
import json
import asyncio
from datetime import datetime


class UUIDVerificationManager:
    def init(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, uuid: str):
        await websocket.accept()
        if uuid not in self.active_connections:
            self.active_connections[uuid] = []
        self.active_connections[uuid].append(websocket)

    def disconnect(self, websocket: WebSocket, uuid: str):
        if uuid in self.active_connections:
            if websocket in self.active_connections[uuid]:
                self.active_connections[uuid].remove(websocket)
            if not self.active_connections[uuid]:
                del self.active_connections[uuid]

    async def send_status_update(self, uuid: str, status: str, data: dict = None):
        if uuid in self.active_connections:
            message = {
                "type": "status_update",
                "uuid": uuid,
                "status": status,
                "timestamp": datetime.utcnow().isoformat(),
                "data": data or {}
            }

            # Send to all connected clients for this UUID
            disconnected = []
            for connection in self.active_connections[uuid]:
                try:
                    await connection.send_text(json.dumps(message))
                except:
                    # Mark broken connections for removal
                    disconnected.append(connection)

            # Remove broken connections
            for connection in disconnected:
                self.active_connections[uuid].remove(connection)


uuid_verification_manager = UUIDVerificationManager()