"""
Cryptographic utilities for Verification Service
RSA key generation, validation, and basic crypto operations
"""
import base64
import hashlib
import secrets
from typing import Tuple, Optional

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey, RSAPrivateKey
from cryptography.exceptions import InvalidSignature


def generate_rsa_keypair(key_size: int = 2048) -> Tuple[RSAPrivateKey, RSAPublicKey]:
    """
    Generate RSA key pair for blind signatures
    
    Args:
        key_size: Size of RSA key in bits (default 2048)
        
    Returns:
        Tuple of (private_key, public_key)
    """
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key_size
    )
    public_key = private_key.public_key()
    
    return private_key, public_key


def serialize_public_key(public_key: RSAPublicKey) -> str:
    """
    Serialize RSA public key to PEM format string
    
    Args:
        public_key: RSA public key object
        
    Returns:
        PEM formatted public key string
    """
    pem_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem_bytes.decode('utf-8')


def serialize_private_key(private_key: RSAPrivateKey, password: Optional[bytes] = None) -> str:
    """
    Serialize RSA private key to PEM format string
    
    Args:
        private_key: RSA private key object
        password: Optional password for encryption
        
    Returns:
        PEM formatted private key string
    """
    encryption_algorithm = serialization.NoEncryption()
    if password:
        encryption_algorithm = serialization.BestAvailableEncryption(password)
    
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=encryption_algorithm
    )
    return pem_bytes.decode('utf-8')


def deserialize_public_key(pem_data: str) -> RSAPublicKey:
    """
    Deserialize PEM formatted public key string to RSA public key object
    
    Args:
        pem_data: PEM formatted public key string
        
    Returns:
        RSA public key object
        
    Raises:
        ValueError: If key format is invalid
    """
    try:
        public_key = serialization.load_pem_public_key(pem_data.encode('utf-8'))
        if not isinstance(public_key, RSAPublicKey):
            raise ValueError("Key is not an RSA public key")
        return public_key
    except Exception as e:
        raise ValueError(f"Invalid public key format: {e}")


def deserialize_private_key(pem_data: str, password: Optional[bytes] = None) -> RSAPrivateKey:
    """
    Deserialize PEM formatted private key string to RSA private key object
    
    Args:
        pem_data: PEM formatted private key string
        password: Optional password for decryption
        
    Returns:
        RSA private key object
        
    Raises:
        ValueError: If key format is invalid
    """
    try:
        private_key = serialization.load_pem_private_key(
            pem_data.encode('utf-8'),
            password=password
        )
        if not isinstance(private_key, RSAPrivateKey):
            raise ValueError("Key is not an RSA private key")
        return private_key
    except Exception as e:
        raise ValueError(f"Invalid private key format: {e}")


def validate_rsa_public_key(pem_data: str) -> bool:
    """
    Validate that a string contains a valid RSA public key
    
    Args:
        pem_data: PEM formatted public key string
        
    Returns:
        True if valid, False otherwise
    """
    try:
        deserialize_public_key(pem_data)
        return True
    except ValueError:
        return False


def calculate_key_hash(public_key: RSAPublicKey) -> str:
    """
    Calculate SHA256 hash of RSA public key
    
    Args:
        public_key: RSA public key object
        
    Returns:
        Hex string of SHA256 hash
    """
    pem_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return hashlib.sha256(pem_bytes).hexdigest()


def calculate_data_hash(data: str) -> str:
    """
    Calculate SHA256 hash of string data
    
    Args:
        data: Input string to hash
        
    Returns:
        Hex string of SHA256 hash
    """
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


def generate_random_salt(length: int = 16) -> str:
    """
    Generate random salt for cryptographic operations
    
    Args:
        length: Length of salt in bytes (default 16)
        
    Returns:
        Hex string of random salt
    """
    return secrets.token_hex(length)


def generate_random_uuid() -> str:
    """
    Generate cryptographically secure random UUID
    
    Returns:
        UUID string in standard format
    """
    import uuid
    return str(uuid.uuid4())


def constant_time_compare(a: str, b: str) -> bool:
    """
    Compare two strings in constant time to prevent timing attacks
    
    Args:
        a: First string
        b: Second string
        
    Returns:
        True if strings are equal, False otherwise
    """
    if len(a) != len(b):
        return False
    
    result = 0
    for x, y in zip(a, b):
        result |= ord(x) ^ ord(y)
    
    return result == 0


def encode_base64(data: bytes) -> str:
    """
    Encode bytes to base64 string
    
    Args:
        data: Bytes to encode
        
    Returns:
        Base64 encoded string
    """
    return base64.b64encode(data).decode('utf-8')


def decode_base64(data: str) -> bytes:
    """
    Decode base64 string to bytes
    
    Args:
        data: Base64 encoded string
        
    Returns:
        Decoded bytes
        
    Raises:
        ValueError: If base64 format is invalid
    """
    try:
        return base64.b64decode(data)
    except Exception as e:
        raise ValueError(f"Invalid base64 format: {e}")


def validate_signature_format(signature: str) -> bool:
    """
    Validate that signature string is in correct base64 format
    
    Args:
        signature: Base64 encoded signature string
        
    Returns:
        True if valid format, False otherwise
    """
    try:
        decoded = decode_base64(signature)
        # RSA-2048 signatures are typically 256 bytes
        return 200 <= len(decoded) <= 400
    except ValueError:
        return False


def create_deterministic_key(seed: str, key_size: int = 2048) -> Tuple[RSAPrivateKey, RSAPublicKey]:
    """
    Create deterministic RSA key pair from seed (for testing/demo)
    WARNING: This is not cryptographically secure for production!
    
    Args:
        seed: Seed string for key generation
        key_size: RSA key size in bits
        
    Returns:
        Tuple of (private_key, public_key)
    """
    # Hash seed to create deterministic entropy
    seed_hash = hashlib.sha256(seed.encode()).digest()
    
    # For demo purposes only - in production use proper key storage
    # This creates a deterministic key based on seed
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key_size
    )
    
    return private_key, private_key.public_key()


def blind_message(message: bytes, blinding_factor: int, public_key: RSAPublicKey) -> bytes:
    """
    Blind a message using RSA blinding (simplified implementation)
    
    Args:
        message: Message to blind
        blinding_factor: Random blinding factor
        public_key: RSA public key for blinding
        
    Returns:
        Blinded message bytes
    """
    # Simplified blinding implementation for demo
    # In production, use proper RSA blinding
    
    # Convert message to integer
    message_int = int.from_bytes(message, byteorder='big')
    
    # Get public key components
    public_numbers = public_key.public_numbers()
    n = public_numbers.n
    e = public_numbers.e
    
    # Blind: m' = m * r^e mod n
    blinded = (message_int * pow(blinding_factor, e, n)) % n
    
    # Convert back to bytes
    byte_length = (blinded.bit_length() + 7) // 8
    return blinded.to_bytes(byte_length, byteorder='big')


def unblind_signature(blinded_signature: bytes, blinding_factor: int, public_key: RSAPublicKey) -> bytes:
    """
    Unblind a signature (simplified implementation)
    
    Args:
        blinded_signature: Blinded signature bytes
        blinding_factor: Original blinding factor
        public_key: RSA public key for unblinding
        
    Returns:
        Unblinded signature bytes
    """
    # Simplified unblinding implementation for demo
    # In production, use proper RSA unblinding
    
    # Convert signature to integer
    sig_int = int.from_bytes(blinded_signature, byteorder='big')
    
    # Get public key components
    public_numbers = public_key.public_numbers()
    n = public_numbers.n
    
    # Unblind: s = s' * r^(-1) mod n
    r_inv = pow(blinding_factor, -1, n)
    unblinded = (sig_int * r_inv) % n
    
    # Convert back to bytes
    byte_length = (unblinded.bit_length() + 7) // 8
    return unblinded.to_bytes(byte_length, byteorder='big')