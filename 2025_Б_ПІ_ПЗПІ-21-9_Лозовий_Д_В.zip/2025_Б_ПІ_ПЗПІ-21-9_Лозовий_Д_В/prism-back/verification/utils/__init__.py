"""
Utilities package for Verification Service
Contains crypto utilities and external service clients
"""

from .crypto import (
    generate_rsa_keypair,
    serialize_public_key,
    serialize_private_key,
    deserialize_public_key,
    deserialize_private_key,
    validate_rsa_public_key,
    calculate_key_hash,
    calculate_data_hash,
    generate_random_salt,
    generate_random_uuid,
    constant_time_compare,
    encode_base64,
    decode_base64,
    validate_signature_format,
    create_deterministic_key,
    blind_message,
    unblind_signature
)

from .poll_client import (
    PollManagementClient,
    PollManagementClientError,
    PollNotFoundError,
    TrustedPartyNotFoundError,
    get_poll_client,
    close_poll_client
)

__all__ = [
    # Crypto utilities
    "generate_rsa_keypair",
    "serialize_public_key",
    "serialize_private_key", 
    "deserialize_public_key",
    "deserialize_private_key",
    "validate_rsa_public_key",
    "calculate_key_hash",
    "calculate_data_hash",
    "generate_random_salt",
    "generate_random_uuid",
    "constant_time_compare",
    "encode_base64",
    "decode_base64",
    "validate_signature_format",
    "create_deterministic_key",
    "blind_message",
    "unblind_signature",
    
    # Poll Management client
    "PollManagementClient",
    "PollManagementClientError",
    "PollNotFoundError", 
    "TrustedPartyNotFoundError",
    "get_poll_client",
    "close_poll_client"
]