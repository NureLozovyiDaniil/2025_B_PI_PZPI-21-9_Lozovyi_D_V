package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	inLogger "poll-management-service/internal/logger"
	"poll-management-service/internal/model"

	"go.uber.org/zap"
)

type VerificationClientInterface struct {
}

type VerificationClient struct {
	baseURL    string
	httpClient *http.Client
	apiKey     string
	logger     *zap.Logger
}

type ZKPVerificationRequest struct {
	PollID      int                    `json:"poll_id"`
	AnonymousID string                 `json:"anonymous_id"`
	Proof       map[string]interface{} `json:"proof"`
}

type ZKPVerificationResponse struct {
	Success        bool      `json:"success"`
	Message        string    `json:"message"`
	Valid          bool      `json:"valid"`
	AnonymousID    string    `json:"anonymous_id"`
	ProofHash      string    `json:"proof_hash"`
	TrustedPartyID int       `json:"trusted_party_id"`
	VerifiedAt     time.Time `json:"verified_at"`
	CanVote        bool      `json:"can_vote"`
}

type AnonymousIDCheckResponse struct {
	Success     bool   `json:"success"`
	PollID      int    `json:"poll_id"`
	AnonymousID string `json:"anonymous_id"`
	IsUsed      bool   `json:"is_used"`
	CanVote     bool   `json:"can_vote"`
	Message     string `json:"message"`
}

type VerificationHealthResponse struct {
	Status    string `json:"status"`
	Service   string `json:"service"`
	Timestamp int64  `json:"timestamp"`
}

type VerificationErrorResponse struct {
	Error   string `json:"error"`
	Message string `json:"message"`
	Code    int    `json:"code,omitempty"`
}

func NewVerificationClient(baseURL, apiKey string, logger *zap.Logger) *VerificationClient {
	return &VerificationClient{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 30 * time.Second,
			Transport: &http.Transport{
				MaxIdleConns:       10,
				IdleConnTimeout:    30 * time.Second,
				DisableCompression: true,
			},
		},
		apiKey: apiKey,
		logger: logger,
	}
}

func (c *VerificationClient) VerifyZKProof(
	ctx context.Context,
	pollID uint,
	anonymousID string,
	proof map[string]interface{},
) (*ZKPVerificationResponse, error) {
	request := ZKPVerificationRequest{
		PollID:      int(pollID),
		AnonymousID: anonymousID,
		Proof:       proof,
	}

	response := &ZKPVerificationResponse{}
	err := c.doRequest(ctx, "POST", "/api/v1/zkp/verify", request, response)
	if err != nil {
		c.logger.Error("Failed to verify ZKP proof",
			zap.Uint("poll_id", pollID),
			zap.String("anonymous_id", anonymousID),
			zap.Error(err))
		return nil, fmt.Errorf("ZKP verification failed: %w", err)
	}

	c.logger.Info("ZKP proof verification completed",
		zap.Uint("poll_id", pollID),
		zap.String("anonymous_id", anonymousID),
		zap.Bool("valid", response.Valid),
		zap.Bool("can_vote", response.CanVote))

	return response, nil
}

func (c *VerificationClient) CheckAnonymousID(
	ctx context.Context,
	pollID uint,
	anonymousID string,
) (*AnonymousIDCheckResponse, error) {
	endpoint := fmt.Sprintf("/api/v1/zkp/check-usage/%d/%s", pollID, anonymousID)

	response := &AnonymousIDCheckResponse{}
	err := c.doRequest(ctx, "GET", endpoint, nil, response)
	if err != nil {
		c.logger.Error("Failed to check anonymous ID usage",
			zap.Uint("poll_id", pollID),
			zap.String("anonymous_id", anonymousID),
			zap.Error(err))
		return nil, fmt.Errorf("anonymous ID check failed: %w", err)
	}

	c.logger.Debug("Anonymous ID check completed",
		zap.Uint("poll_id", pollID),
		zap.String("anonymous_id", anonymousID),
		zap.Bool("is_used", response.IsUsed),
		zap.Bool("can_vote", response.CanVote))

	return response, nil
}

func (c *VerificationClient) Health(ctx context.Context) (*VerificationHealthResponse, error) {
	response := &VerificationHealthResponse{}
	err := c.doRequest(ctx, "GET", "/health", nil, response)
	if err != nil {
		c.logger.Error("Verification Service health check failed", zap.Error(err))
		return nil, fmt.Errorf("health check failed: %w", err)
	}

	c.logger.Debug("Verification Service health check passed",
		zap.String("status", response.Status))

	return response, nil
}

func (c *VerificationClient) doRequest(
	ctx context.Context,
	method, endpoint string,
	requestBody interface{},
	responseBody interface{},
) error {
	url := c.baseURL + endpoint

	var reqBody io.Reader
	if requestBody != nil {
		jsonData, err := json.Marshal(requestBody)
		if err != nil {
			return fmt.Errorf("failed to marshal request: %w", err)
		}
		reqBody = bytes.NewBuffer(jsonData)
	}

	var lastErr error
	for attempt := 1; attempt <= 3; attempt++ {
		if attempt > 1 {
			// Exponential backoff: 1s, 2s, 4s
			delay := time.Duration(1<<(attempt-2)) * time.Second
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(delay):
			}

			c.logger.Warn("Retrying Verification Service request",
				zap.Int("attempt", attempt),
				zap.String("method", method),
				zap.String("endpoint", endpoint))
		}

		req, err := http.NewRequestWithContext(ctx, method, url, reqBody)
		if err != nil {
			lastErr = fmt.Errorf("failed to create request: %w", err)
			continue
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Internal-API-Key", c.apiKey)
		req.Header.Set("User-Agent", "poll-management-service/1.0")

		if requestID := inLogger.GetRequestID(ctx); requestID != "" {
			req.Header.Set("X-Request-ID", requestID)
		}

		resp, err := c.httpClient.Do(req)
		if err != nil {
			lastErr = fmt.Errorf("HTTP request failed: %w", err)
			continue
		}
		defer resp.Body.Close()

		body, err := io.ReadAll(resp.Body)
		if err != nil {
			lastErr = fmt.Errorf("failed to read response: %w", err)
			continue
		}

		if resp.StatusCode >= 200 && resp.StatusCode < 300 {

			if responseBody != nil {
				if err := json.Unmarshal(body, responseBody); err != nil {
					lastErr = fmt.Errorf("failed to unmarshal response: %w", err)
					continue
				}
			}
			return nil
		}

		lastErr = c.handleErrorResponse(resp.StatusCode, body, endpoint)

		if resp.StatusCode >= 400 && resp.StatusCode < 500 {
			break
		}
	}

	return lastErr
}

func (c *VerificationClient) handleErrorResponse(statusCode int, body []byte, endpoint string) error {

	var errorResp VerificationErrorResponse
	if err := json.Unmarshal(body, &errorResp); err != nil {

		return &model.AppError{
			Code:    model.ErrCodeVerificationError,
			Message: fmt.Sprintf("Verification Service error (status %d)", statusCode),
			Details: string(body),
		}
	}

	var appErrorCode model.ErrorCode
	switch statusCode {
	case 400:
		appErrorCode = model.ErrCodeInvalidInput
	case 401:
		appErrorCode = model.ErrCodeUnauthorized
	case 404:
		appErrorCode = model.ErrCodeNotFound
	case 409:
		appErrorCode = model.ErrCodeAlreadyExists
	case 422:
		appErrorCode = model.ErrCodeInvalidZKProof
	default:
		appErrorCode = model.ErrCodeVerificationError
	}

	return &model.AppError{
		Code:    appErrorCode,
		Message: errorResp.Message,
		Details: fmt.Sprintf("Verification Service error at %s: %s", endpoint, errorResp.Error),
	}
}

func (c *VerificationClient) ValidateConfig() error {
	if c.baseURL == "" {
		return fmt.Errorf("verification service base URL is required")
	}
	if c.apiKey == "" {
		return fmt.Errorf("verification service API key is required")
	}
	return nil
}

func (c *VerificationClient) GetBaseURL() string {
	return c.baseURL
}
