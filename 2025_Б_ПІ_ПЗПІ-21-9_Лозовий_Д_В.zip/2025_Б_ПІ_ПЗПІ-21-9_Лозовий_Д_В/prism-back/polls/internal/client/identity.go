package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"
)

// IdentityClientInterface   Identity Service
type IdentityClientInterface interface {
	ValidateVoter(ctx context.Context, jwtToken string) (*UserValidationResponse, error)
	FindUserByEmail(ctx context.Context, email string) (*FindUserResponse, error)

	GetUserByID(ctx context.Context, userID uint) (*FindUserResponse, error)
}

// IdentityClient     Identity Service
type IdentityClient struct {
	baseURL    string
	httpClient *http.Client
}

// NewIdentityClient    Identity Service
func NewIdentityClient(baseURL string) *IdentityClient {
	return &IdentityClient{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

// UserValidationResponse   Identity Service   
type UserValidationResponse struct {
	UserID   uint     `json:"user_id"`
	Email    string   `json:"email"`
	IsActive bool     `json:"is_active"`
	CanVote  bool     `json:"can_vote"`
	Roles    []string `json:"roles"`
}

// FindUserRequest      email
type FindUserRequest struct {
	Email string `json:"email"`
}

// FindUserResponse      
type FindUserResponse struct {
	UserID    uint   `json:"user_id"`
	Email     string `json:"email"`
	PublicKey string `json:"public_key"`
	IsActive  bool   `json:"is_active"`
}

// ValidateVoter     
func (c *IdentityClient) ValidateVoter(ctx context.Context, jwtToken string) (*UserValidationResponse, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/internal/validate-voter", nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Authorization", "Bearer "+jwtToken)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var result UserValidationResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

// FindUserByEmail    email (   )
func (c *IdentityClient) FindUserByEmail(ctx context.Context, email string) (*FindUserResponse, error) {
	requestBody := FindUserRequest{Email: email}
	bodyBytes, err := json.Marshal(requestBody)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/internal/user-by-email/"+email, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("user not found")
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	var result FindUserResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

func (c *IdentityClient) GetUserByID(ctx context.Context, userID uint) (*FindUserResponse, error) {

	var response FindUserResponse
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/internal/users/"+strconv.Itoa(int(userID)), nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("X-Internal-API-Key", "super_secret_key")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		var res map[string]interface{}
		err := json.NewDecoder(resp.Body).Decode(&res)
		fmt.Println(err, res)
		return nil, fmt.Errorf("identity service returned status %d", resp.StatusCode)
	}

	if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	if response.PublicKey == "" {
		return nil, fmt.Errorf("user %d has no public key", userID)
	}

	if len(response.PublicKey) < 66 || len(response.PublicKey) > 130 {
		return nil, fmt.Errorf("invalid public key format for user %d", userID)
	}

	return &response, nil
}
