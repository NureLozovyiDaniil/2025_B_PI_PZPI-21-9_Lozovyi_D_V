package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

type BlockchainClientInterface interface {
	RegisterPoll(ctx context.Context, req RegisterPollRequest) (*TransactionResponse, error)
	RecordVote(ctx context.Context, req RecordVoteRequest) (*TransactionResponse, error)
	RecordAnonymousVote(ctx context.Context, req RecordVoteRequest) (*TransactionResponse, error)
	GetTransactionStatus(ctx context.Context, txHash string) (*TransactionStatusResponse, error)
	StoreResults(ctx context.Context, req StoreResultsRequest) (*TransactionResponse, error)
}

type BlockchainClient struct {
	baseURL    string
	httpClient *http.Client
}

func NewBlockchainClient(baseURL string) *BlockchainClient {
	return &BlockchainClient{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 60 * time.Second,
		},
	}
}

type RegisterPollRequest struct {
	PollID      uint      `json:"poll_id"`
	CreatorID   uint      `json:"creator_id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Category    string    `json:"category"`
	StartTime   time.Time `json:"start_time"`
	EndTime     time.Time `json:"end_time"`
	IsPrivate   bool      `json:"is_private"`
	OptionsHash string    `json:"options_hash"`
}

type RecordVoteRequest struct {
	PollID      uint    `json:"poll_id"`
	OptionID    uint    `json:"option_id"`
	UserID      *uint   `json:"user_id,omitempty"`
	AnonymousID *string `json:"anonymous_id,omitempty"`
	OptionsHash string  `json:"options_hash"`
}

type StoreResultsRequest struct {
	PollID uint `json:"poll_id"`
	//TotalVotes   int    `json:"total_votes"`
	//WinnerOption uint   `json:"winner_option"`
	OptionCounts []int  `json:"option_counts"`
	ResultHash   string `json:"result_hash"`
}

type AddTrustedPartyRequest struct {
	PollID    uint   `json:"poll_id"`
	UserID    uint   `json:"user_id"`
	PublicKey string `json:"public_key"`
}

type RemoveTrustedPartyRequest struct {
	PollID uint `json:"poll_id"`
	UserID uint `json:"user_id"`
}

type TransactionResponse struct {
	TxHash      string  `json:"tx_hash"`
	Status      string  `json:"status"` // pending, confirmed, failed
	BlockNumber *uint64 `json:"block_number,omitempty"`
	GasUsed     *uint64 `json:"gas_used,omitempty"`
	Error       *string `json:"error,omitempty"`
}

type TransactionStatusResponse struct {
	TxHash      string  `json:"tx_hash"`
	Status      string  `json:"status"`
	BlockNumber *uint64 `json:"block_number,omitempty"`
	GasUsed     *uint64 `json:"gas_used,omitempty"`
	Error       *string `json:"error,omitempty"`
}

func (c *BlockchainClient) RegisterPoll(ctx context.Context, req RegisterPollRequest) (*TransactionResponse, error) {
	bodyBytes, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/api/v1/polls/register", bytes.NewBuffer(bodyBytes))
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)

		str := string(body)

		return nil, fmt.Errorf("blockchain service returned status %d. Error: %s", resp.StatusCode, str)
	}

	var result TransactionResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

func (c *BlockchainClient) RecordVote(ctx context.Context, req RecordVoteRequest) (*TransactionResponse, error) {
	bodyBytes, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/api/v1/votes/record", bytes.NewBuffer(bodyBytes))
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("blockchain service returned status %d", resp.StatusCode)
	}

	var result TransactionResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

func (c *BlockchainClient) RecordAnonymousVote(ctx context.Context, req RecordVoteRequest) (*TransactionResponse, error) {
	bodyBytes, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx,
		"POST",
		c.baseURL+"/api/v1/votes/record-anonymous",
		bytes.NewBuffer(bodyBytes),
	)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("blockchain service returned status %d", resp.StatusCode)
	}

	var result TransactionResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

func (c *BlockchainClient) StoreResults(ctx context.Context, req StoreResultsRequest) (*TransactionResponse, error) {
	bodyBytes, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/api/v1/results/store", bytes.NewBuffer(bodyBytes))
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("blockchain service returned status %d", resp.StatusCode)
	}

	var result TransactionResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}

func (c *BlockchainClient) GetTransactionStatus(ctx context.Context, txHash string) (*TransactionStatusResponse, error) {
	httpReq, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/api/v1/transactions/"+txHash+"/status", nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("making request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("transaction not found")
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("blockchain service returned status %d", resp.StatusCode)
	}

	var result TransactionStatusResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decoding response: %w", err)
	}

	return &result, nil
}
