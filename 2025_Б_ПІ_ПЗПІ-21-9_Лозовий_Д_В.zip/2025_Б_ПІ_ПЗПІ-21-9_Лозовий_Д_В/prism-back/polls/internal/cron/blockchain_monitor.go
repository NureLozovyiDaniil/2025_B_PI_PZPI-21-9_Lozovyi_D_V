package cron

import (
	"context"
	"fmt"
	"log"
	"time"

	"poll-management-service/internal/client"
	"poll-management-service/internal/config"
	"poll-management-service/internal/model"
	"poll-management-service/internal/repository"

	"github.com/robfig/cron/v3"
)

type BlockchainMonitor struct {
	repository       *repository.Repository
	blockchainClient client.BlockchainClientInterface
	config           *config.Config
	cron             *cron.Cron
	logger           *log.Logger
	isRunning        bool
}

func NewBlockchainMonitor(
	repo *repository.Repository,
	blockchainClient client.BlockchainClientInterface,
	cfg *config.Config,
	logger *log.Logger,
) *BlockchainMonitor {

	c := cron.New(
		cron.WithLocation(time.UTC),
		cron.WithLogger(cron.VerbosePrintfLogger(logger)),
	)

	return &BlockchainMonitor{
		repository:       repo,
		blockchainClient: blockchainClient,
		config:           cfg,
		cron:             c,
		logger:           logger,
	}
}

func (bm *BlockchainMonitor) Start() error {
	if !bm.config.Cron.EnableJobs {
		bm.logger.Println("Blockchain monitor disabled by config")
		return nil
	}

	if bm.isRunning {
		bm.logger.Println("Blockchain monitor already running")
		return nil
	}

	cronExpr := convertIntervalToCronExpr(bm.config.Cron.BlockchainMonitorInterval)

	_, err := bm.cron.AddFunc(cronExpr, bm.monitorTransactionsJob)
	if err != nil {
		return err
	}

	bm.cron.Start()
	bm.isRunning = true

	bm.logger.Printf("Blockchain monitor started with interval %v (%s)",
		bm.config.Cron.BlockchainMonitorInterval, cronExpr)

	return nil
}

func (bm *BlockchainMonitor) Stop() {
	if !bm.isRunning {
		return
	}

	ctx := bm.cron.Stop()
	select {
	case <-ctx.Done():
		bm.logger.Println("Blockchain monitor stopped gracefully")
	case <-time.After(30 * time.Second):
		bm.logger.Println("Blockchain monitor stop timeout, forcing shutdown")
	}

	bm.isRunning = false
}

func (bm *BlockchainMonitor) monitorTransactionsJob() {
	startTime := time.Now().UTC()
	bm.logger.Println("Starting blockchain monitoring job...")

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()

	processedPending, err := bm.processPendingTransactions(ctx)
	if err != nil {
		bm.logger.Printf("Error processing pending transactions: %v", err)
	}

	processedFailed, err := bm.processFailedTransactions(ctx)
	if err != nil {
		bm.logger.Printf("Error processing failed transactions: %v", err)
	}

	duration := time.Since(startTime)
	bm.logger.Printf("Blockchain monitoring completed in %v (pending: %d, retried: %d)",
		duration, processedPending, processedFailed)
}

func (bm *BlockchainMonitor) processPendingTransactions(ctx context.Context) (int, error) {
	pendingTxs, err := bm.repository.BlockchainTransaction.GetPendingTransactions(ctx)
	if err != nil {
		return 0, fmt.Errorf("getting pending transactions: %w", err)
	}

	if len(pendingTxs) == 0 {
		bm.logger.Println("No pending transactions found")
		return 0, nil
	}

	bm.logger.Printf("Processing %d pending transactions", len(pendingTxs))

	processed := 0
	for _, tx := range pendingTxs {
		if err := bm.checkTransactionStatus(ctx, &tx); err != nil {
			bm.logger.Printf("Error checking transaction %s: %v", safeString(tx.TxHash), err)
			continue
		}
		processed++
	}

	return processed, nil
}

func (bm *BlockchainMonitor) processFailedTransactions(ctx context.Context) (int, error) {

	failedTxs, err := bm.repository.BlockchainTransaction.GetFailedTransactions(ctx)
	if err != nil {
		return 0, fmt.Errorf("getting failed transactions: %w", err)
	}

	if len(failedTxs) == 0 {
		return 0, nil
	}

	bm.logger.Printf("Found %d failed transactions for potential retry", len(failedTxs))

	retried := 0
	for _, tx := range failedTxs {

		if tx.RetryCount >= bm.config.Blockchain.RetryAttempts {
			continue
		}

		timeSinceUpdate := time.Since(tx.UpdatedAt)
		if timeSinceUpdate < 5*time.Minute {
			continue
		}

		if err := bm.retryTransaction(ctx, &tx); err != nil {
			bm.logger.Printf("Error retrying transaction %d: %v", tx.ID, err)
			continue
		}
		retried++
	}

	return retried, nil
}

func (bm *BlockchainMonitor) checkTransactionStatus(ctx context.Context, tx *model.BlockchainTransaction) error {
	if tx.TxHash == nil || *tx.TxHash == "" {
		bm.logger.Printf("Transaction %d has no hash, skipping", tx.ID)
		return nil
	}

	status, err := bm.blockchainClient.GetTransactionStatus(ctx, *tx.TxHash)
	if err != nil {
		bm.logger.Printf("Failed to get status for transaction %s: %v", *tx.TxHash, err)
		return err
	}

	switch status.Status {
	case "confirmed":
		bm.logger.Printf("Transaction %s confirmed in block %d", *tx.TxHash, safeUint64(status.BlockNumber))
		return bm.repository.BlockchainTransaction.MarkAsConfirmed(
			ctx, tx.ID, safeUint64(status.BlockNumber), safeUint64(status.GasUsed))

	case "failed":
		errorMsg := "transaction failed in blockchain"
		if status.Error != nil {
			errorMsg = *status.Error
		}
		bm.logger.Printf("Transaction %s failed: %s", *tx.TxHash, errorMsg)
		return bm.repository.BlockchainTransaction.MarkAsFailed(ctx, tx.ID, errorMsg)

	case "pending":

		if time.Since(tx.CreatedAt) > bm.config.Blockchain.TransactionTimeout {
			timeoutMsg := fmt.Sprintf("transaction timeout after %v", bm.config.Blockchain.TransactionTimeout)
			bm.logger.Printf("Transaction %s timed out", *tx.TxHash)
			return bm.repository.BlockchainTransaction.MarkAsFailed(ctx, tx.ID, timeoutMsg)
		}

		bm.logger.Printf("Transaction %s still pending", *tx.TxHash)

	default:
		bm.logger.Printf("Unknown transaction status '%s' for %s", status.Status, *tx.TxHash)
	}

	return nil
}

func (bm *BlockchainMonitor) retryTransaction(ctx context.Context, tx *model.BlockchainTransaction) error {
	bm.logger.Printf("Retrying transaction %d (attempt %d/%d)",
		tx.ID, tx.RetryCount+1, bm.config.Blockchain.RetryAttempts)

	if err := bm.repository.BlockchainTransaction.IncrementRetryCount(ctx, tx.ID); err != nil {
		return fmt.Errorf("incrementing retry count: %w", err)
	}

	bm.logger.Printf("Retry logic not implemented yet for transaction %d", tx.ID)

	return nil
}

func (bm *BlockchainMonitor) IsRunning() bool {
	return bm.isRunning
}

func (bm *BlockchainMonitor) GetNextRun() time.Time {
	entries := bm.cron.Entries()
	if len(entries) > 0 {
		return entries[0].Next
	}
	return time.Time{}
}

func (bm *BlockchainMonitor) RunNow() error {
	if !bm.isRunning {
		return nil
	}

	bm.logger.Println("Running blockchain monitoring manually...")

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()

	_, err1 := bm.processPendingTransactions(ctx)
	_, err2 := bm.processFailedTransactions(ctx)

	if err1 != nil {
		return err1
	}
	return err2
}

func (bm *BlockchainMonitor) GetStats(ctx context.Context) (map[string]int, error) {
	pending, err := bm.repository.BlockchainTransaction.GetPendingTransactions(ctx)
	if err != nil {
		return nil, err
	}

	failed, err := bm.repository.BlockchainTransaction.GetFailedTransactions(ctx)
	if err != nil {
		return nil, err
	}

	return map[string]int{
		"pending_transactions": len(pending),
		"failed_transactions":  len(failed),
		"is_running":           boolToInt(bm.isRunning),
	}, nil
}

// Helper functions

func safeString(ptr *string) string {
	if ptr == nil {
		return ""
	}
	return *ptr
}

func safeUint64(ptr *uint64) uint64 {
	if ptr == nil {
		return 0
	}
	return *ptr
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}
