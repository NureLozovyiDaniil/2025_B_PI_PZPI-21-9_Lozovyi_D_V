package repository

import (
	"context"
	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

// PollRepository     
type PollRepository interface {
	Create(ctx context.Context, poll *model.Poll) error
	GetByID(ctx context.Context, id uint) (*model.Poll, error)
	Update(ctx context.Context, poll *model.Poll) error
	Delete(ctx context.Context, id uint) error

	    
	List(ctx context.Context, filter model.PollFilter, pagination model.Pagination) ([]model.Poll, model.PaginationResult, error)
	ListByCreator(ctx context.Context, creatorID uint, pagination model.Pagination) ([]model.Poll, model.PaginationResult, error)

	-
	GetActivePolls(ctx context.Context, pagination model.Pagination) ([]model.Poll, model.PaginationResult, error)
	GetPollsToFinalize(ctx context.Context) ([]model.Poll, error)
	UpdateStatus(ctx context.Context, id uint, status model.PollStatus) error
	SetBlockchainTxHash(ctx context.Context, id uint, txHash string) error

	
	ExistsByID(ctx context.Context, id uint) (bool, error)
	IsCreator(ctx context.Context, pollID, userID uint) (bool, error)
}

// OptionRepository      
type OptionRepository interface {
	// CRUD 
	CreateBatch(ctx context.Context, options []model.Option) error
	GetByPollID(ctx context.Context, pollID uint) ([]model.Option, error)
	GetByID(ctx context.Context, id uint) (*model.Option, error)

	
	ExistsByID(ctx context.Context, id uint) (bool, error)
	BelongsToPoll(ctx context.Context, optionID, pollID uint) (bool, error)
}

// VoteRepository     
type VoteRepository interface {
	 
	Create(ctx context.Context, vote *model.Vote) error

	 
	GetByPollID(ctx context.Context, pollID uint) ([]model.Vote, error)
	CountByPollID(ctx context.Context, pollID uint) (int, error)
	CountByOptionID(ctx context.Context, optionID uint) (int, error)

	 
	HasUserVoted(ctx context.Context, pollID, userID uint) (bool, error)
	HasAnonymousVoted(ctx context.Context, pollID uint, anonymousID string) (bool, error)

	
	GetVoteStatsByPoll(ctx context.Context, pollID uint) ([]model.OptionResult, error)

	
	SetBlockchainTx(ctx context.Context, id uint, txHash string) error
}

// TrustedPartyRepository      
type TrustedPartyRepository interface {
	// CRUD 
	Create(ctx context.Context, trustedParty *model.TrustedParty) error
	GetByPollID(ctx context.Context, pollID uint) ([]model.TrustedParty, error)
	CountByPollID(ctx context.Context, pollID uint) (int, error)
	DeleteByUserAndPoll(ctx context.Context, userID, pollID uint) error
	Delete(ctx context.Context, id uint) error

	
	GetByUserAndPoll(ctx context.Context, userID, pollID uint) (*model.TrustedParty, error)

	
	IsTrustedParty(ctx context.Context, userID, pollID uint) (bool, error)
	ExistsByUserAndPoll(ctx context.Context, userID, pollID uint) (bool, error)
}

// BlockchainTransactionRepository      
type BlockchainTransactionRepository interface {
	  
	Create(ctx context.Context, tx *model.BlockchainTransaction) error
	Update(ctx context.Context, tx *model.BlockchainTransaction) error

	
	GetByID(ctx context.Context, id uint) (*model.BlockchainTransaction, error)
	GetByTxHash(ctx context.Context, txHash string) (*model.BlockchainTransaction, error)
	GetByEntity(ctx context.Context, entityType string, entityID uint) ([]model.BlockchainTransaction, error)

	  
	GetPendingTransactions(ctx context.Context) ([]model.BlockchainTransaction, error)
	GetFailedTransactions(ctx context.Context) ([]model.BlockchainTransaction, error)

	 
	MarkAsConfirmed(ctx context.Context, id uint, blockNumber uint64, gasUsed uint64) error
	MarkAsFailed(ctx context.Context, id uint, errorMsg string) error
	IncrementRetryCount(ctx context.Context, id uint) error
}

// ResultRepository      
type ResultRepository interface {
	// CRUD 
	Create(ctx context.Context, result *model.PollResult) error
	Update(ctx context.Context, result *model.PollResult) error
	GetByPollID(ctx context.Context, pollID uint) (*model.PollResult, error)

	   
	CreateOptionResults(ctx context.Context, results []model.OptionResult) error
	GetOptionResultsByPoll(ctx context.Context, pollID uint) ([]model.OptionResult, error)

	
	ExistsByPollID(ctx context.Context, pollID uint) (bool, error)
}

// Repository     
type Repository struct {
	Poll                  PollRepository
	Option                OptionRepository
	Vote                  VoteRepository
	TrustedParty          TrustedPartyRepository
	BlockchainTransaction BlockchainTransactionRepository
	Result                ResultRepository
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{
		Poll:                  NewPollRepository(db),
		Option:                NewOptionRepository(db),
		Vote:                  NewVoteRepository(db),
		TrustedParty:          NewTrustedPartyRepository(db),
		BlockchainTransaction: NewBlockchainTransactionRepository(db),
		Result:                NewResultRepository(db),
	}
}
