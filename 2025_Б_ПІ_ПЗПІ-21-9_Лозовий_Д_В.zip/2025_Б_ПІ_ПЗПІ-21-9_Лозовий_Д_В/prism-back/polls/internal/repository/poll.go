package repository

import (
	"context"
	"time"

	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

// pollRepository   PollRepository
type pollRepository struct {
	db *gorm.DB
}

// NewPollRepository    poll repository
func NewPollRepository(db *gorm.DB) PollRepository {
	return &pollRepository{db: db}
}

// Create       
func (r *pollRepository) Create(ctx context.Context, poll *model.Poll) error {
	return ExecuteInTransaction(ctx, r.db, func(tx *gorm.DB) error {

		if err := tx.Create(poll).Error; err != nil {
			return err
		}

		if len(poll.Options) > 0 {
			for i := range poll.Options {
				poll.Options[i].PollID = poll.ID
			}
			if err := tx.Create(&poll.Options).Error; err != nil {
				return err
			}
		}

		return nil
	})
}

// GetByID    ID    
func (r *pollRepository) GetByID(ctx context.Context, id uint) (*model.Poll, error) {
	var poll model.Poll
	err := r.db.WithContext(ctx).
		Preload("Options").
		Preload("TrustedParties").
		First(&poll, id).Error

	if err != nil {
		return nil, err
	}

	return &poll, nil
}

// Update   
func (r *pollRepository) Update(ctx context.Context, poll *model.Poll) error {
	return r.db.WithContext(ctx).Save(poll).Error
}

// Delete   
func (r *pollRepository) Delete(ctx context.Context, id uint) error {
	return r.db.WithContext(ctx).Delete(&model.Poll{}, id).Error
}

// List       
func (r *pollRepository) List(
	ctx context.Context,
	filter model.PollFilter,
	pagination model.Pagination,
) ([]model.Poll, model.PaginationResult, error) {
	query := r.db.WithContext(ctx).Model(&model.Poll{})

	query = ApplyPollFilter(query, filter)

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("created_at DESC")

	var polls []model.Poll
	err = query.Preload("Options").Find(&polls).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return polls, paginationResult, nil
}

// ListByCreator    
func (r *pollRepository) ListByCreator(
	ctx context.Context,
	creatorID uint,
	pagination model.Pagination,
) ([]model.Poll, model.PaginationResult, error) {
	query := r.db.Table("polls").WithContext(ctx).Where("creator_id = ?", creatorID)

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("created_at DESC")

	var polls []model.Poll
	err = query.Preload("Options").Find(&polls).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return polls, paginationResult, nil
}

// GetActivePolls   
func (r *pollRepository) GetActivePolls(
	ctx context.Context,
	pagination model.Pagination,
) ([]model.Poll, model.PaginationResult, error) {
	now := time.Now().UTC()
	query := r.db.WithContext(ctx).Where(
		"status = ? AND start_time <= ? AND end_time > ?",
		model.PollStatusActive, now, now,
	)

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("end_time ASC")

	var polls []model.Poll
	err = query.Preload("Options").Find(&polls).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return polls, paginationResult, nil
}

// GetPollsToFinalize  ,   
func (r *pollRepository) GetPollsToFinalize(ctx context.Context) ([]model.Poll, error) {
	now := time.Now().UTC()
	var polls []model.Poll

	err := r.db.WithContext(ctx).
		Where("status = ? AND end_time <= ?", model.PollStatusActive, now).
		Preload("Options").
		Find(&polls).Error

	return polls, err
}

// UpdateStatus   
func (r *pollRepository) UpdateStatus(ctx context.Context, id uint, status model.PollStatus) error {
	return r.db.WithContext(ctx).
		Model(&model.Poll{}).
		Where("id = ?", id).
		Update("status", status).Error
}

// SetBlockchainTxHash    
func (r *pollRepository) SetBlockchainTxHash(ctx context.Context, id uint, txHash string) error {
	return r.db.WithContext(ctx).
		Model(&model.Poll{}).
		Where("id = ?", id).
		Update("blockchain_tx_hash", txHash).Error
}

// ExistsByID     ID
func (r *pollRepository) ExistsByID(ctx context.Context, id uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Poll{}).
		Where("id = ?", id).
		Count(&count).Error

	return count > 0, err
}

// IsCreator ,     
func (r *pollRepository) IsCreator(ctx context.Context, pollID, userID uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Poll{}).
		Where("id = ? AND creator_id = ?", pollID, userID).
		Count(&count).Error

	return count > 0, err
}

// optionRepository   OptionRepository
type optionRepository struct {
	db *gorm.DB
}

// NewOptionRepository    option repository
func NewOptionRepository(db *gorm.DB) OptionRepository {
	return &optionRepository{db: db}
}

// CreateBatch    
func (r *optionRepository) CreateBatch(ctx context.Context, options []model.Option) error {
	if len(options) == 0 {
		return nil
	}

	return r.db.WithContext(ctx).Create(&options).Error
}

// GetByPollID     
func (r *optionRepository) GetByPollID(ctx context.Context, pollID uint) ([]model.Option, error) {
	var options []model.Option
	err := r.db.WithContext(ctx).
		Where("poll_id = ?", pollID).
		Order("id ASC").
		Find(&options).Error

	return options, err
}

// GetByID    ID
func (r *optionRepository) GetByID(ctx context.Context, id uint) (*model.Option, error) {
	var option model.Option
	err := r.db.WithContext(ctx).First(&option, id).Error
	if err != nil {
		return nil, err
	}

	return &option, nil
}

// ExistsByID     ID
func (r *optionRepository) ExistsByID(ctx context.Context, id uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Option{}).
		Where("id = ?", id).
		Count(&count).Error

	return count > 0, err
}

// BelongsToPoll ,    
func (r *optionRepository) BelongsToPoll(ctx context.Context, optionID, pollID uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.Option{}).
		Where("id = ? AND poll_id = ?", optionID, pollID).
		Count(&count).Error

	return count > 0, err
}
