package repository

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

type trustedPartyRepository struct {
	db *gorm.DB
}

// NewTrustedPartyRepository        
func NewTrustedPartyRepository(db *gorm.DB) TrustedPartyRepository {
	return &trustedPartyRepository{db: db}
}

// Create    
func (r *trustedPartyRepository) Create(ctx context.Context, trustedParty *model.TrustedParty) error {
	if trustedParty == nil {
		return model.NewAppError(model.ErrCodeInvalidInput, "trusted party cannot be nil")
	}

	exists, err := r.ExistsByUserAndPoll(ctx, trustedParty.UserID, trustedParty.PollID)
	if err != nil {
		return err
	}
	if exists {
		return model.NewAppError(model.ErrCodeAlreadyExists, "user is already a trusted party for this poll")
	}

	if trustedParty.AssignedAt.IsZero() {
		trustedParty.AssignedAt = time.Now().UTC()
	}

	if err := r.db.WithContext(ctx).Create(trustedParty).Error; err != nil {
		if IsUniqueConstraintError(err) {
			return model.NewAppError(model.ErrCodeAlreadyExists, "trusted party already exists for this poll")
		}
		return model.NewAppError(model.ErrCodeInternal, "failed to create trusted party", err.Error())
	}

	return nil
}

// GetByPollID      
func (r *trustedPartyRepository) GetByPollID(ctx context.Context, pollID uint) ([]model.TrustedParty, error) {
	var trustedParties []model.TrustedParty

	err := r.db.WithContext(ctx).
		Where("poll_id = ?", pollID).
		Order("assigned_at ASC").
		Find(&trustedParties).Error

	if err != nil {
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get trusted parties", err.Error())
	}

	return trustedParties, nil
}

// Delete   
func (r *trustedPartyRepository) Delete(ctx context.Context, id uint) error {
	result := r.db.WithContext(ctx).Delete(&model.TrustedParty{}, id)

	if result.Error != nil {
		return model.NewAppError(model.ErrCodeInternal, "failed to delete trusted party", result.Error.Error())
	}

	if result.RowsAffected == 0 {
		return model.NewAppError(model.ErrCodeNotFound, "trusted party not found")
	}

	return nil
}

// GetByUserAndPoll       
func (r *trustedPartyRepository) GetByUserAndPoll(ctx context.Context, userID, pollID uint) (*model.TrustedParty, error) {
	var trustedParty model.TrustedParty

	err := r.db.WithContext(ctx).
		Where("user_id = ? AND poll_id = ?", userID, pollID).
		First(&trustedParty).Error

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, model.NewAppError(model.ErrCodeNotFound, "trusted party not found")
		}
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get trusted party", err.Error())
	}

	return &trustedParty, nil
}

// IsTrustedParty        
func (r *trustedPartyRepository) IsTrustedParty(ctx context.Context, userID, pollID uint) (bool, error) {
	var count int64

	err := r.db.WithContext(ctx).
		Model(&model.TrustedParty{}).
		Where("user_id = ? AND poll_id = ?", userID, pollID).
		Count(&count).Error

	if err != nil {
		return false, model.NewAppError(model.ErrCodeInternal, "failed to check trusted party status", err.Error())
	}

	return count > 0, nil
}

// ExistsByUserAndPoll         
func (r *trustedPartyRepository) ExistsByUserAndPoll(ctx context.Context, userID, pollID uint) (bool, error) {
	return r.IsTrustedParty(ctx, userID, pollID)
}

// GetByUserID        
func (r *trustedPartyRepository) GetByUserID(ctx context.Context, userID uint) ([]model.TrustedParty, error) {
	var trustedParties []model.TrustedParty

	err := r.db.WithContext(ctx).
		Where("user_id = ?", userID).
		Order("assigned_at DESC").
		Find(&trustedParties).Error

	if err != nil {
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get trusted parties for user", err.Error())
	}

	return trustedParties, nil
}

// CountByPollID      
func (r *trustedPartyRepository) CountByPollID(ctx context.Context, pollID uint) (int, error) {
	var count int64

	err := r.db.WithContext(ctx).
		Model(&model.TrustedParty{}).
		Where("poll_id = ?", pollID).
		Count(&count).Error

	if err != nil {
		return 0, model.NewAppError(model.ErrCodeInternal, "failed to count trusted parties", err.Error())
	}

	return int(count), nil
}

// DeleteByUserAndPoll       
func (r *trustedPartyRepository) DeleteByUserAndPoll(ctx context.Context, userID, pollID uint) error {
	result := r.db.WithContext(ctx).
		Where("user_id = ? AND poll_id = ?", userID, pollID).
		Delete(&model.TrustedParty{})

	if result.Error != nil {
		return model.NewAppError(model.ErrCodeInternal, "failed to delete trusted party", result.Error.Error())
	}

	if result.RowsAffected == 0 {
		return model.NewAppError(model.ErrCodeNotFound, "trusted party not found")
	}

	return nil
}

// GetTrustedPartiesWithDetails      
func (r *trustedPartyRepository) GetTrustedPartiesWithDetails(ctx context.Context, pollID uint) ([]model.TrustedParty, error) {
	var trustedParties []model.TrustedParty

	err := r.db.WithContext(ctx).
		Where("poll_id = ?", pollID).
		Order("assigned_at ASC").
		Find(&trustedParties).Error

	if err != nil {
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get trusted parties with details", err.Error())
	}

	return trustedParties, nil
}

// DeleteExpiredTrustedParties      
func (r *trustedPartyRepository) DeleteExpiredTrustedParties(ctx context.Context) error {

	subquery := r.db.WithContext(ctx).
		Model(&model.Poll{}).
		Select("id").
		Where("status IN ?", []string{"ended", "failed"})

	result := r.db.WithContext(ctx).
		Where("poll_id IN (?)", subquery).
		Delete(&model.TrustedParty{})

	if result.Error != nil {
		return model.NewAppError(model.ErrCodeInternal, "failed to delete expired trusted parties", result.Error.Error())
	}

	return nil
}

// GetTrustedPartyStats     
func (r *trustedPartyRepository) GetTrustedPartyStats(ctx context.Context) (map[string]interface{}, error) {
	stats := make(map[string]interface{})

	   
	var totalCount int64
	err := r.db.WithContext(ctx).
		Model(&model.TrustedParty{}).
		Count(&totalCount).Error
	if err != nil {
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get trusted party stats", err.Error())
	}

	    (  )
	var activeCount int64
	err = r.db.WithContext(ctx).
		Model(&model.TrustedParty{}).
		Joins("JOIN polls ON trusted_parties.poll_id = polls.id").
		Where("polls.status = ?", "active").
		Count(&activeCount).Error
	if err != nil {
		return nil, model.NewAppError(model.ErrCodeInternal, "failed to get active trusted party stats", err.Error())
	}

	stats["total_trusted_parties"] = totalCount
	stats["active_trusted_parties"] = activeCount

	return stats, nil
}
