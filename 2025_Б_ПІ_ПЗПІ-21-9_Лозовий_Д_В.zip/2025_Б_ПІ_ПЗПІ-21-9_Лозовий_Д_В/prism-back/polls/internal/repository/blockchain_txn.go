package repository

import (
	"context"

	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

// blockchainTransactionRepository   BlockchainTransactionRepository
type blockchainTransactionRepository struct {
	db *gorm.DB
}

// NewBlockchainTransactionRepository    blockchain transaction repository
func NewBlockchainTransactionRepository(db *gorm.DB) BlockchainTransactionRepository {
	return &blockchainTransactionRepository{db: db}
}

// Create      
func (r *blockchainTransactionRepository) Create(ctx context.Context, tx *model.BlockchainTransaction) error {
	return r.db.WithContext(ctx).Create(tx).Error
}

// Update   
func (r *blockchainTransactionRepository) Update(ctx context.Context, tx *model.BlockchainTransaction) error {
	return r.db.WithContext(ctx).Save(tx).Error
}

// GetByID    ID
func (r *blockchainTransactionRepository) GetByID(ctx context.Context, id uint) (*model.BlockchainTransaction, error) {
	var tx model.BlockchainTransaction
	err := r.db.WithContext(ctx).First(&tx, id).Error
	if err != nil {
		return nil, err
	}

	return &tx, nil
}

// GetByTxHash    
func (r *blockchainTransactionRepository) GetByTxHash(ctx context.Context, txHash string) (*model.BlockchainTransaction, error) {
	var tx model.BlockchainTransaction
	err := r.db.WithContext(ctx).
		Where("tx_hash = ?", txHash).
		First(&tx).Error

	if err != nil {
		return nil, err
	}

	return &tx, nil
}

// GetByEntity      
func (r *blockchainTransactionRepository) GetByEntity(ctx context.Context, entityType string, entityID uint) ([]model.BlockchainTransaction, error) {
	var transactions []model.BlockchainTransaction
	err := r.db.WithContext(ctx).
		Where("entity_type = ? AND entity_id = ?", entityType, entityID).
		Order("created_at DESC").
		Find(&transactions).Error

	return transactions, err
}

// GetPendingTransactions   pending   
func (r *blockchainTransactionRepository) GetPendingTransactions(ctx context.Context) ([]model.BlockchainTransaction, error) {
	var transactions []model.BlockchainTransaction
	err := r.db.WithContext(ctx).
		Where("status = ?", model.TransactionStatusPending).
		Order("created_at ASC").
		Find(&transactions).Error

	return transactions, err
}

// GetFailedTransactions  failed   retry
func (r *blockchainTransactionRepository) GetFailedTransactions(ctx context.Context) ([]model.BlockchainTransaction, error) {
	var transactions []model.BlockchainTransaction
	err := r.db.WithContext(ctx).
		Where("status = ? AND retry_count < ?", model.TransactionStatusFailed, 3).
		Order("created_at ASC").
		Find(&transactions).Error

	return transactions, err
}

// MarkAsConfirmed     confirmed
func (r *blockchainTransactionRepository) MarkAsConfirmed(ctx context.Context, id uint, blockNumber uint64, gasUsed uint64) error {
	updates := map[string]interface{}{
		"status":       model.TransactionStatusConfirmed,
		"block_number": blockNumber,
		"gas_used":     gasUsed,
	}

	return r.db.WithContext(ctx).
		Model(&model.BlockchainTransaction{}).
		Where("id = ?", id).
		Updates(updates).Error
}

// MarkAsFailed     failed
func (r *blockchainTransactionRepository) MarkAsFailed(ctx context.Context, id uint, errorMsg string) error {
	updates := map[string]interface{}{
		"status": model.TransactionStatusFailed,
		"error":  errorMsg,
	}

	return r.db.WithContext(ctx).
		Model(&model.BlockchainTransaction{}).
		Where("id = ?", id).
		Updates(updates).Error
}

// IncrementRetryCount    
func (r *blockchainTransactionRepository) IncrementRetryCount(ctx context.Context, id uint) error {
	return r.db.WithContext(ctx).
		Model(&model.BlockchainTransaction{}).
		Where("id = ?", id).
		Update("retry_count", gorm.Expr("retry_count + 1")).Error
}

// GetTransactionsByType    
func (r *blockchainTransactionRepository) GetTransactionsByType(ctx context.Context, txType string, pagination model.Pagination) ([]model.BlockchainTransaction, model.PaginationResult, error) {
	query := r.db.WithContext(ctx).Where("tx_type = ?", txType)

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("created_at DESC")

	var transactions []model.BlockchainTransaction
	err = query.Find(&transactions).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return transactions, paginationResult, nil
}

// DeleteOldTransactions   completed  (  )
func (r *blockchainTransactionRepository) DeleteOldTransactions(ctx context.Context, olderThanDays int) error {
	return r.db.WithContext(ctx).
		Where("status = ? AND created_at < NOW() - INTERVAL ? DAY",
			model.TransactionStatusConfirmed, olderThanDays).
		Delete(&model.BlockchainTransaction{}).Error
}

// GetTransactionStats    
func (r *blockchainTransactionRepository) GetTransactionStats(ctx context.Context) (map[string]int, error) {
	var results []struct {
		Status string `json:"status"`
		Count  int    `json:"count"`
	}

	err := r.db.WithContext(ctx).
		Model(&model.BlockchainTransaction{}).
		Select("status, COUNT(*) as count").
		Group("status").
		Find(&results).Error

	if err != nil {
		return nil, err
	}

	stats := make(map[string]int)
	for _, result := range results {
		stats[result.Status] = result.Count
	}

	return stats, nil
}

// SetTxHash       
func (r *blockchainTransactionRepository) SetTxHash(ctx context.Context, id uint, txHash string) error {
	return r.db.WithContext(ctx).
		Model(&model.BlockchainTransaction{}).
		Where("id = ?", id).
		Update("tx_hash", txHash).Error
}

// GetRecentTransactions    ( )
func (r *blockchainTransactionRepository) GetRecentTransactions(ctx context.Context, limit int) ([]model.BlockchainTransaction, error) {
	var transactions []model.BlockchainTransaction
	err := r.db.WithContext(ctx).
		Order("created_at DESC").
		Limit(limit).
		Find(&transactions).Error

	return transactions, err
}
