package service

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"log"
	"poll-management-service/internal/client"
	"strings"
	"time"

	"poll-management-service/internal/model"
)

// voteService  VoteService
type voteService struct {
	deps Dependencies
}

// NewVoteService    VoteService
func NewVoteService(deps Dependencies) VoteService {
	return &voteService{
		deps: deps,
	}
}

// CastVote   (    MVP)
func (s *voteService) CastVote(
	ctx context.Context,
	req model.VoteRequest,
	pollID uint,
	userID *uint,
	jwtToken string,
) (*model.VoteResponse, error) {

	if req.AnonymousID != nil || req.ZkProof != nil || req.BlindSignature != nil {
		return nil, model.NewAppError(model.ErrCodeForbidden, "anonymous voting not supported in MVP")
	}

	if userID == nil {
		return nil, model.NewAppError(model.ErrCodeUnauthorized, "user ID required for open voting")
	}

	userValidation, err := s.deps.IdentityClient.ValidateVoter(ctx, jwtToken)
	if err != nil {
		return nil, model.NewAppError(model.ErrCodeUnauthorized, "failed to validate user")
	}

	if !userValidation.IsActive || !userValidation.CanVote {
		return nil, model.NewAppError(model.ErrCodeForbidden, "user cannot vote")
	}

	if userValidation.UserID != *userID {
		return nil, model.NewAppError(model.ErrCodeForbidden, "user ID mismatch")
	}

	canVote, reason, err := s.CanUserVote(ctx, pollID, *userID)
	if err != nil {
		return nil, fmt.Errorf("checking vote eligibility: %w", err)
	}
	if !canVote {
		return nil, model.NewAppError(model.ErrCodeForbidden, reason)
	}

	belongs, err := s.deps.Repository.Option.BelongsToPoll(ctx, req.OptionID, pollID)
	if err != nil {
		return nil, fmt.Errorf("checking option ownership: %w", err)
	}
	if !belongs {
		return nil, model.NewAppError(model.ErrCodeInvalidInput, "option does not belong to this poll")
	}

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return nil, err
	}

	vote := &model.Vote{
		PollID:    pollID,
		OptionID:  req.OptionID,
		UserID:    userID,
		Timestamp: time.Now().UTC(),
	}

	if err := s.deps.Repository.Vote.Create(ctx, vote); err != nil {
		return nil, fmt.Errorf("creating vote: %w", err)
	}

	blockchainReq := client.RecordVoteRequest{
		PollID:      pollID,
		OptionID:    req.OptionID,
		UserID:      userID,
		OptionsHash: poll.OptionsHash,
	}

	txResp, err := s.deps.BlockchainClient.RecordVote(ctx, blockchainReq)
	if err != nil {
		return nil, fmt.Errorf("recording vote in blockchain: %w", err)
	}

	if err := s.deps.Repository.Vote.SetBlockchainTx(ctx, vote.ID, txResp.TxHash); err != nil {

		fmt.Printf("Warning: failed to update vote blockchain tx: %v\n", err)
	}

	blockchainTx := &model.BlockchainTransaction{
		TxHash:     &txResp.TxHash,
		TxType:     "vote_cast",
		EntityType: "vote",
		EntityID:   vote.ID,
		Status:     model.TransactionStatusConfirmed,
	}
	if err := s.deps.Repository.BlockchainTransaction.Create(ctx, blockchainTx); err != nil {

		fmt.Printf("Warning: failed to create blockchain transaction record: %v\n", err)
	}

	return &model.VoteResponse{
		VoteID:       vote.ID,
		PollID:       pollID,
		OptionID:     req.OptionID,
		Timestamp:    vote.Timestamp,
		BlockchainTx: &txResp.TxHash,
	}, nil
}

func (s *voteService) CastAnonymousVote(
	ctx context.Context,
	req model.VoteRequest,
	pollID uint,
) (*model.VoteResponse, error) {

	if err := req.Validate(); err != nil {
		return nil, err
	}

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return nil, &model.AppError{
			Code:    model.ErrCodeNotFound,
			Message: "Poll not found",
		}
	}

	if !poll.IsPrivate {
		return nil, &model.AppError{
			Code:    model.ErrCodeInvalidInput,
			Message: "Anonymous voting is only available for private polls",
		}
	}

	if !poll.IsActive() {
		return nil, &model.AppError{
			Code:    model.ErrCodePollNotActive,
			Message: "Poll is not active",
		}
	}

	hasVoted, err := s.HasAnonymousVoted(ctx, pollID, *req.AnonymousID)
	if err != nil {
		return nil, err
	}
	if hasVoted {
		return nil, &model.AppError{
			Code:    model.ErrCodeAlreadyVoted,
			Message: "Anonymous ID already used for this poll",
		}
	}

	zkpResponse, err := s.deps.VerificationClient.VerifyZKProof(
		ctx,
		pollID,
		*req.AnonymousID,
		req.ZkProof,
	)
	if err != nil {
		return nil, &model.AppError{
			Code:    model.ErrCodeVerificationError,
			Message: "ZKP verification failed",
			Details: err.Error(),
		}
	}

	if !zkpResponse.Valid || !zkpResponse.CanVote {
		return nil, &model.AppError{
			Code:    model.ErrCodeInvalidZKProof,
			Message: "Invalid ZKP proof or cannot vote",
			Details: zkpResponse.Message,
		}
	}

	optionExists, err := s.deps.Repository.Option.BelongsToPoll(ctx, req.OptionID, pollID)
	if err != nil {
		return nil, err
	}
	if !optionExists {
		return nil, &model.AppError{
			Code:    model.ErrCodeInvalidInput,
			Message: "Option does not belong to this poll",
		}
	}

	vote := &model.Vote{
		PollID:      pollID,
		OptionID:    req.OptionID,
		AnonymousID: req.AnonymousID,
		ZkProofHash: &zkpResponse.ProofHash,
	}

	if err := s.deps.Repository.Vote.Create(ctx, vote); err != nil {

		return nil, &model.AppError{
			Code:    model.ErrCodeInternal,
			Message: "Failed to save vote",
		}
	}

	blockchainReq := client.RecordVoteRequest{
		PollID:      pollID,
		OptionID:    req.OptionID,
		AnonymousID: req.AnonymousID,
		OptionsHash: s.calculateOptionsHash(ctx, pollID),
	}

	txResponse, err := s.deps.BlockchainClient.RecordAnonymousVote(ctx, blockchainReq)
	if err != nil {
		log.Printf("Failed to record anonymous vote: %v\n", err)

	} else {

		repErr := s.deps.Repository.Vote.SetBlockchainTx(ctx, vote.ID, txResponse.TxHash)
		if repErr != nil {
			return nil, repErr

		}
	}

	return &model.VoteResponse{
		VoteID:       vote.ID,
		PollID:       pollID,
		OptionID:     req.OptionID,
		BlockchainTx: &txResponse.TxHash,
	}, nil
}

// HasUserVoted       
func (s *voteService) HasUserVoted(ctx context.Context, pollID, userID uint) (bool, error) {
	hasVoted, err := s.deps.Repository.Vote.HasUserVoted(ctx, pollID, userID)
	if err != nil {
		return false, fmt.Errorf("checking if user voted: %w", err)
	}
	return hasVoted, nil
}

func (s *voteService) HasAnonymousVoted(ctx context.Context, pollID uint, anonymousID string) (bool, error) {

	hasVoted, err := s.deps.Repository.Vote.HasAnonymousVoted(ctx, pollID, anonymousID)
	if err != nil {
		return false, err
	}
	if hasVoted {
		return true, nil
	}

	checkResponse, err := s.deps.VerificationClient.CheckAnonymousID(ctx, pollID, anonymousID)
	if err != nil {

		return hasVoted, nil
	}

	return checkResponse.IsUsed, nil
}

// CanAnonymousVote    anonymous ID 
func (s *voteService) CanAnonymousVote(ctx context.Context, pollID uint, anonymousID string) (bool, string, error) {

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return false, "Poll not found", err
	}

	if !poll.IsActive() {
		return false, "Poll is not active", nil
	}

	if !poll.IsPrivate {
		return false, "Anonymous voting not available for public polls", nil
	}

	hasVoted, err := s.HasAnonymousVoted(ctx, pollID, anonymousID)
	if err != nil {
		return false, "Failed to check vote status", err
	}
	if hasVoted {
		return false, "Anonymous ID already used", nil
	}

	if poll.MaxVotes != nil {
		currentVotes, err := s.deps.Repository.Vote.CountByPollID(ctx, pollID)
		if err != nil {
			return false, "Failed to check vote count", err
		}
		if currentVotes >= int(*poll.MaxVotes) {
			return false, "Maximum votes reached", nil
		}
	}

	return true, "Can vote", nil
}

// CanUserVote    
func (s *voteService) CanUserVote(ctx context.Context, pollID uint, userID uint) (bool, string, error) {

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return false, "poll not found", err
	}

	if !poll.IsActive() {
		if poll.Status == model.PollStatusEnded {
			return false, "poll has ended", nil
		}
		if poll.Status == model.PollStatusFailed {
			return false, "poll has failed", nil
		}

		now := time.Now().UTC()
		if now.Before(poll.StartTime) {
			return false, "poll has not started yet", nil
		}
		if now.After(poll.EndTime) {
			return false, "poll has ended", nil
		}

		return false, "poll is not active", nil
	}

	hasVoted, err := s.HasUserVoted(ctx, pollID, userID)
	if err != nil {
		return false, "failed to check voting status", err
	}
	if hasVoted {
		return false, "user has already voted", nil
	}

	if poll.MaxVotes != nil {
		currentVotes, err := s.deps.Repository.Vote.CountByPollID(ctx, pollID)
		if err != nil {
			return false, "failed to count votes", err
		}
		if currentVotes >= *poll.MaxVotes {
			return false, "maximum votes limit reached", nil
		}
	}

	return true, "", nil
}

// calculateVoteHash     
func (s *voteService) calculateVoteHash(userID, pollID, optionID uint) string {
	data := fmt.Sprintf("%d:%d:%d:%d", userID, pollID, optionID, time.Now().UTC().Unix())
	hash := sha256.Sum256([]byte(data))
	return fmt.Sprintf("%x", hash)
}

func (s *voteService) calculateAnonymousVoteHash(pollID uint, optionID uint, anonymousID string) string {
	data := fmt.Sprintf("anonymous_vote:%d:%d:%s", pollID, optionID, anonymousID)
	hash := sha256.Sum256([]byte(data))
	return hex.EncodeToString(hash[:])
}

func (s *voteService) calculateOptionsHash(ctx context.Context, pollID uint) string {
	options, err := s.deps.Repository.Option.GetByPollID(ctx, pollID)
	if err != nil {
		return ""
	}

	var optionsData []string
	for _, option := range options {
		optionsData = append(optionsData, fmt.Sprintf("%d:%s", option.ID, option.Text))
	}

	combinedData := strings.Join(optionsData, "|")
	hash := sha256.Sum256([]byte(combinedData))
	return hex.EncodeToString(hash[:])
}
