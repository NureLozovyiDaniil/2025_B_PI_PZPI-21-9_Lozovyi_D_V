package service

import (
	"context"
	"poll-management-service/internal/client"
	"poll-management-service/internal/model"
	"poll-management-service/internal/repository"
)

type PollService interface {
	CreatePoll(ctx context.Context, req model.CreatePollRequest, creatorID uint) (*model.PollCreationResponse, error)
	DeletePoll(ctx context.Context, pollID uint) error
	GetPollByID(ctx context.Context, id uint, userID *uint) (*model.PollResponse, error)
	ListPolls(ctx context.Context, filter model.PollFilter, pagination model.Pagination) (*model.ListResponse[model.PollResponse], error)
	GetPollsByCreator(ctx context.Context, creatorID uint, pagination model.Pagination) (*model.ListResponse[model.PollResponse], error)

	FinalizePolls(ctx context.Context) error

	GetPollResults(ctx context.Context, pollID uint) (*model.PollResultResponse, error)
	//GetPollStats(ctx context.Context, pollID uint) (*model.PollStatsResponse, error)

	AddTrustedParty(ctx context.Context, pollID uint, req model.AddTrustedPartyRequest, requesterID uint) error
	RemoveTrustedParty(ctx context.Context, pollID uint, trustedPartyID uint, requesterID uint) error
	GetTrustedParties(ctx context.Context, pollID uint) ([]model.TrustedParty, error)

	ValidateUser(ctx context.Context, token string) (*client.UserValidationResponse, error)
	CanUserDeletePoll(ctx context.Context, userID, pollID uint, roles []string) (bool, error)
}

type VoteService interface {
	CastVote(ctx context.Context, req model.VoteRequest, pollID uint, userID *uint, jwtToken string) (*model.VoteResponse, error)
	CastAnonymousVote(ctx context.Context, req model.VoteRequest, pollID uint) (*model.VoteResponse, error)

	HasUserVoted(ctx context.Context, pollID, userID uint) (bool, error)
	CanUserVote(ctx context.Context, pollID uint, userID uint) (bool, string, error)

	HasAnonymousVoted(ctx context.Context, pollID uint, anonymousID string) (bool, error)
	CanAnonymousVote(ctx context.Context, pollID uint, anonymousID string) (bool, string, error)
}

type Service struct {
	Poll PollService
	Vote VoteService
}

type Dependencies struct {
	Repository         repository.Repository
	IdentityClient     client.IdentityClientInterface
	BlockchainClient   client.BlockchainClientInterface
	VerificationClient client.VerificationClient
}

func NewService(deps Dependencies) *Service {
	return &Service{
		Poll: NewPollService(deps),
		Vote: NewVoteService(deps),
	}
}
