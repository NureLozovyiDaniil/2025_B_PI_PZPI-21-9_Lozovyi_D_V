package handler

import (
	"strconv"

	"github.com/gin-gonic/gin"
	"poll-management-service/internal/model"
)

// AddTrustedParty     
// POST /api/v1/polls/:id/trusted-parties
func (h *Handler) AddTrustedParty(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	userID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not authenticated"))
		return
	}

	 
	var req model.AddTrustedPartyRequest
	if err := BindAndValidate(c, &req); err != nil {
		ErrorResponse(c, err)
		return
	}

	err = h.service.Poll.AddTrustedParty(c.Request.Context(), pollID, req, userID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, model.TrustedPartyOperationResponse{
		Success: true,
		Message: "Trusted party added successfully",
		PollID:  pollID,
	})
}

// GetTrustedParties      
// GET /api/v1/polls/:id/trusted-parties
func (h *Handler) GetTrustedParties(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	trustedParties, err := h.service.Poll.GetTrustedParties(c.Request.Context(), pollID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	trustedPartiesResponse := make([]model.TrustedPartyResponse, len(trustedParties))
	for i, tp := range trustedParties {
		trustedPartiesResponse[i] = model.TrustedPartyResponse{
			ID:         tp.ID,
			UserID:     tp.UserID,
			PollID:     tp.PollID,
			PublicKey:  tp.PublicKey,
			AssignedAt: tp.AssignedAt,
			AssignedBy: tp.AssignedBy,
		}
	}

	SuccessResponse(c, model.TrustedPartiesListResponse{
		PollID:         pollID,
		TrustedParties: trustedPartiesResponse,
		Count:          len(trustedPartiesResponse),
	})
}

// RemoveTrustedParty     
// DELETE /api/v1/polls/:id/trusted-parties/:user_id
func (h *Handler) RemoveTrustedParty(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	userIDStr := c.Param("user_id")
	targetUserID, err := strconv.ParseUint(userIDStr, 10, 32)
	if err != nil {
		ErrorResponse(c, model.NewAppError(model.ErrCodeInvalidInput, "invalid user_id parameter"))
		return
	}

	requesterID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not authenticated"))
		return
	}

	err = h.service.Poll.RemoveTrustedParty(c.Request.Context(), pollID, uint(targetUserID), requesterID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, model.TrustedPartyOperationResponse{
		Success: true,
		Message: "Trusted party removed successfully",
		PollID:  pollID,
		UserID:  &[]uint{uint(targetUserID)}[0],
	})
}

// CheckTrustedPartyStatus      
// GET /api/v1/polls/:id/trusted-parties/check
func (h *Handler) CheckTrustedPartyStatus(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	userID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not authenticated"))
		return
	}

	trustedParties, err := h.service.Poll.GetTrustedParties(c.Request.Context(), pollID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	isTrusted := false
	for _, tp := range trustedParties {
		if tp.UserID == userID {
			isTrusted = true
			break
		}
	}

	SuccessResponse(c, gin.H{
		"poll_id":    pollID,
		"user_id":    userID,
		"is_trusted": isTrusted,
		"can_verify": isTrusted,
	})
}
