package handler

import (
	"github.com/gin-gonic/gin"
	"poll-management-service/internal/model"
	"strconv"
	"time"
)

// CreatePoll   
func (h *Handler) CreatePoll(c *gin.Context) {
	var req model.CreatePollRequest
	if err := BindAndValidate(c, &req); err != nil {
		ErrorResponse(c, err)
		return
	}

	creatorID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not found in context"))
		return
	}

	response, err := h.service.Poll.CreatePoll(c.Request.Context(), req, creatorID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, response)
}

func (h *Handler) DeletePoll(c *gin.Context) {
	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	,    (   )
	var userID *uint
	if id, exists := GetUserIDFromContext(c); exists {
		userID = &id
	} else {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not found in context"))
		return
	}
	userRoles, ok := c.Get("user_roles")
	if !ok {
		ErrorResponse(c, err)
		return
	}

	canDelete, err := h.service.Poll.CanUserDeletePoll(c.Request.Context(), *userID, pollID, userRoles.([]string))
	if !canDelete {
		ErrorResponse(c, model.NewAppError(model.ErrCodeForbidden, "user does not have permission to delete poll"))
		return
	}

	err = h.service.Poll.DeletePoll(c.Request.Context(), pollID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, nil)

}

// GetPoll      ID
func (h *Handler) GetPoll(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	,    (   )
	var userID *uint
	if id, exists := GetUserIDFromContext(c); exists {
		userID = &id
	}

	poll, err := h.service.Poll.GetPollByID(c.Request.Context(), pollID, userID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, poll)
}

// ListPolls       
func (h *Handler) ListPolls(c *gin.Context) {

	pagination := model.Pagination{}
	if page := c.Query("page"); page != "" {
		if p, err := strconv.Atoi(page); err == nil {
			pagination.Page = p
		}
	}
	if pageSize := c.Query("page_size"); pageSize != "" {
		if ps, err := strconv.Atoi(pageSize); err == nil {
			pagination.PageSize = ps
		}
	}
	pagination.Validate()

	filter := model.PollFilter{}

	if category := c.Query("category"); category != "" {
		filter.Category = &category
	}

	if isPrivate := c.Query("is_private"); isPrivate != "" {
		if private, err := strconv.ParseBool(isPrivate); err == nil {
			filter.IsPrivate = &private
		}
	}

	if status := c.Query("status"); status != "" {
		pollStatus := model.PollStatus(status)
		filter.Status = &pollStatus
	}

	if search := c.Query("search"); search != "" {
		filter.Search = &search
	}

	if from := c.Query("from_date"); from != "" {
		if fromDate, err := time.Parse("2006-01-02", from); err == nil {
			filter.FromDate = &fromDate
		}
	}
	if to := c.Query("to_date"); to != "" {
		if toDate, err := time.Parse("2006-01-02", to); err == nil {
			filter.ToDate = &toDate
		}
	}

	polls, err := h.service.Poll.ListPolls(c.Request.Context(), filter, pagination)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, polls)
}

// GetMyPolls   ,   
func (h *Handler) GetMyPolls(c *gin.Context) {

	creatorID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not found in context"))
		return
	}

	pagination := model.Pagination{}
	if page := c.Query("page"); page != "" {
		if p, err := strconv.Atoi(page); err == nil {
			pagination.Page = p
		}
	}
	if pageSize := c.Query("page_size"); pageSize != "" {
		if ps, err := strconv.Atoi(pageSize); err == nil {
			pagination.PageSize = ps
		}
	}
	pagination.Validate()

	polls, err := h.service.Poll.GetPollsByCreator(c.Request.Context(), creatorID, pagination)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, polls)
}

func (h *Handler) GetResults(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	results, err := h.service.Poll.GetPollResults(c.Request.Context(), pollID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, results)
}
