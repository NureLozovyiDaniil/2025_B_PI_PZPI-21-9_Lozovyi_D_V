package model

import (
	"fmt"
	"time"
)

type Pagination struct {
	Page     int `json:"page" binding:"omitempty,min=1"`
	PageSize int `json:"page_size" binding:"omitempty,min=1,max=100"`
}

func (p *Pagination) GetOffset() int {
	return (p.Page - 1) * p.PageSize
}

func (p *Pagination) Validate() {
	if p.Page < 1 {
		p.Page = 1
	}
	if p.PageSize < 1 {
		p.PageSize = 20
	}
	if p.PageSize > 100 {
		p.PageSize = 100
	}
}

type PaginationResult struct {
	Page        int   `json:"page"`
	PageSize    int   `json:"page_size"`
	Total       int64 `json:"total"`
	TotalPages  int   `json:"total_pages"`
	HasNext     bool  `json:"has_next"`
	HasPrevious bool  `json:"has_previous"`
}

func NewPaginationResult(page, pageSize int, total int64) PaginationResult {
	totalPages := int((total + int64(pageSize) - 1) / int64(pageSize))
	return PaginationResult{
		Page:        page,
		PageSize:    pageSize,
		Total:       total,
		TotalPages:  totalPages,
		HasNext:     page < totalPages,
		HasPrevious: page > 1,
	}
}

type TimeRange struct {
	From *time.Time `json:"from,omitempty"`
	To   *time.Time `json:"to,omitempty"`
}

type PollFilter struct {
	CreatorId *int        `json:"creator_id"`
	Category  *string     `json:"category"`
	IsPrivate *bool       `json:"is_private"`
	Status    *PollStatus `json:"status"`
	Search    *string     `json:"search"`
	FromDate  *time.Time  `json:"from_date"`
	ToDate    *time.Time  `json:"to_date"`
}

type ErrorCode string

const (
	ErrCodeInvalidInput      ErrorCode = "INVALID_INPUT"
	ErrCodeNotFound          ErrorCode = "NOT_FOUND"
	ErrCodeAlreadyExists     ErrorCode = "ALREADY_EXISTS"
	ErrCodeUnauthorized      ErrorCode = "UNAUTHORIZED"
	ErrCodeForbidden         ErrorCode = "FORBIDDEN"
	ErrCodeInternal          ErrorCode = "INTERNAL_ERROR"
	ErrCodePollNotActive     ErrorCode = "POLL_NOT_ACTIVE"
	ErrCodeAlreadyVoted      ErrorCode = "ALREADY_VOTED"
	ErrCodeMaxVotesReached   ErrorCode = "MAX_VOTES_REACHED"
	ErrCodeInvalidZKProof    ErrorCode = "INVALID_ZK_PROOF"
	ErrCodeVerificationError ErrorCode = "VERIFICATION_ERROR"
)

type AppError struct {
	Code    ErrorCode `json:"code"`
	Message string    `json:"message"`
	Details any       `json:"details,omitempty"`
}

func (e AppError) Error() string {
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func NewAppError(code ErrorCode, message string, details ...any) AppError {
	err := AppError{
		Code:    code,
		Message: message,
	}
	if len(details) > 0 {
		err.Details = details[0]
	}
	return err
}

// Common validation errors
var (
	ErrInvalidCategory   = NewAppError(ErrCodeInvalidInput, "invalid category")
	ErrPollNotFound      = NewAppError(ErrCodeNotFound, "poll not found")
	ErrOptionNotFound    = NewAppError(ErrCodeNotFound, "option not found")
	ErrUserAlreadyVoted  = NewAppError(ErrCodeAlreadyExists, "user already voted")
	ErrPollNotActive     = NewAppError(ErrCodePollNotActive, "poll is not active")
	ErrMaxVotesReached   = NewAppError(ErrCodeMaxVotesReached, "maximum votes reached")
	ErrInvalidZKProof    = NewAppError(ErrCodeInvalidZKProof, "invalid zero-knowledge proof")
	ErrNotVerified       = NewAppError(ErrCodeVerificationError, "user not verified for this poll")
	ErrInsufficientPerms = NewAppError(ErrCodeForbidden, "insufficient permissions")
)

// Predefined categories
var Categories = []string{
	"general",
	"politics",
	"technology",
	"education",
	"healthcare",
	"environment",
	"sports",
	"entertainment",
	"business",
	"community",
	"other",

	//For testing
	"test",
}

func IsValidCategory(category string) bool {
	for _, c := range Categories {
		if c == category {
			return true
		}
	}
	return false
}
