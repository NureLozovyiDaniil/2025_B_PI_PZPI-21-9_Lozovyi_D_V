package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	glogger "gorm.io/gorm/logger"

	"poll-management-service/internal/client"
	"poll-management-service/internal/config"
	"poll-management-service/internal/cron"
	"poll-management-service/internal/handler"
	"poll-management-service/internal/repository"
	"poll-management-service/internal/service"
)

const (
	serviceName = "poll-management-service"
	version     = "1.0.0"
)

func main() {

	appLogger := log.New(os.Stdout, fmt.Sprintf("[%s] ", serviceName), log.LstdFlags|log.Lshortfile)

	appLogger.Printf("Starting %s v%s", serviceName, version)

	cfg, err := config.Load()
	if err != nil {
		appLogger.Fatalf("Failed to load config: %v", err)
	}
	appLogger.Println("Configuration loaded successfully")

	if !cfg.Server.Debug {
		gin.SetMode(gin.ReleaseMode)
	}

	db, err := initDatabase(cfg)
	if err != nil {
		appLogger.Fatalf("Failed to connect to database: %v", err)
	}
	appLogger.Println("Database connection established")

	identityClient := client.NewIdentityClient(cfg.Services.IdentityService.URL)
	blockchainClient := client.NewBlockchainClient(cfg.Services.BlockchainService.URL)
	appLogger.Println("External service clients initialized")

	repo := repository.NewRepository(db)
	appLogger.Println("Repository layer initialized")

	serviceDeps := service.Dependencies{
		Repository:       *repo,
		IdentityClient:   identityClient,
		BlockchainClient: blockchainClient,
	}
	svc := service.NewService(serviceDeps)
	appLogger.Println("Service layer initialized")

	h := handler.NewHandler(svc)
	appLogger.Println("Handler layer initialized")

	router := gin.New()
	router.Use(gin.Recovery())

	router.Use(ginLogger(appLogger))

	router.GET("/health", healthCheck())

	h.InitRoutes(router)
	appLogger.Println("Routes initialized")

	cronJobs := initCronJobs(svc, repo, blockchainClient, cfg, appLogger)
	if err := startCronJobs(cronJobs, appLogger); err != nil {
		appLogger.Fatalf("Failed to start cron jobs: %v", err)
	}

	server := &http.Server{
		Addr:         fmt.Sprintf("%s:%s", cfg.Server.Host, cfg.Server.Port),
		Handler:      router,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
		IdleTimeout:  cfg.Server.IdleTimeout,
	}

	shutdown := make(chan os.Signal, 1)
	signal.Notify(shutdown, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		appLogger.Printf("Server starting on %s", server.Addr)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			appLogger.Fatalf("Failed to start server: %v", err)
		}
	}()

	appLogger.Printf("%s started successfully and ready to accept requests", serviceName)

	<-shutdown
	appLogger.Println("Shutdown signal received, starting graceful shutdown...")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	stopCronJobs(cronJobs, appLogger)

	if err := server.Shutdown(shutdownCtx); err != nil {
		appLogger.Printf("Error during server shutdown: %v", err)
	} else {
		appLogger.Println("Server stopped gracefully")
	}

	if sqlDB, err := db.DB(); err == nil {
		if err := sqlDB.Close(); err != nil {
			appLogger.Printf("Error closing database connection: %v", err)
		} else {
			appLogger.Println("Database connection closed")
		}
	}

	appLogger.Printf("%s stopped", serviceName)
}

func initDatabase(cfg *config.Config) (*gorm.DB, error) {

	gormLogger := glogger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags),
		glogger.Config{
			SlowThreshold:             200 * time.Millisecond,
			LogLevel:                  glogger.Warn,
			IgnoreRecordNotFoundError: true,
			Colorful:                  false,
		},
	)

	db, err := gorm.Open(postgres.Open(cfg.GetDSN()), &gorm.Config{
		Logger: gormLogger,
	})
	if err != nil {
		return nil, fmt.Errorf("opening database connection: %w", err)
	}

	sqlDB, err := db.DB()
	if err != nil {
		return nil, fmt.Errorf("getting underlying sql.DB: %w", err)
	}

	sqlDB.SetMaxOpenConns(cfg.Database.MaxOpenConns)
	sqlDB.SetMaxIdleConns(cfg.Database.MaxIdleConns)
	sqlDB.SetConnMaxLifetime(cfg.Database.ConnMaxLifetime)

	if err := sqlDB.Ping(); err != nil {
		return nil, fmt.Errorf("pinging database: %w", err)
	}

	return db, nil
}

type CronJobs struct {
	PollFinalizer     *cron.PollFinalizer
	BlockchainMonitor *cron.BlockchainMonitor
}

func initCronJobs(
	svc *service.Service,
	repo *repository.Repository,
	blockchainClient client.BlockchainClientInterface,
	cfg *config.Config,
	logger *log.Logger,
) *CronJobs {
	pollFinalizer := cron.NewPollFinalizer(svc, cfg, logger)
	blockchainMonitor := cron.NewBlockchainMonitor(repo, blockchainClient, cfg, logger)

	return &CronJobs{
		PollFinalizer:     pollFinalizer,
		BlockchainMonitor: blockchainMonitor,
	}
}

func startCronJobs(cronJobs *CronJobs, logger *log.Logger) error {
	if err := cronJobs.PollFinalizer.Start(); err != nil {
		return fmt.Errorf("starting poll finalizer: %w", err)
	}

	if err := cronJobs.BlockchainMonitor.Start(); err != nil {
		return fmt.Errorf("starting blockchain monitor: %w", err)
	}

	logger.Println("All cron jobs started successfully")
	return nil
}

func stopCronJobs(cronJobs *CronJobs, logger *log.Logger) {
	logger.Println("Stopping cron jobs...")

	if cronJobs.PollFinalizer != nil {
		cronJobs.PollFinalizer.Stop()
	}

	if cronJobs.BlockchainMonitor != nil {
		cronJobs.BlockchainMonitor.Stop()
	}

	logger.Println("All cron jobs stopped")
}

func ginLogger(logger *log.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		raw := c.Request.URL.RawQuery

		c.Next()

		timeStamp := time.Now()
		latency := timeStamp.Sub(start)
		clientIP := c.ClientIP()
		method := c.Request.Method
		statusCode := c.Writer.Status()
		bodySize := c.Writer.Size()

		if raw != "" {
			path = path + "?" + raw
		}

		logger.Printf("[GIN] %3d | %13v | %15s | %-7s %s",
			statusCode,
			latency,
			clientIP,
			method,
			path,
		)

		if len(c.Errors) > 0 {
			logger.Printf("[GIN] Errors: %s", c.Errors.String())
		}

		_ = bodySize
	}
}

func healthCheck() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"service": serviceName,
			"version": version,
			"status":  "healthy",
			"time":    time.Now().UTC().Format(time.RFC3339),
		})
	}
}
