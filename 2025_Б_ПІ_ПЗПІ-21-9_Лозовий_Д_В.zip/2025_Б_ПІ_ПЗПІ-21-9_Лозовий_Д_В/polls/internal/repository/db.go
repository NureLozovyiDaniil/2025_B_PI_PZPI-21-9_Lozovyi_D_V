package repository

import (
	"context"
	"errors"
	"fmt"
	"poll-management-service/internal/model"
	"time"

	"github.com/golang-migrate/migrate/v4"
	"github.com/golang-migrate/migrate/v4/database/postgres"
	_ "github.com/golang-migrate/migrate/v4/source/file"
	gormpostgres "gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"poll-management-service/internal/config"
)

type Database struct {
	db *gorm.DB
}

func NewDatabase(cfg *config.Config) (*Database, error) {
	var gormLogger = logger.Default.LogMode(logger.Error)

	db, err := gorm.Open(gormpostgres.Open(cfg.GetDSN()), &gorm.Config{
		Logger: gormLogger,
		NowFunc: func() time.Time {
			return time.Now().UTC()
		},
		PrepareStmt: true,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to connect to database: %w", err)
	}

	sqlDB, err := db.DB()
	if err != nil {
		return nil, fmt.Errorf("failed to get sql.DB: %w", err)
	}

	sqlDB.SetMaxIdleConns(cfg.Database.MaxIdleConns)
	sqlDB.SetMaxOpenConns(cfg.Database.MaxOpenConns)
	sqlDB.SetConnMaxLifetime(time.Duration(cfg.Database.ConnMaxLifetime) * time.Second)

	return &Database{db: db}, nil
}

func (d *Database) GetDB() *gorm.DB {
	return d.db
}

func (d *Database) Close() error {
	sqlDB, err := d.db.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}

func (d *Database) Health(ctx context.Context) error {
	sqlDB, err := d.db.DB()
	if err != nil {
		return err
	}
	return sqlDB.PingContext(ctx)
}

func (d *Database) WithTransaction(ctx context.Context, fn func(*gorm.DB) error) error {
	return d.db.WithContext(ctx).Transaction(fn)
}

func (d *Database) WithContext(ctx context.Context) *gorm.DB {
	return d.db.WithContext(ctx)
}

func (d *Database) RunMigrations(migrationsPath string) error {
	sqlDB, err := d.db.DB()
	if err != nil {
		return fmt.Errorf("failed to get sql.DB: %w", err)
	}

	driver, err := postgres.WithInstance(sqlDB, &postgres.Config{})
	if err != nil {
		return fmt.Errorf("failed to create postgres driver: %w", err)
	}

	m, err := migrate.NewWithDatabaseInstance(
		fmt.Sprintf("file://%s", migrationsPath),
		"postgres",
		driver,
	)
	if err != nil {
		return fmt.Errorf("failed to create migrate instance: %w", err)
	}

	if err := m.Up(); err != nil && !errors.Is(err, migrate.ErrNoChange) {
		return fmt.Errorf("failed to run migrations: %w", err)
	}

	return nil
}

func (d *Database) MigrateUp(migrationsPath string) error {
	return d.RunMigrations(migrationsPath)
}

func (d *Database) MigrateDown(migrationsPath string) error {
	sqlDB, err := d.db.DB()
	if err != nil {
		return fmt.Errorf("failed to get sql.DB: %w", err)
	}

	driver, err := postgres.WithInstance(sqlDB, &postgres.Config{})
	if err != nil {
		return fmt.Errorf("failed to create postgres driver: %w", err)
	}

	m, err := migrate.NewWithDatabaseInstance(
		fmt.Sprintf("file://%s", migrationsPath),
		"postgres",
		driver,
	)
	if err != nil {
		return fmt.Errorf("failed to create migrate instance: %w", err)
	}

	if err := m.Steps(-1); err != nil && !errors.Is(err, migrate.ErrNoChange) {
		return fmt.Errorf("failed to rollback migration: %w", err)
	}

	return nil
}

func (d *Database) MigrationVersion(migrationsPath string) (uint, bool, error) {
	sqlDB, err := d.db.DB()
	if err != nil {
		return 0, false, fmt.Errorf("failed to get sql.DB: %w", err)
	}

	driver, err := postgres.WithInstance(sqlDB, &postgres.Config{})
	if err != nil {
		return 0, false, fmt.Errorf("failed to create postgres driver: %w", err)
	}

	m, err := migrate.NewWithDatabaseInstance(
		fmt.Sprintf("file://%s", migrationsPath),
		"postgres",
		driver,
	)
	if err != nil {
		return 0, false, fmt.Errorf("failed to create migrate instance: %w", err)
	}

	version, dirty, err := m.Version()
	if err != nil {
		return 0, false, fmt.Errorf("failed to get migration version: %w", err)
	}

	return version, dirty, nil
}

type TransactionFunc func(*gorm.DB) error

func ExecuteInTransaction(ctx context.Context, db *gorm.DB, fn TransactionFunc) error {
	return db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return fn(tx)
	})
}

func (d *Database) BeginTransaction(ctx context.Context) *gorm.DB {
	return d.db.WithContext(ctx).Begin()
}

func CommitTransaction(tx *gorm.DB) error {
	return tx.Commit().Error
}

func RollbackTransaction(tx *gorm.DB) error {
	return tx.Rollback().Error
}

func ApplyPagination(query *gorm.DB, pagination model.Pagination) *gorm.DB {
	pagination.Validate()
	return query.Offset(pagination.GetOffset()).Limit(pagination.PageSize)
}

func CountWithPagination(query *gorm.DB, pagination model.Pagination) (int64, model.PaginationResult, error) {
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return 0, model.PaginationResult{}, err
	}

	pagination.Validate()
	result := model.NewPaginationResult(pagination.Page, pagination.PageSize, total)

	return total, result, nil
}

func ApplyPollFilter(query *gorm.DB, filter model.PollFilter) *gorm.DB {
	if filter.CreatorId != nil {
		query = query.Where("creator_id = ?", *filter.CreatorId)
	}

	if filter.Category != nil {
		query = query.Where("category = ?", *filter.Category)
	}

	if filter.IsPrivate != nil {
		query = query.Where("is_private = ?", *filter.IsPrivate)
	}

	if filter.Status != nil {
		query = query.Where("status = ?", *filter.Status)
	}

	if filter.Search != nil && *filter.Search != "" {
		search := "%" + *filter.Search + "%"
		query = query.Where("title ILIKE ? OR description ILIKE ?", search, search)
	}

	if filter.FromDate != nil {
		query = query.Where("start_time >= ?", *filter.FromDate)
	}

	if filter.ToDate != nil {
		query = query.Where("end_time <= ?", *filter.ToDate)
	}

	return query
}

func IsUniqueConstraintError(err error) bool {
	if err == nil {
		return false
	}

	return err.Error() == "unique_violation" ||
		err.Error() == "duplicate key value violates unique constraint"
}

func IsForeignKeyConstraintError(err error) bool {
	if err == nil {
		return false
	}

	return err.Error() == "foreign_key_violation"
}
