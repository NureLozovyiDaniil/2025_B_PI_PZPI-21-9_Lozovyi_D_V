package repository

import (
	"context"

	"gorm.io/gorm"

	"poll-management-service/internal/model"
)

type resultRepository struct {
	db *gorm.DB
}

func NewResultRepository(db *gorm.DB) ResultRepository {
	return &resultRepository{db: db}
}

func (r *resultRepository) Create(ctx context.Context, result *model.PollResult) error {
	return r.db.WithContext(ctx).Create(result).Error
}

func (r *resultRepository) Update(ctx context.Context, result *model.PollResult) error {
	return r.db.WithContext(ctx).Save(result).Error
}

func (r *resultRepository) GetByPollID(ctx context.Context, pollID uint) (*model.PollResult, error) {
	var result model.PollResult
	err := r.db.WithContext(ctx).
		Preload("OptionResults").
		Where("poll_id = ?", pollID).
		First(&result).Error

	if err != nil {
		return nil, err
	}

	return &result, nil
}

func (r *resultRepository) CreateOptionResults(ctx context.Context, results []model.OptionResult) error {
	if len(results) == 0 {
		return nil
	}

	return r.db.WithContext(ctx).Create(&results).Error
}

func (r *resultRepository) GetOptionResultsByPoll(ctx context.Context, pollID uint) ([]model.OptionResult, error) {
	var results []model.OptionResult
	err := r.db.WithContext(ctx).
		Where("poll_id = ?", pollID).
		Order("vote_count DESC, option_id ASC").
		Find(&results).Error

	return results, err
}

func (r *resultRepository) ExistsByPollID(ctx context.Context, pollID uint) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Model(&model.PollResult{}).
		Where("poll_id = ?", pollID).
		Count(&count).Error

	return count > 0, err
}

func (r *resultRepository) CreateOrUpdateResults(ctx context.Context, result *model.PollResult, optionResults []model.OptionResult) error {
	return ExecuteInTransaction(ctx, r.db, func(tx *gorm.DB) error {

		var existingResult model.PollResult
		err := tx.Where("poll_id = ?", result.PollID).First(&existingResult).Error

		if err == gorm.ErrRecordNotFound {

			if err := tx.Create(result).Error; err != nil {
				return err
			}
		} else if err == nil {

			result.PollID = existingResult.PollID
			if err := tx.Save(result).Error; err != nil {
				return err
			}

			if err := tx.Where("poll_id = ?", result.PollID).Delete(&model.OptionResult{}).Error; err != nil {
				return err
			}
		} else {
			return err
		}

		if len(optionResults) > 0 {
			for i := range optionResults {
				optionResults[i].PollID = result.PollID
			}
			if err := tx.Create(&optionResults).Error; err != nil {
				return err
			}
		}

		return nil
	})
}

func (r *resultRepository) DeleteResults(ctx context.Context, pollID uint) error {
	return ExecuteInTransaction(ctx, r.db, func(tx *gorm.DB) error {

		if err := tx.Where("poll_id = ?", pollID).Delete(&model.OptionResult{}).Error; err != nil {
			return err
		}

		if err := tx.Where("poll_id = ?", pollID).Delete(&model.PollResult{}).Error; err != nil {
			return err
		}

		return nil
	})
}

func (r *resultRepository) GetResultsWithOptions(ctx context.Context, pollID uint) (*model.PollResultResponse, error) {

	pollResult, err := r.GetByPollID(ctx, pollID)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT 
			or.option_id,
			o.text,
			o.description,
			or.vote_count,
			or.percentage
		FROM option_results or
		JOIN options o ON or.option_id = o.id
		WHERE or.poll_id = ? AND o.deleted_at IS NULL
		ORDER BY or.vote_count DESC, or.option_id ASC
	`

	var optionResponses []model.OptionResponse
	err = r.db.WithContext(ctx).Raw(query, pollID).Scan(&optionResponses).Error
	if err != nil {
		return nil, err
	}

	response := &model.PollResultResponse{
		PollID:       pollResult.PollID,
		TotalVotes:   pollResult.TotalVotes,
		Options:      optionResponses,
		WinnerOption: pollResult.WinnerOption,
		ResultHash:   pollResult.ResultHash,
	}

	return response, nil
}

func (r *resultRepository) GetTopPolls(ctx context.Context, limit int) ([]model.PollResult, error) {
	var results []model.PollResult
	err := r.db.WithContext(ctx).
		Order("total_votes DESC").
		Limit(limit).
		Find(&results).Error

	return results, err
}

func (r *resultRepository) GetResultsByDateRange(ctx context.Context, timeRange model.TimeRange, pagination model.Pagination) ([]model.PollResult, model.PaginationResult, error) {
	query := r.db.WithContext(ctx).Model(&model.PollResult{})

	query = query.Joins("JOIN polls ON poll_results.poll_id = polls.id")

	if timeRange.From != nil {
		query = query.Where("polls.created_at >= ?", *timeRange.From)
	}

	if timeRange.To != nil {
		query = query.Where("polls.created_at <= ?", *timeRange.To)
	}

	_, paginationResult, err := CountWithPagination(query, pagination)
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	query = ApplyPagination(query, pagination)
	query = query.Order("poll_results.updated_at DESC")

	var results []model.PollResult
	err = query.Find(&results).Error
	if err != nil {
		return nil, model.PaginationResult{}, err
	}

	return results, paginationResult, nil
}

func (r *resultRepository) GetResultStats(ctx context.Context) (map[string]interface{}, error) {
	var stats struct {
		TotalPolls     int64   `json:"total_polls"`
		TotalVotes     int64   `json:"total_votes"`
		AverageVotes   float64 `json:"average_votes"`
		MaxVotes       int     `json:"max_votes"`
		PollsWithVotes int64   `json:"polls_with_votes"`
	}

	err := r.db.WithContext(ctx).
		Model(&model.PollResult{}).
		Count(&stats.TotalPolls).Error
	if err != nil {
		return nil, err
	}

	err = r.db.WithContext(ctx).
		Model(&model.PollResult{}).
		Select("SUM(total_votes) as total_votes, AVG(total_votes) as average_votes, MAX(total_votes) as max_votes").
		Row().Scan(&stats.TotalVotes, &stats.AverageVotes, &stats.MaxVotes)
	if err != nil {
		return nil, err
	}

	err = r.db.WithContext(ctx).
		Model(&model.PollResult{}).
		Where("total_votes > 0").
		Count(&stats.PollsWithVotes).Error
	if err != nil {
		return nil, err
	}

	result := map[string]interface{}{
		"total_polls":      stats.TotalPolls,
		"total_votes":      stats.TotalVotes,
		"average_votes":    stats.AverageVotes,
		"max_votes":        stats.MaxVotes,
		"polls_with_votes": stats.PollsWithVotes,
	}

	return result, nil
}
