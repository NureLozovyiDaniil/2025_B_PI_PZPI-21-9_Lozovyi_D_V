CREATE TABLE polls (
                       id SERIAL PRIMARY KEY,
                       title VARCHAR(255) NOT NULL,
                       description TEXT,
                       category VARCHAR(100) NOT NULL,
                       is_private BOOLEAN NOT NULL DEFAULT FALSE,
                       creator_id INTEGER NOT NULL,
                       start_time TIMESTAMP NOT NULL,
                       end_time TIMESTAMP NOT NULL,
                       status VARCHAR(20) NOT NULL DEFAULT 'active',
                       min_voter_turnout INTEGER,
                       max_votes INTEGER,
                       blockchain_tx_hash VARCHAR(66),
                       options_hash VARCHAR(66),
                       created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                       updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                       deleted_at TIMESTAMP,

    -- Constraints
                       CONSTRAINT check_end_time_after_start CHECK (end_time > start_time),
                       CONSTRAINT check_status_valid CHECK (status IN ('active', 'ended', 'failed')),
                       CONSTRAINT check_min_voter_turnout_positive CHECK (min_voter_turnout IS NULL OR min_voter_turnout > 0),
                       CONSTRAINT check_max_votes_positive CHECK (max_votes IS NULL OR max_votes > 0)
);

CREATE INDEX idx_polls_creator_id ON polls(creator_id);
CREATE INDEX idx_polls_category ON polls(category);
CREATE INDEX idx_polls_status ON polls(status);
CREATE INDEX idx_polls_is_private ON polls(is_private);
CREATE INDEX idx_polls_title ON polls(title);
CREATE INDEX idx_polls_start_time ON polls(start_time);
CREATE INDEX idx_polls_end_time ON polls(end_time);
CREATE INDEX idx_polls_blockchain_tx_hash ON polls(blockchain_tx_hash);
CREATE INDEX idx_polls_deleted_at ON polls(deleted_at);

CREATE INDEX idx_polls_status_start_end ON polls(status, start_time, end_time);
CREATE INDEX idx_polls_category_status ON polls(category, status);
