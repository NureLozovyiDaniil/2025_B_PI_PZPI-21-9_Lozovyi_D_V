CREATE TABLE trusted_parties (
                                 id SERIAL PRIMARY KEY,
                                 user_id INTEGER NOT NULL,
                                 poll_id INTEGER NOT NULL,
                                 public_key VARCHAR(130) NOT NULL,
                                 assigned_at TIMESTAMP NOT NULL DEFAULT NOW(),
                                 assigned_by INTEGER NOT NULL,
                                 created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                                 updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                                 deleted_at TIMESTAMP,

    -- Foreign key constraints
                                 CONSTRAINT fk_trusted_parties_poll_id FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,

    -- Business logic constraints
                                 CONSTRAINT check_public_key_format CHECK (
                                     LENGTH(public_key) >= 66 AND LENGTH(public_key) <= 130 AND
                                     public_key ~ '^0x[a-fA-F0-9]+$'
),

    -- Prevent duplicate trusted parties for same poll
    CONSTRAINT unique_user_poll_trusted UNIQUE (user_id, poll_id)
);

CREATE INDEX idx_trusted_parties_user_id ON trusted_parties(user_id);
CREATE INDEX idx_trusted_parties_poll_id ON trusted_parties(poll_id);
CREATE INDEX idx_trusted_parties_assigned_by ON trusted_parties(assigned_by);
CREATE INDEX idx_trusted_parties_public_key ON trusted_parties(public_key);
CREATE INDEX idx_trusted_parties_deleted_at ON trusted_parties(deleted_at);

CREATE INDEX idx_trusted_parties_poll_user ON trusted_parties(poll_id, user_id);
