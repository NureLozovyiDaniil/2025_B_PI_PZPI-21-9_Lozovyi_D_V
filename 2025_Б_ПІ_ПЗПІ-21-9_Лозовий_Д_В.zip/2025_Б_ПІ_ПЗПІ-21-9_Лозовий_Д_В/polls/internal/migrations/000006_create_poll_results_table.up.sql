CREATE TABLE poll_results (
                              poll_id INTEGER PRIMARY KEY,
                              total_votes INTEGER NOT NULL DEFAULT 0,
                              winner_option INTEGER,
                              result_hash VARCHAR(64),
                              created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                              updated_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- Foreign key constraints
                              CONSTRAINT fk_poll_results_poll_id FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
                              CONSTRAINT fk_poll_results_winner_option FOREIGN KEY (winner_option) REFERENCES options(id),

    -- Validation constraints
                              CONSTRAINT check_total_votes_positive CHECK (total_votes >= 0)
);

CREATE INDEX idx_poll_results_total_votes ON poll_results(total_votes);
CREATE INDEX idx_poll_results_winner_option ON poll_results(winner_option);
CREATE INDEX idx_poll_results_result_hash ON poll_results(result_hash);
CREATE INDEX idx_poll_results_updated_at ON poll_results(updated_at);
