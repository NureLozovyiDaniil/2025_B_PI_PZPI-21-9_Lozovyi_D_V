CREATE TABLE blockchain_transactions (
                                         id SERIAL PRIMARY KEY,
                                         tx_hash VARCHAR(66) UNIQUE,
                                         tx_type VARCHAR(50) NOT NULL,
                                         entity_type VARCHAR(50) NOT NULL,
                                         entity_id INTEGER NOT NULL,
                                         status VARCHAR(20) NOT NULL DEFAULT 'pending',
                                         block_number BIGINT,
                                         gas_price BIGINT,
                                         gas_used BIGINT,
                                         error TEXT,
                                         retry_count INTEGER NOT NULL DEFAULT 0,
                                         created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                                         updated_at TIMESTAMP NOT NULL DEFAULT NOW(),

    -- Validation constraints
                                         CONSTRAINT check_status_valid CHECK (status IN ('pending', 'confirmed', 'failed')),
                                         CONSTRAINT check_tx_type_valid CHECK (tx_type IN (
                                                                                           'poll_creation', 'vote_cast', 'result_publication',
                                                                                           'trusted_party_add', 'poll_finalization'
                                             )),
                                         CONSTRAINT check_entity_type_valid CHECK (entity_type IN ('poll', 'vote', 'result')),
                                         CONSTRAINT check_retry_count_positive CHECK (retry_count >= 0),
                                         CONSTRAINT check_gas_price_positive CHECK (gas_price IS NULL OR gas_price > 0),
                                         CONSTRAINT check_gas_used_positive CHECK (gas_used IS NULL OR gas_used > 0),
                                         CONSTRAINT check_block_number_positive CHECK (block_number IS NULL OR block_number > 0)
);

CREATE INDEX idx_blockchain_tx_hash ON blockchain_transactions(tx_hash);
CREATE INDEX idx_blockchain_tx_type ON blockchain_transactions(tx_type);
CREATE INDEX idx_blockchain_entity_type ON blockchain_transactions(entity_type);
CREATE INDEX idx_blockchain_entity_id ON blockchain_transactions(entity_id);
CREATE INDEX idx_blockchain_status ON blockchain_transactions(status);
CREATE INDEX idx_blockchain_block_number ON blockchain_transactions(block_number);
CREATE INDEX idx_blockchain_created_at ON blockchain_transactions(created_at);

CREATE INDEX idx_blockchain_entity_type_id ON blockchain_transactions(entity_type, entity_id);
CREATE INDEX idx_blockchain_status_retry ON blockchain_transactions(status, retry_count);
CREATE INDEX idx_blockchain_tx_type_status ON blockchain_transactions(tx_type, status);
