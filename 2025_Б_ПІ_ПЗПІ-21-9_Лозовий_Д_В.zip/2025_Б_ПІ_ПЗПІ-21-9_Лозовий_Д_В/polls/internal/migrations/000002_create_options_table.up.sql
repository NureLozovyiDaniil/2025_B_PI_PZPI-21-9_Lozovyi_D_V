CREATE TABLE options (
                         id SERIAL PRIMARY KEY,
                         poll_id INTEGER NOT NULL,
                         text VARCHAR(500) NOT NULL,
                         description TEXT,
                         created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                         updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                         deleted_at TIMESTAMP,

    -- Foreign key constraints
                         CONSTRAINT fk_options_poll_id FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,

    -- Validation constraints
                         CONSTRAINT check_text_not_empty CHECK (LENGTH(TRIM(text)) > 0)
);


CREATE INDEX idx_options_poll_id ON options(poll_id);
CREATE INDEX idx_options_deleted_at ON options(deleted_at);

CREATE INDEX idx_options_poll_id_deleted_at ON options(poll_id, deleted_at);

