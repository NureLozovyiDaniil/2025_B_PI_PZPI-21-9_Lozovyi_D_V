package service

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"poll-management-service/internal/client"
	"poll-management-service/internal/model"
	"time"
)

type pollService struct {
	deps Dependencies
}

func NewPollService(deps Dependencies) PollService {
	return &pollService{
		deps: deps,
	}
}

func (s *pollService) CreatePoll(ctx context.Context, req model.CreatePollRequest, creatorID uint) (*model.PollCreationResponse, error) {

	options := make([]model.Option, len(req.Options))
	for i, optReq := range req.Options {
		options[i] = model.Option{
			Text:        optReq.Text,
			Description: optReq.Description,
		}
	}
	optionsHash := s.calculateOptionsHash(options)

	poll := &model.Poll{
		Title:           req.Title,
		Description:     req.Description,
		Category:        req.Category,
		IsPrivate:       req.IsPrivate,
		CreatorID:       creatorID,
		StartTime:       req.StartTime,
		EndTime:         req.EndTime,
		Status:          model.PollStatusActive,
		MinVoterTurnout: req.MinVoterTurnout,
		MaxVotes:        req.MaxVotes,
		OptionsHash:     optionsHash,
	}

	if err := s.deps.Repository.Poll.Create(ctx, poll); err != nil {
		return nil, fmt.Errorf("creating poll: %w", err)
	}

	for i := range options {
		options[i].PollID = poll.ID
	}

	if err := s.deps.Repository.Option.CreateBatch(ctx, options); err != nil {
		return nil, fmt.Errorf("creating options: %w", err)
	}

	if req.IsPrivate {
		if err := s.createInitialTrustedParty(ctx, poll); err != nil {
			return nil, err
		}
	}

	blockchainReq := client.RegisterPollRequest{
		PollID:      poll.ID,
		CreatorID:   creatorID,
		Title:       poll.Title,
		Description: poll.Description,
		Category:    poll.Category,
		StartTime:   poll.StartTime,
		EndTime:     poll.EndTime,
		IsPrivate:   poll.IsPrivate,
		OptionsHash: optionsHash,
	}

	txResp, err := s.deps.BlockchainClient.RegisterPoll(ctx, blockchainReq)
	if err != nil {
		return nil, fmt.Errorf("registering poll in blockchain: %w", err)
	}

	if err := s.deps.Repository.Poll.SetBlockchainTxHash(ctx, poll.ID, txResp.TxHash); err != nil {
		return nil, fmt.Errorf("updating blockchain tx hash: %w", err)
	}

	blockchainTx := &model.BlockchainTransaction{
		TxHash:     &txResp.TxHash,
		TxType:     "poll_creation",
		EntityType: "poll",
		EntityID:   poll.ID,
		Status:     model.TransactionStatusConfirmed,
	}
	if err := s.deps.Repository.BlockchainTransaction.Create(ctx, blockchainTx); err != nil {

		fmt.Printf("Warning: failed to create blockchain transaction record: %v\n", err)
	}

	return &model.PollCreationResponse{
		PollID:           poll.ID,
		BlockchainTxHash: txResp.TxHash,
		Message:          "Poll created successfully",
	}, nil
}

func (s *pollService) createInitialTrustedParty(ctx context.Context, poll *model.Poll) error {

	user, err := s.deps.IdentityClient.GetUserByID(ctx, poll.CreatorID)
	if err != nil {
		return model.NewAppError(model.ErrCodeInternal, "failed to get creator information", err.Error())
	}

	trustedParty := &model.TrustedParty{
		UserID:     poll.CreatorID,
		PollID:     poll.ID,
		PublicKey:  user.PublicKey,
		AssignedAt: time.Now().UTC(),
		AssignedBy: poll.CreatorID,
	}

	if err := s.deps.Repository.TrustedParty.Create(ctx, trustedParty); err != nil {
		return err
	}

	return nil
}

func (s *pollService) DeletePoll(ctx context.Context, pollID uint) error {
	err := s.deps.Repository.Poll.Delete(ctx, pollID)
	if err != nil {
		return fmt.Errorf("deleting poll: %w", err)
	}

	return s.deps.Repository.Poll.UpdateStatus(ctx, pollID, model.PollStatusFailed)
}

func (s *pollService) CanUserDeletePoll(ctx context.Context, userID, pollID uint, roles []string) (bool, error) {
	for _, role := range roles {
		if role == "admin" {
			return true, nil
		}
	}

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return false, err
	}

	return poll.CreatorID == userID, nil
}

func (s *pollService) GetPollByID(ctx context.Context, id uint, userID *uint) (*model.PollResponse, error) {
	poll, err := s.deps.Repository.Poll.GetByID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("getting poll: %w", err)
	}

	options, err := s.deps.Repository.Option.GetByPollID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("getting options: %w", err)
	}

	voteCount, err := s.deps.Repository.Vote.CountByPollID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("counting votes: %w", err)
	}

	canVote := false
	hasVoted := false
	if userID != nil {
		canVote = poll.IsActive()
		if canVote {
			hasVoted, err = s.deps.Repository.Vote.HasUserVoted(ctx, id, *userID)
			if err != nil {
				return nil, fmt.Errorf("checking if user voted: %w", err)
			}
			canVote = canVote && !hasVoted
		}
	}

	optionResponses := make([]model.OptionResponse, len(options))
	for i, opt := range options {
		optionResponses[i] = model.OptionResponse{
			ID:          opt.ID,
			Text:        opt.Text,
			Description: opt.Description,
		}
	}

	return &model.PollResponse{
		ID:              poll.ID,
		Title:           poll.Title,
		Description:     poll.Description,
		Category:        poll.Category,
		IsPrivate:       poll.IsPrivate,
		CreatorID:       poll.CreatorID,
		StartTime:       poll.StartTime,
		EndTime:         poll.EndTime,
		Status:          string(poll.Status),
		MinVoterTurnout: poll.MinVoterTurnout,
		MaxVotes:        poll.MaxVotes,
		VoteCount:       voteCount,
		CanVote:         canVote,
		HasVoted:        hasVoted,
		IsActive:        poll.IsActive(),
		Options:         optionResponses,
	}, nil
}

func (s *pollService) ListPolls(ctx context.Context, filter model.PollFilter, pagination model.Pagination) (*model.ListResponse[model.PollResponse], error) {
	pagination.Validate()

	polls, paginationResult, err := s.deps.Repository.Poll.List(ctx, filter, pagination)
	if err != nil {
		return nil, fmt.Errorf("listing polls: %w", err)
	}

	responses := make([]model.PollResponse, len(polls))
	for i, poll := range polls {

		voteCount, _ := s.deps.Repository.Vote.CountByPollID(ctx, poll.ID)
		canVote := time.Now().UTC().After(poll.StartTime) &&
			time.Now().UTC().Before(poll.EndTime) &&
			poll.Status == model.PollStatusActive

		responses[i] = model.PollResponse{
			ID:          poll.ID,
			Title:       poll.Title,
			Description: poll.Description,
			Category:    poll.Category,
			IsPrivate:   poll.IsPrivate,
			CreatorID:   poll.CreatorID,
			StartTime:   poll.StartTime,
			EndTime:     poll.EndTime,
			Status:      string(poll.Status),
			VoteCount:   voteCount,
			IsActive:    poll.IsActive(),
			CanVote:     canVote,
		}
	}

	return &model.ListResponse[model.PollResponse]{
		Items:      responses,
		Pagination: paginationResult,
	}, nil
}

func (s *pollService) GetPollsByCreator(ctx context.Context, creatorID uint, pagination model.Pagination) (*model.ListResponse[model.PollResponse], error) {
	pagination.Validate()

	polls, paginationResult, err := s.deps.Repository.Poll.ListByCreator(ctx, creatorID, pagination)
	if err != nil {
		return nil, fmt.Errorf("listing polls by creator: %w", err)
	}

	responses := make([]model.PollResponse, len(polls))
	for i, poll := range polls {
		voteCount, _ := s.deps.Repository.Vote.CountByPollID(ctx, poll.ID)

		responses[i] = model.PollResponse{
			ID:          poll.ID,
			Title:       poll.Title,
			Description: poll.Description,
			Category:    poll.Category,
			IsPrivate:   poll.IsPrivate,
			CreatorID:   poll.CreatorID,
			StartTime:   poll.StartTime,
			EndTime:     poll.EndTime,
			Status:      string(poll.Status),
			VoteCount:   voteCount,
			IsActive:    poll.IsActive(),
		}
	}

	return &model.ListResponse[model.PollResponse]{
		Items:      responses,
		Pagination: paginationResult,
	}, nil
}

func (s *pollService) FinalizePolls(ctx context.Context) error {
	polls, err := s.deps.Repository.Poll.GetPollsToFinalize(ctx)
	if err != nil {
		return fmt.Errorf("getting polls to finalize: %w", err)
	}

	for _, poll := range polls {
		if err := s.finalizePoll(ctx, &poll); err != nil {
			fmt.Printf("Error finalizing poll %d: %v\n", poll.ID, err)
			continue
		}
	}

	return nil
}

func (s *pollService) GetPollResults(ctx context.Context, pollID uint) (*model.PollResultResponse, error) {
	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return nil, fmt.Errorf("getting poll: %w", err)
	}

	cachedResult, err := s.deps.Repository.Result.GetByPollID(ctx, pollID)
	if err == nil && cachedResult != nil {

		optionResults, err := s.deps.Repository.Result.GetOptionResultsByPoll(ctx, pollID)
		if err != nil {
			return nil, fmt.Errorf("getting cached option results: %w", err)
		}

		optionResponses := make([]model.OptionResponse, len(optionResults))
		for i, result := range optionResults {
			option, _ := s.deps.Repository.Option.GetByID(ctx, result.OptionID)
			optionResponses[i] = model.OptionResponse{
				ID:         result.OptionID,
				VoteCount:  result.VoteCount,
				Percentage: result.Percentage,
			}
			if option != nil {
				optionResponses[i].Text = option.Text
				optionResponses[i].Description = option.Description
			}
		}

		return &model.PollResultResponse{
			PollID:       pollID,
			Title:        poll.Title,
			Status:       string(poll.Status),
			TotalVotes:   cachedResult.TotalVotes,
			Options:      optionResponses,
			WinnerOption: cachedResult.WinnerOption,
			ResultHash:   cachedResult.ResultHash,
		}, nil
	}

	return s.calculatePollResults(ctx, poll)
}

func (s *pollService) calculateOptionsHash(options []model.Option) string {
	data, _ := json.Marshal(options)
	hash := sha256.Sum256(data)
	return fmt.Sprintf("%x", hash)
}

func (s *pollService) finalizePoll(ctx context.Context, poll *model.Poll) error {
	result, err := s.calculatePollResults(ctx, poll)
	if err != nil {
		return fmt.Errorf("calculating results: %w", err)
	}

	status := model.PollStatusEnded
	if poll.MinVoterTurnout != nil && result.TotalVotes < *poll.MinVoterTurnout {
		status = model.PollStatusFailed
	}

	if err := s.deps.Repository.Poll.UpdateStatus(ctx, poll.ID, status); err != nil {
		return fmt.Errorf("updating poll status: %w", err)
	}

	pollResult := &model.PollResult{
		PollID:       poll.ID,
		TotalVotes:   result.TotalVotes,
		WinnerOption: result.WinnerOption,
		ResultHash:   result.ResultHash,
	}

	if err := s.deps.Repository.Result.Create(ctx, pollResult); err != nil {
		return fmt.Errorf("caching results: %w", err)
	}

	optionResults := make([]model.OptionResult, len(result.Options))
	for i, opt := range result.Options {
		optionResults[i] = model.OptionResult{
			PollID:     poll.ID,
			OptionID:   opt.ID,
			VoteCount:  opt.VoteCount,
			Percentage: opt.Percentage,
		}
	}

	if err := s.deps.Repository.Result.CreateOptionResults(ctx, optionResults); err != nil {
		return fmt.Errorf("saving option results: %w", err)
	}

	if status == model.PollStatusEnded {
		if err := s.storeResultsInBlockchain(ctx, poll, result); err != nil {
			fmt.Printf("Warning: failed to store results in blockchain for poll %d: %v\n", poll.ID, err)
		}
	}

	return nil
}

func (s *pollService) storeResultsInBlockchain(ctx context.Context, poll *model.Poll, result *model.PollResultResponse) error {

	optionCounts := make([]int, len(result.Options))
	for i, option := range result.Options {
		optionCounts[i] = option.VoteCount
	}

	blockchainReq := client.StoreResultsRequest{
		PollID: poll.ID,

		OptionCounts: optionCounts,
	}

	time.Sleep(5 * time.Second)
	txResp, err := s.deps.BlockchainClient.StoreResults(ctx, blockchainReq)
	if err != nil {
		return fmt.Errorf("storing results in blockchain: %w", err)
	}

	blockchainTx := &model.BlockchainTransaction{
		TxHash:     &txResp.TxHash,
		TxType:     "poll_finalization",
		EntityType: "result",
		EntityID:   poll.ID,
		Status:     model.TransactionStatusConfirmed,
	}

	if err := s.deps.Repository.BlockchainTransaction.Create(ctx, blockchainTx); err != nil {
		fmt.Printf("Warning: failed to create blockchain transaction record: %v\n", err)
	}

	fmt.Printf("Results for poll %d sent to blockchain: %s\n", poll.ID, txResp.TxHash)
	return nil
}

func (s *pollService) calculatePollResults(ctx context.Context, poll *model.Poll) (*model.PollResultResponse, error) {

	voteStats, err := s.deps.Repository.Vote.GetVoteStatsByPoll(ctx, poll.ID)
	if err != nil {
		return nil, fmt.Errorf("getting vote stats: %w", err)
	}

	totalVotes := 0
	for _, stat := range voteStats {
		totalVotes += stat.VoteCount
	}

	options, err := s.deps.Repository.Option.GetByPollID(ctx, poll.ID)
	if err != nil {
		return nil, fmt.Errorf("getting options: %w", err)
	}

	optionResponses := make([]model.OptionResponse, len(options))
	var winnerOption *uint
	maxVotes := 0

	for i, option := range options {
		voteCount := 0
		percentage := 0.0

		for _, stat := range voteStats {
			if stat.OptionID == option.ID {
				voteCount = stat.VoteCount
				if totalVotes > 0 {
					percentage = float64(voteCount) / float64(totalVotes) * 100
				}
				break
			}
		}

		optionResponses[i] = model.OptionResponse{
			ID:          option.ID,
			Text:        option.Text,
			Description: option.Description,
			VoteCount:   voteCount,
			Percentage:  percentage,
		}

		if voteCount > maxVotes {
			maxVotes = voteCount
			winnerOption = &option.ID
		}
	}

	resultData, _ := json.Marshal(optionResponses)
	hash := sha256.Sum256(resultData)
	resultHash := fmt.Sprintf("%x", hash)

	return &model.PollResultResponse{
		PollID:       poll.ID,
		Title:        poll.Title,
		Status:       string(poll.Status),
		TotalVotes:   totalVotes,
		Options:      optionResponses,
		WinnerOption: winnerOption,
		ResultHash:   &resultHash,
	}, nil
}

func (s *pollService) ValidateUser(ctx context.Context, token string) (*client.UserValidationResponse, error) {
	user, err := s.deps.IdentityClient.ValidateVoter(ctx, token)
	if err != nil {
		return nil, model.NewAppError(model.ErrCodeUnauthorized, "failed to validate user", err.Error())
	}

	if !user.IsActive {
		return nil, model.NewAppError(model.ErrCodeUnauthorized, "user account is not active")
	}

	return user, nil
}

func (s *pollService) AddTrustedParty(ctx context.Context, pollID uint, req model.AddTrustedPartyRequest, requesterID uint) error {

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return fmt.Errorf("failed to get poll %w", err)
	}

	if poll.CreatorID != requesterID {
		return model.NewAppError(model.ErrCodeForbidden, "only poll creator can add trusted parties")
	}

	if !poll.IsPrivate {
		return model.NewAppError(model.ErrCodeInvalidInput, "trusted parties can only be added to private polls")
	}

	if time.Now().UTC().After(poll.StartTime) {
		return model.NewAppError(model.ErrCodeInvalidInput, "cannot add trusted parties after poll has started")
	}

	user, err := s.deps.IdentityClient.FindUserByEmail(ctx, req.Email)
	if err != nil {
		return model.NewAppError(model.ErrCodeNotFound, "user not found", err.Error())
	}

	if !user.IsActive {
		return model.NewAppError(model.ErrCodeInvalidInput, "user is not active")
	}

	exists, err := s.deps.Repository.TrustedParty.ExistsByUserAndPoll(ctx, user.UserID, pollID)
	if err != nil {
		return err
	}

	if exists {
		return model.NewAppError(model.ErrCodeAlreadyExists, "user is already a trusted party for this poll")
	}

	count, err := s.deps.Repository.TrustedParty.CountByPollID(ctx, pollID)
	if err != nil {
		return err
	}

	if count >= 10 {
		return model.NewAppError(model.ErrCodeInvalidInput, "maximum number of trusted parties (10) reached")
	}

	trustedParty := &model.TrustedParty{
		UserID:     user.UserID,
		PollID:     pollID,
		PublicKey:  user.PublicKey,
		AssignedAt: time.Now().UTC(),
		AssignedBy: requesterID,
	}

	if err := s.deps.Repository.TrustedParty.Create(ctx, trustedParty); err != nil {
		return err
	}

	return nil
}

func (s *pollService) RemoveTrustedParty(ctx context.Context, pollID uint, trustedPartyUserID uint, requesterID uint) error {

	poll, err := s.deps.Repository.Poll.GetByID(ctx, pollID)
	if err != nil {
		return err
	}

	if poll.CreatorID != requesterID {
		return model.NewAppError(model.ErrCodeForbidden, "only poll creator can remove trusted parties")
	}

	if time.Now().UTC().After(poll.StartTime) {
		return model.NewAppError(model.ErrCodeInvalidInput, "cannot remove trusted parties after poll has started")
	}

	if trustedPartyUserID == poll.CreatorID {
		return model.NewAppError(model.ErrCodeInvalidInput, "poll creator cannot be removed as trusted party")
	}

	_, err = s.deps.Repository.TrustedParty.GetByUserAndPoll(ctx, trustedPartyUserID, pollID)
	if err != nil {
		return err
	}

	count, err := s.deps.Repository.TrustedParty.CountByPollID(ctx, pollID)
	if err != nil {
		return err
	}

	if count <= 1 {
		return model.NewAppError(model.ErrCodeInvalidInput, "cannot remove last trusted party")
	}

	if err := s.deps.Repository.TrustedParty.DeleteByUserAndPoll(ctx, trustedPartyUserID, pollID); err != nil {
		return err
	}

	return nil
}

func (s *pollService) GetTrustedParties(ctx context.Context, pollID uint) ([]model.TrustedParty, error) {

	exists, err := s.deps.Repository.Poll.ExistsByID(ctx, pollID)
	if err != nil {
		return nil, err
	}

	if !exists {
		return nil, model.NewAppError(model.ErrCodeNotFound, "poll not found")
	}

	trustedParties, err := s.deps.Repository.TrustedParty.GetByPollID(ctx, pollID)
	if err != nil {
		return nil, err
	}

	return trustedParties, nil
}
