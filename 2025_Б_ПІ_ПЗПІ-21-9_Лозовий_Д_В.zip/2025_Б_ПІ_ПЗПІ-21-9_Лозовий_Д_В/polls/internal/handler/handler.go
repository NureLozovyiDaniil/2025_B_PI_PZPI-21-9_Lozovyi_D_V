package handler

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"poll-management-service/internal/model"
	"poll-management-service/internal/service"
)

type Handler struct {
	service *service.Service
}

func NewHandler(svc *service.Service) *Handler {
	return &Handler{
		service: svc,
	}
}

func (h *Handler) InitRoutes(router *gin.Engine) {
	api := router.Group("/api/v1")

	api.Use(h.corsMiddleware())
	api.Use(h.loggerMiddleware())

	public := api.Group("")
	{

		public.GET("/polls", h.ListPolls)
		public.OPTIONS("/polls", h.ListPolls)

		public.GET("/polls/:id", h.GetPoll)
		public.OPTIONS("/polls/:id", h.GetPoll)

		public.GET("/polls/:id/results", h.GetResults)
	}

	protected := api.Group("")
	protected.Use(h.authMiddleware())
	{

		polls := protected.Group("/polls")
		{
			polls.POST("", h.CreatePoll)
			polls.GET("/my", h.GetMyPolls)
			polls.DELETE("/:id", h.DeletePoll)
			polls.POST("/:id/vote", h.CastVote)
			polls.OPTIONS("/:id/vote", h.CastVote)
			polls.GET("/:id/vote-status", h.CheckVoteStatus)

			trustedParties := polls.Group("/:id/trusted-parties")
			{
				trustedParties.POST("", h.AddTrustedParty)
				trustedParties.GET("", h.GetTrustedParties)
				trustedParties.DELETE("/:user_id", h.RemoveTrustedParty)
				trustedParties.GET("/check", h.CheckTrustedPartyStatus)
			}
		}
	}
}

func SuccessResponse(c *gin.Context, data interface{}) {
	c.JSON(http.StatusOK, model.SuccessResponse{
		Success: true,
		Message: "success",
		Data:    data,
	})
}

func ErrorResponse(c *gin.Context, err error) {
	var appErr model.AppError
	var statusCode int

	var e model.AppError
	if errors.As(err, &e) {
		appErr = e
		statusCode = getHTTPStatusFromErrorCode(e.Code)
	}

	c.JSON(statusCode, model.ErrorResponse{
		Error:   appErr.Code,
		Message: appErr.Message,
		Details: appErr.Details,
	})
}

func getHTTPStatusFromErrorCode(code model.ErrorCode) int {
	switch code {
	case model.ErrCodeInvalidInput:
		return http.StatusBadRequest
	case model.ErrCodeNotFound:
		return http.StatusNotFound
	case model.ErrCodeAlreadyExists:
		return http.StatusConflict
	case model.ErrCodeUnauthorized:
		return http.StatusUnauthorized
	case model.ErrCodeForbidden:
		return http.StatusForbidden
	case model.ErrCodePollNotActive:
		return http.StatusBadRequest
	case model.ErrCodeAlreadyVoted:
		return http.StatusConflict
	case model.ErrCodeMaxVotesReached:
		return http.StatusBadRequest
	case model.ErrCodeInvalidZKProof:
		return http.StatusBadRequest
	case model.ErrCodeVerificationError:
		return http.StatusBadRequest
	default:
		return http.StatusInternalServerError
	}
}

func GetUintParam(c *gin.Context, param string) (uint, error) {
	str := c.Param(param)
	val, err := strconv.ParseUint(str, 10, 32)
	if err != nil {
		return 0, model.NewAppError(model.ErrCodeInvalidInput, "invalid "+param+" parameter")
	}
	return uint(val), nil
}

func GetUserIDFromContext(c *gin.Context) (uint, bool) {
	userID, exists := c.Get("user_id")
	if !exists {
		return 0, false
	}

	if id, ok := userID.(uint); ok {
		return id, true
	}

	return 0, false
}

func GetJWTFromContext(c *gin.Context) (string, bool) {
	token, exists := c.Get("jwt_token")
	if !exists {
		return "", false
	}

	if tokenStr, ok := token.(string); ok {
		return tokenStr, true
	}

	return "", false
}

func BindAndValidate(c *gin.Context, obj interface{}) error {
	if err := c.ShouldBindJSON(obj); err != nil {
		return model.NewAppError(model.ErrCodeInvalidInput, "invalid request format", err.Error())
	}
	return nil
}

func (h *Handler) corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization")
		c.Header("Access-Control-Max-Age", "86400")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusOK)
			return
		}

		c.Next()
	}
}

func (h *Handler) loggerMiddleware() gin.HandlerFunc {
	return gin.Logger()
}

func (h *Handler) authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "authorization header required"))
			c.Abort()
			return
		}

		if len(authHeader) < 7 || authHeader[:7] != "Bearer " {
			ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "invalid authorization header format"))
			c.Abort()
			return
		}

		token := authHeader[7:]

		user, err := h.service.Poll.ValidateUser(c.Request.Context(), token)
		if err != nil {
			ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, err.Error()))
			c.Abort()
			return
		}

		if !user.CanVote {
			ErrorResponse(c, model.NewAppError(model.ErrCodeForbidden, "user not allowed to vote"))
			c.Abort()
			return
		}

		c.Set("user_id", user.UserID)
		c.Set("jwt_token", token)
		c.Set("user_roles", user.Roles)

		c.Next()
	}
}
