package handler

import (
	"github.com/gin-gonic/gin"
	"poll-management-service/internal/model"
)

func (h *Handler) CastVote(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	var req model.VoteRequest
	if err := BindAndValidate(c, &req); err != nil {
		ErrorResponse(c, err)
		return
	}

	jwtToken, exists := GetJWTFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "JWT token not found in context"))
		return
	}

	var userID *uint
	if req.AnonymousID == nil {

		id, exists := GetUserIDFromContext(c)
		if !exists {
			ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not found in context"))
			return
		}
		userID = &id
	}

	response, err := h.service.Vote.CastVote(c.Request.Context(), req, pollID, userID, jwtToken)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	SuccessResponse(c, response)
}

func (h *Handler) CheckVoteStatus(c *gin.Context) {

	pollID, err := GetUintParam(c, "id")
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	userID, exists := GetUserIDFromContext(c)
	if !exists {
		ErrorResponse(c, model.NewAppError(model.ErrCodeUnauthorized, "user not found in context"))
		return
	}

	hasVoted, err := h.service.Vote.HasUserVoted(c.Request.Context(), pollID, userID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	canVote, reason, err := h.service.Vote.CanUserVote(c.Request.Context(), pollID, userID)
	if err != nil {
		ErrorResponse(c, err)
		return
	}

	response := map[string]interface{}{
		"poll_id":   pollID,
		"user_id":   userID,
		"has_voted": hasVoted,
		"can_vote":  canVote,
		"reason":    reason,
	}

	SuccessResponse(c, response)
}
