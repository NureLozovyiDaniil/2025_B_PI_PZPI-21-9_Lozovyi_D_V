package model

import (
	"time"
)

type CreatePollRequest struct {
	Title           string                `json:"title" binding:"required,max=255"`
	Description     string                `json:"description" binding:"max=2000"`
	Category        string                `json:"category" binding:"required,max=100"`
	IsPrivate       bool                  `json:"is_private"`
	StartTime       time.Time             `json:"start_time" binding:"required"`
	EndTime         time.Time             `json:"end_time" binding:"required,gtfield=StartTime"`
	MinVoterTurnout *int                  `json:"min_voter_turnout,omitempty" binding:"omitempty,min=1"`
	MaxVotes        *int                  `json:"max_votes,omitempty" binding:"omitempty,min=1"`
	Options         []CreateOptionRequest `json:"options" binding:"required,min=2,max=10,dive"`
	TrustedParties  []string              `json:"trusted_parties,omitempty"`
}

type CreateOptionRequest struct {
	Text        string  `json:"text" binding:"required,max=500"`
	Description *string `json:"description,omitempty" binding:"omitempty,max=2000"`
}

type VoteRequest struct {
	OptionID    uint    `json:"option_id" binding:"required"`
	AnonymousID *string `json:"anonymous_id,omitempty"`

	ZkProof        map[string]interface{}
	BlindSignature *string `json:"blind_signature,omitempty"`
}

type PollResponse struct {
	ID              uint             `json:"id"`
	Title           string           `json:"title"`
	Description     string           `json:"description"`
	Category        string           `json:"category"`
	IsPrivate       bool             `json:"is_private"`
	CreatorID       uint             `json:"creator_id"`
	StartTime       time.Time        `json:"start_time"`
	EndTime         time.Time        `json:"end_time"`
	Status          string           `json:"status"`
	MinVoterTurnout *int             `json:"min_voter_turnout,omitempty"`
	MaxVotes        *int             `json:"max_votes,omitempty"`
	VoteCount       int              `json:"vote_count"`
	CanVote         bool             `json:"can_vote"`
	HasVoted        bool             `json:"has_voted"`
	IsActive        bool             `json:"is_active"`
	Options         []OptionResponse `json:"options"`
}

type PollCreationResponse struct {
	PollID           uint   `json:"poll_id"`
	BlockchainTxHash string `json:"blockchain_tx_hash"`
	Message          string `json:"message"`
}

type OptionResponse struct {
	ID          uint    `json:"id"`
	Text        string  `json:"text"`
	Description *string `json:"description,omitempty"`
	VoteCount   int     `json:"vote_count,omitempty"`
	Percentage  float64 `json:"percentage,omitempty"`
}

type VoteResponse struct {
	VoteID       uint      `json:"vote_id"`
	PollID       uint      `json:"poll_id"`
	OptionID     uint      `json:"option_id"`
	Timestamp    time.Time `json:"timestamp"`
	BlockchainTx *string   `json:"blockchain_tx,omitempty"`
}

type PollResultResponse struct {
	PollID       uint             `json:"poll_id"`
	Title        string           `json:"title"`
	Status       string           `json:"status"`
	TotalVotes   int              `json:"total_votes"`
	Options      []OptionResponse `json:"options"`
	WinnerOption *uint            `json:"winner_option,omitempty"`
	ResultHash   *string          `json:"result_hash,omitempty"`
}

type TrustedPartyResponse struct {
	ID         uint      `json:"id"`
	UserID     uint      `json:"user_id"`
	PollID     uint      `json:"poll_id"`
	PublicKey  string    `json:"public_key"`
	AssignedAt time.Time `json:"assigned_at"`
	AssignedBy uint      `json:"assigned_by"`
}

type TrustedPartiesListResponse struct {
	PollID         uint                   `json:"poll_id"`
	TrustedParties []TrustedPartyResponse `json:"trusted_parties"`
	Count          int                    `json:"count"`
}

type RemoveTrustedPartyRequest struct {
	UserID uint `json:"user_id" binding:"required"`
}

type TrustedPartyOperationResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
	PollID  uint   `json:"poll_id"`
	UserID  *uint  `json:"user_id,omitempty"`
}

type AddTrustedPartyRequest struct {
	Email string `json:"email" binding:"required,email"`
}

type CreateVerificationRequest struct {
	PollID         uint   `json:"poll_id" binding:"required"`
	BlindedMessage string `json:"blinded_message" binding:"required,max=256"`
}

type ProcessVerificationRequest struct {
	Action          string `json:"action" binding:"required,oneof=approve reject"`
	BlindSignature  string `json:"blind_signature,omitempty" binding:"required_if=Action approve"`
	RejectionReason string `json:"rejection_reason,omitempty" binding:"required_if=Action reject"`
}

type ListPollsRequest struct {
	Pagination
	Category  *string     `json:"category,omitempty"`
	IsPrivate *bool       `json:"is_private,omitempty"`
	Status    *PollStatus `json:"status,omitempty"`
	Search    *string     `json:"search,omitempty"`
}

type ListResponse[T any] struct {
	Items      []T              `json:"items"`
	Pagination PaginationResult `json:"pagination"`
}

type SuccessResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
}

type ErrorResponse struct {
	Error   ErrorCode `json:"error"`
	Message string    `json:"message"`
	Details any       `json:"details,omitempty"`
}

func (r *VoteRequest) Validate() error {
	if *r.AnonymousID == "" {
		return NewAppError(ErrCodeInvalidInput,
			"anonymous_id is required",
			"anonymous_id must be a 64-character hex string",
		)
	}

	if len(*r.AnonymousID) != 64 {
		return NewAppError(ErrCodeInvalidInput,
			"invalid anonymous_id length",
			"anonymous_id must be exactly 64 characters",
		)
	}

	for _, char := range *r.AnonymousID {
		if !((char >= '0' && char <= '9') || (char >= 'a' && char <= 'f') || (char >= 'A' && char <= 'F')) {
			return NewAppError(ErrCodeInvalidInput,
				"invalid anonymous_id format",
				"anonymous_id must be a hex string",
			)
		}
	}

	if r.OptionID == 0 {
		return NewAppError(ErrCodeInvalidInput,
			"option_id is required",
			"option_id must be greater than 0",
		)
	}

	if r.ZkProof == nil || len(r.ZkProof) == 0 {
		return NewAppError(ErrCodeInvalidInput,
			"zk_proof is required",
			"zk_proof must contain valid proof data",
		)
	}

	return nil
}
