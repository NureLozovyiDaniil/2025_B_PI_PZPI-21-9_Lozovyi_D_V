package model

import (
	"time"

	"gorm.io/gorm"
)

type PollStatus string

const (
	PollStatusActive PollStatus = "active"
	PollStatusEnded  PollStatus = "ended"
	PollStatusFailed PollStatus = "failed"
)

type Poll struct {
	ID               uint           `json:"id" gorm:"primaryKey"`
	Title            string         `json:"title" gorm:"not null;size:255;index"`
	Description      string         `json:"description" gorm:"type:text"`
	Category         string         `json:"category" gorm:"not null;size:100;index"`
	IsPrivate        bool           `json:"is_private" gorm:"not null;default:false;index"`
	CreatorID        uint           `json:"creator_id" gorm:"not null;index"`
	StartTime        time.Time      `json:"start_time" gorm:"not null;index"`
	EndTime          time.Time      `json:"end_time" gorm:"not null;index"`
	Status           PollStatus     `json:"status" gorm:"not null;type:varchar(20);default:'active';index"`
	MinVoterTurnout  *int           `json:"min_voter_turnout,omitempty"`
	MaxVotes         *int           `json:"max_votes,omitempty"`
	BlockchainTxHash *string        `json:"blockchain_tx_hash,omitempty" gorm:"size:66;index"`
	OptionsHash      string         `json:"options_hash,omitempty" gorm:"size:66;index"`
	CreatedAt        time.Time      `json:"created_at"`
	UpdatedAt        time.Time      `json:"updated_at"`
	DeletedAt        gorm.DeletedAt `json:"-" gorm:"index"`

	Options        []Option       `json:"options,omitempty" gorm:"foreignKey:PollID;constraint:OnDelete:CASCADE"`
	Votes          []Vote         `json:"votes,omitempty" gorm:"foreignKey:PollID;constraint:OnDelete:CASCADE"`
	TrustedParties []TrustedParty `json:"trusted_parties,omitempty" gorm:"foreignKey:PollID;constraint:OnDelete:CASCADE"`
}

func (Poll) TableName() string {
	return "polls"
}

func (p *Poll) BeforeCreate(tx *gorm.DB) error {
	if p.Status == "" {
		p.Status = PollStatusActive
	}

	if p.EndTime.Before(p.StartTime) {
		return NewAppError(ErrCodeInvalidInput, "end time must be after start time")
	}

	if !IsValidCategory(p.Category) {
		return ErrInvalidCategory
	}

	return nil
}

func (p *Poll) IsActive() bool {
	now := time.Now().UTC()
	return p.Status == PollStatusActive &&
		now.After(p.StartTime) &&
		now.Before(p.EndTime)
}

type Option struct {
	ID          uint           `json:"id" gorm:"primaryKey"`
	PollID      uint           `json:"poll_id" gorm:"not null;index"`
	Text        string         `json:"text" gorm:"not null;size:500"`
	Description *string        `json:"description,omitempty" gorm:"type:text"`
	CreatedAt   time.Time      `json:"created_at"`
	UpdatedAt   time.Time      `json:"updated_at"`
	DeletedAt   gorm.DeletedAt `json:"-" gorm:"index"`
}

func (Option) TableName() string {
	return "options"
}

type Vote struct {
	ID           uint           `json:"id" gorm:"primaryKey"`
	PollID       uint           `json:"poll_id" gorm:"not null;index"`
	OptionID     uint           `json:"option_id" gorm:"not null;index"`
	UserID       *uint          `json:"user_id,omitempty" gorm:"index"`
	AnonymousID  *string        `json:"anonymous_id,omitempty" gorm:"size:64;index"`
	ZkProofHash  *string        `json:"zk_proof_hash,omitempty" gorm:"size:64"`
	BlockchainTx *string        `json:"blockchain_tx,omitempty" gorm:"size:66"`
	Timestamp    time.Time      `json:"timestamp" gorm:"not null;index"`
	CreatedAt    time.Time      `json:"created_at"`
	DeletedAt    gorm.DeletedAt `json:"-" gorm:"index"`
}

func (Vote) TableName() string {
	return "votes"
}

func (v *Vote) BeforeCreate(tx *gorm.DB) error {
	if v.Timestamp.IsZero() {
		v.Timestamp = time.Now().UTC()
	}

	if v.UserID == nil && v.AnonymousID == nil {
		return NewAppError(ErrCodeInvalidInput, "either user_id or anonymous_id required")
	}

	if v.UserID != nil && v.AnonymousID != nil {
		return NewAppError(ErrCodeInvalidInput, "cannot have both user_id and anonymous_id")
	}

	if v.AnonymousID != nil && (v.ZkProofHash == nil || *v.ZkProofHash == "") {
		return NewAppError(ErrCodeInvalidInput, "zk_proof_hash required for anonymous votes")
	}

	return nil
}

type TrustedParty struct {
	ID         uint           `json:"id" gorm:"primaryKey"`
	UserID     uint           `json:"user_id" gorm:"not null;index"`
	PollID     uint           `json:"poll_id" gorm:"not null;index"`
	PublicKey  string         `json:"public_key" gorm:"not null;size:130"`
	AssignedAt time.Time      `json:"assigned_at" gorm:"not null"`
	AssignedBy uint           `json:"assigned_by" gorm:"not null"`
	CreatedAt  time.Time      `json:"created_at"`
	UpdatedAt  time.Time      `json:"updated_at"`
	DeletedAt  gorm.DeletedAt `json:"-" gorm:"index"`
}

func (TrustedParty) TableName() string {
	return "trusted_parties"
}

type TransactionStatus string

const (
	TransactionStatusPending   TransactionStatus = "pending"
	TransactionStatusConfirmed TransactionStatus = "confirmed"
	TransactionStatusFailed    TransactionStatus = "failed"
)

type BlockchainTransaction struct {
	ID          uint              `json:"id" gorm:"primaryKey"`
	TxHash      *string           `json:"tx_hash,omitempty" gorm:"size:66;uniqueIndex"`
	TxType      string            `json:"tx_type" gorm:"not null;size:50;index"`
	EntityType  string            `json:"entity_type" gorm:"not null;size:50"`
	EntityID    uint              `json:"entity_id" gorm:"not null;index"`
	Status      TransactionStatus `json:"status" gorm:"not null;size:20;default:'pending';index"`
	BlockNumber *uint64           `json:"block_number,omitempty"`
	GasPrice    *uint64           `json:"gas_price,omitempty"`
	GasUsed     *uint64           `json:"gas_used,omitempty"`
	Error       *string           `json:"error,omitempty" gorm:"type:text"`
	RetryCount  int               `json:"retry_count" gorm:"default:0"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
}

func (BlockchainTransaction) TableName() string {
	return "blockchain_transactions"
}

type PollResult struct {
	PollID        uint           `json:"poll_id" gorm:"primaryKey"`
	TotalVotes    int            `json:"total_votes" gorm:"not null;default:0"`
	WinnerOption  *uint          `json:"winner_option,omitempty"`
	ResultHash    *string        `json:"result_hash,omitempty" gorm:"size:64"`
	OptionResults []OptionResult `json:"option_results,omitempty" gorm:"foreignKey:PollID;constraint:OnDelete:CASCADE"`
	CreatedAt     time.Time      `json:"created_at"`
	UpdatedAt     time.Time      `json:"updated_at"`
}

func (PollResult) TableName() string {
	return "poll_results"
}

type OptionResult struct {
	ID         uint      `json:"id" gorm:"primaryKey"`
	PollID     uint      `json:"poll_id" gorm:"not null;index"`
	OptionID   uint      `json:"option_id" gorm:"not null;index"`
	VoteCount  int       `json:"vote_count" gorm:"not null;default:0"`
	Percentage float64   `json:"percentage" gorm:"not null;default:0"`
	CreatedAt  time.Time `json:"created_at"`
}

func (OptionResult) TableName() string {
	return "option_results"
}
