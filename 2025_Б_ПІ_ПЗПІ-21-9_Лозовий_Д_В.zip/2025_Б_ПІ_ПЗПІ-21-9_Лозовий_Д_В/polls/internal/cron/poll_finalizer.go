package cron

import (
	"context"
	"fmt"
	"log"
	"time"

	"poll-management-service/internal/config"
	"poll-management-service/internal/service"

	"github.com/robfig/cron/v3"
)

type PollFinalizer struct {
	service   *service.Service
	config    *config.Config
	cron      *cron.Cron
	logger    *log.Logger
	isRunning bool
}

func NewPollFinalizer(svc *service.Service, cfg *config.Config, logger *log.Logger) *PollFinalizer {

	c := cron.New(
		cron.WithLocation(time.UTC),
		cron.WithLogger(cron.VerbosePrintfLogger(logger)),
	)

	return &PollFinalizer{
		service: svc,
		config:  cfg,
		cron:    c,
		logger:  logger,
	}
}

func (pf *PollFinalizer) Start() error {
	if !pf.config.Cron.EnableJobs {
		pf.logger.Println("Poll finalizer disabled by config")
		return nil
	}

	if pf.isRunning {
		pf.logger.Println("Poll finalizer already running")
		return nil
	}

	cronExpr := convertIntervalToCronExpr(pf.config.Cron.PollFinalizerInterval)

	_, err := pf.cron.AddFunc(cronExpr, pf.finalizePollsJob)
	if err != nil {
		return err
	}

	pf.cron.Start()
	pf.isRunning = true

	pf.logger.Printf("Poll finalizer started with interval %v (%s)",
		pf.config.Cron.PollFinalizerInterval, cronExpr)

	return nil
}

func (pf *PollFinalizer) Stop() {
	if !pf.isRunning {
		return
	}

	ctx := pf.cron.Stop()
	select {
	case <-ctx.Done():
		pf.logger.Println("Poll finalizer stopped gracefully")
	case <-time.After(30 * time.Second):
		pf.logger.Println("Poll finalizer stop timeout, forcing shutdown")
	}

	pf.isRunning = false
}

func (pf *PollFinalizer) finalizePollsJob() {
	startTime := time.Now().UTC()
	pf.logger.Println("Starting poll finalization job...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	err := pf.service.Poll.FinalizePolls(ctx)
	if err != nil {
		pf.logger.Printf("Error finalizing polls: %v", err)
		return
	}

	duration := time.Since(startTime)
	pf.logger.Printf("Poll finalization job completed in %v", duration)
}

func (pf *PollFinalizer) IsRunning() bool {
	return pf.isRunning
}

func (pf *PollFinalizer) GetNextRun() time.Time {
	entries := pf.cron.Entries()
	if len(entries) > 0 {
		return entries[0].Next
	}
	return time.Time{}
}

func (pf *PollFinalizer) RunNow() error {
	if !pf.isRunning {
		return nil
	}

	pf.logger.Println("Running poll finalization manually...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	return pf.service.Poll.FinalizePolls(ctx)
}

func convertIntervalToCronExpr(interval time.Duration) string {
	switch {
	case interval == time.Minute:
		return "* * * * *"
	case interval == 5*time.Minute:
		return "*/5 * * * *"
	case interval == 10*time.Minute:
		return "*/10 * * * *"
	case interval == 30*time.Minute:
		return "*/30 * * * *"
	case interval == time.Hour:
		return "0 * * * *"
	default:

		minutes := int(interval.Minutes())
		if minutes <= 0 {
			minutes = 5
		}
		if minutes >= 60 {
			minutes = 59
		}
		return fmt.Sprintf("*/%d * * * *", minutes)
	}
}
