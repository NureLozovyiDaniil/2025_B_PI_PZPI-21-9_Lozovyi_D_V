package proxy

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"gateway/internal/config"

	"go.uber.org/zap"
)

type ServiceClient struct {
	name         string
	baseURL      string
	httpClient   *http.Client
	config       config.ServiceConfig
	logger       *zap.Logger
	healthStatus sync.Map
}

type Client struct {
	services map[string]*ServiceClient
	logger   *zap.Logger
}

func NewClient(servicesConfig config.ServicesConfig, logger *zap.Logger) *Client {
	client := &Client{
		services: make(map[string]*ServiceClient),
		logger:   logger,
	}

	client.services["identity"] = NewServiceClient("identity", servicesConfig.Identity, logger)
	client.services["poll"] = NewServiceClient("poll", servicesConfig.Poll, logger)
	client.services["verification"] = NewServiceClient("verification", servicesConfig.Verification, logger)
	client.services["blockchain"] = NewServiceClient("blockchain", servicesConfig.Blockchain, logger)

	client.startHealthChecks()

	return client
}

func NewServiceClient(name string, cfg config.ServiceConfig, logger *zap.Logger) *ServiceClient {
	return &ServiceClient{
		name:    name,
		baseURL: cfg.BaseURL,
		config:  cfg,
		logger:  logger.With(zap.String("service", name)),
		httpClient: &http.Client{
			Timeout: cfg.Timeout,
			Transport: &http.Transport{
				MaxIdleConns:        100,
				MaxIdleConnsPerHost: 10,
				IdleConnTimeout:     90 * time.Second,
			},
		},
	}
}

func (c *Client) ProxyRequest(serviceName string, originalReq *http.Request, requestID string) (*http.Response, error) {
	service, exists := c.services[serviceName]
	if !exists {
		return nil, fmt.Errorf("service %s not found", serviceName)
	}

	return service.ProxyRequest(originalReq, requestID)
}

func (sc *ServiceClient) ProxyRequest(originalReq *http.Request, requestID string) (*http.Response, error) {

	targetURL, err := sc.buildTargetURL(originalReq)
	if err != nil {
		return nil, fmt.Errorf("failed to build target URL: %w", err)
	}

	var bodyBytes []byte
	if originalReq.Body != nil {
		bodyBytes, err = io.ReadAll(originalReq.Body)
		if err != nil {
			return nil, fmt.Errorf("failed to read request body: %w", err)
		}
		originalReq.Body = io.NopCloser(bytes.NewReader(bodyBytes))
	}

	var lastErr error
	for attempt := 0; attempt <= sc.config.MaxRetries; attempt++ {
		if attempt > 0 {
			sc.logger.Debug("retrying request",
				zap.String("request_id", requestID),
				zap.Int("attempt", attempt),
				zap.String("url", targetURL))

			time.Sleep(sc.config.RetryDelay)
		}

		req, err := sc.createProxyRequest(originalReq, targetURL, bodyBytes, requestID)
		if err != nil {
			lastErr = err
			continue
		}

		resp, err := sc.httpClient.Do(req)
		if err != nil {
			lastErr = err
			sc.logger.Warn("request failed",
				zap.String("request_id", requestID),
				zap.Error(err),
				zap.Int("attempt", attempt+1))
			continue
		}

		if sc.shouldRetry(resp.StatusCode) && attempt < sc.config.MaxRetries {
			resp.Body.Close()
			lastErr = fmt.Errorf("received retryable status code: %d", resp.StatusCode)
			sc.logger.Warn("retryable response received",
				zap.String("request_id", requestID),
				zap.Int("status", resp.StatusCode),
				zap.Int("attempt", attempt+1))
			continue
		}

		sc.logger.Debug("request completed",
			zap.String("request_id", requestID),
			zap.String("method", originalReq.Method),
			zap.String("url", targetURL),
			zap.Int("status", resp.StatusCode),
			zap.Int("attempts", attempt+1))

		return resp, nil
	}

	return nil, fmt.Errorf("request failed after %d attempts: %w", sc.config.MaxRetries+1, lastErr)
}

func (sc *ServiceClient) createProxyRequest(originalReq *http.Request, targetURL string, bodyBytes []byte, requestID string) (*http.Request, error) {

	var bodyReader io.Reader
	if len(bodyBytes) > 0 {
		bodyReader = bytes.NewReader(bodyBytes)
	}

	req, err := http.NewRequestWithContext(originalReq.Context(), originalReq.Method, targetURL, bodyReader)
	if err != nil {
		return nil, err
	}

	sc.copyHeaders(originalReq, req)

	req.Header.Set("X-Request-ID", requestID)
	req.Header.Set("X-Forwarded-For", originalReq.RemoteAddr)
	req.Header.Set("X-Forwarded-Proto", "http")
	req.Header.Set("X-Gateway-Service", sc.name)

	req.Header.Set("User-Agent", "api-gateway/1.0.0")

	return req, nil
}

func (sc *ServiceClient) copyHeaders(from, to *http.Request) {

	headersToProxy := []string{
		"Content-Type",
		"Content-Length",
		"Authorization",
		"Accept",
		"Accept-Encoding",
		"Accept-Language",
		"Cache-Control",
		"If-Match",
		"If-None-Match",
		"If-Modified-Since",
		"If-Unmodified-Since",
		"X-User-ID",
		"X-User-Roles",
	}

	for _, header := range headersToProxy {
		if value := from.Header.Get(header); value != "" {
			to.Header.Set(header, value)
		}
	}

	for key, values := range from.Header {
		if strings.HasPrefix(key, "X-") &&
			key != "X-Request-ID" &&
			key != "X-Forwarded-For" &&
			key != "X-Forwarded-Proto" &&
			key != "X-Gateway-Service" {
			for _, value := range values {
				to.Header.Add(key, value)
			}
		}
	}
}

func (sc *ServiceClient) buildTargetURL(req *http.Request) (string, error) {
	targetURL, err := url.Parse(sc.baseURL)
	if err != nil {
		return "", err
	}

	targetURL.Path = req.URL.Path
	targetURL.RawQuery = req.URL.RawQuery

	return targetURL.String(), nil
}

func (sc *ServiceClient) shouldRetry(statusCode int) bool {

	retryableStatuses := []int{
		http.StatusInternalServerError,
		http.StatusBadGateway,
		http.StatusServiceUnavailable,
		http.StatusGatewayTimeout,
		http.StatusTooManyRequests,
	}

	for _, status := range retryableStatuses {
		if statusCode == status {
			return true
		}
	}

	return false
}

func (sc *ServiceClient) HealthCheck(ctx context.Context) error {
	healthURL := sc.baseURL + sc.config.HealthEndpoint

	req, err := http.NewRequestWithContext(ctx, "GET", healthURL, nil)
	if err != nil {
		return fmt.Errorf("failed to create health check request: %w", err)
	}

	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("health check request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		sc.healthStatus.Store("healthy", true)
		return nil
	}

	sc.healthStatus.Store("healthy", false)
	return fmt.Errorf("health check failed with status: %d", resp.StatusCode)
}

func (sc *ServiceClient) IsHealthy() bool {
	if status, ok := sc.healthStatus.Load("healthy"); ok {
		return status.(bool)
	}
	return false
}

func (c *Client) startHealthChecks() {
	ticker := time.NewTicker(30 * time.Second)

	go func() {
		defer ticker.Stop()

		for range ticker.C {
			for name, service := range c.services {
				go func(serviceName string, svc *ServiceClient) {
					ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
					defer cancel()

					if err := svc.HealthCheck(ctx); err != nil {
						c.logger.Warn("service health check failed",
							zap.String("service", serviceName),
							zap.Error(err))
					} else {
						c.logger.Debug("service health check passed",
							zap.String("service", serviceName))
					}
				}(name, service)
			}
		}
	}()
}

func (c *Client) GetServiceHealth() map[string]bool {
	health := make(map[string]bool)
	for name, service := range c.services {
		health[name] = service.IsHealthy()
	}
	return health
}

func (c *Client) Close() error {
	c.logger.Info("closing proxy clients")

	for name, service := range c.services {
		if service.httpClient != nil {
			service.httpClient.CloseIdleConnections()
			c.logger.Debug("closed service client", zap.String("service", name))
		}
	}

	return nil
}

func (c *Client) GetService(name string) (*ServiceClient, bool) {
	service, exists := c.services[name]
	return service, exists
}
