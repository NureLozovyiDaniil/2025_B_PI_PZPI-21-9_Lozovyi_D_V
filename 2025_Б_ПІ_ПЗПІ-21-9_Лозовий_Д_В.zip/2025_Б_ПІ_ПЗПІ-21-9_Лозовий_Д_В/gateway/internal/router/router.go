package router

import (
	"net/http"
	"time"

	"gateway/internal/config"
	"gateway/internal/middleware"
	"gateway/internal/proxy"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

type Router struct {
	config      *config.Config
	middlewares *middleware.Manager
	proxy       *proxy.ProxyHandler
	logger      *zap.Logger
}

func New(cfg *config.Config, middlewares *middleware.Manager, proxyClient *proxy.Client, logger *zap.Logger) *Router {
	proxyHandler := proxy.NewProxyHandler(proxyClient, logger)

	return &Router{
		config:      cfg,
		middlewares: middlewares,
		proxy:       proxyHandler,
		logger:      logger,
	}
}

func (r *Router) SetupRoutes(engine *gin.Engine) {

	r.setupGlobalMiddleware(engine)

	r.setupLocalRoutes(engine)

	r.setupAPIRoutes(engine)
}

func (r *Router) setupGlobalMiddleware(engine *gin.Engine) {

	engine.Use(middleware.RequestID())

	engine.Use(middleware.CORS(&r.config.CORS, r.logger))

	engine.Use(middleware.SecurityHeaders())
	engine.Use(middleware.CSPHeader(r.config.Environment != "production"))

	engine.Use(middleware.RequestLogger(r.logger))
	engine.Use(middleware.ErrorLogger(r.logger))

	engine.Use(middleware.PerformanceLogger(r.logger, 5*time.Second))

	engine.Use(middleware.RateLimit(&r.config.RateLimit, r.logger))

	engine.Use(gin.Recovery())
}

func (r *Router) setupLocalRoutes(engine *gin.Engine) {

	engine.GET("/health", r.healthCheck)

	gateway := engine.Group("/gateway")
	{
		gateway.GET("/status", r.proxy.GetServicesStatus())
		gateway.GET("/metrics", r.proxy.GetServiceMetrics())
		gateway.GET("/version", r.versionInfo)
	}

	admin := engine.Group("/gateway/admin")
	admin.Use(middleware.Auth(r.config, r.logger))
	admin.Use(middleware.RequireAdmin(r.logger))
	{
		admin.GET("/config", r.getGatewayConfig)
		admin.GET("/services", r.getServiceDetails)
		admin.POST("/services/:name/health", r.forceHealthCheck)
	}
}

func (r *Router) setupAPIRoutes(engine *gin.Engine) {
	api := engine.Group("/api/v1")

	r.setupPublicAPIRoutes(api)

	r.setupProtectedAPIRoutes(api)
}

func (r *Router) setupPublicAPIRoutes(api *gin.RouterGroup) {

	public := api.Group("")
	public.Use(middleware.BurstProtection(20, time.Minute, r.logger))

	auth := public.Group("/auth")
	auth.Use(middleware.EndpointSpecificRateLimit(r.logger))
	{

		auth.POST("/register", r.proxy.ProxyRequest)
		auth.POST("/login", r.proxy.ProxyRequest)
	}

	polls := public.Group("/polls")
	{
		polls.GET("/public", r.proxy.ProxyRequest)
		polls.GET("/public/:id", r.proxy.ProxyRequest)
		polls.GET("/public/:id/results", r.proxy.ProxyRequest)
	}
}

func (r *Router) setupProtectedAPIRoutes(api *gin.RouterGroup) {

	protected := api.Group("")
	protected.Use(middleware.Auth(r.config, r.logger))
	protected.Use(middleware.UserBasedRateLimit(&r.config.RateLimit, r.logger))

	r.setupUserRoutes(protected)

	r.setupPollRoutes(protected)

	r.setupVerificationRoutes(protected)

	r.setupBlockchainRoutes(protected)

	r.setupAdminRoutes(protected)
}

func (r *Router) setupUserRoutes(protected *gin.RouterGroup) {
	users := protected.Group("/users")
	{

		users.GET("/me", r.proxy.ProxyRequest)
		users.PUT("/me", r.proxy.ProxyRequest)
		users.PUT("/me/password", r.proxy.ProxyRequest)

		adminUsers := users.Group("")
		adminUsers.Use(middleware.RequireAnyRole([]string{"admin", "super_admin"}, r.logger))
		{
			adminUsers.GET("/", r.proxy.ProxyRequest)
			adminUsers.GET("/:id", r.proxy.ProxyRequest)
			adminUsers.PUT("/:id", r.proxy.ProxyRequest)
			adminUsers.DELETE("/:id", r.proxy.ProxyRequest)
		}
	}

	roles := protected.Group("/roles")
	roles.Use(middleware.RequireAnyRole([]string{"admin", "super_admin"}, r.logger))
	{
		roles.GET("/", r.proxy.ProxyRequest)
		roles.GET("/:id", r.proxy.ProxyRequest)
		roles.POST("/", r.proxy.ProxyRequest)
		roles.PUT("/:id", r.proxy.ProxyRequest)
		roles.DELETE("/:id", r.proxy.ProxyRequest)
	}

	userRoles := protected.Group("/user-roles")
	userRoles.Use(middleware.RequireAnyRole([]string{"admin", "super_admin"}, r.logger))
	{
		userRoles.POST("/", r.proxy.ProxyRequest)
		userRoles.DELETE("/:user_id/:role_id", r.proxy.ProxyRequest)
		userRoles.PUT("/:user_id/:role_id", r.proxy.ProxyRequest)
		userRoles.GET("/user/:user_id", r.proxy.ProxyRequest)
	}
}

func (r *Router) setupPollRoutes(protected *gin.RouterGroup) {
	polls := protected.Group("/polls")
	{

		polls.GET("/", r.proxy.ProxyRequest)
		polls.GET("/:id", r.proxy.ProxyRequest)
		polls.POST("/", r.proxy.ProxyRequest)
		polls.PUT("/:id", r.proxy.ProxyRequest)
		polls.DELETE("/:id", r.proxy.ProxyRequest)

		privatePoll := polls.Group("/private")
		privatePoll.Use(middleware.RequirePremium(r.logger))
		{
			privatePoll.POST("/", r.proxy.ProxyRequest)
			privatePoll.GET("/:id", r.proxy.ProxyRequest)
		}
	}

	votes := protected.Group("/votes")
	{
		votes.POST("/", r.proxy.ProxyRequest)
		votes.GET("/poll/:poll_id", r.proxy.ProxyRequest)
		votes.DELETE("/:id", r.proxy.ProxyRequest)
	}

	results := protected.Group("/results")
	{
		results.GET("/poll/:poll_id", r.proxy.ProxyRequest)
	}
}

func (r *Router) setupVerificationRoutes(protected *gin.RouterGroup) {
	verification := protected.Group("/verification")
	verification.Use(middleware.EndpointSpecificRateLimit(r.logger))
	{

		verification.POST("/blind-signature/request", r.proxy.ProxyRequest)
		verification.GET("/blind-signature/:id", r.proxy.ProxyRequest)

		verification.POST("/zkp/generate", r.proxy.ProxyRequest)
		verification.POST("/zkp/verify", r.proxy.ProxyRequest)

		trustedParties := verification.Group("/trusted-parties")
		trustedParties.Use(middleware.RequireAnyRole([]string{"admin", "premium"}, r.logger))
		{
			trustedParties.GET("/", r.proxy.ProxyRequest)
			trustedParties.POST("/", r.proxy.ProxyRequest)
			trustedParties.PUT("/:id", r.proxy.ProxyRequest)
			trustedParties.DELETE("/:id", r.proxy.ProxyRequest)
		}
	}
}

func (r *Router) setupBlockchainRoutes(protected *gin.RouterGroup) {
	blockchain := protected.Group("/blockchain")
	blockchain.Use(middleware.EndpointSpecificRateLimit(r.logger))
	{

		blockchain.POST("/transactions", r.proxy.ProxyRequest)
		blockchain.GET("/transactions/:hash", r.proxy.ProxyRequest)

		contracts := blockchain.Group("/contracts")
		{
			contracts.GET("/poll-registry/:poll_id", r.proxy.ProxyRequest)
			contracts.GET("/voting-verifier/:proof_id", r.proxy.ProxyRequest)
			contracts.GET("/result-storage/:poll_id", r.proxy.ProxyRequest)
		}

		adminBlockchain := blockchain.Group("/admin")
		adminBlockchain.Use(middleware.RequireAdmin(r.logger))
		{
			adminBlockchain.GET("/status", r.proxy.ProxyRequest)
			adminBlockchain.POST("/deploy", r.proxy.ProxyRequest)
		}
	}
}

func (r *Router) setupAdminRoutes(protected *gin.RouterGroup) {
	admin := protected.Group("/admin")
	admin.Use(middleware.RequireAnyRole([]string{"admin", "super_admin"}, r.logger))
	{

		admin.GET("/stats", r.proxy.ProxyRequest)
		admin.POST("/maintenance", r.proxy.ProxyRequest)
	}

	system := protected.Group("/system")
	system.Use(middleware.RequireRole("super_admin", r.logger))
	{
		system.GET("/config", r.proxy.ProxyRequest)
		system.PUT("/config", r.proxy.ProxyRequest)
	}
}

func (r *Router) healthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "ok",
		"timestamp": time.Now().Unix(),
		"service":   "api-gateway",
	})
}

func (r *Router) versionInfo(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"service":     "api-gateway",
		"version":     "1.0.0",
		"build":       time.Now().Format("2006-01-02"),
		"environment": r.config.Environment,
	})
}

func (r *Router) getGatewayConfig(c *gin.Context) {

	c.JSON(http.StatusOK, gin.H{
		"data": gin.H{
			"environment":    r.config.Environment,
			"server_address": r.config.ServerAddress,
			"rate_limit":     r.config.RateLimit,
			"cors":           r.config.CORS,
			"services": gin.H{
				"identity":     gin.H{"base_url": r.config.Services.Identity.BaseURL},
				"poll":         gin.H{"base_url": r.config.Services.Poll.BaseURL},
				"verification": gin.H{"base_url": r.config.Services.Verification.BaseURL},
				"blockchain":   gin.H{"base_url": r.config.Services.Blockchain.BaseURL},
			},
		},
	})
}

func (r *Router) getServiceDetails(c *gin.Context) {

	c.JSON(http.StatusOK, gin.H{
		"data": gin.H{
			"services":  r.config.Services,
			"timestamp": time.Now().Unix(),
		},
	})
}

func (r *Router) forceHealthCheck(c *gin.Context) {
	serviceName := c.Param("name")

	r.logger.Info("forced health check requested",
		zap.String("service", serviceName),
		zap.Uint("admin_user_id", c.GetUint("userID")))

	c.JSON(http.StatusOK, gin.H{
		"message": "Health check triggered for service: " + serviceName,
	})
}
