package middleware

import (
	"fmt"
	"net/http"
	"strconv"
	"sync"
	"time"

	"gateway/internal/config"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"golang.org/x/time/rate"
)

type RateLimiter struct {
	limiters map[string]*rate.Limiter
	mutex    sync.RWMutex
	rate     rate.Limit
	burst    int
	cleanup  time.Duration
	logger   *zap.Logger
}

func NewRateLimiter(requestsPerSecond float64, burstSize int, logger *zap.Logger) *RateLimiter {
	rl := &RateLimiter{
		limiters: make(map[string]*rate.Limiter),
		rate:     rate.Limit(requestsPerSecond),
		burst:    burstSize,
		cleanup:  time.Minute * 5,
		logger:   logger,
	}

	go rl.cleanupRoutine()

	return rl
}

func (rl *RateLimiter) getLimiter(key string) *rate.Limiter {
	rl.mutex.RLock()
	limiter, exists := rl.limiters[key]
	rl.mutex.RUnlock()

	if exists {
		return limiter
	}

	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	if limiter, exists := rl.limiters[key]; exists {
		return limiter
	}

	limiter = rate.NewLimiter(rl.rate, rl.burst)
	rl.limiters[key] = limiter
	return limiter
}

func (rl *RateLimiter) cleanupRoutine() {
	ticker := time.NewTicker(rl.cleanup)
	defer ticker.Stop()

	for range ticker.C {
		rl.mutex.Lock()
		for key, limiter := range rl.limiters {

			if limiter.Tokens() == float64(rl.burst) {
				delete(rl.limiters, key)
			}
		}
		rl.mutex.Unlock()
	}
}

func RateLimit(cfg *config.RateLimitConfig, logger *zap.Logger) gin.HandlerFunc {
	if !cfg.Enabled {
		return func(c *gin.Context) {
			c.Next()
		}
	}

	limiter := NewRateLimiter(cfg.RequestsPerSecond, cfg.BurstSize, logger)

	return func(c *gin.Context) {

		key := c.ClientIP()

		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("client_ip", key),
				zap.String("path", c.Request.URL.Path),
				zap.String("method", c.Request.Method))

			c.Header("X-RateLimit-Limit", strconv.FormatFloat(cfg.RequestsPerSecond, 'f', 2, 64))
			c.Header("X-RateLimit-Remaining", "0")
			c.Header("X-RateLimit-Reset", strconv.FormatInt(time.Now().Add(time.Second).Unix(), 10))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_RATE_LIMIT_EXCEEDED",
					"message": "Rate limit exceeded. Please slow down your requests.",
				},
			})
			c.Abort()
			return
		}

		remaining := int(clientLimiter.Tokens())
		c.Header("X-RateLimit-Limit", strconv.FormatFloat(cfg.RequestsPerSecond, 'f', 2, 64))
		c.Header("X-RateLimit-Remaining", strconv.Itoa(remaining))

		c.Next()
	}
}

func UserBasedRateLimit(cfg *config.RateLimitConfig, logger *zap.Logger) gin.HandlerFunc {
	if !cfg.Enabled {
		return func(c *gin.Context) {
			c.Next()
		}
	}

	limiter := NewRateLimiter(cfg.RequestsPerSecond, cfg.BurstSize, logger)

	return func(c *gin.Context) {
		var key string

		if userID := c.GetUint("userID"); userID > 0 {
			key = fmt.Sprintf("user:%d", userID)
		} else {

			key = fmt.Sprintf("ip:%s", c.ClientIP())
		}

		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("user rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("key", key),
				zap.String("path", c.Request.URL.Path))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_USER_RATE_LIMIT_EXCEEDED",
					"message": "User rate limit exceeded. Please slow down your requests.",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func EndpointSpecificRateLimit(logger *zap.Logger) gin.HandlerFunc {

	limiters := map[string]*RateLimiter{
		"auth":         NewRateLimiter(5, 10, logger),
		"polls":        NewRateLimiter(20, 30, logger),
		"votes":        NewRateLimiter(10, 15, logger),
		"verification": NewRateLimiter(2, 5, logger),
		"blockchain":   NewRateLimiter(1, 3, logger),
		"default":      NewRateLimiter(50, 100, logger),
	}

	return func(c *gin.Context) {
		path := c.Request.URL.Path
		category := getEndpointCategory(path)

		limiter := limiters[category]
		if limiter == nil {
			limiter = limiters["default"]
		}

		var key string
		if userID := c.GetUint("userID"); userID > 0 {
			key = fmt.Sprintf("%s:user:%d", category, userID)
		} else {
			key = fmt.Sprintf("%s:ip:%s", category, c.ClientIP())
		}

		clientLimiter := limiter.getLimiter(key)

		if !clientLimiter.Allow() {
			requestID, _ := c.Get("requestID")

			logger.Warn("endpoint-specific rate limit exceeded",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("category", category),
				zap.String("key", key),
				zap.String("path", path))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_ENDPOINT_RATE_LIMIT_EXCEEDED",
					"message": fmt.Sprintf("Rate limit exceeded for %s operations", category),
				},
			})
			c.Abort()
			return
		}

		remaining := int(clientLimiter.Tokens())
		c.Header("X-RateLimit-Category", category)
		c.Header("X-RateLimit-Remaining", strconv.Itoa(remaining))

		c.Next()
	}
}

func BurstProtection(maxBurst int, windowDuration time.Duration, logger *zap.Logger) gin.HandlerFunc {
	type clientData struct {
		requests []time.Time
		mutex    sync.Mutex
	}

	clients := make(map[string]*clientData)
	clientsMutex := sync.RWMutex{}

	go func() {
		ticker := time.NewTicker(windowDuration)
		defer ticker.Stop()

		for range ticker.C {
			now := time.Now()
			clientsMutex.Lock()
			for key, data := range clients {
				data.mutex.Lock()

				validRequests := []time.Time{}
				for _, req := range data.requests {
					if now.Sub(req) < windowDuration {
						validRequests = append(validRequests, req)
					}
				}
				data.requests = validRequests

				if len(validRequests) == 0 {
					delete(clients, key)
				}
				data.mutex.Unlock()
			}
			clientsMutex.Unlock()
		}
	}()

	return func(c *gin.Context) {
		clientIP := c.ClientIP()
		now := time.Now()

		clientsMutex.RLock()
		client, exists := clients[clientIP]
		clientsMutex.RUnlock()

		if !exists {
			clientsMutex.Lock()
			client = &clientData{
				requests: []time.Time{},
			}
			clients[clientIP] = client
			clientsMutex.Unlock()
		}

		client.mutex.Lock()
		defer client.mutex.Unlock()

		validRequests := []time.Time{}
		for _, req := range client.requests {
			if now.Sub(req) < windowDuration {
				validRequests = append(validRequests, req)
			}
		}
		client.requests = validRequests

		if len(client.requests) >= maxBurst {
			requestID, _ := c.Get("requestID")

			logger.Warn("burst protection triggered",
				zap.String("request_id", fmt.Sprintf("%v", requestID)),
				zap.String("client_ip", clientIP),
				zap.Int("requests_in_window", len(client.requests)),
				zap.Int("max_burst", maxBurst),
				zap.Duration("window", windowDuration))

			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": gin.H{
					"code":    "ERR_BURST_LIMIT_EXCEEDED",
					"message": "Too many requests in a short time. Please wait before retrying.",
				},
			})
			c.Abort()
			return
		}

		client.requests = append(client.requests, now)

		c.Next()
	}
}

func getEndpointCategory(path string) string {
	switch {
	case contains(path, "/auth/"):
		return "auth"
	case contains(path, "/polls/"):
		return "polls"
	case contains(path, "/votes/"):
		return "votes"
	case contains(path, "/verification/"):
		return "verification"
	case contains(path, "/blockchain/"):
		return "blockchain"
	default:
		return "default"
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || (len(s) > len(substr) &&
		(s[:len(substr)] == substr || s[len(s)-len(substr):] == substr ||
			s[1:len(substr)+1] == substr)))
}
