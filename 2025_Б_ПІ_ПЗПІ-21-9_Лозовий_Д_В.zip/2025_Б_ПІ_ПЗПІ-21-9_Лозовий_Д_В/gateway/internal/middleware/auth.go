package middleware

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"gateway/internal/config"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"go.uber.org/zap"
)

type Claims struct {
	UserID uint     `json:"user_id"`
	Roles  []string `json:"roles"`
	jwt.RegisteredClaims
}

func Auth(cfg *config.Config, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {

		header := c.GetHeader("Authorization")
		if header == "" {
			logger.Warn("missing authorization header",
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))

			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_MISSING_TOKEN",
					"message": "Authorization header is required",
				},
			})
			c.Abort()
			return
		}

		headerParts := strings.SplitN(header, " ", 2)
		if len(headerParts) != 2 || headerParts[0] != "Bearer" {
			logger.Warn("invalid token format",
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))

			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN_FORMAT",
					"message": "Invalid authorization header format",
				},
			})
			c.Abort()
			return
		}

		tokenString := headerParts[1]

		userID, roles, err := parseJWTToken(tokenString, cfg.JWT.SecretKey)
		if err != nil {
			logger.Warn("invalid token",
				zap.Error(err),
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))

			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_INVALID_TOKEN",
					"message": "Invalid or expired token",
				},
			})
			c.Abort()
			return
		}

		c.Set("userID", userID)
		c.Set("roles", roles)
		c.Set("permissions", extractPermissionsFromRoles(roles))

		c.Header("X-User-ID", strconv.Itoa(int(userID)))
		c.Header("X-User-Roles", strings.Join(roles, ","))

		if shouldLogAuth(c.FullPath()) {
			logger.Info("authenticated request",
				zap.Uint("user_id", userID),
				zap.Strings("roles", roles),
				zap.String("path", c.FullPath()),
				zap.String("method", c.Request.Method))
		}

		c.Next()
	}
}

func RequireRole(requiredRole string, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			logger.Warn("user not authenticated for role check",
				zap.String("required_role", requiredRole),
				zap.String("path", c.FullPath()))

			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			logger.Error("invalid role data format")
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		hasRole := false
		for _, role := range rolesList {
			if role == requiredRole {
				hasRole = true
				break
			}
		}

		if !hasRole {
			logger.Warn("insufficient role",
				zap.String("required_role", requiredRole),
				zap.Strings("user_roles", rolesList),
				zap.Uint("user_id", c.GetUint("userID")))

			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": fmt.Sprintf("Required role '%s' not found", requiredRole),
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func RequireAnyRole(requiredRoles []string, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		roles, exists := c.Get("roles")
		if !exists {
			c.JSON(http.StatusUnauthorized, gin.H{
				"error": gin.H{
					"code":    "ERR_UNAUTHORIZED",
					"message": "User not authenticated",
				},
			})
			c.Abort()
			return
		}

		rolesList, ok := roles.([]string)
		if !ok {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": gin.H{
					"code":    "ERR_INTERNAL",
					"message": "Invalid role data",
				},
			})
			c.Abort()
			return
		}

		hasRole := false
		for _, userRole := range rolesList {
			for _, requiredRole := range requiredRoles {
				if userRole == requiredRole {
					hasRole = true
					break
				}
			}
			if hasRole {
				break
			}
		}

		if !hasRole {
			logger.Warn("insufficient roles",
				zap.Strings("required_roles", requiredRoles),
				zap.Strings("user_roles", rolesList),
				zap.Uint("user_id", c.GetUint("userID")))

			c.JSON(http.StatusForbidden, gin.H{
				"error": gin.H{
					"code":    "ERR_INSUFFICIENT_ROLE",
					"message": "Required role not found",
				},
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

func RequirePremium(logger *zap.Logger) gin.HandlerFunc {
	return RequireAnyRole([]string{"premium", "admin", "super_admin"}, logger)
}

func RequireAdmin(logger *zap.Logger) gin.HandlerFunc {
	return RequireAnyRole([]string{"admin", "super_admin"}, logger)
}

func parseJWTToken(tokenString, secretKey string) (uint, []string, error) {
	token, err := jwt.ParseWithClaims(tokenString, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(secretKey), nil
	})

	if err != nil {
		return 0, nil, err
	}

	if claims, ok := token.Claims.(*Claims); ok && token.Valid {
		return claims.UserID, claims.Roles, nil
	}

	return 0, nil, fmt.Errorf("invalid token claims")
}

func extractPermissionsFromRoles(roles []string) []string {
	permissionMap := map[string][]string{
		"admin": {
			"users:read", "users:write", "users:delete",
			"roles:read", "roles:write", "roles:delete",
			"polls:read", "polls:write", "polls:delete",
			"votes:read", "verification:manage",
		},
		"moderator": {
			"users:read", "users:write",
			"roles:read",
			"polls:read", "polls:write",
			"votes:read",
		},
		"premium": {
			"users:read",
			"polls:read", "polls:write", "polls:create_private",
			"votes:write",
		},
		"user": {
			"users:read",
			"polls:read", "polls:create_public",
			"votes:write",
		},
		"super_admin": {"*:*"},
	}

	var permissions []string
	permissionSet := make(map[string]bool)

	for _, role := range roles {
		if rolePermissions, exists := permissionMap[role]; exists {
			for _, permission := range rolePermissions {
				if !permissionSet[permission] {
					permissions = append(permissions, permission)
					permissionSet[permission] = true
				}
			}
		}
	}

	return permissions
}

func shouldLogAuth(path string) bool {
	sensitivePatterns := []string{
		"/api/v1/admin",
		"/api/v1/roles",
		"/api/v1/user-roles",
		"/api/v1/polls/private",
		"/api/v1/verification",
		"/api/v1/blockchain",
	}

	for _, pattern := range sensitivePatterns {
		if strings.Contains(path, pattern) {
			return true
		}
	}
	return false
}
