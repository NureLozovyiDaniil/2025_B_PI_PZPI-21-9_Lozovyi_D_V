package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"go.uber.org/zap"

	"blockchain-service/internal/api"
	"blockchain-service/internal/client"
	"blockchain-service/internal/config"
	"blockchain-service/internal/service"
	"blockchain-service/internal/utils"
	"blockchain-service/internal/web3"
)

const (
	ServiceName    = "blockchain-service"
	ServiceVersion = "1.0.0-phase1"
	ServicePhase   = "Phase 1 (Open Voting Only)"
)

func main() {

	ctx := context.Background()

	fmt.Printf("🚀 Starting %s v%s\n", ServiceName, ServiceVersion)
	fmt.Printf("📋 %s\n", ServicePhase)
	fmt.Println()

	cfg, err := loadConfiguration()
	if err != nil {
		fmt.Printf("❌ Failed to load configuration: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("⚙️  Configuration loaded successfully\n")
	fmt.Printf("🌐 Network: %s (Chain ID: %d)\n", cfg.GetNetworkName(), cfg.Blockchain.ChainID)
	fmt.Printf("🔗 RPC URL: %s\n", cfg.Blockchain.RpcURL)
	fmt.Printf("👤 Identity Service: %s\n", cfg.Identity.BaseURL)
	fmt.Println()

	if err := utils.InitLogger(&cfg.Logging); err != nil {
		fmt.Printf("❌ Failed to initialize logger: %v\n", err)
		os.Exit(1)
	}
	defer utils.Shutdown()

	logger := utils.GetLogger()
	logger.Info("Logger initialized",
		zap.String("service", ServiceName),
		zap.String("version", ServiceVersion),
		zap.String("phase", ServicePhase))

	components, err := initializeComponents(ctx, cfg, logger)
	if err != nil {
		logger.Fatal("Failed to initialize components", zap.Error(err))
	}

	if err := performHealthChecks(ctx, components, logger); err != nil {
		logger.Fatal("Health checks failed", zap.Error(err))
	}

	httpServer := createHTTPServer(cfg, components, logger)

	go func() {
		logger.Info("Starting HTTP server",
			zap.String("address", fmt.Sprintf(":%s", cfg.Server.Port)),
			zap.Duration("read_timeout", cfg.Server.ReadTimeout),
			zap.Duration("write_timeout", cfg.Server.WriteTimeout))

		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("HTTP server failed to start", zap.Error(err))
		}
	}()

	fmt.Printf("✅ %s started successfully!\n", ServiceName)
	fmt.Printf("🌐 Server running on port %s\n", cfg.Server.Port)
	fmt.Printf("📖 API docs: http://localhost:%s/api/v1/docs\n", cfg.Server.Port)
	fmt.Printf("❤️  Health check: http://localhost:%s/api/health\n", cfg.Server.Port)
	fmt.Println()
	fmt.Println("Press Ctrl+C to gracefully shutdown...")

	waitForShutdownSignal(ctx, httpServer, components, logger)
}

type Components struct {
	Web3Client        *web3.Web3Client
	IdentityClient    *client.IdentityClient
	BlockchainService *service.BlockchainService
}

func loadConfiguration() (*config.Config, error) {
	cfg, err := config.LoadConfig(".")
	if err != nil {
		return nil, fmt.Errorf("loading config: %w", err)
	}

	if !cfg.Blockchain.HasContractAddresses() {
		fmt.Printf("⚠️  Warning: Contract addresses not configured\n")
		fmt.Printf("   Set BLOCKCHAIN_POLL_REGISTRY_ADDRESS, BLOCKCHAIN_VOTE_VERIFIER_ADDRESS, BLOCKCHAIN_RESULT_STORAGE_ADDRESS\n")
		fmt.Printf("   Service will start but contract operations will fail\n")
		fmt.Println()
	}

	return cfg, nil
}

func initializeComponents(ctx context.Context, cfg *config.Config, logger *zap.Logger) (*Components, error) {
	logger.Info("Initializing system components...")

	logger.Info("Connecting to blockchain network...",
		zap.String("network", cfg.GetNetworkName()),
		zap.Int64("chain_id", cfg.Blockchain.ChainID))

	web3Client, err := web3.NewWeb3Client(&cfg.Blockchain)
	if err != nil {
		return nil, fmt.Errorf("failed to create Web3 client: %w", err)
	}

	logger.Info("Web3 client connected successfully",
		zap.String("address", web3Client.GetAddress().Hex()))

	logger.Info("Initializing Identity Service client...",
		zap.String("base_url", cfg.Identity.BaseURL))

	identityClient := client.NewIdentityClient(&cfg.Identity)

	logger.Info("Identity client initialized successfully")

	logger.Info("Initializing Blockchain Service...")

	blockchainService, err := service.NewBlockchainService(web3Client, identityClient, &cfg.Blockchain)
	if err != nil {

		if err.Error() == "contract addresses not configured" {
			logger.Warn("Blockchain service initialized with limited functionality",
				zap.Error(err))

			blockchainService = nil
		} else {
			return nil, fmt.Errorf("failed to create Blockchain service: %w", err)
		}
	} else {
		logger.Info("Blockchain service initialized successfully")
	}

	return &Components{
		Web3Client:        web3Client,
		IdentityClient:    identityClient,
		BlockchainService: blockchainService,
	}, nil
}

func performHealthChecks(ctx context.Context, components *Components, logger *zap.Logger) error {
	logger.Info("Performing health checks...")

	logger.Info("Checking Web3 connection...")
	web3Health := components.Web3Client.Health(ctx)
	if !web3Health["connected"].(bool) {
		return fmt.Errorf("Web3 connection failed: %v", web3Health["error"])
	}

	logger.Info("Web3 connection healthy",
		zap.String("network", web3Health["network_name"].(string)),
		zap.Any("block_number", web3Health["block_number"]),
		zap.String("balance", web3Health["balance_eth"].(string)+" ETH"))

	logger.Info("Checking Identity Service connection...")
	identityHealth, err := components.IdentityClient.Health(ctx)
	if err != nil {
		logger.Warn("Identity Service health check failed",
			zap.Error(err),
			zap.String("note", "Service will start but user address resolution will fail"))
	} else {
		logger.Info("Identity Service connection healthy",
			zap.String("status", identityHealth.Status),
			zap.String("version", identityHealth.Version))
	}

	if components.BlockchainService != nil {
		logger.Info("Checking Blockchain Service...")
		blockchainHealth := components.BlockchainService.Health(ctx)
		if blockchainHealth["overall_status"] != "healthy" {
			logger.Warn("Blockchain Service health check issues detected",
				zap.Any("health", blockchainHealth))
		} else {
			logger.Info("Blockchain Service healthy")
		}
	}

	logger.Info("Health checks completed successfully")
	return nil
}

func createHTTPServer(cfg *config.Config, components *Components, logger *zap.Logger) *http.Server {
	logger.Info("Setting up HTTP server...")

	if components.BlockchainService != nil {
		routerCfg := api.RouterConfig{
			Config:            cfg,
			BlockchainService: components.BlockchainService,
		}
		ginRouter := api.NewRouter(routerCfg)

		server := &http.Server{
			Addr:         ":" + cfg.Server.Port,
			Handler:      ginRouter,
			ReadTimeout:  cfg.Server.ReadTimeout,
			WriteTimeout: cfg.Server.WriteTimeout,
			IdleTimeout:  cfg.Server.IdleTimeout,
		}

		logger.Info("HTTP server configured successfully")
		return server
	}

	logger.Warn("Creating limited HTTP server (Blockchain Service not available)")

	mux := http.NewServeMux()
	mux.HandleFunc("/api/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		w.Write([]byte(`{
			"status": "limited",
			"message": "Service running with limited functionality",
			"web3_connected": true,
			"contracts_configured": false
		}`))
	})

	return &http.Server{
		Addr:         ":" + cfg.Server.Port,
		Handler:      mux,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
		IdleTimeout:  cfg.Server.IdleTimeout,
	}
}

func waitForShutdownSignal(ctx context.Context, server *http.Server, components *Components, logger *zap.Logger) {

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	sig := <-quit
	logger.Info("Received shutdown signal",
		zap.String("signal", sig.String()))

	fmt.Printf("\n🛑 Gracefully shutting down %s...\n", ServiceName)

	shutdownCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()

	logger.Info("Shutting down HTTP server...")
	if err := server.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP server shutdown error", zap.Error(err))
	} else {
		logger.Info("HTTP server stopped gracefully")
	}

	logger.Info("Closing external connections...")

	if components.Web3Client != nil {
		components.Web3Client.Close()
		logger.Info("Web3 client connection closed")
	}

	if components.IdentityClient != nil {
		components.IdentityClient.ClearCache()
		logger.Info("Identity client cache cleared")
	}

	logger.Info("Graceful shutdown completed successfully")
	fmt.Printf("👋 %s stopped. Goodbye!\n", ServiceName)
}

func init() {

	setDefaultEnvIfEmpty("BLOCKCHAIN_SERVICE_PORT", "8081")
	setDefaultEnvIfEmpty("BLOCKCHAIN_RPC_URL", "http://localhost:8545")
	setDefaultEnvIfEmpty("BLOCKCHAIN_CHAIN_ID", "31337")
	setDefaultEnvIfEmpty("IDENTITY_BASE_URL", "http://localhost:8080")

	setDefaultEnvIfEmpty("BLOCKCHAIN_LOGGING_LEVEL", "info")
	setDefaultEnvIfEmpty("BLOCKCHAIN_LOGGING_FORMAT", "json")
	setDefaultEnvIfEmpty("BLOCKCHAIN_LOGGING_OUTPUT", "stdout")
}

func setDefaultEnvIfEmpty(key, defaultValue string) {
	if os.Getenv(key) == "" {
		os.Setenv(key, defaultValue)
	}
}
