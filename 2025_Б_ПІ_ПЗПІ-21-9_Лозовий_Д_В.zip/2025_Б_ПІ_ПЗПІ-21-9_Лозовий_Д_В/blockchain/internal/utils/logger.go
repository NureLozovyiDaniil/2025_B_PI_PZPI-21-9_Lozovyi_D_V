package utils

import (
	"context"
	"fmt"
	"os"
	"time"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"gopkg.in/natefinch/lumberjack.v2"

	"blockchain-service/internal/config"
)

var logger *zap.Logger

func InitLogger(cfg *config.LoggingConfig) error {
	var err error
	logger, err = NewLogger(cfg)
	if err != nil {
		return fmt.Errorf("failed to initialize logger: %w", err)
	}
	return nil
}

func NewLogger(cfg *config.LoggingConfig) (*zap.Logger, error) {

	level, err := zapcore.ParseLevel(cfg.Level)
	if err != nil {
		level = zapcore.InfoLevel
	}

	encoderConfig := zap.NewProductionEncoderConfig()
	if cfg.Format == "console" {
		encoderConfig = zap.NewDevelopmentEncoderConfig()
		encoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	}

	encoderConfig.TimeKey = "timestamp"
	encoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
	encoderConfig.MessageKey = "message"
	encoderConfig.LevelKey = "level"
	encoderConfig.CallerKey = "caller"

	var encoder zapcore.Encoder
	if cfg.Format == "json" {
		encoder = zapcore.NewJSONEncoder(encoderConfig)
	} else {
		encoder = zapcore.NewConsoleEncoder(encoderConfig)
	}

	var cores []zapcore.Core

	switch cfg.Output {
	case "stdout":
		cores = append(cores, zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), level))
	case "file":
		fileWriter := getFileWriter(cfg)
		cores = append(cores, zapcore.NewCore(encoder, zapcore.AddSync(fileWriter), level))
	case "both":
		fileWriter := getFileWriter(cfg)
		cores = append(cores,
			zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), level),
			zapcore.NewCore(encoder, zapcore.AddSync(fileWriter), level),
		)
	default:
		cores = append(cores, zapcore.NewCore(encoder, zapcore.AddSync(os.Stdout), level))
	}

	core := zapcore.NewTee(cores...)
	return zap.New(core, zap.AddCaller(), zap.AddStacktrace(zapcore.ErrorLevel)), nil
}

func getFileWriter(cfg *config.LoggingConfig) zapcore.WriteSyncer {
	lumberJackLogger := &lumberjack.Logger{
		Filename:   cfg.Filename,
		MaxSize:    cfg.MaxSize,
		MaxBackups: cfg.MaxBackups,
		MaxAge:     cfg.MaxAge,
		Compress:   true,
	}
	return zapcore.AddSync(lumberJackLogger)
}

func GetLogger() *zap.Logger {
	if logger == nil {

		logger, _ = zap.NewDevelopment()
	}
	return logger
}

func Shutdown() {
	if logger != nil {
		_ = logger.Sync()
	}
}

type contextKey string

const (
	RequestIDKey    contextKey = "request_id"
	UserIDKey       contextKey = "user_id"
	PollIDKey       contextKey = "poll_id"
	TransactionKey  contextKey = "tx_hash"
	BlockchainOpKey contextKey = "blockchain_op"
)

func WithRequestID(ctx context.Context, requestID string) context.Context {
	return context.WithValue(ctx, RequestIDKey, requestID)
}

func WithUserID(ctx context.Context, userID uint) context.Context {
	return context.WithValue(ctx, UserIDKey, userID)
}

func WithPollID(ctx context.Context, pollID uint) context.Context {
	return context.WithValue(ctx, PollIDKey, pollID)
}

func WithTransaction(ctx context.Context, txHash string) context.Context {
	return context.WithValue(ctx, TransactionKey, txHash)
}

func getFieldsFromContext(ctx context.Context) []zap.Field {
	var fields []zap.Field

	if requestID, ok := ctx.Value(RequestIDKey).(string); ok && requestID != "" {
		fields = append(fields, zap.String("request_id", requestID))
	}

	if userID, ok := ctx.Value(UserIDKey).(uint); ok && userID != 0 {
		fields = append(fields, zap.Uint("user_id", userID))
	}

	if pollID, ok := ctx.Value(PollIDKey).(uint); ok && pollID != 0 {
		fields = append(fields, zap.Uint("poll_id", pollID))
	}

	if txHash, ok := ctx.Value(TransactionKey).(string); ok && txHash != "" {
		fields = append(fields, zap.String("tx_hash", txHash))
	}

	if blockchainOp, ok := ctx.Value(BlockchainOpKey).(string); ok && blockchainOp != "" {
		fields = append(fields, zap.String("blockchain_op", blockchainOp))
	}

	return fields
}

func Info(ctx context.Context, msg string, fields ...zap.Field) {
	contextFields := getFieldsFromContext(ctx)
	allFields := append(contextFields, fields...)
	GetLogger().Info(msg, allFields...)
}

func Warn(ctx context.Context, msg string, fields ...zap.Field) {
	contextFields := getFieldsFromContext(ctx)
	allFields := append(contextFields, fields...)
	GetLogger().Warn(msg, allFields...)
}

func Error(ctx context.Context, msg string, err error, fields ...zap.Field) {
	contextFields := getFieldsFromContext(ctx)
	allFields := append(contextFields, zap.Error(err))
	allFields = append(allFields, fields...)
	GetLogger().Error(msg, allFields...)
}

func Debug(ctx context.Context, msg string, fields ...zap.Field) {
	contextFields := getFieldsFromContext(ctx)
	allFields := append(contextFields, fields...)
	GetLogger().Debug(msg, allFields...)
}

func LogBlockchainOperation(ctx context.Context, operation, address string, gasUsed *uint64, duration time.Duration) {
	fields := []zap.Field{
		zap.String("operation", operation),
		zap.String("contract_address", address),
		zap.Duration("duration", duration),
	}

	if gasUsed != nil {
		fields = append(fields, zap.Uint64("gas_used", *gasUsed))
	}

	Info(ctx, "Blockchain operation completed", fields...)
}

func LogTransactionSent(ctx context.Context, txHash string, operation string, gasLimit uint64, gasPrice int64) {
	ctx = WithTransaction(ctx, txHash)
	ctx = context.WithValue(ctx, BlockchainOpKey, operation)

	Info(ctx, "Transaction sent to blockchain",
		zap.String("operation", operation),
		zap.Uint64("gas_limit", gasLimit),
		zap.Int64("gas_price", gasPrice),
	)
}

func LogTransactionConfirmed(ctx context.Context, txHash string, blockNumber uint64, gasUsed uint64) {
	ctx = WithTransaction(ctx, txHash)

	Info(ctx, "Transaction confirmed",
		zap.Uint64("block_number", blockNumber),
		zap.Uint64("gas_used", gasUsed),
	)
}

func LogTransactionFailed(ctx context.Context, txHash string, operation string, err error, retryAttempt int) {
	ctx = WithTransaction(ctx, txHash)
	ctx = context.WithValue(ctx, BlockchainOpKey, operation)

	Error(ctx, "Transaction failed", err,
		zap.String("operation", operation),
		zap.Int("retry_attempt", retryAttempt),
	)
}

func LogPollOperation(ctx context.Context, pollID uint, operation string, details map[string]interface{}) {
	ctx = WithPollID(ctx, pollID)

	fields := []zap.Field{
		zap.String("operation", operation),
	}

	for key, value := range details {
		fields = append(fields, zap.Any(key, value))
	}

	Info(ctx, "Poll operation", fields...)
}

func LogVoteOperation(ctx context.Context, pollID uint, userID uint, operation string, details map[string]interface{}) {
	ctx = WithPollID(ctx, pollID)
	ctx = WithUserID(ctx, userID)

	fields := []zap.Field{
		zap.String("operation", operation),
	}

	for key, value := range details {
		fields = append(fields, zap.Any(key, value))
	}

	Info(ctx, "Vote operation", fields...)
}

func LogAPIRequest(ctx context.Context, method, path string, statusCode int, duration time.Duration) {
	fields := []zap.Field{
		zap.String("method", method),
		zap.String("path", path),
		zap.Int("status_code", statusCode),
		zap.Duration("duration", duration),
	}

	if statusCode >= 400 {
		Warn(ctx, "HTTP request completed with error", fields...)
	} else {
		Info(ctx, "HTTP request completed", fields...)
	}
}

func LogIdentityServiceCall(ctx context.Context, endpoint string, userID uint, duration time.Duration, err error) {
	ctx = WithUserID(ctx, userID)

	fields := []zap.Field{
		zap.String("service", "identity"),
		zap.String("endpoint", endpoint),
		zap.Duration("duration", duration),
	}

	if err != nil {
		Error(ctx, "Identity service call failed", err, fields...)
	} else {
		Info(ctx, "Identity service call completed", fields...)
	}
}
