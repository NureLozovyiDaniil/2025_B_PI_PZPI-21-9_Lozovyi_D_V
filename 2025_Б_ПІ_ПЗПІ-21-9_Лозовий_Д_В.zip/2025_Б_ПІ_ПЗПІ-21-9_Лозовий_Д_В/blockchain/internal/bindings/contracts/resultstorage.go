package contracts

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

type ResultStoragePollResult struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	OptionCounts   []*big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}

var ResultStorageMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"initialOwner\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_pollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_voteVerifier\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"EnforcedPause\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ExpectedPause\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"}],\"name\":\"OwnableInvalidOwner\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"OwnableUnauthorizedAccount\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ReentrancyGuardReentrantCall\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Paused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"}],\"name\":\"ResultsFinalized\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"}],\"name\":\"ResultsStored\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"bool\",\"name\":\"isValid\",\"type\":\"bool\"}],\"name\":\"ResultsVerified\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Unpaused\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"MAX_OPTIONS_STORAGE\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"finalizeResults\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getResults\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"optionCounts\",\"type\":\"uint256[]\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"internalType\":\"structResultStorage.PollResult\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"_resultsHash\",\"type\":\"bytes32\"}],\"name\":\"getResultsByHash\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"optionCounts\",\"type\":\"uint256[]\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"internalType\":\"structResultStorage.PollResult\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getResultsSummary\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"getTotalPublishedResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"hasResults\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pollRegistry\",\"outputs\":[{\"internalType\":\"contractPollRegistry\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"pollResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"totalVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"winnerOptionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"resultsHash\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"publishedAt\",\"type\":\"uint256\"},{\"internalType\":\"bool\",\"name\":\"isFinalized\",\"type\":\"bool\"},{\"internalType\":\"address\",\"name\":\"publishedBy\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"resultsByHash\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"resultsExist\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256[]\",\"name\":\"_optionCounts\",\"type\":\"uint256[]\"}],\"name\":\"storeResults\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"totalPublishedResults\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newPollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_newVoteVerifier\",\"type\":\"address\"}],\"name\":\"updateContracts\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"verifyResults\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"voteVerifier\",\"outputs\":[{\"internalType\":\"contractVoteVerifier\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"}]",
}

var ResultStorageABI = ResultStorageMetaData.ABI

type ResultStorage struct {
	ResultStorageCaller
	ResultStorageTransactor
	ResultStorageFilterer
}

type ResultStorageCaller struct {
	contract *bind.BoundContract
}

type ResultStorageTransactor struct {
	contract *bind.BoundContract
}

type ResultStorageFilterer struct {
	contract *bind.BoundContract
}

type ResultStorageSession struct {
	Contract     *ResultStorage
	CallOpts     bind.CallOpts
	TransactOpts bind.TransactOpts
}

type ResultStorageCallerSession struct {
	Contract *ResultStorageCaller
	CallOpts bind.CallOpts
}

type ResultStorageTransactorSession struct {
	Contract     *ResultStorageTransactor
	TransactOpts bind.TransactOpts
}

type ResultStorageRaw struct {
	Contract *ResultStorage
}

type ResultStorageCallerRaw struct {
	Contract *ResultStorageCaller
}

type ResultStorageTransactorRaw struct {
	Contract *ResultStorageTransactor
}

func NewResultStorage(address common.Address, backend bind.ContractBackend) (*ResultStorage, error) {
	contract, err := bindResultStorage(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &ResultStorage{ResultStorageCaller: ResultStorageCaller{contract: contract}, ResultStorageTransactor: ResultStorageTransactor{contract: contract}, ResultStorageFilterer: ResultStorageFilterer{contract: contract}}, nil
}

func NewResultStorageCaller(address common.Address, caller bind.ContractCaller) (*ResultStorageCaller, error) {
	contract, err := bindResultStorage(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &ResultStorageCaller{contract: contract}, nil
}

func NewResultStorageTransactor(address common.Address, transactor bind.ContractTransactor) (*ResultStorageTransactor, error) {
	contract, err := bindResultStorage(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &ResultStorageTransactor{contract: contract}, nil
}

func NewResultStorageFilterer(address common.Address, filterer bind.ContractFilterer) (*ResultStorageFilterer, error) {
	contract, err := bindResultStorage(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &ResultStorageFilterer{contract: contract}, nil
}

func bindResultStorage(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := ResultStorageMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

func (_ResultStorage *ResultStorageRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _ResultStorage.Contract.ResultStorageCaller.contract.Call(opts, result, method, params...)
}

func (_ResultStorage *ResultStorageRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.Contract.ResultStorageTransactor.contract.Transfer(opts)
}

func (_ResultStorage *ResultStorageRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _ResultStorage.Contract.ResultStorageTransactor.contract.Transact(opts, method, params...)
}

func (_ResultStorage *ResultStorageCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _ResultStorage.Contract.contract.Call(opts, result, method, params...)
}

func (_ResultStorage *ResultStorageTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.Contract.contract.Transfer(opts)
}

func (_ResultStorage *ResultStorageTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _ResultStorage.Contract.contract.Transact(opts, method, params...)
}

func (_ResultStorage *ResultStorageCaller) MAXOPTIONSSTORAGE(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "MAX_OPTIONS_STORAGE")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) MAXOPTIONSSTORAGE() (*big.Int, error) {
	return _ResultStorage.Contract.MAXOPTIONSSTORAGE(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) MAXOPTIONSSTORAGE() (*big.Int, error) {
	return _ResultStorage.Contract.MAXOPTIONSSTORAGE(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) GetResults(opts *bind.CallOpts, _pollId *big.Int) (ResultStoragePollResult, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResults", _pollId)

	if err != nil {
		return *new(ResultStoragePollResult), err
	}

	out0 := *abi.ConvertType(out[0], new(ResultStoragePollResult)).(*ResultStoragePollResult)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) GetResults(_pollId *big.Int) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCallerSession) GetResults(_pollId *big.Int) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCaller) GetResultsByHash(opts *bind.CallOpts, _resultsHash [32]byte) (ResultStoragePollResult, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResultsByHash", _resultsHash)

	if err != nil {
		return *new(ResultStoragePollResult), err
	}

	out0 := *abi.ConvertType(out[0], new(ResultStoragePollResult)).(*ResultStoragePollResult)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) GetResultsByHash(_resultsHash [32]byte) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResultsByHash(&_ResultStorage.CallOpts, _resultsHash)
}

func (_ResultStorage *ResultStorageCallerSession) GetResultsByHash(_resultsHash [32]byte) (ResultStoragePollResult, error) {
	return _ResultStorage.Contract.GetResultsByHash(&_ResultStorage.CallOpts, _resultsHash)
}

func (_ResultStorage *ResultStorageCaller) GetResultsSummary(opts *bind.CallOpts, _pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getResultsSummary", _pollId)

	outstruct := new(struct {
		TotalVotes     *big.Int
		WinnerOptionId *big.Int
		IsFinalized    bool
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.TotalVotes = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.WinnerOptionId = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.IsFinalized = *abi.ConvertType(out[2], new(bool)).(*bool)

	return *outstruct, err

}

func (_ResultStorage *ResultStorageSession) GetResultsSummary(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	return _ResultStorage.Contract.GetResultsSummary(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCallerSession) GetResultsSummary(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	IsFinalized    bool
}, error) {
	return _ResultStorage.Contract.GetResultsSummary(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCaller) GetTotalPublishedResults(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "getTotalPublishedResults")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) GetTotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.GetTotalPublishedResults(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) GetTotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.GetTotalPublishedResults(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) HasResults(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "hasResults", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) HasResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.HasResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCallerSession) HasResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.HasResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) Owner() (common.Address, error) {
	return _ResultStorage.Contract.Owner(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) Owner() (common.Address, error) {
	return _ResultStorage.Contract.Owner(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) Paused(opts *bind.CallOpts) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "paused")

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) Paused() (bool, error) {
	return _ResultStorage.Contract.Paused(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) Paused() (bool, error) {
	return _ResultStorage.Contract.Paused(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) PollRegistry(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "pollRegistry")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) PollRegistry() (common.Address, error) {
	return _ResultStorage.Contract.PollRegistry(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) PollRegistry() (common.Address, error) {
	return _ResultStorage.Contract.PollRegistry(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) PollResults(opts *bind.CallOpts, arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "pollResults", arg0)

	outstruct := new(struct {
		PollId         *big.Int
		TotalVotes     *big.Int
		WinnerOptionId *big.Int
		ResultsHash    [32]byte
		PublishedAt    *big.Int
		IsFinalized    bool
		PublishedBy    common.Address
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.PollId = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.TotalVotes = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.WinnerOptionId = *abi.ConvertType(out[2], new(*big.Int)).(**big.Int)
	outstruct.ResultsHash = *abi.ConvertType(out[3], new([32]byte)).(*[32]byte)
	outstruct.PublishedAt = *abi.ConvertType(out[4], new(*big.Int)).(**big.Int)
	outstruct.IsFinalized = *abi.ConvertType(out[5], new(bool)).(*bool)
	outstruct.PublishedBy = *abi.ConvertType(out[6], new(common.Address)).(*common.Address)

	return *outstruct, err

}

func (_ResultStorage *ResultStorageSession) PollResults(arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	return _ResultStorage.Contract.PollResults(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCallerSession) PollResults(arg0 *big.Int) (struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedAt    *big.Int
	IsFinalized    bool
	PublishedBy    common.Address
}, error) {
	return _ResultStorage.Contract.PollResults(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCaller) ResultsByHash(opts *bind.CallOpts, arg0 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "resultsByHash", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) ResultsByHash(arg0 [32]byte) (*big.Int, error) {
	return _ResultStorage.Contract.ResultsByHash(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCallerSession) ResultsByHash(arg0 [32]byte) (*big.Int, error) {
	return _ResultStorage.Contract.ResultsByHash(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCaller) ResultsExist(opts *bind.CallOpts, arg0 *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "resultsExist", arg0)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) ResultsExist(arg0 *big.Int) (bool, error) {
	return _ResultStorage.Contract.ResultsExist(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCallerSession) ResultsExist(arg0 *big.Int) (bool, error) {
	return _ResultStorage.Contract.ResultsExist(&_ResultStorage.CallOpts, arg0)
}

func (_ResultStorage *ResultStorageCaller) TotalPublishedResults(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "totalPublishedResults")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) TotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.TotalPublishedResults(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) TotalPublishedResults() (*big.Int, error) {
	return _ResultStorage.Contract.TotalPublishedResults(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) VerifyResults(opts *bind.CallOpts, _pollId *big.Int) (bool, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "verifyResults", _pollId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) VerifyResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.VerifyResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCallerSession) VerifyResults(_pollId *big.Int) (bool, error) {
	return _ResultStorage.Contract.VerifyResults(&_ResultStorage.CallOpts, _pollId)
}

func (_ResultStorage *ResultStorageCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) Version() (string, error) {
	return _ResultStorage.Contract.Version(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) Version() (string, error) {
	return _ResultStorage.Contract.Version(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCaller) VoteVerifier(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _ResultStorage.contract.Call(opts, &out, "voteVerifier")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_ResultStorage *ResultStorageSession) VoteVerifier() (common.Address, error) {
	return _ResultStorage.Contract.VoteVerifier(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageCallerSession) VoteVerifier() (common.Address, error) {
	return _ResultStorage.Contract.VoteVerifier(&_ResultStorage.CallOpts)
}

func (_ResultStorage *ResultStorageTransactor) FinalizeResults(opts *bind.TransactOpts, _pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "finalizeResults", _pollId)
}

func (_ResultStorage *ResultStorageSession) FinalizeResults(_pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.FinalizeResults(&_ResultStorage.TransactOpts, _pollId)
}

func (_ResultStorage *ResultStorageTransactorSession) FinalizeResults(_pollId *big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.FinalizeResults(&_ResultStorage.TransactOpts, _pollId)
}

func (_ResultStorage *ResultStorageTransactor) Pause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "pause")
}

func (_ResultStorage *ResultStorageSession) Pause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Pause(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactorSession) Pause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Pause(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactor) RenounceOwnership(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "renounceOwnership")
}

func (_ResultStorage *ResultStorageSession) RenounceOwnership() (*types.Transaction, error) {
	return _ResultStorage.Contract.RenounceOwnership(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactorSession) RenounceOwnership() (*types.Transaction, error) {
	return _ResultStorage.Contract.RenounceOwnership(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactor) StoreResults(opts *bind.TransactOpts, _pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "storeResults", _pollId, _optionCounts)
}

func (_ResultStorage *ResultStorageSession) StoreResults(_pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.StoreResults(&_ResultStorage.TransactOpts, _pollId, _optionCounts)
}

func (_ResultStorage *ResultStorageTransactorSession) StoreResults(_pollId *big.Int, _optionCounts []*big.Int) (*types.Transaction, error) {
	return _ResultStorage.Contract.StoreResults(&_ResultStorage.TransactOpts, _pollId, _optionCounts)
}

func (_ResultStorage *ResultStorageTransactor) TransferOwnership(opts *bind.TransactOpts, newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "transferOwnership", newOwner)
}

func (_ResultStorage *ResultStorageSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.TransferOwnership(&_ResultStorage.TransactOpts, newOwner)
}

func (_ResultStorage *ResultStorageTransactorSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.TransferOwnership(&_ResultStorage.TransactOpts, newOwner)
}

func (_ResultStorage *ResultStorageTransactor) Unpause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "unpause")
}

func (_ResultStorage *ResultStorageSession) Unpause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Unpause(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactorSession) Unpause() (*types.Transaction, error) {
	return _ResultStorage.Contract.Unpause(&_ResultStorage.TransactOpts)
}

func (_ResultStorage *ResultStorageTransactor) UpdateContracts(opts *bind.TransactOpts, _newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.contract.Transact(opts, "updateContracts", _newPollRegistry, _newVoteVerifier)
}

func (_ResultStorage *ResultStorageSession) UpdateContracts(_newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.UpdateContracts(&_ResultStorage.TransactOpts, _newPollRegistry, _newVoteVerifier)
}

func (_ResultStorage *ResultStorageTransactorSession) UpdateContracts(_newPollRegistry common.Address, _newVoteVerifier common.Address) (*types.Transaction, error) {
	return _ResultStorage.Contract.UpdateContracts(&_ResultStorage.TransactOpts, _newPollRegistry, _newVoteVerifier)
}

type ResultStorageOwnershipTransferredIterator struct {
	Event *ResultStorageOwnershipTransferred

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStorageOwnershipTransferredIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageOwnershipTransferred)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageOwnershipTransferred)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStorageOwnershipTransferredIterator) Error() error {
	return it.fail
}

func (it *ResultStorageOwnershipTransferredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStorageOwnershipTransferred struct {
	PreviousOwner common.Address
	NewOwner      common.Address
	Raw           types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterOwnershipTransferred(opts *bind.FilterOpts, previousOwner []common.Address, newOwner []common.Address) (*ResultStorageOwnershipTransferredIterator, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageOwnershipTransferredIterator{contract: _ResultStorage.contract, event: "OwnershipTransferred", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchOwnershipTransferred(opts *bind.WatchOpts, sink chan<- *ResultStorageOwnershipTransferred, previousOwner []common.Address, newOwner []common.Address) (event.Subscription, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStorageOwnershipTransferred)
				if err := _ResultStorage.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParseOwnershipTransferred(log types.Log) (*ResultStorageOwnershipTransferred, error) {
	event := new(ResultStorageOwnershipTransferred)
	if err := _ResultStorage.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type ResultStoragePausedIterator struct {
	Event *ResultStoragePaused

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStoragePausedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStoragePaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStoragePaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStoragePausedIterator) Error() error {
	return it.fail
}

func (it *ResultStoragePausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStoragePaused struct {
	Account common.Address
	Raw     types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterPaused(opts *bind.FilterOpts) (*ResultStoragePausedIterator, error) {

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return &ResultStoragePausedIterator{contract: _ResultStorage.contract, event: "Paused", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchPaused(opts *bind.WatchOpts, sink chan<- *ResultStoragePaused) (event.Subscription, error) {

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStoragePaused)
				if err := _ResultStorage.contract.UnpackLog(event, "Paused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParsePaused(log types.Log) (*ResultStoragePaused, error) {
	event := new(ResultStoragePaused)
	if err := _ResultStorage.contract.UnpackLog(event, "Paused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type ResultStorageResultsFinalizedIterator struct {
	Event *ResultStorageResultsFinalized

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStorageResultsFinalizedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsFinalized)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsFinalized)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStorageResultsFinalizedIterator) Error() error {
	return it.fail
}

func (it *ResultStorageResultsFinalizedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStorageResultsFinalized struct {
	PollId      *big.Int
	ResultsHash [32]byte
	Raw         types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterResultsFinalized(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsFinalizedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsFinalizedIterator{contract: _ResultStorage.contract, event: "ResultsFinalized", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchResultsFinalized(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsFinalized, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsFinalized", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStorageResultsFinalized)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsFinalized", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParseResultsFinalized(log types.Log) (*ResultStorageResultsFinalized, error) {
	event := new(ResultStorageResultsFinalized)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsFinalized", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type ResultStorageResultsStoredIterator struct {
	Event *ResultStorageResultsStored

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStorageResultsStoredIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsStored)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsStored)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStorageResultsStoredIterator) Error() error {
	return it.fail
}

func (it *ResultStorageResultsStoredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStorageResultsStored struct {
	PollId         *big.Int
	TotalVotes     *big.Int
	WinnerOptionId *big.Int
	ResultsHash    [32]byte
	PublishedBy    common.Address
	PublishedAt    *big.Int
	Raw            types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterResultsStored(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsStoredIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsStored", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsStoredIterator{contract: _ResultStorage.contract, event: "ResultsStored", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchResultsStored(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsStored, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsStored", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStorageResultsStored)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsStored", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParseResultsStored(log types.Log) (*ResultStorageResultsStored, error) {
	event := new(ResultStorageResultsStored)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsStored", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type ResultStorageResultsVerifiedIterator struct {
	Event *ResultStorageResultsVerified

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStorageResultsVerifiedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageResultsVerified)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageResultsVerified)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStorageResultsVerifiedIterator) Error() error {
	return it.fail
}

func (it *ResultStorageResultsVerifiedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStorageResultsVerified struct {
	PollId      *big.Int
	ResultsHash [32]byte
	IsValid     bool
	Raw         types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterResultsVerified(opts *bind.FilterOpts, pollId []*big.Int) (*ResultStorageResultsVerifiedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "ResultsVerified", pollIdRule)
	if err != nil {
		return nil, err
	}
	return &ResultStorageResultsVerifiedIterator{contract: _ResultStorage.contract, event: "ResultsVerified", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchResultsVerified(opts *bind.WatchOpts, sink chan<- *ResultStorageResultsVerified, pollId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "ResultsVerified", pollIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStorageResultsVerified)
				if err := _ResultStorage.contract.UnpackLog(event, "ResultsVerified", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParseResultsVerified(log types.Log) (*ResultStorageResultsVerified, error) {
	event := new(ResultStorageResultsVerified)
	if err := _ResultStorage.contract.UnpackLog(event, "ResultsVerified", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type ResultStorageUnpausedIterator struct {
	Event *ResultStorageUnpaused

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *ResultStorageUnpausedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(ResultStorageUnpaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(ResultStorageUnpaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *ResultStorageUnpausedIterator) Error() error {
	return it.fail
}

func (it *ResultStorageUnpausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type ResultStorageUnpaused struct {
	Account common.Address
	Raw     types.Log
}

func (_ResultStorage *ResultStorageFilterer) FilterUnpaused(opts *bind.FilterOpts) (*ResultStorageUnpausedIterator, error) {

	logs, sub, err := _ResultStorage.contract.FilterLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return &ResultStorageUnpausedIterator{contract: _ResultStorage.contract, event: "Unpaused", logs: logs, sub: sub}, nil
}

func (_ResultStorage *ResultStorageFilterer) WatchUnpaused(opts *bind.WatchOpts, sink chan<- *ResultStorageUnpaused) (event.Subscription, error) {

	logs, sub, err := _ResultStorage.contract.WatchLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(ResultStorageUnpaused)
				if err := _ResultStorage.contract.UnpackLog(event, "Unpaused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_ResultStorage *ResultStorageFilterer) ParseUnpaused(log types.Log) (*ResultStorageUnpaused, error) {
	event := new(ResultStorageUnpaused)
	if err := _ResultStorage.contract.UnpackLog(event, "Unpaused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
