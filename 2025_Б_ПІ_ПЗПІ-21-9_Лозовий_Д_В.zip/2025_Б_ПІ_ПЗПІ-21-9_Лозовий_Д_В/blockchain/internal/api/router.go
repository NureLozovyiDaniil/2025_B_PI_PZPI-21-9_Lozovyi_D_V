package api

import (
	"net/http"

	"github.com/gin-gonic/gin"

	"blockchain-service/internal/config"
	"blockchain-service/internal/service"
)

type RouterConfig struct {
	Config            *config.Config
	BlockchainService *service.BlockchainService
}

func NewRouter(cfg RouterConfig) *gin.Engine {

	if cfg.Config.IsProduction() {
		gin.SetMode(gin.ReleaseMode)
	} else if cfg.Config.IsDevelopment() {
		gin.SetMode(gin.DebugMode)
	} else {
		gin.SetMode(gin.TestMode)
	}

	router := gin.New()

	handler := NewHandler(cfg.BlockchainService)

	setupMiddleware(router)

	setupRoutes(router, handler)

	return router
}

func setupMiddleware(router *gin.Engine) {

	router.Use(RecoveryMiddleware())

	router.Use(CORSMiddleware())

	router.Use(RequestLoggerMiddleware())

	router.Use(SecurityHeadersMiddleware())

	router.Use(RateLimitMiddleware())
}

func setupRoutes(router *gin.Engine, handler *Handler) {

	api := router.Group("/api")

	api.GET("/health", handler.Health)

	v1 := api.Group("/v1")

	polls := v1.Group("/polls")
	{
		polls.POST("/register", handler.RegisterPoll)
		polls.GET("/:id", handler.GetPollById)
		polls.GET("/:id/results", handler.GetPollResults)

	}

	votes := v1.Group("/votes")
	{
		votes.POST("/record", handler.RecordVote)
		votes.POST("/record-anonymous", handler.RecordAnonymousVote)

	}

	transactions := v1.Group("/transactions")
	{
		transactions.GET("/:hash/status", handler.GetTransactionStatus)

	}

	results := v1.Group("/results")
	{
		results.POST("/store", handler.StoreResults)

	}

	admin := v1.Group("/admin")
	{

		admin.GET("/stats", handler.GetSystemStats)

	}

	utils := v1.Group("/utils")
	{
		utils.GET("/users/:id/address", handler.GetUserAddress)

	}

	setupDocsRoutes(v1)

	router.NoRoute(notFoundHandler)
	router.NoMethod(methodNotAllowedHandler)
}

func setupDocsRoutes(v1 *gin.RouterGroup) {
	docs := v1.Group("/docs")
	{
		docs.GET("/", apiDocsHandler)
		docs.GET("/openapi.json", openAPISpecHandler)

	}
}

func SecurityHeadersMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		c.Header("X-Content-Type-Options", "nosniff")
		c.Header("X-Frame-Options", "DENY")
		c.Header("X-XSS-Protection", "1; mode=block")
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")

		c.Header("Content-Security-Policy", "default-src 'none'")

		c.Next()
	}
}

func RateLimitMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		c.Next()
	}
}

func (h *Handler) GetSystemStats(c *gin.Context) {

	requestID := c.GetString("request_id")
	if requestID == "" {
		requestID = "unknown"
	}

	health := h.blockchainService.Health(c.Request.Context())

	stats := map[string]interface{}{
		"health":         health,
		"uptime":         "TODO: implement uptime tracking",
		"requests_total": "TODO: implement request counting",
		"blockchain_info": map[string]interface{}{
			"network":      health["web3"].(map[string]interface{})["network_name"],
			"block_number": health["web3"].(map[string]interface{})["block_number"],
			"connected":    health["web3"].(map[string]interface{})["connected"],
		},
	}

	c.JSON(http.StatusOK, SuccessResponse{
		Success: true,
		Data:    stats,
		Message: "System statistics retrieved successfully",
	})
}

func notFoundHandler(c *gin.Context) {
	c.JSON(http.StatusNotFound, ErrorResponse{
		Error:   "not_found",
		Message: "The requested endpoint was not found",
		Code:    http.StatusNotFound,
	})
}

func methodNotAllowedHandler(c *gin.Context) {
	c.JSON(http.StatusMethodNotAllowed, ErrorResponse{
		Error:   "method_not_allowed",
		Message: "The requested HTTP method is not allowed for this endpoint",
		Code:    http.StatusMethodNotAllowed,
	})
}

func apiDocsHandler(c *gin.Context) {
	docs := map[string]interface{}{
		"service": "blockchain-service",
		"version": "1.0.0-phase1",
		"phase":   "Phase 1 (Open Voting Only)",
		"endpoints": map[string]interface{}{
			"polls": map[string]interface{}{
				"POST /api/v1/polls/register":   "Register a new poll in blockchain",
				"GET /api/v1/polls/:id/results": "Get poll results from blockchain",
			},
			"votes": map[string]interface{}{
				"POST /api/v1/votes/record": "Record a vote in blockchain",
			},
			"transactions": map[string]interface{}{
				"GET /api/v1/transactions/:hash/status": "Get transaction status",
			},
			"results": map[string]interface{}{
				"POST /api/v1/results/store": "Store poll results in blockchain",
			},
			"system": map[string]interface{}{
				"GET /api/health":         "Health check",
				"GET /api/v1/admin/stats": "System statistics",
			},
		},
		"supported_networks": []string{
			"Hardhat Local (31337)",
			"Polygon Mumbai (80001)",
			"Polygon Mainnet (137)",
		},
		"features": map[string]interface{}{
			"phase1_ready": []string{
				"Open voting registration",
				"Vote recording with user addresses",
				"Transaction status monitoring",
				"Results storage",
				"Health monitoring",
			},
			"phase2_planned": []string{
				"Private voting with ZKP",
				"Trusted party management",
				"Anonymous vote verification",
				"Blind signature integration",
			},
		},
	}

	c.JSON(http.StatusOK, docs)
}

func openAPISpecHandler(c *gin.Context) {

	spec := map[string]interface{}{
		"openapi": "3.0.0",
		"info": map[string]interface{}{
			"title":       "Blockchain Service API",
			"version":     "1.0.0-phase1",
			"description": "Blockchain integration service for voting platform",
		},
		"servers": []map[string]interface{}{
			{
				"url":         "http://localhost:8081/api",
				"description": "Development server",
			},
		},
		"paths": map[string]interface{}{
			"/health": map[string]interface{}{
				"get": map[string]interface{}{
					"summary": "Health check",
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Service is healthy",
						},
					},
				},
			},
		},
	}

	c.JSON(http.StatusOK, spec)
}

type RouterOptions struct {
	EnableDocs      bool
	EnableMetrics   bool
	EnableProfiling bool
}

func NewRouterWithOptions(cfg RouterConfig, opts RouterOptions) *gin.Engine {
	router := NewRouter(cfg)

	if opts.EnableMetrics {

	}

	if opts.EnableProfiling {

	}

	return router
}
