package contracts

import (
	"context"
	"fmt"
	"math/big"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"

	"blockchain-service/internal/utils"
	"blockchain-service/internal/web3"

	"blockchain-service/internal/bindings/contracts"
)

type ResultStorageManager struct {
	web3Client      *web3.Web3Client
	contractAddress common.Address

	contract *contracts.ResultStorage
}

type PollResult struct {
	PollID       *big.Int
	TotalVotes   *big.Int
	WinnerOption *big.Int
	OptionCounts []*big.Int
	ResultsHash  [32]byte
	PublishedAt  *big.Int
	IsFinalized  bool
	PublishedBy  common.Address
}

type StoreResultsRequest struct {
	PollID       uint
	OptionCounts []uint
}

func NewResultStorageManager(web3Client *web3.Web3Client, contractAddress string) (*ResultStorageManager, error) {
	if !utils.ValidateEthereumAddress(contractAddress) {
		return nil, fmt.Errorf("invalid contract address: %s", contractAddress)
	}

	addr := common.HexToAddress(contractAddress)

	contract, err := contracts.NewResultStorage(addr, web3Client.GetClient())
	if err != nil {
		return nil, fmt.Errorf("failed to instantiate ResultStorage contract: %w", err)
	}

	return &ResultStorageManager{
		web3Client:      web3Client,
		contractAddress: addr,
		contract:        contract,
	}, nil
}

func (r *ResultStorageManager) StoreResults(ctx context.Context, req StoreResultsRequest) (string, error) {

	if err := r.validateStoreResultsRequest(req); err != nil {
		return "", fmt.Errorf("validation failed: %w", err)
	}

	auth, err := r.web3Client.GetTransactor(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	optionCountsBig := make([]*big.Int, len(req.OptionCounts))
	for i, count := range req.OptionCounts {
		optionCountsBig[i] = big.NewInt(int64(count))
	}

	pollID := big.NewInt(int64(req.PollID))

	tx, err := r.contract.StoreResults(auth, pollID, optionCountsBig)
	if err != nil {
		return "", fmt.Errorf("failed to store results: %w", err)
	}

	utils.LogTransactionSent(ctx, tx.Hash().Hex(), "store_results",
		auth.GasLimit, auth.GasPrice.Int64())

	utils.LogPollOperation(ctx, req.PollID, "store_results", map[string]interface{}{
		"tx_hash":       tx.Hash().Hex(),
		"option_counts": req.OptionCounts,
		"total_options": len(req.OptionCounts),
	})

	return tx.Hash().Hex(), nil

}

func (r *ResultStorageManager) FinalizeResults(ctx context.Context, pollID uint) (string, error) {

	if pollID == 0 {
		return "", fmt.Errorf("poll ID cannot be zero")
	}

	auth, err := r.web3Client.GetTransactor(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	pollIDBig := big.NewInt(int64(pollID))

	tx, err := r.contract.FinalizeResults(auth, pollIDBig)
	if err != nil {
		return "", fmt.Errorf("failed to finalize results: %w", err)
	}

	utils.LogTransactionSent(ctx, tx.Hash().Hex(), "finalize_results",
		auth.GasLimit, auth.GasPrice.Int64())

	utils.LogPollOperation(ctx, pollID, "finalize_results", map[string]interface{}{
		"tx_hash": tx.Hash().Hex(),
	})

	return tx.Hash().Hex(), nil

}

func (r *ResultStorageManager) GetResults(ctx context.Context, pollID uint) (*PollResult, error) {

	if pollID == 0 {
		return nil, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	result, err := r.contract.GetResults(callOpts, pollIDBig)
	if err != nil {
		return nil, fmt.Errorf("failed to get results from contract: %w", err)
	}

	pollResult := &PollResult{
		PollID:       result.PollId,
		TotalVotes:   result.TotalVotes,
		WinnerOption: result.WinnerOptionId,
		OptionCounts: result.OptionCounts,
		ResultsHash:  result.ResultsHash,
		PublishedAt:  result.PublishedAt,
		IsFinalized:  result.IsFinalized,
		PublishedBy:  result.PublishedBy,
	}

	utils.LogPollOperation(ctx, pollID, "get_results", map[string]interface{}{
		"total_votes":   result.TotalVotes.Uint64(),
		"winner_option": result.WinnerOptionId.Uint64(),
		"is_finalized":  result.IsFinalized,
		"published_by":  result.PublishedBy.Hex(),
	})

	return pollResult, nil

}

func (r *ResultStorageManager) HasResults(ctx context.Context, pollID uint) (bool, error) {
	if pollID == 0 {
		return false, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	hasResults, err := r.contract.HasResults(callOpts, pollIDBig)
	if err != nil {
		return false, fmt.Errorf("failed to check if results exist: %w", err)
	}

	return hasResults, nil

}

func (r *ResultStorageManager) VerifyResults(ctx context.Context, pollID uint) (bool, error) {
	if pollID == 0 {
		return false, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	isValid, err := r.contract.VerifyResults(callOpts, pollIDBig)
	if err != nil {
		return false, fmt.Errorf("failed to verify results: %w", err)
	}

	utils.LogPollOperation(ctx, pollID, "verify_results", map[string]interface{}{
		"is_valid": isValid,
	})

	return isValid, nil
}

func (r *ResultStorageManager) GetResultsByHash(ctx context.Context, resultsHash [32]byte) (*PollResult, error) {
	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	result, err := r.contract.GetResultsByHash(callOpts, resultsHash)
	if err != nil {
		return nil, fmt.Errorf("failed to get results by hash: %w", err)
	}

	pollResult := &PollResult{
		PollID:       result.PollId,
		TotalVotes:   result.TotalVotes,
		WinnerOption: result.WinnerOptionId,
		OptionCounts: result.OptionCounts,
		ResultsHash:  result.ResultsHash,
		PublishedAt:  result.PublishedAt,
		IsFinalized:  result.IsFinalized,
		PublishedBy:  result.PublishedBy,
	}

	return pollResult, nil

}

func (r *ResultStorageManager) GetResultsSummary(ctx context.Context, pollID uint) (uint64, uint64, bool, error) {
	if pollID == 0 {
		return 0, 0, false, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	var result struct {
		TotalVotes     *big.Int
		WinnerOptionId *big.Int
		IsFinalized    bool
	}

	result, err := r.contract.GetResultsSummary(callOpts, pollIDBig)
	if err != nil {
		return 0, 0, false, fmt.Errorf("failed to get results summary: %w", err)
	}

	return result.TotalVotes.Uint64(), result.WinnerOptionId.Uint64(), result.IsFinalized, nil

}

func (r *ResultStorageManager) GetTotalPublishedResults(ctx context.Context) (uint64, error) {
	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	total, err := r.contract.GetTotalPublishedResults(callOpts)
	if err != nil {
		return 0, fmt.Errorf("failed to get total published results: %w", err)
	}

	return total.Uint64(), nil

}

func (r *ResultStorageManager) validateStoreResultsRequest(req StoreResultsRequest) error {
	if req.PollID == 0 {
		return fmt.Errorf("poll ID cannot be zero")
	}

	if len(req.OptionCounts) == 0 {
		return fmt.Errorf("option counts cannot be empty")
	}

	if len(req.OptionCounts) > 20 {
		return fmt.Errorf("maximum 20 options allowed, got %d", len(req.OptionCounts))
	}

	totalVotes := uint(0)
	for _, count := range req.OptionCounts {
		totalVotes += count
	}

	if totalVotes == 0 {
		return fmt.Errorf("total votes cannot be zero")
	}

	return nil
}

func (r *ResultStorageManager) GetContractAddress() common.Address {
	return r.contractAddress
}

func ParseResultsHash(hexStr string) ([32]byte, error) {
	var hash [32]byte

	if len(hexStr) == 66 && hexStr[:2] == "0x" {
		hexStr = hexStr[2:]
	}

	if len(hexStr) != 64 {
		return hash, fmt.Errorf("hash must be exactly 64 hex characters")
	}

	bytes := common.FromHex("0x" + hexStr)
	if len(bytes) != 32 {
		return hash, fmt.Errorf("invalid hex hash")
	}

	copy(hash[:], bytes)
	return hash, nil
}

func ResultsHashToString(hash [32]byte) string {
	return common.Bytes2Hex(hash[:])
}

func CalculateWinnerOption(optionCounts []uint) uint {
	if len(optionCounts) == 0 {
		return 0
	}

	maxVotes := optionCounts[0]
	winnerOption := uint(1)

	for i, votes := range optionCounts {
		if votes > maxVotes {
			maxVotes = votes
			winnerOption = uint(i + 1)
		}
	}

	return winnerOption
}

func CalculateTotalVotes(optionCounts []uint) uint {
	total := uint(0)
	for _, count := range optionCounts {
		total += count
	}
	return total
}
