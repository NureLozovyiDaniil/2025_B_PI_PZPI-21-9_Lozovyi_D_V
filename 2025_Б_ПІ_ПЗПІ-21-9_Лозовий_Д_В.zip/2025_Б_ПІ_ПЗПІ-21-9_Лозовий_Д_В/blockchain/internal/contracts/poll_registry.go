package contracts

import (
	"context"
	"fmt"
	"go.uber.org/zap"
	_ "go.uber.org/zap"
	"math/big"
	"time"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"

	"blockchain-service/internal/bindings/contracts"
	"blockchain-service/internal/utils"
	"blockchain-service/internal/web3"
)

type PollStatus uint8

const (
	PollStatusActive PollStatus = 0
	PollStatusEnded  PollStatus = 1
	PollStatusFailed PollStatus = 2
)

type PollMetadata struct {
	PollID      *big.Int
	Title       string
	Category    string
	OptionsHash [32]byte
	Creator     common.Address
	StartTime   *big.Int
	EndTime     *big.Int
	IsPrivate   bool
	Status      PollStatus
	CreatedAt   *big.Int
}

type PollRegistryManager struct {
	web3Client      *web3.Web3Client
	contractAddress common.Address

	contract *contracts.PollRegistry
}

type RegisterPollRequest struct {
	PollID      uint
	Title       string
	Category    string
	OptionsHash string
	CreatorID   uint
	StartTime   time.Time
	EndTime     time.Time
	IsPrivate   bool
}

func NewPollRegistryManager(web3Client *web3.Web3Client, contractAddress string) (*PollRegistryManager, error) {
	if !utils.ValidateEthereumAddress(contractAddress) {
		return nil, fmt.Errorf("invalid contract address: %s", contractAddress)
	}

	addr := common.HexToAddress(contractAddress)

	pollRegistryContract, err := contracts.NewPollRegistry(addr, web3Client.GetClient())
	if err != nil {
		return nil, err
	}

	return &PollRegistryManager{
		web3Client:      web3Client,
		contractAddress: addr,
		contract:        pollRegistryContract,
	}, nil
}

func (p *PollRegistryManager) RegisterPoll(ctx context.Context, req RegisterPollRequest, creatorAddress common.Address) (string, error) {
	utils.Debug(ctx, "Registering poll in blockchain",
		zap.Uint("poll_id", req.PollID),
		zap.String("title", req.Title),
		zap.String("category", req.Category),
		zap.String("creator", creatorAddress.Hex()),
	)

	if err := p.validateRegisterPollRequest(req); err != nil {
		return "", fmt.Errorf("validation failed: %w", err)
	}

	optionsHash, err := p.parseOptionsHash(req.OptionsHash)
	if err != nil {
		return "", fmt.Errorf("invalid options hash: %w", err)
	}

	pollID := big.NewInt(int64(req.PollID))
	startTime := big.NewInt(req.StartTime.Unix())
	endTime := big.NewInt(req.EndTime.Unix())

	auth, err := p.web3Client.GetTransactor(ctx)
	if err != nil || auth == nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	fmt.Printf("Got poll: %v", req)

	tx, err := p.contract.RegisterPoll(auth, pollID, req.Title, req.Category,
		optionsHash, creatorAddress, startTime, endTime, req.IsPrivate)
	if err != nil {
		return "", fmt.Errorf("failed to register poll: %w", err)
	}

	return tx.Hash().Hex(), nil

}

func (p *PollRegistryManager) GetPoll(ctx context.Context, pollID uint) (*PollMetadata, error) {

	if pollID == 0 {
		return nil, fmt.Errorf("poll ID cannot be zero")
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	pollData, err := p.contract.GetPoll(callOpts, pollIDBig)
	if err != nil {
		return nil, fmt.Errorf("failed to get poll from contract: %w", err)
	}

	return &PollMetadata{
		PollID:      pollData.PollId,
		Title:       pollData.Title,
		Category:    pollData.Category,
		OptionsHash: pollData.OptionsHash,
		Creator:     pollData.Creator,
		StartTime:   pollData.StartTime,
		EndTime:     pollData.EndTime,
		IsPrivate:   pollData.IsPrivate,
		Status:      PollStatus(pollData.Status),
		CreatedAt:   pollData.CreatedAt,
	}, nil

}

func (p *PollRegistryManager) UpdatePollStatus(ctx context.Context, pollID uint, status PollStatus) (string, error) {

	if pollID == 0 {
		return "", fmt.Errorf("poll ID cannot be zero")
	}

	if status > PollStatusFailed {
		return "", fmt.Errorf("invalid poll status: %d", status)
	}

	auth, err := p.web3Client.GetTransactor(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get transactor: %w", err)
	}

	pollIDBig := big.NewInt(int64(pollID))

	tx, err := p.contract.UpdatePollStatus(auth, pollIDBig, uint8(status))
	if err != nil {
		return "", fmt.Errorf("failed to update poll status: %w", err)
	}

	return tx.Hash().Hex(), nil

}

func (p *PollRegistryManager) PollExists(ctx context.Context, pollID uint) (bool, error) {
	if pollID == 0 {
		return false, nil
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	exists, err := p.contract.PollExists(callOpts, pollIDBig)
	if err != nil {
		return false, fmt.Errorf("failed to check poll existence: %w", err)
	}

	return exists, nil

}

func (p *PollRegistryManager) IsPollActive(ctx context.Context, pollID uint) (bool, error) {
	if pollID == 0 {
		return false, nil
	}

	pollIDBig := big.NewInt(int64(pollID))

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	isActive, err := p.contract.IsPollActive(callOpts, pollIDBig)
	if err != nil {
		return false, fmt.Errorf("failed to check poll activity: %w", err)
	}

	return isActive, nil

}

func (p *PollRegistryManager) GetCreatorPolls(ctx context.Context, creator common.Address) ([]*big.Int, error) {

	callOpts := &bind.CallOpts{
		Context: ctx,
		Pending: false,
	}

	pollIDs, err := p.contract.GetCreatorPolls(callOpts, creator)
	if err != nil {
		return nil, fmt.Errorf("failed to get creator polls: %w", err)
	}

	return pollIDs, nil

}

func (p *PollRegistryManager) validateRegisterPollRequest(req RegisterPollRequest) error {
	if req.PollID == 0 {
		return fmt.Errorf("poll ID cannot be zero")
	}

	if len(req.Title) == 0 || len(req.Title) > 255 {
		return fmt.Errorf("title length must be between 1 and 255 characters")
	}

	if len(req.Category) == 0 || len(req.Category) > 100 {
		return fmt.Errorf("category length must be between 1 and 100 characters")
	}

	if len(req.OptionsHash) != 64 {
		return fmt.Errorf("options hash must be exactly 64 characters")
	}

	if req.EndTime.Before(req.StartTime) {
		return fmt.Errorf("end time must be after start time")
	}

	if req.StartTime.Before(time.Now().Add(-3 * time.Hour)) {
		return fmt.Errorf("start time cannot be more than 2 hours in the past")
	}

	return nil
}

func (p *PollRegistryManager) parseOptionsHash(hexStr string) ([32]byte, error) {
	var hash [32]byte

	if len(hexStr) == 66 && hexStr[:2] == "0x" {
		hexStr = hexStr[2:]
	}

	if len(hexStr) != 64 {
		return hash, fmt.Errorf("hash must be exactly 64 hex characters")
	}

	bytes := common.FromHex("0x" + hexStr)
	if len(bytes) != 32 {
		return hash, fmt.Errorf("invalid hex hash")
	}

	copy(hash[:], bytes)
	return hash, nil
}

func (p *PollRegistryManager) generateMockTxHash(operation string, pollID uint) string {
	timestamp := time.Now().Unix()
	return fmt.Sprintf("0x%s%d%d000000000000000000000000000000000000000000000000",
		operation[:8], pollID, timestamp%1000)
}

func (p *PollRegistryManager) GetContractAddress() common.Address {
	return p.contractAddress
}

func StatusToString(status PollStatus) string {
	switch status {
	case PollStatusActive:
		return "active"
	case PollStatusEnded:
		return "ended"
	case PollStatusFailed:
		return "failed"
	default:
		return "unknown"
	}
}

func StringToStatus(status string) (PollStatus, error) {
	switch status {
	case "active":
		return PollStatusActive, nil
	case "ended":
		return PollStatusEnded, nil
	case "failed":
		return PollStatusFailed, nil
	default:
		return PollStatusActive, fmt.Errorf("unknown poll status: %s", status)
	}
}
