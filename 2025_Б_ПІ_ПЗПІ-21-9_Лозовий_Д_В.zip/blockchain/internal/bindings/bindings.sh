echo "🚀 Generating Go bindings for smart contracts..."

# Проверка наличия abigen
if ! command -v abigen &> /dev/null; then
    echo "❌ abigen not found. Installing..."
    go install github.com/ethereum/go-ethereum/cmd/abigen@latest
fi

# Создание директории для bindings если её нет
CONTRACTS_DIR="./contracts"
mkdir -p $CONTRACTS_DIR

# Функция для генерации binding
generate_binding() {
    local contract_name=$1
    local abi_file=$2
    local package_name="contracts"

    echo "📄 Generating binding for $contract_name..."

    # Извлечение только ABI из JSON файла
    abi=$(cat "$abi_file" | jq -r '.abi')

    # Создание временного файла с чистым ABI
    temp_abi_file="/tmp/${contract_name}_abi.json"
    echo "$abi" > "$temp_abi_file"

    # Генерация Go binding
    abigen \
        --abi="$temp_abi_file" \
        --pkg="$package_name" \
        --type="$contract_name" \
        --out="$CONTRACTS_DIR/${contract_name,,}.go"

    # Удаление временного файла
    rm "$temp_abi_file"

    if [ $? -eq 0 ]; then
        echo "✅ $contract_name binding generated successfully"
    else
        echo "❌ Failed to generate $contract_name binding"
        exit 1
    fi
}

# Генерация bindings для каждого контракта
generate_binding "PollRegistry" "./PollRegistry.json"
generate_binding "VoteVerifier" "./VoteVerifier.json"
generate_binding "ResultStorage" "./ResultStorage.json"

echo "✨ All bindings generated successfully!"
echo ""
echo "📁 Generated files:"
ls -la $CONTRACTS_DIR/

# Создание index файла для удобного импорта
cat > "$CONTRACTS_DIR/contracts.go" << 'EOF'
// Package contracts содержит сгенерированные Go bindings для смарт-контрактов
package contracts

import (
	"github.com/ethereum/go-ethereum/common"
)

// Адреса контрактов для локальной сети Hardhat
var (
	PollRegistryAddress  = common.HexToAddress("0x5FbDB2315678afecb367f032d93F642f64180aa3")
	VoteVerifierAddress  = common.HexToAddress("0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512")
	ResultStorageAddress = common.HexToAddress("0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0")
)
EOF

echo ""
echo "🎉 Done! You can now use the generated bindings in your Go code."