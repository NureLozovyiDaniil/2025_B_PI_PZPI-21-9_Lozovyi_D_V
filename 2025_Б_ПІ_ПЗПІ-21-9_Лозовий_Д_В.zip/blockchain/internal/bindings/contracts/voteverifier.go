package contracts

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

type VoteVerifierVote struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}

var VoteVerifierMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"initialOwner\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_pollRegistry\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_authorizedService\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"EnforcedPause\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ExpectedPause\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"}],\"name\":\"OwnableInvalidOwner\",\"type\":\"error\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"OwnableUnauthorizedAccount\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"ReentrancyGuardReentrantCall\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":true,\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"}],\"name\":\"AnonymousVoteRecorded\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"oldService\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"newService\",\"type\":\"address\"}],\"name\":\"AuthorizedServiceUpdated\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Paused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"}],\"name\":\"Unpaused\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"}],\"name\":\"VoteRecorded\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"MAX_OPTIONS_PER_POLL\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"anonymousVoterChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"authorizedService\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"}],\"name\":\"getAnonymousChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"}],\"name\":\"getOptionVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_maxOptions\",\"type\":\"uint256\"}],\"name\":\"getPollResults\",\"outputs\":[{\"internalType\":\"uint256[]\",\"name\":\"\",\"type\":\"uint256[]\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getPollStatistics\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"totalVotes_\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"openVotes\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"anonymousVotes\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"}],\"name\":\"getPollVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"getUserChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"_voteHash\",\"type\":\"bytes32\"}],\"name\":\"getVoteByHash\",\"outputs\":[{\"components\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"internalType\":\"bool\",\"name\":\"isAnonymous\",\"type\":\"bool\"}],\"internalType\":\"structVoteVerifier.Vote\",\"name\":\"\",\"type\":\"tuple\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"}],\"name\":\"hasAnonymousIdVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"hasUserVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"name\":\"hasVoted\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"optionVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"pollRegistry\",\"outputs\":[{\"internalType\":\"contractPollRegistry\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"pollVoteCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"bytes32\",\"name\":\"_optionsHash\",\"type\":\"bytes32\"}],\"name\":\"recordAnonymousVote\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"_pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_optionId\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"_optionsHash\",\"type\":\"bytes32\"},{\"internalType\":\"address\",\"name\":\"_voter\",\"type\":\"address\"}],\"name\":\"recordVote\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"totalVotes\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newAuthorizedService\",\"type\":\"address\"}],\"name\":\"updateAuthorizedService\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_newPollRegistry\",\"type\":\"address\"}],\"name\":\"updatePollRegistry\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"usedAnonymousIds\",\"outputs\":[{\"internalType\":\"bool\",\"name\":\"\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"name\":\"voterChoice\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"votesByHash\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"pollId\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"optionId\",\"type\":\"uint256\"},{\"internalType\":\"address\",\"name\":\"voter\",\"type\":\"address\"},{\"internalType\":\"bytes32\",\"name\":\"anonymousId\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"timestamp\",\"type\":\"uint256\"},{\"internalType\":\"bytes32\",\"name\":\"voteHash\",\"type\":\"bytes32\"},{\"internalType\":\"bool\",\"name\":\"isAnonymous\",\"type\":\"bool\"}],\"stateMutability\":\"view\",\"type\":\"function\"}]",
}

var VoteVerifierABI = VoteVerifierMetaData.ABI

type VoteVerifier struct {
	VoteVerifierCaller
	VoteVerifierTransactor
	VoteVerifierFilterer
}

type VoteVerifierCaller struct {
	contract *bind.BoundContract
}

type VoteVerifierTransactor struct {
	contract *bind.BoundContract
}

type VoteVerifierFilterer struct {
	contract *bind.BoundContract
}

type VoteVerifierSession struct {
	Contract     *VoteVerifier
	CallOpts     bind.CallOpts
	TransactOpts bind.TransactOpts
}

type VoteVerifierCallerSession struct {
	Contract *VoteVerifierCaller
	CallOpts bind.CallOpts
}

type VoteVerifierTransactorSession struct {
	Contract     *VoteVerifierTransactor
	TransactOpts bind.TransactOpts
}

type VoteVerifierRaw struct {
	Contract *VoteVerifier
}

type VoteVerifierCallerRaw struct {
	Contract *VoteVerifierCaller
}

type VoteVerifierTransactorRaw struct {
	Contract *VoteVerifierTransactor
}

func NewVoteVerifier(address common.Address, backend bind.ContractBackend) (*VoteVerifier, error) {
	contract, err := bindVoteVerifier(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &VoteVerifier{VoteVerifierCaller: VoteVerifierCaller{contract: contract}, VoteVerifierTransactor: VoteVerifierTransactor{contract: contract}, VoteVerifierFilterer: VoteVerifierFilterer{contract: contract}}, nil
}

func NewVoteVerifierCaller(address common.Address, caller bind.ContractCaller) (*VoteVerifierCaller, error) {
	contract, err := bindVoteVerifier(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierCaller{contract: contract}, nil
}

func NewVoteVerifierTransactor(address common.Address, transactor bind.ContractTransactor) (*VoteVerifierTransactor, error) {
	contract, err := bindVoteVerifier(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierTransactor{contract: contract}, nil
}

func NewVoteVerifierFilterer(address common.Address, filterer bind.ContractFilterer) (*VoteVerifierFilterer, error) {
	contract, err := bindVoteVerifier(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierFilterer{contract: contract}, nil
}

func bindVoteVerifier(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := VoteVerifierMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

func (_VoteVerifier *VoteVerifierRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _VoteVerifier.Contract.VoteVerifierCaller.contract.Call(opts, result, method, params...)
}

func (_VoteVerifier *VoteVerifierRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.Contract.VoteVerifierTransactor.contract.Transfer(opts)
}

func (_VoteVerifier *VoteVerifierRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _VoteVerifier.Contract.VoteVerifierTransactor.contract.Transact(opts, method, params...)
}

func (_VoteVerifier *VoteVerifierCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _VoteVerifier.Contract.contract.Call(opts, result, method, params...)
}

func (_VoteVerifier *VoteVerifierTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.Contract.contract.Transfer(opts)
}

func (_VoteVerifier *VoteVerifierTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _VoteVerifier.Contract.contract.Transact(opts, method, params...)
}

func (_VoteVerifier *VoteVerifierCaller) MAXOPTIONSPERPOLL(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "MAX_OPTIONS_PER_POLL")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) MAXOPTIONSPERPOLL() (*big.Int, error) {
	return _VoteVerifier.Contract.MAXOPTIONSPERPOLL(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) MAXOPTIONSPERPOLL() (*big.Int, error) {
	return _VoteVerifier.Contract.MAXOPTIONSPERPOLL(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) AnonymousVoterChoice(opts *bind.CallOpts, arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "anonymousVoterChoice", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) AnonymousVoterChoice(arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.AnonymousVoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCallerSession) AnonymousVoterChoice(arg0 *big.Int, arg1 [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.AnonymousVoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCaller) AuthorizedService(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "authorizedService")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) AuthorizedService() (common.Address, error) {
	return _VoteVerifier.Contract.AuthorizedService(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) AuthorizedService() (common.Address, error) {
	return _VoteVerifier.Contract.AuthorizedService(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) GetAnonymousChoice(opts *bind.CallOpts, _pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getAnonymousChoice", _pollId, _anonymousId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetAnonymousChoice(_pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.GetAnonymousChoice(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetAnonymousChoice(_pollId *big.Int, _anonymousId [32]byte) (*big.Int, error) {
	return _VoteVerifier.Contract.GetAnonymousChoice(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

func (_VoteVerifier *VoteVerifierCaller) GetOptionVoteCount(opts *bind.CallOpts, _pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getOptionVoteCount", _pollId, _optionId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetOptionVoteCount(_pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetOptionVoteCount(&_VoteVerifier.CallOpts, _pollId, _optionId)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetOptionVoteCount(_pollId *big.Int, _optionId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetOptionVoteCount(&_VoteVerifier.CallOpts, _pollId, _optionId)
}

func (_VoteVerifier *VoteVerifierCaller) GetPollResults(opts *bind.CallOpts, _pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollResults", _pollId, _maxOptions)

	if err != nil {
		return *new([]*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new([]*big.Int)).(*[]*big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetPollResults(_pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	return _VoteVerifier.Contract.GetPollResults(&_VoteVerifier.CallOpts, _pollId, _maxOptions)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetPollResults(_pollId *big.Int, _maxOptions *big.Int) ([]*big.Int, error) {
	return _VoteVerifier.Contract.GetPollResults(&_VoteVerifier.CallOpts, _pollId, _maxOptions)
}

func (_VoteVerifier *VoteVerifierCaller) GetPollStatistics(opts *bind.CallOpts, _pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollStatistics", _pollId)

	outstruct := new(struct {
		TotalVotes     *big.Int
		OpenVotes      *big.Int
		AnonymousVotes *big.Int
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.TotalVotes = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.OpenVotes = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.AnonymousVotes = *abi.ConvertType(out[2], new(*big.Int)).(**big.Int)

	return *outstruct, err

}

func (_VoteVerifier *VoteVerifierSession) GetPollStatistics(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	return _VoteVerifier.Contract.GetPollStatistics(&_VoteVerifier.CallOpts, _pollId)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetPollStatistics(_pollId *big.Int) (struct {
	TotalVotes     *big.Int
	OpenVotes      *big.Int
	AnonymousVotes *big.Int
}, error) {
	return _VoteVerifier.Contract.GetPollStatistics(&_VoteVerifier.CallOpts, _pollId)
}

func (_VoteVerifier *VoteVerifierCaller) GetPollVoteCount(opts *bind.CallOpts, _pollId *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getPollVoteCount", _pollId)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetPollVoteCount(_pollId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetPollVoteCount(&_VoteVerifier.CallOpts, _pollId)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetPollVoteCount(_pollId *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.GetPollVoteCount(&_VoteVerifier.CallOpts, _pollId)
}

func (_VoteVerifier *VoteVerifierCaller) GetUserChoice(opts *bind.CallOpts, _pollId *big.Int, _voter common.Address) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getUserChoice", _pollId, _voter)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetUserChoice(_pollId *big.Int, _voter common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.GetUserChoice(&_VoteVerifier.CallOpts, _pollId, _voter)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetUserChoice(_pollId *big.Int, _voter common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.GetUserChoice(&_VoteVerifier.CallOpts, _pollId, _voter)
}

func (_VoteVerifier *VoteVerifierCaller) GetVoteByHash(opts *bind.CallOpts, _voteHash [32]byte) (VoteVerifierVote, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "getVoteByHash", _voteHash)

	if err != nil {
		return *new(VoteVerifierVote), err
	}

	out0 := *abi.ConvertType(out[0], new(VoteVerifierVote)).(*VoteVerifierVote)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) GetVoteByHash(_voteHash [32]byte) (VoteVerifierVote, error) {
	return _VoteVerifier.Contract.GetVoteByHash(&_VoteVerifier.CallOpts, _voteHash)
}

func (_VoteVerifier *VoteVerifierCallerSession) GetVoteByHash(_voteHash [32]byte) (VoteVerifierVote, error) {
	return _VoteVerifier.Contract.GetVoteByHash(&_VoteVerifier.CallOpts, _voteHash)
}

func (_VoteVerifier *VoteVerifierCaller) HasAnonymousIdVoted(opts *bind.CallOpts, _pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasAnonymousIdVoted", _pollId, _anonymousId)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) HasAnonymousIdVoted(_pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	return _VoteVerifier.Contract.HasAnonymousIdVoted(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

func (_VoteVerifier *VoteVerifierCallerSession) HasAnonymousIdVoted(_pollId *big.Int, _anonymousId [32]byte) (bool, error) {
	return _VoteVerifier.Contract.HasAnonymousIdVoted(&_VoteVerifier.CallOpts, _pollId, _anonymousId)
}

func (_VoteVerifier *VoteVerifierCaller) HasUserVoted(opts *bind.CallOpts, _pollId *big.Int, _voter common.Address) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasUserVoted", _pollId, _voter)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) HasUserVoted(_pollId *big.Int, _voter common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasUserVoted(&_VoteVerifier.CallOpts, _pollId, _voter)
}

func (_VoteVerifier *VoteVerifierCallerSession) HasUserVoted(_pollId *big.Int, _voter common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasUserVoted(&_VoteVerifier.CallOpts, _pollId, _voter)
}

func (_VoteVerifier *VoteVerifierCaller) HasVoted(opts *bind.CallOpts, arg0 *big.Int, arg1 common.Address) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "hasVoted", arg0, arg1)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) HasVoted(arg0 *big.Int, arg1 common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasVoted(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCallerSession) HasVoted(arg0 *big.Int, arg1 common.Address) (bool, error) {
	return _VoteVerifier.Contract.HasVoted(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCaller) OptionVoteCount(opts *bind.CallOpts, arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "optionVoteCount", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) OptionVoteCount(arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.OptionVoteCount(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCallerSession) OptionVoteCount(arg0 *big.Int, arg1 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.OptionVoteCount(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) Owner() (common.Address, error) {
	return _VoteVerifier.Contract.Owner(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) Owner() (common.Address, error) {
	return _VoteVerifier.Contract.Owner(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) Paused(opts *bind.CallOpts) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "paused")

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) Paused() (bool, error) {
	return _VoteVerifier.Contract.Paused(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) Paused() (bool, error) {
	return _VoteVerifier.Contract.Paused(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) PollRegistry(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "pollRegistry")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) PollRegistry() (common.Address, error) {
	return _VoteVerifier.Contract.PollRegistry(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) PollRegistry() (common.Address, error) {
	return _VoteVerifier.Contract.PollRegistry(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) PollVoteCount(opts *bind.CallOpts, arg0 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "pollVoteCount", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) PollVoteCount(arg0 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.PollVoteCount(&_VoteVerifier.CallOpts, arg0)
}

func (_VoteVerifier *VoteVerifierCallerSession) PollVoteCount(arg0 *big.Int) (*big.Int, error) {
	return _VoteVerifier.Contract.PollVoteCount(&_VoteVerifier.CallOpts, arg0)
}

func (_VoteVerifier *VoteVerifierCaller) TotalVotes(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "totalVotes")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) TotalVotes() (*big.Int, error) {
	return _VoteVerifier.Contract.TotalVotes(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) TotalVotes() (*big.Int, error) {
	return _VoteVerifier.Contract.TotalVotes(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) UsedAnonymousIds(opts *bind.CallOpts, arg0 *big.Int, arg1 [32]byte) (bool, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "usedAnonymousIds", arg0, arg1)

	if err != nil {
		return *new(bool), err
	}

	out0 := *abi.ConvertType(out[0], new(bool)).(*bool)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) UsedAnonymousIds(arg0 *big.Int, arg1 [32]byte) (bool, error) {
	return _VoteVerifier.Contract.UsedAnonymousIds(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCallerSession) UsedAnonymousIds(arg0 *big.Int, arg1 [32]byte) (bool, error) {
	return _VoteVerifier.Contract.UsedAnonymousIds(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) Version() (string, error) {
	return _VoteVerifier.Contract.Version(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCallerSession) Version() (string, error) {
	return _VoteVerifier.Contract.Version(&_VoteVerifier.CallOpts)
}

func (_VoteVerifier *VoteVerifierCaller) VoterChoice(opts *bind.CallOpts, arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "voterChoice", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

func (_VoteVerifier *VoteVerifierSession) VoterChoice(arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.VoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCallerSession) VoterChoice(arg0 *big.Int, arg1 common.Address) (*big.Int, error) {
	return _VoteVerifier.Contract.VoterChoice(&_VoteVerifier.CallOpts, arg0, arg1)
}

func (_VoteVerifier *VoteVerifierCaller) VotesByHash(opts *bind.CallOpts, arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	var out []interface{}
	err := _VoteVerifier.contract.Call(opts, &out, "votesByHash", arg0)

	outstruct := new(struct {
		PollId      *big.Int
		OptionId    *big.Int
		Voter       common.Address
		AnonymousId [32]byte
		Timestamp   *big.Int
		VoteHash    [32]byte
		IsAnonymous bool
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.PollId = *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)
	outstruct.OptionId = *abi.ConvertType(out[1], new(*big.Int)).(**big.Int)
	outstruct.Voter = *abi.ConvertType(out[2], new(common.Address)).(*common.Address)
	outstruct.AnonymousId = *abi.ConvertType(out[3], new([32]byte)).(*[32]byte)
	outstruct.Timestamp = *abi.ConvertType(out[4], new(*big.Int)).(**big.Int)
	outstruct.VoteHash = *abi.ConvertType(out[5], new([32]byte)).(*[32]byte)
	outstruct.IsAnonymous = *abi.ConvertType(out[6], new(bool)).(*bool)

	return *outstruct, err

}

func (_VoteVerifier *VoteVerifierSession) VotesByHash(arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	return _VoteVerifier.Contract.VotesByHash(&_VoteVerifier.CallOpts, arg0)
}

func (_VoteVerifier *VoteVerifierCallerSession) VotesByHash(arg0 [32]byte) (struct {
	PollId      *big.Int
	OptionId    *big.Int
	Voter       common.Address
	AnonymousId [32]byte
	Timestamp   *big.Int
	VoteHash    [32]byte
	IsAnonymous bool
}, error) {
	return _VoteVerifier.Contract.VotesByHash(&_VoteVerifier.CallOpts, arg0)
}

func (_VoteVerifier *VoteVerifierTransactor) Pause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "pause")
}

func (_VoteVerifier *VoteVerifierSession) Pause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Pause(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactorSession) Pause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Pause(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactor) RecordAnonymousVote(opts *bind.TransactOpts, _pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "recordAnonymousVote", _pollId, _optionId, _anonymousId, _optionsHash)
}

func (_VoteVerifier *VoteVerifierSession) RecordAnonymousVote(_pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordAnonymousVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _anonymousId, _optionsHash)
}

func (_VoteVerifier *VoteVerifierTransactorSession) RecordAnonymousVote(_pollId *big.Int, _optionId *big.Int, _anonymousId [32]byte, _optionsHash [32]byte) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordAnonymousVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _anonymousId, _optionsHash)
}

func (_VoteVerifier *VoteVerifierTransactor) RecordVote(opts *bind.TransactOpts, _pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "recordVote", _pollId, _optionId, _optionsHash, _voter)
}

func (_VoteVerifier *VoteVerifierSession) RecordVote(_pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _optionsHash, _voter)
}

func (_VoteVerifier *VoteVerifierTransactorSession) RecordVote(_pollId *big.Int, _optionId *big.Int, _optionsHash [32]byte, _voter common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.RecordVote(&_VoteVerifier.TransactOpts, _pollId, _optionId, _optionsHash, _voter)
}

func (_VoteVerifier *VoteVerifierTransactor) RenounceOwnership(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "renounceOwnership")
}

func (_VoteVerifier *VoteVerifierSession) RenounceOwnership() (*types.Transaction, error) {
	return _VoteVerifier.Contract.RenounceOwnership(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactorSession) RenounceOwnership() (*types.Transaction, error) {
	return _VoteVerifier.Contract.RenounceOwnership(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactor) TransferOwnership(opts *bind.TransactOpts, newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "transferOwnership", newOwner)
}

func (_VoteVerifier *VoteVerifierSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.TransferOwnership(&_VoteVerifier.TransactOpts, newOwner)
}

func (_VoteVerifier *VoteVerifierTransactorSession) TransferOwnership(newOwner common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.TransferOwnership(&_VoteVerifier.TransactOpts, newOwner)
}

func (_VoteVerifier *VoteVerifierTransactor) Unpause(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "unpause")
}

func (_VoteVerifier *VoteVerifierSession) Unpause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Unpause(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactorSession) Unpause() (*types.Transaction, error) {
	return _VoteVerifier.Contract.Unpause(&_VoteVerifier.TransactOpts)
}

func (_VoteVerifier *VoteVerifierTransactor) UpdateAuthorizedService(opts *bind.TransactOpts, _newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "updateAuthorizedService", _newAuthorizedService)
}

func (_VoteVerifier *VoteVerifierSession) UpdateAuthorizedService(_newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdateAuthorizedService(&_VoteVerifier.TransactOpts, _newAuthorizedService)
}

func (_VoteVerifier *VoteVerifierTransactorSession) UpdateAuthorizedService(_newAuthorizedService common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdateAuthorizedService(&_VoteVerifier.TransactOpts, _newAuthorizedService)
}

func (_VoteVerifier *VoteVerifierTransactor) UpdatePollRegistry(opts *bind.TransactOpts, _newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.contract.Transact(opts, "updatePollRegistry", _newPollRegistry)
}

func (_VoteVerifier *VoteVerifierSession) UpdatePollRegistry(_newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdatePollRegistry(&_VoteVerifier.TransactOpts, _newPollRegistry)
}

func (_VoteVerifier *VoteVerifierTransactorSession) UpdatePollRegistry(_newPollRegistry common.Address) (*types.Transaction, error) {
	return _VoteVerifier.Contract.UpdatePollRegistry(&_VoteVerifier.TransactOpts, _newPollRegistry)
}

type VoteVerifierAnonymousVoteRecordedIterator struct {
	Event *VoteVerifierAnonymousVoteRecorded

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierAnonymousVoteRecordedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierAnonymousVoteRecorded)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierAnonymousVoteRecorded)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierAnonymousVoteRecordedIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierAnonymousVoteRecordedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierAnonymousVoteRecorded struct {
	PollId      *big.Int
	AnonymousId [32]byte
	OptionId    *big.Int
	VoteHash    [32]byte
	Timestamp   *big.Int
	Raw         types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterAnonymousVoteRecorded(opts *bind.FilterOpts, pollId []*big.Int, anonymousId [][32]byte, optionId []*big.Int) (*VoteVerifierAnonymousVoteRecordedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var anonymousIdRule []interface{}
	for _, anonymousIdItem := range anonymousId {
		anonymousIdRule = append(anonymousIdRule, anonymousIdItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "AnonymousVoteRecorded", pollIdRule, anonymousIdRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierAnonymousVoteRecordedIterator{contract: _VoteVerifier.contract, event: "AnonymousVoteRecorded", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchAnonymousVoteRecorded(opts *bind.WatchOpts, sink chan<- *VoteVerifierAnonymousVoteRecorded, pollId []*big.Int, anonymousId [][32]byte, optionId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var anonymousIdRule []interface{}
	for _, anonymousIdItem := range anonymousId {
		anonymousIdRule = append(anonymousIdRule, anonymousIdItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "AnonymousVoteRecorded", pollIdRule, anonymousIdRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierAnonymousVoteRecorded)
				if err := _VoteVerifier.contract.UnpackLog(event, "AnonymousVoteRecorded", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParseAnonymousVoteRecorded(log types.Log) (*VoteVerifierAnonymousVoteRecorded, error) {
	event := new(VoteVerifierAnonymousVoteRecorded)
	if err := _VoteVerifier.contract.UnpackLog(event, "AnonymousVoteRecorded", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type VoteVerifierAuthorizedServiceUpdatedIterator struct {
	Event *VoteVerifierAuthorizedServiceUpdated

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierAuthorizedServiceUpdated)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierAuthorizedServiceUpdated)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierAuthorizedServiceUpdatedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierAuthorizedServiceUpdated struct {
	OldService common.Address
	NewService common.Address
	Raw        types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterAuthorizedServiceUpdated(opts *bind.FilterOpts) (*VoteVerifierAuthorizedServiceUpdatedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "AuthorizedServiceUpdated")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierAuthorizedServiceUpdatedIterator{contract: _VoteVerifier.contract, event: "AuthorizedServiceUpdated", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchAuthorizedServiceUpdated(opts *bind.WatchOpts, sink chan<- *VoteVerifierAuthorizedServiceUpdated) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "AuthorizedServiceUpdated")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierAuthorizedServiceUpdated)
				if err := _VoteVerifier.contract.UnpackLog(event, "AuthorizedServiceUpdated", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParseAuthorizedServiceUpdated(log types.Log) (*VoteVerifierAuthorizedServiceUpdated, error) {
	event := new(VoteVerifierAuthorizedServiceUpdated)
	if err := _VoteVerifier.contract.UnpackLog(event, "AuthorizedServiceUpdated", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type VoteVerifierOwnershipTransferredIterator struct {
	Event *VoteVerifierOwnershipTransferred

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierOwnershipTransferredIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierOwnershipTransferred)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierOwnershipTransferred)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierOwnershipTransferredIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierOwnershipTransferredIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierOwnershipTransferred struct {
	PreviousOwner common.Address
	NewOwner      common.Address
	Raw           types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterOwnershipTransferred(opts *bind.FilterOpts, previousOwner []common.Address, newOwner []common.Address) (*VoteVerifierOwnershipTransferredIterator, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierOwnershipTransferredIterator{contract: _VoteVerifier.contract, event: "OwnershipTransferred", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchOwnershipTransferred(opts *bind.WatchOpts, sink chan<- *VoteVerifierOwnershipTransferred, previousOwner []common.Address, newOwner []common.Address) (event.Subscription, error) {

	var previousOwnerRule []interface{}
	for _, previousOwnerItem := range previousOwner {
		previousOwnerRule = append(previousOwnerRule, previousOwnerItem)
	}
	var newOwnerRule []interface{}
	for _, newOwnerItem := range newOwner {
		newOwnerRule = append(newOwnerRule, newOwnerItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "OwnershipTransferred", previousOwnerRule, newOwnerRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierOwnershipTransferred)
				if err := _VoteVerifier.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParseOwnershipTransferred(log types.Log) (*VoteVerifierOwnershipTransferred, error) {
	event := new(VoteVerifierOwnershipTransferred)
	if err := _VoteVerifier.contract.UnpackLog(event, "OwnershipTransferred", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type VoteVerifierPausedIterator struct {
	Event *VoteVerifierPaused

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierPausedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierPaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierPaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierPausedIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierPausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierPaused struct {
	Account common.Address
	Raw     types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterPaused(opts *bind.FilterOpts) (*VoteVerifierPausedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierPausedIterator{contract: _VoteVerifier.contract, event: "Paused", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchPaused(opts *bind.WatchOpts, sink chan<- *VoteVerifierPaused) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "Paused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierPaused)
				if err := _VoteVerifier.contract.UnpackLog(event, "Paused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParsePaused(log types.Log) (*VoteVerifierPaused, error) {
	event := new(VoteVerifierPaused)
	if err := _VoteVerifier.contract.UnpackLog(event, "Paused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type VoteVerifierUnpausedIterator struct {
	Event *VoteVerifierUnpaused

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierUnpausedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierUnpaused)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierUnpaused)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierUnpausedIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierUnpausedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierUnpaused struct {
	Account common.Address
	Raw     types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterUnpaused(opts *bind.FilterOpts) (*VoteVerifierUnpausedIterator, error) {

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return &VoteVerifierUnpausedIterator{contract: _VoteVerifier.contract, event: "Unpaused", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchUnpaused(opts *bind.WatchOpts, sink chan<- *VoteVerifierUnpaused) (event.Subscription, error) {

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "Unpaused")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierUnpaused)
				if err := _VoteVerifier.contract.UnpackLog(event, "Unpaused", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParseUnpaused(log types.Log) (*VoteVerifierUnpaused, error) {
	event := new(VoteVerifierUnpaused)
	if err := _VoteVerifier.contract.UnpackLog(event, "Unpaused", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

type VoteVerifierVoteRecordedIterator struct {
	Event *VoteVerifierVoteRecorded

	contract *bind.BoundContract
	event    string

	logs chan types.Log
	sub  ethereum.Subscription
	done bool
	fail error
}

func (it *VoteVerifierVoteRecordedIterator) Next() bool {

	if it.fail != nil {
		return false
	}

	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(VoteVerifierVoteRecorded)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}

	select {
	case log := <-it.logs:
		it.Event = new(VoteVerifierVoteRecorded)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

func (it *VoteVerifierVoteRecordedIterator) Error() error {
	return it.fail
}

func (it *VoteVerifierVoteRecordedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

type VoteVerifierVoteRecorded struct {
	PollId    *big.Int
	Voter     common.Address
	OptionId  *big.Int
	VoteHash  [32]byte
	Timestamp *big.Int
	Raw       types.Log
}

func (_VoteVerifier *VoteVerifierFilterer) FilterVoteRecorded(opts *bind.FilterOpts, pollId []*big.Int, voter []common.Address, optionId []*big.Int) (*VoteVerifierVoteRecordedIterator, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var voterRule []interface{}
	for _, voterItem := range voter {
		voterRule = append(voterRule, voterItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.FilterLogs(opts, "VoteRecorded", pollIdRule, voterRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return &VoteVerifierVoteRecordedIterator{contract: _VoteVerifier.contract, event: "VoteRecorded", logs: logs, sub: sub}, nil
}

func (_VoteVerifier *VoteVerifierFilterer) WatchVoteRecorded(opts *bind.WatchOpts, sink chan<- *VoteVerifierVoteRecorded, pollId []*big.Int, voter []common.Address, optionId []*big.Int) (event.Subscription, error) {

	var pollIdRule []interface{}
	for _, pollIdItem := range pollId {
		pollIdRule = append(pollIdRule, pollIdItem)
	}
	var voterRule []interface{}
	for _, voterItem := range voter {
		voterRule = append(voterRule, voterItem)
	}
	var optionIdRule []interface{}
	for _, optionIdItem := range optionId {
		optionIdRule = append(optionIdRule, optionIdItem)
	}

	logs, sub, err := _VoteVerifier.contract.WatchLogs(opts, "VoteRecorded", pollIdRule, voterRule, optionIdRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:

				event := new(VoteVerifierVoteRecorded)
				if err := _VoteVerifier.contract.UnpackLog(event, "VoteRecorded", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

func (_VoteVerifier *VoteVerifierFilterer) ParseVoteRecorded(log types.Log) (*VoteVerifierVoteRecorded, error) {
	event := new(VoteVerifierVoteRecorded)
	if err := _VoteVerifier.contract.UnpackLog(event, "VoteRecorded", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
