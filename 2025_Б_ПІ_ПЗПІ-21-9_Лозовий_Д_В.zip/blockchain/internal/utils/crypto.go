package utils

import (
	"context"
	"crypto/ecdsa"
	"encoding/hex"
	"fmt"
	"math/big"
	"regexp"
	"strings"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

const AnonymousIDKey = "anonymous_id"

func WithAnonymousID(ctx context.Context, anonymousID string) context.Context {
	return context.WithValue(ctx, AnonymousIDKey, anonymousID)
}

func GetAnonymousID(ctx context.Context) string {
	if anonymousID, ok := ctx.Value(AnonymousIDKey).(string); ok {
		return anonymousID
	}
	return ""
}

func PublicKeyToAddress(publicKeyHex string) (common.Address, error) {
	publicKeyHex = strings.TrimPrefix(publicKeyHex, "0x")

	if len(publicKeyHex) != 128 && len(publicKeyHex) != 130 {
		return common.Address{}, fmt.Errorf("invalid public key length: expected 128 or 130 characters, got %d", len(publicKeyHex))
	}
	if len(publicKeyHex) == 130 && publicKeyHex[:2] == "04" {
		publicKeyHex = publicKeyHex[2:]
	}

	publicKeyBytes, err := hex.DecodeString(publicKeyHex)
	if err != nil {
		return common.Address{}, fmt.Errorf("failed to decode public key hex: %w", err)
	}
	if len(publicKeyBytes) != 64 {
		return common.Address{}, fmt.Errorf("invalid public key bytes length: expected 64, got %d", len(publicKeyBytes))
	}

	pubKey := &ecdsa.PublicKey{
		Curve: crypto.S256(),
	}

	pubKey.X = new(big.Int).SetBytes(publicKeyBytes[:32])
	pubKey.Y = new(big.Int).SetBytes(publicKeyBytes[32:])

	if !pubKey.Curve.IsOnCurve(pubKey.X, pubKey.Y) {
		return common.Address{}, fmt.Errorf("public key point is not on the secp256k1 curve")
	}

	address := crypto.PubkeyToAddress(*pubKey)

	return address, nil
}

func ValidateEthereumAddress(addr string) bool {

	ethereumAddressRegex := regexp.MustCompile("^0x[0-9a-fA-F]{40}$")
	if !ethereumAddressRegex.MatchString(addr) {
		return false
	}

	return common.IsHexAddress(addr)
}

func ValidateTransactionHash(hash string) bool {

	txHashRegex := regexp.MustCompile("^0x[0-9a-fA-F]{64}$")
	return txHashRegex.MatchString(hash)
}

func NormalizeEthereumAddress(addr string) (common.Address, error) {
	if !ValidateEthereumAddress(addr) {
		return common.Address{}, fmt.Errorf("invalid ethereum address format: %s", addr)
	}

	return common.HexToAddress(addr), nil
}

func AddressToString(addr common.Address) string {
	return addr.Hex()
}

func ValidatePublicKey(publicKeyHex string) error {

	publicKeyHex = strings.TrimPrefix(publicKeyHex, "0x")

	if len(publicKeyHex) != 128 && len(publicKeyHex) != 130 {
		return fmt.Errorf("invalid public key length: expected 128 or 130 characters, got %d", len(publicKeyHex))
	}

	if len(publicKeyHex) == 130 && publicKeyHex[:2] == "04" {
		publicKeyHex = publicKeyHex[2:]
	}

	hexRegex := regexp.MustCompile("^[0-9a-fA-F]+$")
	if !hexRegex.MatchString(publicKeyHex) {
		return fmt.Errorf("public key contains non-hex characters")
	}

	publicKeyBytes, err := hex.DecodeString(publicKeyHex)
	if err != nil {
		return fmt.Errorf("failed to decode public key hex: %w", err)
	}

	if len(publicKeyBytes) != 64 {
		return fmt.Errorf("invalid public key bytes length: expected 64, got %d", len(publicKeyBytes))
	}

	pubKey := &ecdsa.PublicKey{
		Curve: crypto.S256(),
	}

	pubKey.X = new(big.Int).SetBytes(publicKeyBytes[:32])
	pubKey.Y = new(big.Int).SetBytes(publicKeyBytes[32:])

	if !pubKey.Curve.IsOnCurve(pubKey.X, pubKey.Y) {
		return fmt.Errorf("public key point is not on the secp256k1 curve")
	}

	return nil
}

func CompareAddresses(addr1, addr2 string) bool {

	normalizedAddr1, err1 := NormalizeEthereumAddress(addr1)
	normalizedAddr2, err2 := NormalizeEthereumAddress(addr2)

	if err1 != nil || err2 != nil {
		return false
	}

	return normalizedAddr1 == normalizedAddr2
}

func IsZeroAddress(addr common.Address) bool {
	return addr == common.HexToAddress("0x0000000000000000000000000000000000000000")
}

func GenerateRandomAddress() common.Address {
	privateKey, err := crypto.GenerateKey()
	if err != nil {

		return common.HexToAddress("0x1234567890123456789012345678901234567890")
	}

	return crypto.PubkeyToAddress(privateKey.PublicKey)
}

func ExtractPublicKeyFromPrivateKey(privateKeyHex string) (string, error) {

	privateKeyHex = strings.TrimPrefix(privateKeyHex, "0x")

	privateKeyBytes, err := hex.DecodeString(privateKeyHex)
	if err != nil {
		return "", fmt.Errorf("failed to decode private key: %w", err)
	}

	privateKey, err := crypto.ToECDSA(privateKeyBytes)
	if err != nil {
		return "", fmt.Errorf("failed to create ECDSA private key: %w", err)
	}

	publicKey := privateKey.PublicKey

	publicKeyBytes := crypto.FromECDSAPub(&publicKey)
	if len(publicKeyBytes) == 65 && publicKeyBytes[0] == 0x04 {

		publicKeyBytes = publicKeyBytes[1:]
	}

	return hex.EncodeToString(publicKeyBytes), nil
}
