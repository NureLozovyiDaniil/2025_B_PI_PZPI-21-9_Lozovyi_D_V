package service

import (
	"context"
	"crypto/sha256"
	"fmt"
	"go.uber.org/zap"
	"time"

	"github.com/ethereum/go-ethereum/common"

	"blockchain-service/internal/client"
	"blockchain-service/internal/config"
	"blockchain-service/internal/contracts"
	"blockchain-service/internal/utils"
	"blockchain-service/internal/web3"
)

type BlockchainService struct {
	web3Client     *web3.Web3Client
	identityClient *client.IdentityClient
	pollRegistry   *contracts.PollRegistryManager
	voteVerifier   *contracts.VoteVerifierManager
	resultStorage  *contracts.ResultStorageManager
	cfg            *config.BlockchainConfig
}

type RegisterPollRequest struct {
	PollID      uint      `json:"poll_id" binding:"required,min=1"`
	Title       string    `json:"title" binding:"required,max=255"`
	Description string    `json:"description" binding:"max=2000"`
	Category    string    `json:"category" binding:"required,max=100"`
	CreatorID   uint      `json:"creator_id" binding:"required,min=1"`
	StartTime   time.Time `json:"start_time" binding:"required"`
	EndTime     time.Time `json:"end_time" binding:"required,gtfield=StartTime"`
	IsPrivate   bool      `json:"is_private"`
	OptionsHash string    `json:"options_hash" binding:"required,len=64"`
}

type RecordVoteRequest struct {
	PollID      uint    `json:"poll_id" binding:"required,min=1"`
	OptionID    uint    `json:"option_id" binding:"required,min=1"`
	UserID      uint    `json:"user_id" binding:"required,min=1"`
	AnonymousID *string `json:"anonymous_id,omitempty"`
	OptionsHash string  `json:"options_hash" binding:"required,len=64"`
}

type StoreResultsRequest struct {
	PollID       uint   `json:"poll_id" binding:"required,min=1"`
	OptionCounts []uint `json:"option_counts" binding:"required,min=1,max=20"`
}

type TransactionResponse struct {
	TxHash      string  `json:"tx_hash"`
	Status      string  `json:"status"`
	BlockNumber *uint64 `json:"block_number,omitempty"`
	GasUsed     *uint64 `json:"gas_used,omitempty"`
	Error       *string `json:"error,omitempty"`
}

type GetResultsResponse struct {
	PollID       uint   `json:"poll_id"`
	TotalVotes   uint64 `json:"total_votes"`
	WinnerOption uint64 `json:"winner_option"`
	OptionCounts []uint `json:"option_counts"`
	IsFinalized  bool   `json:"is_finalized"`
	ResultsHash  string `json:"results_hash"`
	PublishedBy  string `json:"published_by"`
	PublishedAt  int64  `json:"published_at"`
}

func NewBlockchainService(
	web3Client *web3.Web3Client,
	identityClient *client.IdentityClient,
	cfg *config.BlockchainConfig,
) (*BlockchainService, error) {

	if !cfg.HasContractAddresses() {
		return nil, fmt.Errorf("contract addresses not configured")
	}

	pollRegistry, err := contracts.NewPollRegistryManager(web3Client, cfg.PollRegistryAddress)
	if err != nil {
		return nil, fmt.Errorf("failed to create PollRegistry manager: %w", err)
	}

	voteVerifier, err := contracts.NewVoteVerifierManager(web3Client, cfg.VoteVerifierAddress)
	if err != nil {
		return nil, fmt.Errorf("failed to create VoteVerifier manager: %w", err)
	}

	resultStorage, err := contracts.NewResultStorageManager(web3Client, cfg.ResultStorageAddress)
	if err != nil {
		return nil, fmt.Errorf("failed to create ResultStorage manager: %w", err)
	}

	return &BlockchainService{
		web3Client:     web3Client,
		identityClient: identityClient,
		pollRegistry:   pollRegistry,
		voteVerifier:   voteVerifier,
		resultStorage:  resultStorage,
		cfg:            cfg,
	}, nil
}

func (s *BlockchainService) RegisterPollOnBlockchain(ctx context.Context, req RegisterPollRequest) (*TransactionResponse, error) {
	ctx = utils.WithPollID(ctx, req.PollID)

	publicKey, err := s.identityClient.GetUserPublicKey(ctx, req.CreatorID)
	if err != nil {
		return nil, fmt.Errorf("failed to get creator public key: %w", err)
	}

	creatorAddress, err := utils.PublicKeyToAddress(publicKey)
	if err != nil {
		return nil, fmt.Errorf("failed to convert public key to address: %w", err)
	}

	pollReq := contracts.RegisterPollRequest{
		PollID:      req.PollID,
		Title:       req.Title,
		Category:    req.Category,
		OptionsHash: req.OptionsHash,
		CreatorID:   req.CreatorID,
		StartTime:   req.StartTime,
		EndTime:     req.EndTime,
		IsPrivate:   req.IsPrivate,
	}

	var txHash string
	var lastErr error

	for attempt := 1; attempt <= s.cfg.RetryAttempts; attempt++ {
		txHash, lastErr = s.pollRegistry.RegisterPoll(ctx, pollReq, creatorAddress)
		if lastErr == nil {
			break
		}

		if attempt < s.cfg.RetryAttempts {
			utils.Warn(ctx, "Poll registration failed, retrying",
				zap.Int("attempt", attempt),
				zap.Error(lastErr),
			)

			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(s.cfg.RetryDelay):

			}
		}
	}

	if lastErr != nil {
		utils.Error(ctx, "Poll registration failed after all attempts",
			lastErr,
			zap.Int("attempts", s.cfg.RetryAttempts),
		)
		errStr := lastErr.Error()
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, lastErr
	}

	utils.LogTransactionSent(ctx, txHash, "register_poll", s.cfg.GasLimit, s.cfg.GasPrice)

	return &TransactionResponse{
		TxHash: txHash,
		Status: "confirmed",
	}, nil
}

func (s *BlockchainService) GetPollById(ctx context.Context, pollId uint) (*contracts.PollMetadata, error) {
	ctx = utils.WithPollID(ctx, pollId)
	poll, err := s.pollRegistry.GetPoll(ctx, pollId)
	if err != nil {
		return nil, err
	}

	return poll, nil
}

func (s *BlockchainService) RecordVoteOnBlockchain(ctx context.Context, req RecordVoteRequest) (*TransactionResponse, error) {
	ctx = utils.WithPollID(ctx, req.PollID)
	ctx = utils.WithUserID(ctx, req.UserID)

	publicKey, err := s.identityClient.GetUserPublicKey(ctx, req.UserID)
	if err != nil {
		return nil, fmt.Errorf("failed to get user public key: %w", err)
	}

	voterAddress, err := utils.PublicKeyToAddress(publicKey)
	if err != nil {
		return nil, fmt.Errorf("failed to convert public key to address: %w", err)
	}

	hasVoted, err := s.voteVerifier.HasUserVoted(ctx, req.PollID, voterAddress)
	if err != nil {
		return nil, fmt.Errorf("failed to check if user voted: %w", err)
	}

	if hasVoted {
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  stringPtr("user already voted in this poll"),
		}, fmt.Errorf("user %d already voted in poll %d", req.UserID, req.PollID)
	}

	voteReq := contracts.RecordVoteRequest{
		PollID:      req.PollID,
		OptionID:    req.OptionID,
		VoterAddr:   voterAddress,
		OptionsHash: req.OptionsHash,
	}

	var txHash string
	var lastErr error

	for attempt := 1; attempt <= s.cfg.RetryAttempts; attempt++ {
		txHash, lastErr = s.voteVerifier.RecordVote(ctx, voteReq)
		if lastErr == nil {
			break
		}

		if attempt < s.cfg.RetryAttempts {

			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(s.cfg.RetryDelay):

			}
		}
	}

	if lastErr != nil {

		errStr := lastErr.Error()
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, lastErr
	}

	utils.LogTransactionSent(ctx, txHash, "record_vote", s.cfg.GasLimit, s.cfg.GasPrice)

	utils.LogVoteOperation(ctx, req.PollID, req.UserID, "record_vote", map[string]interface{}{
		"tx_hash":       txHash,
		"option_id":     req.OptionID,
		"voter_address": voterAddress.Hex(),
	})

	return &TransactionResponse{
		TxHash: txHash,
		Status: "confirmed",
	}, nil
}

func (s *BlockchainService) RecordAnonymousVoteOnBlockchain(
	ctx context.Context,
	req RecordVoteRequest,
) (*TransactionResponse, error) {
	ctx = utils.WithPollID(ctx, req.PollID)

	if req.AnonymousID == nil || *req.AnonymousID == "" {
		return nil, fmt.Errorf("anonymous ID is required for anonymous voting")
	}

	if req.UserID != 0 {
		return nil, fmt.Errorf("user ID must not be specified for anonymous voting")
	}

	ctx = utils.WithAnonymousID(ctx, *req.AnonymousID)

	utils.Info(ctx, "Starting anonymous vote recording on blockchain",
		zap.Uint("PollID", req.PollID),
		zap.Uint("option_id", req.OptionID),
		zap.String("anonymous_id", *req.AnonymousID),
	)

	anonymousIDBytes := common.HexToHash(*req.AnonymousID)

	hasVoted, err := s.voteVerifier.HasAnonymousIdVoted(ctx, req.PollID, anonymousIDBytes)
	if err != nil {
		return nil, fmt.Errorf("failed to check if anonymous ID voted: %w", err)
	}

	if hasVoted {
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  stringPtr("anonymous ID already used in this poll"),
		}, fmt.Errorf("anonymous ID %s already voted in poll %d", *req.AnonymousID, req.PollID)
	}

	voteReq := contracts.RecordAnonymousVoteRequest{
		PollID:      req.PollID,
		OptionID:    req.OptionID,
		AnonymousID: anonymousIDBytes,
		OptionsHash: req.OptionsHash,
	}

	var txHash string
	var lastErr error

	for attempt := 1; attempt <= s.cfg.RetryAttempts; attempt++ {
		txHash, lastErr = s.voteVerifier.RecordAnonymousVote(ctx, voteReq)
		if lastErr == nil {
			break
		}

		if attempt < s.cfg.RetryAttempts {
			utils.Warn(ctx, "Anonymous vote recording failed, retrying",
				zap.Int("attempt", attempt),
				zap.Error(lastErr))

			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(s.cfg.RetryDelay):

			}
		}
	}

	if lastErr != nil {
		utils.Error(ctx, "Anonymous vote recording failed after all attempts", lastErr,
			zap.Int("attempts", s.cfg.RetryAttempts))
		errStr := lastErr.Error()
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, lastErr
	}

	utils.LogTransactionSent(ctx, txHash, "record_anonymous_vote", s.cfg.GasLimit, s.cfg.GasPrice)

	utils.LogVoteOperation(ctx, req.PollID, 0, "record_anonymous_vote", map[string]interface{}{
		"tx_hash":      txHash,
		"option_id":    req.OptionID,
		"anonymous_id": *req.AnonymousID,
	})

	return &TransactionResponse{
		TxHash: txHash,
		Status: "confirmed",
	}, nil
}

func (s *BlockchainService) GetTransactionStatus(ctx context.Context, txHash string) (*TransactionResponse, error) {

	if !utils.ValidateTransactionHash(txHash) {
		return nil, fmt.Errorf("invalid transaction hash format")
	}

	hash := common.HexToHash(txHash)

	receipt, err := s.web3Client.WaitForTransaction(ctx, hash)
	if err != nil {
		return &TransactionResponse{
			TxHash: txHash,
			Status: "failed",
			Error:  stringPtr(err.Error()),
		}, nil
	}

	response := &TransactionResponse{
		TxHash:      txHash,
		BlockNumber: &receipt.BlockNumber,
		GasUsed:     &receipt.GasUsed,
	}

	if receipt.Status == 1 {
		response.Status = "confirmed"
		utils.LogTransactionConfirmed(ctx, txHash, receipt.BlockNumber, receipt.GasUsed)
	} else {
		response.Status = "failed"
		response.Error = &receipt.Error
		utils.LogTransactionFailed(ctx, txHash, "unknown", fmt.Errorf(receipt.Error), 1)
	}

	return response, nil
}

func (s *BlockchainService) StoreResultsOnBlockchain(ctx context.Context, req StoreResultsRequest) (*TransactionResponse, error) {
	ctx = utils.WithPollID(ctx, req.PollID)

	poll, err := s.pollRegistry.GetPoll(ctx, req.PollID)
	if err != nil {
		errStr := fmt.Sprintf("failed to get poll metadata: %v", err)
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, err
	}

	if poll.Status == contracts.PollStatusActive {
		utils.Info(ctx, "Updating poll status to ended before storing results")

		_, err = s.pollRegistry.UpdatePollStatus(ctx, req.PollID, contracts.PollStatusEnded)
		if err != nil {
			errStr := fmt.Sprintf("failed to update poll status: %v", err)
			return &TransactionResponse{
				TxHash: "",
				Status: "failed",
				Error:  &errStr,
			}, err
		}

		time.Sleep(3 * time.Second)
	}

	currentTime := time.Now().Unix()
	if poll.EndTime.Int64() > currentTime {
		errStr := fmt.Sprintf("poll %d is still active, ends at %s",
			req.PollID, time.Unix(poll.EndTime.Int64(), 0).Format(time.RFC3339))
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, fmt.Errorf("poll is still active")
	}

	storeReq := contracts.StoreResultsRequest{
		PollID:       req.PollID,
		OptionCounts: req.OptionCounts,
	}

	var txHash string
	var lastErr error

	for attempt := 1; attempt <= s.cfg.RetryAttempts; attempt++ {
		txHash, lastErr = s.resultStorage.StoreResults(ctx, storeReq)
		if lastErr == nil {
			break
		}

		if attempt < s.cfg.RetryAttempts {

			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(s.cfg.RetryDelay):

			}
		}
	}

	if lastErr != nil {

		errStr := lastErr.Error()
		return &TransactionResponse{
			TxHash: "",
			Status: "failed",
			Error:  &errStr,
		}, lastErr
	}

	utils.LogTransactionSent(ctx, txHash, "store_results", s.cfg.GasLimit, s.cfg.GasPrice)

	return &TransactionResponse{
		TxHash: txHash,
		Status: "confirmed",
	}, nil
}

func (s *BlockchainService) GetPollResultsFromBlockchain(ctx context.Context, pollID uint) (*GetResultsResponse, error) {
	ctx = utils.WithPollID(ctx, pollID)

	hasResults, err := s.resultStorage.HasResults(ctx, pollID)
	if err != nil {
		return nil, fmt.Errorf("failed to check if results exist: %w", err)
	}

	if !hasResults {
		return nil, fmt.Errorf("results not found for poll %d", pollID)
	}

	result, err := s.resultStorage.GetResults(ctx, pollID)
	if err != nil {
		return nil, fmt.Errorf("failed to get results: %w", err)
	}

	optionCounts := make([]uint, len(result.OptionCounts))
	for i, count := range result.OptionCounts {
		optionCounts[i] = uint(count.Uint64())
	}

	response := &GetResultsResponse{
		PollID:       pollID,
		TotalVotes:   result.TotalVotes.Uint64(),
		WinnerOption: result.WinnerOption.Uint64(),
		OptionCounts: optionCounts,
		IsFinalized:  result.IsFinalized,
		ResultsHash:  contracts.ResultsHashToString(result.ResultsHash),
		PublishedBy:  result.PublishedBy.Hex(),
		PublishedAt:  result.PublishedAt.Int64(),
	}

	utils.LogPollOperation(ctx, pollID, "get_results_from_blockchain", map[string]interface{}{
		"total_votes":   response.TotalVotes,
		"winner_option": response.WinnerOption,
		"is_finalized":  response.IsFinalized,
	})

	return response, nil
}

func (s *BlockchainService) Health(ctx context.Context) map[string]interface{} {
	health := make(map[string]interface{})

	web3Health := s.web3Client.Health(ctx)
	health["web3"] = web3Health

	if identityHealth, err := s.identityClient.Health(ctx); err == nil {
		health["identity_service"] = map[string]interface{}{
			"status":   "healthy",
			"response": identityHealth,
		}
	} else {
		health["identity_service"] = map[string]interface{}{
			"status": "unhealthy",
			"error":  err.Error(),
		}
	}

	health["contracts"] = map[string]interface{}{
		"poll_registry":  s.pollRegistry.GetContractAddress().Hex(),
		"vote_verifier":  s.voteVerifier.GetContractAddress().Hex(),
		"result_storage": s.resultStorage.GetContractAddress().Hex(),
	}

	web3Connected := web3Health["connected"].(bool)
	identityHealthy := health["identity_service"].(map[string]interface{})["status"] == "healthy"

	health["overall_status"] = "healthy"
	if !web3Connected || !identityHealthy {
		health["overall_status"] = "unhealthy"
	}

	return health
}

func (s *BlockchainService) GenerateOptionsHash(options []string) string {
	hash := sha256.New()
	for _, option := range options {
		hash.Write([]byte(option))
	}
	return fmt.Sprintf("%x", hash.Sum(nil))
}

func stringPtr(s string) *string {
	return &s
}
